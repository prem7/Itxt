/*

package com.dci.unitTest;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.inet.pdfc.PDFComparer;
import com.inet.pdfc.config.ConfigurationFactory;
import com.inet.pdfc.config.IConfiguration;
import com.inet.pdfc.config.PDFCProperty;
import com.inet.pdfc.generator.PdfComparator;
import com.inet.pdfc.generator.model.DiffGroup;
import com.inet.pdfc.results.ResultModel;



@RunWith(Parameterized.class)
public class CompareTwoFoldersAsUnitTest {

	// the configuration containing various settings for i-net PDFC
	private static IConfiguration configuration;

	// the logger that is set and reseted during the JUnit test
	private static Logger logger = Logger.getRootLogger();

	// the appender for showing log output on a console with a simple layout
	private static ConsoleAppender consoleAppender = new ConsoleAppender( new SimpleLayout() );

	// the log level to be reseted after the test
	private static Level loglevel = logger.getLevel();

	// the PDF file, that should be compared with a reference file
	private File currentPdfFile = null;

	// the reference file to compare with
	private File referencePdfFile = null;

	// The root folder of the PDF files that should be compared.
	// It must be set with the -DcurrentFolder=... java option
	private static String SOURCE ="";      //= "C:\\reports\\Testing";

	// The root folder of the reference PDF files.
	// It must be set with the -DreferenceFolder=... java option
	private static String REFERENCE="";//  = "C:\\reports\\Final";

	// The root folder of the sources.
	private static String sourceRootDir;


	*/
/**
	 * This filter lists only PDF files.
	 *//*

	static final FileFilter  PDFFILEFILTER = new FileFilter() {
		public boolean accept( File f ) {
			return f.isFile() && f.getName().endsWith( ".pdf" );
		}
	};

	*/
/**
	 * This filter lists only directories.
	 *//*

	static final FileFilter  SUBDIRECTORYFILTER  = new FileFilter() {
		public boolean accept( File f ) {
			return f.isDirectory();
		}
	};

	*/
/**
	 * The constructor sets the current PDF file that should be compared with the specified reference PDF file.
	 * @param currentPdf the PDF file that should be compared
	 * @param referencePdf the reference PDF file
	 *//*

	public CompareTwoFoldersAsUnitTest(String currentPdf, String referencePdf) {
		currentPdfFile = new File( currentPdf );
		referencePdfFile = new File( referencePdf );
	}

	*/
/**
	 * Initialize the test by enabling console output to the logger and setting the log level to display some informations.
	 * These changes to the logger will be reseted.
	 * In addition the create PNG image settings of the PDFC configuration will be disabled.
	 * 
	 *//*

	@BeforeClass
	public static void init() {
		
		String[] ignoreText = new String[20];
		ignoreText[0]= "S";
		
		logger.addAppender( consoleAppender );
		logger.setLevel( Level.INFO );
		configuration = ConfigurationFactory.getConfiguration();
		*/
/*configuration.putObject( PDFCProperty.TOLERANCE_LINE_POSITION,4);
		configuration.putObject( PDFCProperty.CONTINUOUS_COMPARE,Boolean.TRUE  );*//*

		configuration.putObject( PDFCProperty.NORMALIZERS,",HEADER_FOOTER");
		configuration.putObject( PDFCProperty.FIXED_FOOTER_SIZE,85 ); 
		configuration.putObject( PDFCProperty.TOLERANCE_TEXT_LOCATION,-2);
		configuration.putObject( PDFCProperty.TOLERANCE_TEXT_SIZE,0.5);
		configuration.putObject( PDFCProperty.TOLERANCE_IMAGE_DISTANCE,2);
		configuration.putObject( PDFCProperty.TOLERANCE_LINE_SIZE,2);
		configuration.putObject( PDFCProperty.TEXT_ALIGN_RATIO,0.4);
		configuration.putObject( PDFCProperty.INVISIBLEELEMENTS_HIDE_ROTATION,Boolean.TRUE);
		configuration.putObject( PDFCProperty.TOLERANCE_IMAGE_SIZE,0.23);
		configuration.putObject( PDFCProperty.COMPARE_LINE_STYLES,Boolean.TRUE);
		configuration.putObject( PDFCProperty.MODULES,"MODULE_PAGEPROPERTIES,MODULE_TEXT_WORDORDER");
		configuration.putObject( PDFCProperty.FILTER_PATTERNS,"S� \n S \n 1 \n A� \n A \n S� \n NEW \n ! \n D");
	//	configuration.putObject( PDFCProperty.FILTER_PATTERNS,"S");
		configuration.putObject( PDFCProperty.CONTINUOUS_FILTERS,",REGEXP,HEADERFOOTER");
		configuration.putObject( PDFCProperty.TOLERANCE_IMAGE_PIXEL_VALUE,0.23);
		configuration.putObject( PDFCProperty.FIXED_HEADER_SIZE,76);
		configuration.putObject( PDFCProperty.USE_PIXEL_MEDIUM_VALUE,Boolean.TRUE);
		configuration.putObject( PDFCProperty.CONTINUOUS_COMPARE_TYPES,",TEXT");
		configuration.putObject( PDFCProperty.TOLERANCE_LINE_THICKNESS,0);
	
		
*/
/*		configuration.putObject( PDFCProperty.FILTER_PATTERNS,"A�");
		configuration.putObject( PDFCProperty.FILTER_PATTERNS,"S�");
		configuration.putObject( PDFCProperty.FILTER_PATTERNS,"RPO RPO|text|active");*//*

	
	}

	*/
/**
	 * Resets the changes to the logger after this test has run.
	 *//*

	@AfterClass
	public static void shutdown() {
		logger.removeAppender( consoleAppender );
		logger.setLevel( loglevel );
	}

	*/
/**
	 * Creates a collection that contains a mapping for all PDF files in the source folder with their
	 * corresponding reference PDF files.
	 * This test will be executed for each entry in this collection.
	 * @return  a list with all source PDF files an their corresponding reference files.
	 *//*

	@Parameters
	public static Collection<Object[]> data() {
		List<Object[]> list = new java.util.ArrayList<Object[]>();
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if(eProperties.getProperty("comparisionOriginalFolder")!=null && !eProperties.getProperty("comparisionOriginalFolder").isEmpty() && eProperties.getProperty("comparisionOriginalFolder")!=" ")
		{
			SOURCE = eProperties.getProperty("comparisionOriginalFolder");
		}
		
		if(eProperties.getProperty("comparisionNewGenFolder")!=null && !eProperties.getProperty("comparisionNewGenFolder").isEmpty() && eProperties.getProperty("comparisionNewGenFolder")!=" ")
		{
			REFERENCE = eProperties.getProperty("comparisionNewGenFolder");
		}
		// the source directory must be set
		assertTrue( "Test directory not defined", SOURCE != null );
		File mainDir = new File( SOURCE );
		// it must be a directory
		assertTrue( "Test directory " + SOURCE + " is not a directory ", mainDir.isDirectory() );

		try{
			// get the root path of the sources
			sourceRootDir = mainDir.getCanonicalPath();
		} catch( IOException e ) {
			fail( "Canonical representation of main directory");
		}
		// add all founded PDF files in the source directory to the list
		list.addAll( preparePaths( mainDir ) );

		assertTrue( "There are no PDF files in the source directory at " + SOURCE, list.size() != 0 );
		return list;
	}

	*/
/**
	 * Makes recursive search of PDF files in current directory and in it's sub directories.
	 * @param sourceDir  the current directory to look for PDF files
	 * @return  list of all found PDF files
	 *//*

	private static List<Object[]> preparePaths( File sourceDir ) {
		List<Object[]> paramList = new ArrayList<Object[]>();
		try{
			String currentSourcePath = sourceDir.getCanonicalPath();
			String subDirPath;
			subDirPath = currentSourcePath.substring( sourceRootDir.length() );
			if( subDirPath.length() != 0 ) {
				if( subDirPath.charAt( 0 ) == File.separatorChar ) {
					subDirPath = subDirPath.substring( 1 );
				}
			}
			// get all files using the filter
			File[] pdfFiles = sourceDir.listFiles( PDFFILEFILTER );
			for( int i=0; i<pdfFiles.length; i++ ) {
				File pdfFile = pdfFiles[i];
				String pdfName = pdfFile.getName();
				if( pdfName.trim().length() != 0 ) {
					// set the path for the source file
					String sourceFilePath = currentSourcePath + File.separatorChar + pdfName;
					// set the path for the corresponding reference file
					String refListsPath   = REFERENCE + File.separatorChar;
					if( subDirPath.length() != 0 ) {
						refListsPath   = refListsPath + subDirPath + File.separatorChar;
					}
					refListsPath   = refListsPath + pdfName;

					// add the source file with its corresponding reference file to the list.
					Object[] params = new String[]{refListsPath, sourceFilePath  };
					paramList.add( params );
				}
			}

			// parse the source sub directories
			File[] subDirs = sourceDir.listFiles( SUBDIRECTORYFILTER );
			for( int i=0; i<subDirs.length; i++ ) {
				File subDir = subDirs[i];
				paramList.addAll( preparePaths(subDir ) );
			}
		} catch( IOException e ) {
			e.printStackTrace();
		}
		return paramList;
	}



	public int countDifferences(){
		int count = 0;

		return count;
	}

	*/
/**
	 * Compares the current PDF file with it's reference file and checks if there are any differences.
	 * @throws IOException if the canonical path of the current PDF file can not be obtained
	 *//*

	@Test
	public void compare() throws IOException {
		Logger log = Logger.getLogger(CompareTwoFoldersAsUnitTest.class.getName());
		// compare the current PDF file with it's reference
		PDFComparer  pdfComparer  = new PDFComparer();
		pdfComparer.setConfiguration(configuration);
		ResultModel result =pdfComparer.compare( referencePdfFile, currentPdfFile );
		for (DiffGroup tempVar : result.getDifferences(true)) {
		//	log.info(tempVar.getBoundingElements());
		}
		int differenceCount = result.getDifferencesCount( false );
		
	//	log.info(result.getDifferencesCount( false ));
	//	log.info(result.getComparisonParameters().toString());
	//	log.info( differenceCount + " differences found in " + currentPdfFile.getCanonicalPath());
		assertTrue( differenceCount + " differences found in " + currentPdfFile.getCanonicalPath(), differenceCount == 0 );

	}
}*/
