package com.dci.translationChecker;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dci.enterprise.dao.TranslationHelperDAO;
import com.dci.enterprise.dao.VMDSHelperDAO;

public class VMDSHelper {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static  void main(String[] args) {

		long startSystemTime = System.currentTimeMillis();
		List<String> list = new ArrayList<String>();
		Logger log = Logger.getLogger(VMDSHelper.class.getName());
		log.info("Starting program");


		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
			generateEnglishPDFs(context, list);
		String test ="\n";
				
		String temp = html2text(test);
		System.out.println(temp);
		System.out.println(countWords(temp));
		context.close();
		System.err.println("TOTAL TIME TAKE "+((System.currentTimeMillis()-startSystemTime)));
		log.info("Exiting the program");

	}

	public static void generateEnglishPDFs(ApplicationContext context, List<String> list) {			

		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		String[] vehicleList = null;

		VMDSHelperDAO vmdsHelperDAO = (VMDSHelperDAO)context.getBean("VMDSHelperDAO");
		vmdsHelperDAO.startVMDSCheck();
		
	}



	public static String html2text(String html) {
		return  "";
	}

	public static int countWords(String str)
	{
		String words[]=str.split(" ");
		int count=words.length;
		return count;
	}

}




