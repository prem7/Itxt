package com.dci.translationChecker;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dci.enterprise.dao.ColorAndTrimDAO;
import com.dci.enterprise.dao.DistributionUpdatesDAO;
import com.dci.enterprise.dao.EngineAxleDAO;
import com.dci.enterprise.dao.InteriorEqpDAO;
import com.dci.enterprise.dao.ItextDistributionUpdatesPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextEngineAxlePDFGeneratorDAO;
import com.dci.enterprise.dao.ItextExteriorPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextInteriorPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextRpoCodesPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextSpecsAndDimensionPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextStdEquipPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextTraileringSpecsPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextWheelsPDFGeneratorDAO;
import com.dci.enterprise.dao.RpoCodesDAO;
import com.dci.enterprise.dao.SpecsAndDimensionDAO;
import com.dci.enterprise.dao.StandardEqpDAO;
import com.dci.enterprise.dao.TraileringSpecsDAO;
import com.dci.enterprise.dao.TranslationHelperDAO;
import com.dci.enterprise.dao.WheelsAndRadiosDao;
import com.dci.enterprise.model.ColorAndTrimBean;
import com.dci.enterprise.model.ColorAndTrimHelper;
import com.dci.enterprise.model.ColorRestrictionBean;
import com.dci.enterprise.model.ColorTrimAvailabliltiy;
import com.dci.enterprise.model.DistribtionUpdatesBean;
import com.dci.enterprise.model.EngineAxleBean;
import com.dci.enterprise.model.EngineAxleContentBean;
import com.dci.enterprise.model.EngineAxleTableHeaders;
import com.dci.enterprise.model.RpoCodesBean;
import com.dci.enterprise.model.SpecsAndDimBeanContent;
import com.dci.enterprise.model.SpecsAndDimHelper;
import com.dci.enterprise.model.SpecsAndDimensionBean;
import com.dci.enterprise.model.StandardEqpBean;
import com.dci.enterprise.model.TraileringSpecsBean;
import com.dci.enterprise.model.TraileringSpecsBeanRestriction;
import com.dci.enterprise.model.TraileringSpecsGCWRContent;
import com.dci.enterprise.model.TraileringSpecsGCWRHeaderBean;
import com.dci.enterprise.model.WheelsAndRadiosBean;
import com.dci.general.utilities.UtilityDAO;
import com.dci.general.utilities.VehicleConstant;

public class TranslationChecker {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static  void main(String[] args) {

		long startSystemTime = System.currentTimeMillis();
		List<String> list = new ArrayList<String>();
		Logger log = Logger.getLogger(TranslationChecker.class.getName());
		//public List<ColorAndTrimBean> mainMethod(){
		//long Start = System.currentTimeMillis();
		log.info("Starting program");


		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		generateEnglishPDFs(context, list);
		//	System.out.println(" FindAll :"+ );
		context.close();
		System.err.println("TOTAL TIME TAKE "+((System.currentTimeMillis()-startSystemTime)));
		//return ;
		log.info("Exiting the program");

	}

	public static void generateEnglishPDFs(ApplicationContext context, List<String> list) {			

		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String[] vehicleList = null;

		if(eProperties.getProperty("singlevehicleId")!=null && !eProperties.getProperty("singlevehicleId").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			vehicleList= new String[1];
			vehicleList[0] = eProperties.getProperty("singlevehicleId");
			System.out.println(eProperties.getProperty("singlevehicleId")+"  "+eProperties.getProperty("listVehicleIds")+"/testing");	

		}

		else
		{
			int test =	eProperties.getProperty("listVehicleIds").split(",").length;
			vehicleList = eProperties.getProperty("listVehicleIds").split(",");
			System.out.println(vehicleList);

		}


		if(eProperties.getProperty("generateChangedVehiclesOnly").equals("true")){

			UtilityDAO utilityDAO = (UtilityDAO)context.getBean("UtilityDAO");
			vehicleList = utilityDAO.getVehicleItemsXML(1);
		}



		ColorAndTrimDAO colorAndTrimDAO = (ColorAndTrimDAO)context.getBean("ColorAndTrimDAO");
		StandardEqpDAO standardEqpDAO = (StandardEqpDAO)context.getBean("StandardEqpBeanDao");
		InteriorEqpDAO interiorEqpDAO = (InteriorEqpDAO) context.getBean("InteriorBeanDao");
		InteriorEqpDAO exteriorEqpDAO = (InteriorEqpDAO) context.getBean("ExteriorBeanDao");
		RpoCodesDAO rpoCodesDAO = (RpoCodesDAO) context.getBean("RpoCodesBeanDao");
		EngineAxleDAO engineAxleDAO = (EngineAxleDAO) context.getBean("EngineAxleDAO");
		TraileringSpecsDAO traileringSpecsDAO = (TraileringSpecsDAO) context.getBean("TraileringSpecsDAO");
		DistributionUpdatesDAO distributionUpdatesDAO = (DistributionUpdatesDAO) context.getBean("distributionUpdatesDAO");
		SpecsAndDimensionDAO specsAndDimensionDAO = (SpecsAndDimensionDAO) context.getBean("SpecsAndDimensionDAO");
		WheelsAndRadiosDao wheelsAndRadiosDao = (WheelsAndRadiosDao)context.getBean("WheelsAndRadiosDao");

		TranslationHelperDAO translationHelperDAO = (TranslationHelperDAO)context.getBean("TranslationHelperDAO");

		ItextTraileringSpecsPDFGeneratorDAO itextTraileringSpecsPDFGeneratorDAO =(ItextTraileringSpecsPDFGeneratorDAO)context.getBean("ItextPDFGenerator_TraileringSpecs");

		ItextPDFGeneratorDAO itextPDFGeneratorDAO = (ItextPDFGeneratorDAO)context.getBean("ItextGenerator");

		ItextStdEquipPDFGeneratorDAO itextStdEquipPDFGeneratorDAO = (ItextStdEquipPDFGeneratorDAO)context.getBean("ItextPDFGenerator_StdEqp");

		ItextStdEquipPDFGeneratorDAO itextEquipGroupPDFGeneratorDAO = (ItextStdEquipPDFGeneratorDAO)context.getBean("ItextPDFGenerator_EqpGroup");

		ItextStdEquipPDFGeneratorDAO itextEquipGroupAddlPDFGeneratorDAO = (ItextStdEquipPDFGeneratorDAO)context.getBean("ItextPDFGenerator_EqpGroupAddOptions");

		ItextStdEquipPDFGeneratorDAO itextPegStairStepDAO = (ItextStdEquipPDFGeneratorDAO)context.getBean("ItextPDFGenerator_PegStair");

		ItextInteriorPDFGeneratorDAO interiorPDFGeneratorDAO = (ItextInteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_Interior");

		ItextExteriorPDFGeneratorDAO exteriorPDFGeneratorDAO = (ItextExteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_Exterior");

		ItextInteriorPDFGeneratorDAO mechanicalPDFGeneratorDAO = (ItextInteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_Mech");

		ItextInteriorPDFGeneratorDAO seoShipPDFGeneratorDAO = (ItextInteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_SeoShip");

		ItextInteriorPDFGeneratorDAO onStarPDFGeneratorDAO = (ItextInteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_OnStar");

		ItextRpoCodesPDFGeneratorDAO rpoCodesPDFGeneratorDAO = (ItextRpoCodesPDFGeneratorDAO)context.getBean("ItextPDFGenerator_RpoCodes");

		ItextDistributionUpdatesPDFGeneratorDAO distributionUpdatesPDFGeneratorDAO = (ItextDistributionUpdatesPDFGeneratorDAO)context.getBean("ItextPDFGenerator_DistUpdates");

		ItextSpecsAndDimensionPDFGeneratorDAO specsAndDimensionPDFGeneratorDAO =(ItextSpecsAndDimensionPDFGeneratorDAO)context.getBean("ItextPDFGenerator_SpecsAndDimension");

		ItextSpecsAndDimensionPDFGeneratorDAO dimensionPDFGeneratorDAO =(ItextSpecsAndDimensionPDFGeneratorDAO)context.getBean("ItextPDFGenerator_Dimension");

		ItextWheelsPDFGeneratorDAO itextWheelsPDFGeneratorDAO = (ItextWheelsPDFGeneratorDAO)context.getBean("ItextGenerator_wheels");

		itextWheelsPDFGeneratorDAO = (ItextWheelsPDFGeneratorDAO)context.getBean("ItextGenerator_wheels");

		ItextEngineAxlePDFGeneratorDAO itextEngineAxlePDFGeneratorDAO = (ItextEngineAxlePDFGeneratorDAO)context.getBean("ItextPDFGenerator_EngineAxle");

		itextEngineAxlePDFGeneratorDAO = (ItextEngineAxlePDFGeneratorDAO)context.getBean("ItextPDFGenerator_EngineAxle");


		//		list = (specsAndDimensionDAO.getAVehicles());

		/*colorAndTrimDAO.setLangFrench(false);
				colorAndTrimDAO.setLangEnglish(true);
				colorAndTrimDAO.setPageType(OrderingInfoConstants.EXTERIOR);*/

		for (String vehicle : vehicleList) {

			//itextPDFGeneratorDAO.startRadioPDFGeneration(colorAndTrimDAO.getVehicleItemsXML(1, "1",vehicle));
			//	List<List<StandardEqpBean>>temp=	standardEqpDAO.getVehicleItemsXML(1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1);

			//--StandardEquipment 
			/*	if (eProperties.getProperty("genStdEquip","").equals("true")){
				itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(
						standardEqpDAO.getVehicleItemsXML(1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText()


						);
			}
			 */
			System.out.println("Current Vehicle - "+ vehicle);
			if (eProperties.getProperty("genColorTrim","").equals("true")){

				//comparing the sizes  for different lang parameter		

				compareColorAndTrim(colorAndTrimDAO.getVehicleItemsXML(4, vehicle, 1), colorAndTrimDAO.getVehicleItemsXML(4, vehicle, 2), vehicle, translationHelperDAO);
			}


			if (eProperties.getProperty("genSpecs","").equals("true")) {
				compareSpecs(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 2,1),specsAndDimensionDAO.getVehicleItemsXML(vehicle, 2,2),vehicle,translationHelperDAO);
			}

			//Dimension
			if (eProperties.getProperty("genDimen","").equals("true")) {
				compareDimension(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 1,1),specsAndDimensionDAO.getVehicleItemsXML(vehicle, 1,2),vehicle,translationHelperDAO);
			}


			if (eProperties.getProperty("genRadios","").equals("true")){
				compareRadio(wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,1),wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,2), vehicle);
			}

			//wheels
			if (eProperties.getProperty("genWheels","").equals("true")){
				compareWheels(wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.WHEELS,vehicle,1),wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.WHEELS,vehicle,2), vehicle);
			}

			if (eProperties.getProperty("genRPOCodes","").equals("true")) {
				compareRpoCodes(rpoCodesDAO.getVehicleItemsXML(vehicle, 1),rpoCodesDAO.getVehicleItemsXML(vehicle, 2),vehicle,translationHelperDAO);
			}

			//-- DISTUPDATES
			if (eProperties.getProperty("genDistUpdates","").equals("true")) {
				compareDistUpdate(distributionUpdatesDAO.getVehicleItemsXML(vehicle, 1),distributionUpdatesDAO.getVehicleItemsXML(vehicle, 2),vehicle,translationHelperDAO);
			}
			if (eProperties.getProperty("genInterior","").equals("true")){
				//compareInterior(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
				compareInterior(interiorEqpDAO, 5, 2, "oced.optionCodeSort ", "oced.optionCodeSort ", vehicle,"genInterior",translationHelperDAO);
			}

			if (eProperties.getProperty("genOnStar","").equals("true")){
				//compareInterior(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
				compareInterior(interiorEqpDAO, 5, 5, "oced.optionCodeSort ", "oced.optionCodeSort ", vehicle,"genOnStar", translationHelperDAO);
			}



			if (eProperties.getProperty("genStdEquip","").equals("true")){
				compareStdEqp(standardEqpDAO,1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle,"genStdEquip");
				//		compareInterior(interiorEqpDAO, 5, 5, "oced.optionCodeSort ", "oced.optionCodeSort ", vehicle,"genOnStar");

			}

			if (eProperties.getProperty("genMechanical","").equals("true")){
				//compareInterior(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
				compareInterior(interiorEqpDAO, 5, 3, "oced.optionCodeSort ", "oced.optionCodeSort ", vehicle,"genMechanical", translationHelperDAO);
			}


			//Seo Ship
			if (eProperties.getProperty("genSEOShipThru","").equals("true")){
				compareInterior(interiorEqpDAO, 5, 4, "oced.optionCodeSort ","oced.optionCodeSort ", vehicle,"genSEOShipThru", translationHelperDAO);
			}


			if (eProperties.getProperty("genEqGroupsStair","").equals("true")) {
				//itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.POG,null);

				compareStdEqp(standardEqpDAO,1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle,"genEqGroupsStair");
				//itextPegStairStepDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),standardEqpDAO.getRegOption());


			}


			if (eProperties.getProperty("genEqGroups","").equals("true")) {
				//itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.POG,null);

				compareStdEqp(standardEqpDAO,1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle,"genEqGroups");
				//itextPegStairStepDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),standardEqpDAO.getRegOption());
			}

			if (eProperties.getProperty("genEqGroupsWithAddlOptions","").equals("true")) {
				//itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.POG,null);

				compareStdEqp(standardEqpDAO,1, "((poc.availableCodeID = 2) OR (poc.availableCodeID = 10)) AND (oc.categoryid != 4) AND (oc.categoryid != 5)", " oced.optionCodeSort ", vehicle,"genEqGroupsWithAddlOptions");
				//itextPegStairStepDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),standardEqpDAO.getRegOption());
			}


			if (eProperties.getProperty("genExterior","").equals("true")){
				compareInterior(interiorEqpDAO, 5, 1, "oced.optionCodeSort ","oced.optionCodeSort ", vehicle,"genExterior", translationHelperDAO);
			}

			if (eProperties.getProperty("genEngineAxle","").equals("true") ) {
				//		itextEngineAxlePDFGeneratorDAO.startSpecsAndDimPDFGeneration(engineAxleDAO.getVehicleItemsXML(vehicle, 1, 1));

				compareEngine(engineAxleDAO.getVehicleItemsXML(vehicle, 1, 1), engineAxleDAO.getVehicleItemsXML(vehicle, 1, 2),vehicle,translationHelperDAO);
			}

			if (eProperties.getProperty("genTrailering","").equals("true") ) {
				//		itextEngineAxlePDFGeneratorDAO.startSpecsAndDimPDFGeneration(engineAxleDAO.getVehicleItemsXML(vehicle, 1, 1));

				compareTrailering(traileringSpecsDAO.getVehicleItemsXML(1, vehicle, 1), traileringSpecsDAO.getVehicleItemsXML(1, vehicle, 2), vehicle);
			}



			/*
			//-- Equipment Groups -- 
			if (eProperties.getProperty("genEqGroups","").equals("true")){
				itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),standardEqpDAO.getRegOption());
			}

			// Additional Option XML -- 
			itextEquipGroupAddlPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, "((poc.availableCodeID = 2) OR (poc.availableCodeID = 10)) AND (oc.categoryid != 4) AND (oc.categoryid != 5)", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),null,null,VehicleConstant.PRINTBOOKS,standardEqpDAO.getRegOption());
			//NON USED REGULTORY OPTION	itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, "((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.regulatoryFlag = 1)", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText());

			//Radios
			if (eProperties.getProperty("genRadios","").equals("true")){
				itextWheelsPDFGeneratorDAO.startRadioPDFGeneration(VehicleConstant.RADIOS,wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,1));
			}

			//wheels
			if (eProperties.getProperty("genWheels","").equals("true")){
				itextWheelsPDFGeneratorDAO.startRadioPDFGeneration(VehicleConstant.WHEELS,wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.WHEELS,vehicle,1));
			}

			//interiors
			if (eProperties.getProperty("genInterior","").equals("true")){
				interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
			}

			//Mechanical
			if (eProperties.getProperty("genMechanical","").equals("true")){
				mechanicalPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,3, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
			}

			//Seo Ship
			if (eProperties.getProperty("genSEOShipThru","").equals("true")){
				seoShipPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,4, "sc.subcategorysorter ,oced.optionCodeSort ", " sc.subcategorysorter ,oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
			}

			//genOnStar
			if (eProperties.getProperty("genOnStar","").equals("true")){
				onStarPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,5, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
			}


			//Exteriors
			if (eProperties.getProperty("genExterior","").equals("true")){
				//itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText());

				exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),exteriorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
			}

			//---- RPO CODES ---//
			if (eProperties.getProperty("genRPOCodes","").equals("true")) {
				rpoCodesPDFGeneratorDAO.startRpoCodesPDFGeneration(rpoCodesDAO.getVehicleItemsXML(vehicle, 1));
			}

			//-- DISTUPDATES
			if (eProperties.getProperty("genDistUpdates","").equals("true")) {
				distributionUpdatesPDFGeneratorDAO.startDistUpdatePDFGeneration(distributionUpdatesDAO.getVehicleItemsXML(vehicle, 1));
			}

			//SpecsAndDimension
			//Specs
			if (eProperties.getProperty("genSpecs","").equals("true")) {
				specsAndDimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 2,1));
			}

			//Dimension
			if (eProperties.getProperty("genDimen","").equals("true")) {
				dimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 1,1));
			}

			//EngineAxle
			if (eProperties.getProperty("genEngineAxle","").equals("true") ) {
				itextEngineAxlePDFGeneratorDAO.startSpecsAndDimPDFGeneration(engineAxleDAO.getVehicleItemsXML(vehicle, 1, 1));
			}

			//Trailering
			if (eProperties.getProperty("genTrailering","").equals("true")) {
				itextTraileringSpecsPDFGeneratorDAO.startRadioPDFGeneration(traileringSpecsDAO.getVehicleItemsXML(1, vehicle, 1),null,null,0);
			}


			if (eProperties.getProperty("genEqGroupsStair","").equals("true")) {
				//itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.POG,null);
				itextPegStairStepDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),standardEqpDAO.getRegOption());


			}
			 */






		}
	}



	private static void compareEngine(List<ArrayList<Object>> list_en,

			List<ArrayList<Object>> list_fr, String vehicle, TranslationHelperDAO translationHelperDAO) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());

		for(int page = 0 ; page<list_en.size(); page ++){
			if(!list_en.get(page).isEmpty()){
				if(!list_fr.isEmpty() && !list_fr.get(page).isEmpty()){

					List<EngineAxleBean>  rowHeaderList_en=(List<EngineAxleBean>)list_en.get(page).get(0);
					List<EngineAxleBean>  rowHeaderList_fr=(List<EngineAxleBean>)list_fr.get(page).get(0);
					if(rowHeaderList_en.size()!=rowHeaderList_fr.size()){

						System.err.println("MISMATCH in rowHeaderList --Engine for " +vehicle + " on page "+page+" "+(rowHeaderList_en.size()-rowHeaderList_fr.size()));
						log.error("MISMATCH in Engine -rowHeaderList-Engine  " +vehicle + " on page "+page);
					
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (EngineAxleBean dim_en : rowHeaderList_en) {
							temp.add(dim_en.getEngineID());
						}
						for (EngineAxleBean dim_fr : rowHeaderList_fr) {
							if(!temp.contains(dim_fr.getEngineID())){
								keyvalues += "'"+dim_fr.getEngineID()+"',";
							}
						}
						if(keyvalues.length()>0){
						keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						checkIfExistsInTranslation(translationHelperDAO, "ENGINEID", keyvalues, vehicle,"Engine");
						}
						
						
						rowHeaderList_en.removeAll(rowHeaderList_fr);
						log.error(rowHeaderList_en);
					}

					List<EngineAxleTableHeaders>  contentList_en=(List<EngineAxleTableHeaders>)list_en.get(page).get(1);
					List<EngineAxleTableHeaders>  contentList_fr=(List<EngineAxleTableHeaders>)list_fr.get(page).get(1);
					if(contentList_en.size()!=contentList_fr.size()){

						System.err.println("MISMATCH in engineAxleHeaderList --Engine for " +vehicle + " on page "+page +" "+(contentList_en.size()-contentList_fr.size()) );
						log.error("MISMATCH in engineAxleHeaderList --Engine for " +vehicle + " on page "+page);
						contentList_en.removeAll(contentList_en);
						log.error(contentList_en);
					}

					List<EngineAxleContentBean>  columnHeaderList_en=(List<EngineAxleContentBean>)list_en.get(page).get(2);
					List<EngineAxleContentBean>  columnHeaderList_fr=(List<EngineAxleContentBean>)list_fr.get(page).get(2);
					if(columnHeaderList_en.size()!=columnHeaderList_fr.size()){
						System.err.println("MISMATCH in engineAxleContentList --Engine for " +vehicle + " on page "+page + "  "+(columnHeaderList_en.size()-columnHeaderList_fr.size()));
						log.error("MISMATCH in engineAxleContentList --Engine for " +vehicle + " on page "+page);
						//columnHeaderList_en.removeAll(columnHeaderList_fr);
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (EngineAxleContentBean dim_en : columnHeaderList_en) {
							temp.add(dim_en.getComponentID());
						}
						for (EngineAxleContentBean dim_fr : columnHeaderList_fr) {
							if(!temp.contains(dim_fr.getComponentID())){
								keyvalues += "'"+dim_fr.getComponentID()+"',";
							}
						}
						if(keyvalues.length()>0){
						keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						checkIfExistsInTranslation(translationHelperDAO, "COMPONENTID", keyvalues, vehicle,"Engine");
						}
						
						
						log.error(columnHeaderList_en);
					}


				}
				else {
					System.err.println("Translation not found for French -- Engine "+vehicle);

				}

			}
		}
	}



	private static void compareTrailering(List<ArrayList<Object>> list_en,

			List<ArrayList<Object>> list_fr, String vehicle) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());

		for(int page = 0 ; page<list_en.size(); page ++){
			if(!((List<TraileringSpecsBean>) list_en.get(page).get(0)).isEmpty()){
				if(!list_fr.isEmpty() && !list_fr.get(page).isEmpty()){

					List<TraileringSpecsBean>  traileringSpecsHeaderList_en=(List<TraileringSpecsBean>)list_en.get(page).get(0);
					List<TraileringSpecsBean>  traileringSpecsHeaderList_fr=(List<TraileringSpecsBean>)list_fr.get(page).get(0);
					if(traileringSpecsHeaderList_en.size()!=traileringSpecsHeaderList_fr.size()){

						System.err.println("MISMATCH in traileringSpecsHeaderList --trailering for " +vehicle + " on page "+page+" "+(traileringSpecsHeaderList_en.size()-traileringSpecsHeaderList_fr.size()));
						log.error("MISMATCH in Engine -traileringSpecsHeaderList-trailering  " +vehicle + " on page "+page);
						traileringSpecsHeaderList_en.removeAll(traileringSpecsHeaderList_fr);
						log.error(traileringSpecsHeaderList_en);
					}

					List<EngineAxleTableHeaders>  traileringSpecsContentBeansList_en=(List<EngineAxleTableHeaders>)list_en.get(page).get(1);
					List<EngineAxleTableHeaders>  traileringSpecsContentBeansList_fr=(List<EngineAxleTableHeaders>)list_fr.get(page).get(1);
					if(traileringSpecsContentBeansList_en.size()!=traileringSpecsContentBeansList_fr.size()){

						System.err.println("MISMATCH in traileringSpecsContentBeansList_en --Engine for " +vehicle + " on page "+page +" "+(traileringSpecsContentBeansList_en.size()-traileringSpecsContentBeansList_fr.size()) );
						log.error("MISMATCH in traileringSpecsContentBeansList_en --Engine for " +vehicle + " on page "+page);
						traileringSpecsContentBeansList_en.removeAll(traileringSpecsContentBeansList_fr);
						log.error(traileringSpecsContentBeansList_en);
					}

					List<EngineAxleContentBean>  traileringSpecsGCWRBeanList_en=(List<EngineAxleContentBean>)list_en.get(page).get(2);
					List<EngineAxleContentBean>  traileringSpecsGCWRBeanList_fr=(List<EngineAxleContentBean>)list_fr.get(page).get(2);
					if(traileringSpecsGCWRBeanList_en.size()!=traileringSpecsGCWRBeanList_fr.size()){
						System.err.println("MISMATCH in engineAxleContentList --Engine for " +vehicle + " on page "+page + "  "+(traileringSpecsGCWRBeanList_en.size()-traileringSpecsGCWRBeanList_fr.size()));
						log.error("MISMATCH in engineAxleContentList --Engine for " +vehicle + " on page "+page);
						traileringSpecsGCWRBeanList_en.removeAll(traileringSpecsGCWRBeanList_fr);
						log.error(traileringSpecsGCWRBeanList_en);
					}
					List<TraileringSpecsGCWRContent>  traileringSpecsGCWRContentList_en=(List<TraileringSpecsGCWRContent>)list_en.get(page).get(3);
					List<TraileringSpecsGCWRContent>  traileringSpecsGCWRContentList_fr=(List<TraileringSpecsGCWRContent>)list_fr.get(page).get(3);
					if(traileringSpecsGCWRContentList_en.size()!=traileringSpecsGCWRContentList_fr.size()){
						System.err.println("MISMATCH in engineAxleContentList --Engine for " +vehicle + " on page "+page + "  "+(traileringSpecsGCWRContentList_en.size()-traileringSpecsGCWRContentList_fr.size()));
						log.error("MISMATCH in engineAxleContentList --Engine for " +vehicle + " on page "+page);
						traileringSpecsGCWRContentList_en.removeAll(traileringSpecsGCWRContentList_fr);
						log.error(traileringSpecsGCWRContentList_en);
					}

					List<TraileringSpecsGCWRHeaderBean>  traileringSpecsGCWRHeaderBeansList_en=(List<TraileringSpecsGCWRHeaderBean>)list_en.get(page).get(4);
					List<TraileringSpecsGCWRHeaderBean>  traileringSpecsGCWRHeaderBeansList_fr=(List<TraileringSpecsGCWRHeaderBean>)list_fr.get(page).get(4);
					if(traileringSpecsGCWRHeaderBeansList_en.size()!=traileringSpecsGCWRHeaderBeansList_fr.size()){
						System.err.println("MISMATCH in traileringSpecsGCWRHeaderBeansList_en --Engine for " +vehicle + " on page "+page + "  "+(traileringSpecsGCWRHeaderBeansList_en.size()-traileringSpecsGCWRHeaderBeansList_fr.size()));
						log.error("MISMATCH in traileringSpecsGCWRHeaderBeansList_en --Engine for " +vehicle + " on page "+page);
						traileringSpecsGCWRHeaderBeansList_en.removeAll(traileringSpecsGCWRHeaderBeansList_fr);
						log.error(traileringSpecsGCWRHeaderBeansList_en);
					}

					List<TraileringSpecsBeanRestriction>  traileringSpecsBeanRestrictionList_en=(List<TraileringSpecsBeanRestriction>)list_en.get(page).get(5);
					List<TraileringSpecsBeanRestriction>  traileringSpecsBeanRestrictionList_fr=(List<TraileringSpecsBeanRestriction>)list_fr.get(page).get(5);
					if(traileringSpecsBeanRestrictionList_en.size()!=traileringSpecsBeanRestrictionList_fr.size()){
						System.err.println("MISMATCH in traileringSpecsBeanRestrictionList_en --Engine for " +vehicle + " on page "+page + "  "+(traileringSpecsBeanRestrictionList_en.size()-traileringSpecsBeanRestrictionList_fr.size()));
						log.error("MISMATCH in traileringSpecsBeanRestrictionList_en --Engine for " +vehicle + " on page "+page);
						traileringSpecsBeanRestrictionList_en.removeAll(traileringSpecsBeanRestrictionList_fr);
						log.error(traileringSpecsBeanRestrictionList_en);
					}

					List<TraileringSpecsBeanRestriction>  traileringSpecsBeanRestrictionList_en1=(List<TraileringSpecsBeanRestriction>)list_en.get(page).get(6);
					List<TraileringSpecsBeanRestriction>  traileringSpecsBeanRestrictionList_fr1=(List<TraileringSpecsBeanRestriction>)list_fr.get(page).get(6);
					if(traileringSpecsBeanRestrictionList_en1.size()!=traileringSpecsBeanRestrictionList_fr1.size()){
						System.err.println("MISMATCH in traileringSpecsBeanRestrictionList_en1 --Engine for " +vehicle + " on page "+page + "  "+(traileringSpecsBeanRestrictionList_en1.size()-traileringSpecsBeanRestrictionList_fr1.size()));
						log.error("MISMATCH in traileringSpecsBeanRestrictionList_en1 --Engine for " +vehicle + " on page "+page);
						traileringSpecsBeanRestrictionList_en1.removeAll(traileringSpecsBeanRestrictionList_fr1);
						log.error(traileringSpecsBeanRestrictionList_en1);
					}
				}
				else {
					System.err.println("Translation not found for French -- Engine "+vehicle);

				}

			}
		}
	}

	private static void compareInterior(InteriorEqpDAO interiorEqpDAO,int subCategoryID,int categoryID,  String availCode_SQLCondition,String availCode_Sort, String vehicleID, String Type, TranslationHelperDAO translationHelperDAO) {

		Logger log = Logger.getLogger(TranslationChecker.class.getName());
		Object[][]	list_en = interiorEqpDAO.getVehicleItemsXML(subCategoryID,categoryID, availCode_SQLCondition, availCode_Sort, vehicleID, 1); 
		Object[][]	list_fr = interiorEqpDAO.getVehicleItemsXML(categoryID,categoryID, availCode_SQLCondition, availCode_Sort, vehicleID, 2);
		for(int i=0;i<3;i++){


			if((i<list_en.length && list_en[i][0]!=null && list_en[i][1]!=null)){


				if((i<list_fr.length && list_fr[i][0]!=null && list_fr[i][1]!=null)){

					List<StandardEqpBean>	vehicleItemsXML_en = (List<StandardEqpBean>) list_en[i][0];
					List<StandardEqpBean>	availableCodeList_en = (List<StandardEqpBean>) list_en[i][1];	

					List<StandardEqpBean>	vehicleItemsXML_fr = (List<StandardEqpBean>) list_fr[i][0];
					List<StandardEqpBean>	availableCodeList_fr = (List<StandardEqpBean>) list_fr[i][1];
					if(!vehicleItemsXML_en.isEmpty()){
						if(!vehicleItemsXML_fr.isEmpty()){
							if(vehicleItemsXML_en.size()!=vehicleItemsXML_fr.size()){

								System.err.println("MISMATCH in vehicleItemsXML --  "+Type+" for " +vehicleID+" Differences - "+(vehicleItemsXML_en.size()-vehicleItemsXML_fr.size()+" on page "+i));
								log.error("MISMATCH in vehicleItemsXML --Interior  " +vehicleID);
								String keyvalues = "";
								ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
								for (StandardEqpBean dim_en : vehicleItemsXML_en) {
									temp.add(dim_en.getRpoId());
								}
								for (StandardEqpBean dim_fr : vehicleItemsXML_fr) {
									if(!temp.contains(dim_fr.getRpoId())){
										keyvalues += "'"+dim_fr.getRpoId()+"',";
									}
								}
								if(keyvalues.length()>0){
								keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
								checkIfExistsInTranslation(translationHelperDAO, "RPOID", keyvalues, vehicleID,Type);
								}
								
								vehicleItemsXML_en.removeAll(vehicleItemsXML_fr);
								log.error(vehicleItemsXML_en);
							}
						}

						else {
							System.err.println("Translation not found for French -- "+ Type +" "+vehicleID);

						}
					}

				}
				/*else {
				System.err.println("Translation not found for French -- DstUpdate "+vehicle);

			}
				 */
			}
		}

		/*interiorEqpDAO.getAvaialableCode();
		interiorEqpDAO.getPackageList();
		interiorEqpDAO.getModelList();
		interiorEqpDAO.getPackageDescText();*/


	}




	private static void compareDistUpdate(
			List<DistribtionUpdatesBean> list_en,
			List<DistribtionUpdatesBean> list_fr, String vehicle, TranslationHelperDAO translationHelperDAO) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());

		if(!list_en.isEmpty()){
			if(!list_fr.isEmpty() && !list_fr.isEmpty()){

				List<DistribtionUpdatesBean>  disList_en=(List<DistribtionUpdatesBean>)list_en;
				List<DistribtionUpdatesBean>  disList_fr=(List<DistribtionUpdatesBean>)list_fr;
				if(disList_en.size()!=disList_fr.size()){

					System.err.println("MISMATCH in DisList --DstUpdate for " +vehicle);
					log.error("MISMATCH in DisList --DstUpdate  " +vehicle);
					String keyvalues = "";
					ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
					for (DistribtionUpdatesBean dim_en : disList_fr) {
						temp.add(dim_en.getDistID());
					}
					for (DistribtionUpdatesBean dim_fr : disList_en) {
						if(!temp.contains(dim_fr.getDistID())){
							keyvalues += "'"+dim_fr.getDistID()+"',";
						}
					}
					if(keyvalues.length()>0){
					keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
					checkIfExistsInTranslation(translationHelperDAO, "DISTUPDATEID", keyvalues, vehicle,"DstUpdate - DISTUPDATEID");
					}
					
					disList_en.removeAll(disList_fr);
					log.error(disList_en);
				}
			}
			else {
				System.err.println("Translation not found for French -- DstUpdate "+vehicle);

			}

		}
	}

	private static void compareRpoCodes(List<RpoCodesBean> list_en,
			List<RpoCodesBean> list_fr, String vehicle, TranslationHelperDAO translationHelperDAO) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());

		if(!list_en.isEmpty()){
			if(!list_fr.isEmpty() && !list_fr.isEmpty()){

				List<RpoCodesBean>  rpoList_en=(List<RpoCodesBean>)list_en;
				List<RpoCodesBean>  rpoList_fr=(List<RpoCodesBean>)list_fr;
				if(rpoList_en.size()!=rpoList_fr.size()){

					System.err.println("MISMATCH in rowHeaderlist --RPO for " +vehicle);
					log.error("MISMATCH in rowHeaderlist --RPO  " +vehicle);
					String keyvalues = "";
					ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
					for (RpoCodesBean dim_en : rpoList_en) {
						temp.add(dim_en.getRpoId());
					}
					for (RpoCodesBean dim_fr : rpoList_fr) {
						if(!temp.contains(dim_fr.getRpoId())){
							keyvalues += "'"+dim_fr.getRpoId()+"',";
						}
					}
					if(keyvalues.length()>0){
					keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
					checkIfExistsInTranslation(translationHelperDAO, "RPOID", keyvalues, vehicle, "RPOCODES - RPOID");
					}
				//	rpoList_en.removeAll(rpoList_fr);
					log.error(rpoList_en);
				}
			}
			else {
				System.err.println("Translation not found for French -- RPO "+vehicle);

			}

		}
	}

	private static void compareWheels(
			List<WheelsAndRadiosBean> list_en,
			List<WheelsAndRadiosBean> list_fr, String vehicle) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());

		if(!list_en.isEmpty()){
			if(!list_fr.isEmpty() && !list_fr.isEmpty()){

				List<WheelsAndRadiosBean>  wheelsList_en=(List<WheelsAndRadiosBean>)list_en;
				List<WheelsAndRadiosBean>  wheelsList_fr=(List<WheelsAndRadiosBean>)list_fr;
				if(wheelsList_en.size()!=wheelsList_fr.size()){

					System.err.println("MISMATCH in rowHeaderlist --Wheels for " +vehicle);
					log.error("MISMATCH in rowHeaderlist --Wheels  " +vehicle);
				//	wheelsList_en.removeAll(wheelsList_fr);
					
				
					log.error(wheelsList_en);
				}
			}
			else {
				System.err.println("Translation not found for French -- Wheels "+vehicle);

			}

		}
	}

	private static void compareRadio(List<WheelsAndRadiosBean> list_en,
			List<WheelsAndRadiosBean> list_fr, String vehicle) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());

		if(!list_en.isEmpty()){
			if(!list_fr.isEmpty() && !list_fr.isEmpty()){

				List<WheelsAndRadiosBean>  wheelsList_en=(List<WheelsAndRadiosBean>)list_en;
				List<WheelsAndRadiosBean>  wheelsList_fr=(List<WheelsAndRadiosBean>)list_fr;
				if(wheelsList_en.size()!=wheelsList_fr.size()){

					System.err.println("MISMATCH in rowHeaderlist --Radios for " +vehicle);
					log.error("MISMATCH in rowHeaderlist --Radios  " +vehicle);
					wheelsList_en.removeAll(wheelsList_fr);
					log.error(wheelsList_en);
				}
			}
			else {
				System.err.println("Translation not found for French -- Radios "+vehicle);

			}

		}
	}

	private static void compareSpecs(List<ArrayList<Object>> list_en,

			List<ArrayList<Object>> list_fr, String vehicle, TranslationHelperDAO translationHelperDAO) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());

		for(int page = 0 ; page<list_en.size(); page ++){
			if(!list_en.get(page).isEmpty()){
				if(!list_fr.isEmpty() && !list_fr.get(page).isEmpty()){

					List<SpecsAndDimensionBean>  rowHeaderList_en=(List<SpecsAndDimensionBean>)list_en.get(page).get(0);
					List<SpecsAndDimensionBean>  rowHeaderList_fr=(List<SpecsAndDimensionBean>)list_fr.get(page).get(0);
					if(rowHeaderList_en.size()!=rowHeaderList_fr.size()){

						System.err.println("MISMATCH in rowHeaderlist --SPECS for " +vehicle + " on page "+page);
						log.error("MISMATCH in rowHeaderlist --SPECS  " +vehicle + " on page "+page);
						rowHeaderList_en.removeAll(rowHeaderList_fr);
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (SpecsAndDimensionBean dim_en : rowHeaderList_en) {
							temp.add(dim_en.getRowHeaderID());
						}
						for (SpecsAndDimensionBean dim_fr : rowHeaderList_fr) {
							if(!temp.contains(dim_fr.getRowHeaderID())){
								keyvalues += "'"+dim_fr.getRowHeaderID()+"',";
							}
						}
						if(keyvalues.length()>0){
						keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						checkIfExistsInTranslation(translationHelperDAO, "ROWHEADERID", keyvalues, vehicle,"Specs - ROWHEADERID");
						}
						log.error(rowHeaderList_en);
					}

					List<SpecsAndDimBeanContent>  contentList_en=(List<SpecsAndDimBeanContent>)list_en.get(page).get(1);
					List<SpecsAndDimBeanContent>  contentList_fr=(List<SpecsAndDimBeanContent>)list_fr.get(page).get(1);
					if(contentList_en.size()!=contentList_fr.size()){

						System.err.println("MISMATCH in contentList --SPECS for " +vehicle + " on page "+page);
						log.error("MISMATCH in contentList --SPECS for " +vehicle + " on page "+page);
						contentList_en.removeAll(contentList_en);
						log.error(contentList_en);
					}

					List<SpecsAndDimHelper>  columnHeaderList_en=(List<SpecsAndDimHelper>)list_en.get(page).get(2);
					List<SpecsAndDimHelper>  columnHeaderList_fr=(List<SpecsAndDimHelper>)list_fr.get(page).get(2);
					if(columnHeaderList_en.size()!=columnHeaderList_fr.size()){
						System.err.println("MISMATCH in columnHeaderList --SPECS for " +vehicle + " on page "+page);
						log.error("MISMATCH in columnHeaderList --SPECS for " +vehicle + " on page "+page);
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (SpecsAndDimHelper dim_en : columnHeaderList_en) {
							temp.add(dim_en.getColumnHeaderID());
						}
						for (SpecsAndDimHelper dim_fr : columnHeaderList_fr) {
							if(!temp.contains(dim_fr.getColumnHeaderID())){
								keyvalues += "'"+dim_fr.getColumnHeaderID()+"',";
							}
						}
						if(keyvalues.length()>0){
						keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						checkIfExistsInTranslation(translationHelperDAO, "ROWHEADERID", keyvalues, vehicle,"Specs - ColumnHeaderID");
						}
						
						
						//columnHeaderList_en.removeAll(columnHeaderList_fr);
						log.error(columnHeaderList_en);
					}


				}
				else {
					System.err.println("Translation not found for French -- Specs "+vehicle);

				}

			}
		}
	}

	private static void compareDimension(
			List<ArrayList<Object>> list_en,
			List<ArrayList<Object>> list_fr,String vehicle, TranslationHelperDAO translationHelperDAO) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());

		for(int page = 0 ; page<list_en.size(); page ++){
			if(!list_en.get(page).isEmpty()){
				if(!list_fr.isEmpty() && !list_fr.get(page).isEmpty()){

					List<SpecsAndDimensionBean>  rowHeaderList_en=(List<SpecsAndDimensionBean>)list_en.get(page).get(0);
					List<SpecsAndDimensionBean>  rowHeaderList_fr=(List<SpecsAndDimensionBean>)list_fr.get(page).get(0);
					if(rowHeaderList_en.size()!=rowHeaderList_fr.size()){

						System.err.println("MISMATCH in rowHeaderlist --SPECS for " +vehicle + " on page "+page);
						log.error("MISMATCH in rowHeaderlist --SPECS  " +vehicle + " on page "+page);
						rowHeaderList_en.removeAll(rowHeaderList_fr);
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (SpecsAndDimensionBean dim_en : rowHeaderList_fr) {
							temp.add(dim_en.getRowHeaderID());
						}
						for (SpecsAndDimensionBean dim_fr : rowHeaderList_en) {
							if(!temp.contains(dim_fr.getRowHeaderID())){
								keyvalues += "'"+dim_fr.getRowHeaderID()+"',";
							}
						}
						if(keyvalues.length()>0){
						keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						checkIfExistsInTranslation(translationHelperDAO, "COLUMNHEADERID", keyvalues, vehicle,"Dimension - ROWHEADERID");
						}
						log.error(rowHeaderList_en);
					}

					List<SpecsAndDimBeanContent>  contentList_en=(List<SpecsAndDimBeanContent>)list_en.get(page).get(1);
					List<SpecsAndDimBeanContent>  contentList_fr=(List<SpecsAndDimBeanContent>)list_fr.get(page).get(1);
					if(contentList_en.size()!=contentList_fr.size()){

						System.err.println("MISMATCH in contentList --SPECS for " +vehicle + " on page "+page);
						log.error("MISMATCH in contentList --SPECS for " +vehicle + " on page "+page);
					
						contentList_en.removeAll(contentList_en);
						log.error(contentList_en);
					}

					List<SpecsAndDimHelper>  columnHeaderList_en=(List<SpecsAndDimHelper>)list_en.get(page).get(2);
					List<SpecsAndDimHelper>  columnHeaderList_fr=(List<SpecsAndDimHelper>)list_fr.get(page).get(2);
					if(columnHeaderList_en.size()!=columnHeaderList_fr.size()){
						System.err.println("MISMATCH in columnHeaderList --SPECS for " +vehicle + " on page "+page);
						log.error("MISMATCH in columnHeaderList --SPECS for " +vehicle + " on page "+page);
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (SpecsAndDimHelper dim_en : columnHeaderList_fr) {
							temp.add(dim_en.getColumnHeaderID());
						}
						for (SpecsAndDimHelper dim_fr : columnHeaderList_en) {
							if(!temp.contains(dim_fr.getColumnHeaderID())){
								keyvalues += "'"+dim_fr.getColumnHeaderID()+"',";
							}
						}
						if(keyvalues.length()>0){
						keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						
						checkIfExistsInTranslation(translationHelperDAO, "COLUMNHEADERID", keyvalues, vehicle,"SPECS - columnHeaderList");
						}
						columnHeaderList_en.removeAll(columnHeaderList_fr);
						log.error(columnHeaderList_en);
					}


				}
				else {
					System.err.println("Translation not found for French -- Specs "+vehicle);

				}

			}
		}
	}

	private static void compareStdEqp(StandardEqpDAO standardEqpDAO,int subCategoryID,  String availCode_SQLCondition,String availCode_Sort, String vehicleID, String Type) {

		Logger log = Logger.getLogger(TranslationChecker.class.getName());
		Object[][]	list_en = standardEqpDAO.getVehicleItemsXML(subCategoryID, availCode_SQLCondition, availCode_Sort, vehicleID, 1); 
		Object[][]	list_fr = standardEqpDAO.getVehicleItemsXML(subCategoryID, availCode_SQLCondition, availCode_Sort, vehicleID, 2);
		for(int i=0;i<3;i++){


			if((i<list_en.length && list_en[i][0]!=null && list_en[i][1]!=null)){


				if((i<list_fr.length && list_fr[i][0]!=null && list_fr[i][1]!=null)){

					List<StandardEqpBean>	vehicleItemsXML_en = (List<StandardEqpBean>) list_en[i][0];
					List<StandardEqpBean>	availableCodeList_en = (List<StandardEqpBean>) list_en[i][1];	

					List<StandardEqpBean>	vehicleItemsXML_fr = (List<StandardEqpBean>) list_fr[i][0];
					List<StandardEqpBean>	availableCodeList_fr = (List<StandardEqpBean>) list_fr[i][1];
					if(!vehicleItemsXML_en.isEmpty()){
						if(!vehicleItemsXML_fr.isEmpty()){
							if(vehicleItemsXML_en.size()!=vehicleItemsXML_fr.size()){

								System.err.println("MISMATCH in vehicleItemsXML --  "+Type+" for " +vehicleID+" Differences - "+(vehicleItemsXML_en.size()-vehicleItemsXML_fr.size()+" on page "+i));
								log.error("MISMATCH in vehicleItemsXML --Interior  " +vehicleID);
								vehicleItemsXML_en.removeAll(vehicleItemsXML_fr);
								log.error(vehicleItemsXML_en);
							}
						}

						else {
							System.err.println("Translation not found for French -- "+ Type +" "+vehicleID);

						}
					}

				}
				/*else {
				System.err.println("Translation not found for French -- DstUpdate "+vehicle);

			}
				 */
			}
		}
	}

	static void compareColorAndTrim(List<ArrayList<Object>> list_en, List<ArrayList<Object>> list_fr, String vehicle, TranslationHelperDAO translationHelperDAO) {
		Logger log = Logger.getLogger(TranslationChecker.class.getName());
		Map<Long, ColorAndTrimBean> linkedHash_en;
		Map<Long, ColorAndTrimBean> linkedHash_fr;
		for(int page = 0 ; page<list_en.size(); page ++){

			if(!list_en.get(page).isEmpty()){
				if(!list_fr.isEmpty() && !list_fr.get(page).isEmpty()){
					List<ColorAndTrimHelper> seatInteriorList_en = (List<ColorAndTrimHelper>) list_en.get(page).get(0);
					List<ColorAndTrimHelper> seatInteriorList_fr = (List<ColorAndTrimHelper>) list_fr.get(page).get(0);
					if(seatInteriorList_en.size()!=seatInteriorList_fr.size()){

						System.err.println("MISMATCH in SeatInteriorList for " +vehicle + " on page "+page);
						log.error("MISMATCH in SeatInteriorList for " +vehicle + " on page "+page);
						seatInteriorList_en.removeAll(seatInteriorList_fr);
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (ColorAndTrimHelper colorAndTrimHelper : seatInteriorList_en) {
							temp.add(colorAndTrimHelper.getSeatID());
						}
						for (ColorAndTrimHelper colorAndTrimHelper : seatInteriorList_fr) {
							if(!temp.contains(colorAndTrimHelper.getSeatID())){
								keyvalues += "'"+colorAndTrimHelper.getSeatID()+"',";
							}
						}
						keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						checkIfExistsInTranslation(translationHelperDAO, "SEATTYPE", keyvalues, vehicle,"SeatInteriorList");
						log.error(seatInteriorList_en);
					}

					linkedHash_en =  (Map<Long, ColorAndTrimBean>) list_en.get(page).get(1);
					linkedHash_fr =  (Map<Long, ColorAndTrimBean>) list_fr.get(page).get(1);

					if(linkedHash_en.size()!=linkedHash_fr.size()){
						System.err.println("MISMATCH in Linked Hash "+vehicle + " on page "+page);
					}

					List<ColorAndTrimBean> tempColorTrimSeatList_en = (List<ColorAndTrimBean>) list_en.get(page).get(7);
					List<ColorAndTrimBean> tempColorTrimSeatList_fr = (List<ColorAndTrimBean>) list_fr.get(page).get(7);
					if(tempColorTrimSeatList_en.size()!=tempColorTrimSeatList_fr.size()){
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (ColorAndTrimBean colorAndTrimBean : tempColorTrimSeatList_fr) {
							temp.add(colorAndTrimBean.getSeatID());
						}
						for (ColorAndTrimBean colorAndTrimBean : tempColorTrimSeatList_en) {
							if(!temp.contains(colorAndTrimBean.getSeatID())){
								keyvalues += "'"+colorAndTrimBean.getSeatID()+"',";
							}
						}
						if(keyvalues.length()>1){
							keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						}
						System.err.println("MISMATCH in tempColorTrimSeatList "+vehicle + " on page "+page);
						checkIfExistsInTranslation(translationHelperDAO, "SEATID", keyvalues, vehicle,"tempColorTrimSeatList");
						log.error("MISMATCH in tempColorTrimSeatList "+vehicle + " on page "+page);
					}

					List<ColorAndTrimBean>	seatIntAvailability_en = (List<ColorAndTrimBean>) list_en.get(page).get(3);
					List<ColorAndTrimBean>	seatIntAvailability_fr = (List<ColorAndTrimBean>) list_fr.get(page).get(3);
					if(seatIntAvailability_en.size()!=seatIntAvailability_fr.size()){

						System.err.println("MISMATCH in seatIntAvailability "+vehicle + " on page "+page);
						log.error("MISMATCH in seatIntAvailability "+vehicle + " on page "+page);
						seatIntAvailability_en.removeAll(seatIntAvailability_fr);
						log.error(seatIntAvailability_en);
					}



					List<ColorAndTrimBean> colorAndTrim_ExtList_en = (List<ColorAndTrimBean>) list_en.get(page).get(4);
					List<ColorAndTrimBean> colorAndTrim_ExtList_fr = (List<ColorAndTrimBean>) list_fr.get(page).get(4);
					if(colorAndTrim_ExtList_en.size()!=colorAndTrim_ExtList_fr.size()){

						System.err.println("MISMATCH in colorAndTrim_ExtList "+vehicle + " on page "+page);
						colorAndTrim_ExtList_en.removeAll(colorAndTrim_ExtList_fr);
						log.error(colorAndTrim_ExtList_en);

						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (ColorAndTrimBean colorAndTrimBean : colorAndTrim_ExtList_fr) {
							temp.add(colorAndTrimBean.getExteriorColorID());
						}
						for (ColorAndTrimBean colorAndTrimBean : colorAndTrim_ExtList_en) {
							if(!temp.contains(colorAndTrimBean.getExteriorColorID()))
								keyvalues += "'"+colorAndTrimBean.getExteriorColorID()+"',";
						}

						if(keyvalues.length()>1){
							keyvalues=	keyvalues.substring(0,keyvalues.length()-1);

							checkIfExistsInTranslation(translationHelperDAO, "EXTERIORCOLORID",keyvalues,vehicle,"colorAndTrim_ExtList");			

						}
					}

					List<ColorTrimAvailabliltiy> colorTrimAvailabliltiys_en =(List<ColorTrimAvailabliltiy>) list_en.get(page).get(5);
					List<ColorTrimAvailabliltiy> colorTrimAvailabliltiys_fr =(List<ColorTrimAvailabliltiy>) list_fr.get(page).get(5);
					if(colorTrimAvailabliltiys_en.size()!=colorTrimAvailabliltiys_fr.size()){

						System.err.println("MISMATCH in colorTrimAvailabliltiys "+vehicle + " on page "+page);
						log.error("MISMATCH in colorTrimAvailabliltiys "+vehicle + " on page "+page);
						colorTrimAvailabliltiys_en.removeAll(colorTrimAvailabliltiys_fr);
						log.error(colorTrimAvailabliltiys_en);
					}


					List<ColorRestrictionBean> restrictionList_en =(List<ColorRestrictionBean>)list_en.get(page).get(6);
					List<ColorRestrictionBean> restrictionList_fr =(List<ColorRestrictionBean>)list_fr.get(page).get(6);
					if(restrictionList_en.size()!=restrictionList_fr.size()){

						System.err.println("MISMATCH in restrictionList "+vehicle + " on page "+page);
						log.error("MISMATCH in restrictionList "+vehicle + " on page "+page);
						restrictionList_en.removeAll(restrictionList_fr);
						String keyvalues = "";
						ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>();
						for (ColorRestrictionBean rest_en : restrictionList_en) {
							temp.add(rest_en.getRestrictionID());
						}
						for (ColorRestrictionBean rest_fr : restrictionList_fr) {
							if(!temp.contains(rest_fr.getRestrictionID())){
								keyvalues += "'"+rest_fr.getRestrictionID()+"',";
							}
						}
						keyvalues=	keyvalues.substring(0,keyvalues.length()-1);
						checkIfExistsInTranslation(translationHelperDAO, "RESTRICTIONTEXT", keyvalues, vehicle,"Restriction List");
						log.error(restrictionList_en);
					}


					List<ColorTrimAvailabliltiy> colorList_en = (List<ColorTrimAvailabliltiy>) list_en.get(page).get(2);
					List<ColorTrimAvailabliltiy> colorList_fr = (List<ColorTrimAvailabliltiy>) list_fr.get(page).get(2);
					if(colorList_en.size()!=colorList_fr.size()){

						System.err.println("MISMATCH in colorList "+vehicle + " on page "+page);
						log.error("MISMATCH in colorList "+vehicle + " on page "+page);
					}

				}
				else {
					System.err.println("Translation not found for French on page "+vehicle);

				}

			}
		}

	}



	/**
	 * 
	 * To check whether the missing key values exists in the translation queue.
	 * 
	 * 
	 *  @param translationHelperDAO  the TranslationHelperDAO 
	 *  @param keyColumns for Column values
	 *  @param vehicle for vehicleID
	 * 	@param string for calling MethodName
	 *  @return void
	 *  
	 */
	private static void checkIfExistsInTranslation(TranslationHelperDAO translationHelperDAO,String keyColumns, String keyvalues, String vehicle, String string ) {

		if(translationHelperDAO.checkTranslation(keyColumns, keyvalues , vehicle)){
			System.err.println("vehicle in translation Process");
		}
		else
			System.err.println(string+" doesnt Exist in translation Log");

	}

}




