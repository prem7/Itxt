package com.dci.enterprise.dao;

import java.util.List;

import com.dci.enterprise.model.WheelsAndRadiosBean;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextWheelsPDFGeneratorDAO {
	

	void onCloseDocument(PdfWriter writer, Document document);

	public void startRadioPDFGeneration(int subcategoryID,	List<WheelsAndRadiosBean> vehicleItemsXML);

	void startRadioPDFGeneration(int subcategoryID,
			List<WheelsAndRadiosBean> vehicleItemsXML, Document document,
			PdfWriter writer, int vehiclePrint);
}
