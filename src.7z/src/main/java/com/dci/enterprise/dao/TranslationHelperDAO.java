package com.dci.enterprise.dao;

import java.util.List;

import com.dci.enterprise.model.WheelsAndRadiosBean;

public interface TranslationHelperDAO {
	
	public boolean checkTranslation(String keyColumns, String keyValues,String vehicleID);


}
