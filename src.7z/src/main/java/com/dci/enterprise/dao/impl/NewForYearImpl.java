package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.ModelCoverPageDAO;
import com.dci.enterprise.dao.NewFeaturesCoverPageDAO;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.ModelCoverPageBean;
import com.dci.enterprise.model.NewFeaturesBean;
import com.dci.enterprise.model.StandardEqpBean;
import com.dci.enterprise.model.StdEqpHelper;
import com.dci.general.utilities.VehicleConstant;

public class NewForYearImpl implements NewFeaturesCoverPageDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private int pageNumber = 1;
	List<StandardEqpBean> standardEqpBeanHeaderlist = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentlist1 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentlist2 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentlist3 = new ArrayList<StandardEqpBean>();
	List<StdEqpHelper> stdEqpHelperList = new ArrayList<StdEqpHelper>();
	List<StandardEqpBean> standardEqpBeanContentAvailabilty1 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentAvailabilty2 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentAvailabilty3 = new ArrayList<StandardEqpBean>();
	static public List<ArrayList<BigDecimal>> modelList = null;
	static public List<ArrayList<BigDecimal>> ListPackage= null;
	static	HashMap<BigDecimal,ArrayList<String>>  packageDescTextMap = new HashMap<BigDecimal, ArrayList<String>>();
	static List<HashMap <BigDecimal,ArrayList<String>>> packageNameMap =null;
	static	Object [][] standardEqpBeanArr =null;
	static public ArrayList<BigDecimal> modelListTemp = null;
	static String vehicleID=null;
	List<List<StandardEqpBean>> finalList = new ArrayList<List<StandardEqpBean>>();
	static boolean isCanada=false;
	static boolean isVehicleActive=false;
	static int lang=1;

	static public ArrayList<NewFeaturesBean> newFeaturesList;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	ModelCoverPageBean modelCoverPageBean = new ModelCoverPageBean();
	String getVehicle = null;
	String getColumnsOption = null;
	public ModelCoverPageBean getVehicleItemsXML(int subCategoryID, String vehicleID, int lang) {
		modelCoverPageBean = new ModelCoverPageBean();
		this.lang = lang;

		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		query = new Query();
		this.vehicleID= vehicleID;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d,vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);

		for (Map row : vehicle) {

			if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

				isCanada= true;
			}
			else{
				isCanada=false;
			}

			if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

				isVehicleActive= true;
			}
			else{
				isVehicleActive=false;
			}


		}

		if(isVehicleActive){
			if(isCanada)
			{
				log.info("VEHICLE is in Canadian Region");
				//nonDomesticCoverPage(vehicleID);	

			}
			else{
				log.info("VEHICLE is in non-Canadian Region");
				DomesticCoverPage(vehicleID);	
			}


		}
		else{
			log.error("VEHICLE NOT ACTIVE");
		}


		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND "+
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";
		List<Map<String, Object>> vehicleli = jdbcTemplate.queryForList(getVehicle);
		
			for (Map vehicleDetails : vehicleli) {

				modelCoverPageBean.setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				modelCoverPageBean.setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				modelCoverPageBean.setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				modelCoverPageBean.setDivisionID((BigDecimal)(vehicleDetails.get("DIVISIONID")));
				modelCoverPageBean.setRegionID((BigDecimal)(vehicleDetails.get("REGIONID")));
				modelCoverPageBean.setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
			}

		modelCoverPageBean.setNewFeaturesList(newFeaturesList);
		return modelCoverPageBean;

	}




	private void DomesticCoverPage(String vehicleID) {
		
		newFeaturesList = new ArrayList<NewFeaturesBean>();
		NewFeaturesBean newFeaturesBean = new NewFeaturesBean();
		String getNewFeatures = "SELECT nf.*, t.TypeID, t.type, t.type2, i.*" + 
				"             FROM NewFeatures nf, Type t, Images i " + 
				"             WHERE (nf.ImageID = i.ImageID(+))" + 
				"             AND (nf.TypeID = t.TypeID)" + 
				"             AND nf.vehicleID = "+vehicleID + 
				"             ORDER BY nf.TypeID, nf.nfSort";

		List<Map<String, Object>> newFeatures = jdbcTemplate.queryForList(getNewFeatures);
		
		for (Map row : newFeatures) {
			newFeaturesBean = new NewFeaturesBean();
			newFeaturesBean.setNFtext((String) (row.get("NFTEXT")));
			newFeaturesBean.setTypeID(((BigDecimal)(row.get("TYPEID"))));
			//newFeaturesList.add((BigDecimal)(row.get("TYPEID")),(String) (row.get("NFTEXT")));
			newFeaturesList.add(newFeaturesBean);
		}


	}




	/*private void nonDomesticCoverPage(String vehicleID2) {
		modelNames = new LinkedHashMap<BigDecimal, String>();

		String getModelNames = "select * from v_model where vehicleid = "+vehicleID+" order by modelsort and lang=1";

		List<Map<String, Object>> modelNameList = jdbcTemplate.queryForList(getModelNames);
		for (Map row : modelNameList) {

			modelNames.put((BigDecimal) (row.get("MODELID")),(String) (row.get("MODELDESC")+" ("+row.get("MODELNAME")+")"));

		}




	}*/








	public List<ArrayList<BigDecimal>> getModelList(){
		return modelList;
	}

	public Object[][] getAvaialableCode() {

		return standardEqpBeanArr;

	}

	public List<HashMap<BigDecimal, ArrayList<String>>>  getPackageList(){
		return packageNameMap;
	}

	


	


	public boolean isRequired(int pdfType,String vehicle) {
		String getButtonList= null;
		stdEqpHelperList = new ArrayList<StdEqpHelper>();

		getButtonList ="SELECT b.* FROM button b, vehiclebutton vb WHERE " +
				" (vb.VehicleID = " + vehicle + ") and" +
				" (b.ButtonID = vb.ButtonID) and" +
				" (b.parentbuttonID is not null) order by b.buttonsort";
		jdbcTemplate = new JdbcTemplate(dataSource);
		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getButtonList);
		List<BigDecimal> tempList = new ArrayList<BigDecimal>();
		for (Map row : modelIDList) {
			tempList.add((BigDecimal)(row.get("BUTTONID")));
		}

		getButtonList="	SELECT b.*, vb.VehicleID FROM button b, vehiclebutton vb WHERE"
				+ " (vb.VehicleID = " + vehicle + ") and   (b.ButtonID = vb.ButtonID) and  "
				+ " (b.ButtonLocation = 0)   and"
				+ "  (b.parentbuttonID is null) order by b.buttonsort";       

		List<Map<String, Object>> buttonList = jdbcTemplate.queryForList(getButtonList);
		List<BigDecimal> button_List = new ArrayList<BigDecimal>();
		for (Map row : buttonList) {
			button_List.add((BigDecimal)(row.get("BUTTONID")));
		}


		if(tempList.contains(new BigDecimal(pdfType)) || button_List.contains(new BigDecimal(pdfType)))
		{
			return true;
		}		

		return false;


	}





}
