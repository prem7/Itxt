package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.DistributionUpdatesDAO;
import com.dci.enterprise.model.DistribtionUpdatesBean;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.RpoCodesBean;

public class DistributionUpdatesDAOImpl implements DistributionUpdatesDAO{

	private int numOfWeeks = 1;
	private int numOfMonths = 1;
	private int numOfDays = 0;
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	static String vehicleID=null;
	List<DistribtionUpdatesBean> finalList;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	String getVehicle = null;


	public List<DistribtionUpdatesBean> getVehicleItemsXML( String vehicleID,int localeCode) {

		
		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		query = new Query();
		this.vehicleID= vehicleID;
		finalList= new ArrayList<DistribtionUpdatesBean>();


		try{

			getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d,vehicle v, region r WHERE " +
					" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
					" (v.divisionID = d.divisionID) and " +
					" (v.regionID = d.regionID) and " +
					" (d.regionID = r.regionID) ";

			List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
			boolean isCanada=false;
			boolean isVehicleActive=false;
			for (Map row : vehicle) {

				if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

					isCanada= true;
				}
				else{
					isCanada=false;
				}

				if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

					isVehicleActive= true;
				}
				else{
					isVehicleActive=false;
				}


			}

			if(isVehicleActive){
				if(isCanada)
				{
					log.info("VEHICLE is in Canadian Region");
					nonDomesticVehicles(vehicleID, localeCode );	
				}
				else{
					log.info("VEHICLE is in non-Canadian Region");
					domesticVehicles(vehicleID, localeCode );
				}


			}
			else{
				log.error("VEHICLE NOT ACTIVE");
			}


		}
		catch(Exception e ){
			System.out.println("Exception " +e);
		}
		return finalList;

	}

	private void domesticVehicles(String vehicleID2, int localeCode) {
		finalList= new ArrayList<DistribtionUpdatesBean>();

		getNumOfMonths("12");

		String   distUpdatesql= "with r as (select rownum i, vehicleid, dudate, dutext from distupdate du where du.vehicleid="+vehicleID2+"  and " +
				" du.disttype='R'),s as (select distinct (select min(i) from r where dbms_lob.compare(r.dutext,t.dutext) =  0) min_i,dudate from distupdate t where " +
				" t.vehicleid="+vehicleID2+" and t.disttype='R' order by duDate desc ) select (select dutext from r where r.i=s.min_i) dutext,  " +
				" (select vehicleid from r where r.i=s.min_i) vehicleid,  (select EXTRACT(MONTH FROM duDate) as duMonth from r where r.i=s.min_i) duMonth ," +
				" (select EXTRACT(DAY FROM duDate) as duDay from r where r.i=s.min_i) duDay," + 
				" (select EXTRACT(YEAR FROM duDate) as duYear from r where r.i=s.min_i) duYear," + 
				" (select TO_CHAR(duDate, 'Month') as monthName  from r where r.i=s.min_i) monthName," + 
				" (select (EXTRACT(Month FROM duDate)||'0'||EXTRACT(Day FROM duDate)||'0'||EXTRACT(Year FROM duDate))  as Stamp  from r where r.i=s.min_i) Stamp" + 
				" from s";

		List<Map<String, Object>> rpoCode = jdbcTemplate.queryForList(distUpdatesql);


		for (Map row : rpoCode) {

			DistribtionUpdatesBean distUpdate = new DistribtionUpdatesBean();

			distUpdate.setDuDay((BigDecimal)(row.get("DUDAY")));
			distUpdate.setDuMonth((BigDecimal)(row.get("DUMONTH")));
			distUpdate.setDuYear((BigDecimal)(row.get("DUYEAR")));
			distUpdate.setDuText((String.valueOf(row.get("DUTEXT"))));

			
	
			finalList.add(distUpdate);
		} 
		
		if(finalList.size()==0){
			DistribtionUpdatesBean distUpdate = new DistribtionUpdatesBean();
			distUpdate.setDuDay(new BigDecimal(10));
			distUpdate.setDuMonth(new BigDecimal(10));
			distUpdate.setDuYear(new BigDecimal(2010));
			distUpdate.setDuText("temp");
			finalList.add(distUpdate);
		}
		
	
		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ")  and "+
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(finalList.size()>0){
			for (Map vehicleDetails : vehicle) {

				finalList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				finalList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				finalList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				finalList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				finalList.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				finalList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				finalList.get(0).setRegionID((BigDecimal) ((vehicleDetails.get("REGIONID"))));
				finalList.get(0).setLocaleCode((BigDecimal) ((vehicleDetails.get("LOCALECODE"))));

			}
			
			
		}




	}

	private void nonDomesticVehicles(String vehicleID2, int localeCode) {
		finalList= new ArrayList<DistribtionUpdatesBean>();
		getNumOfMonths("12");

		String   distUpdatesql= "with r as (select rownum i, vehicleid,dudate, dutext from v_distupdate du where du.vehicleid="+vehicleID2+" and du.localecode="+localeCode+" and " +
				" du.disttype='R'),s as (select distinct (select min(i) from r where dbms_lob.compare(r.dutext,t.dutext) =  0) min_i, dudate from v_distupdate t where " +
				" t.vehicleid="+vehicleID2+" and t.disttype='R' and t.localecode="+localeCode+" order by duDate desc ) select (select dutext from r where r.i=s.min_i) dutext,  " +
				"(select vehicleid from r where r.i=s.min_i) vehicleid,  (select EXTRACT(MONTH FROM duDate) as duMonth from r where r.i=s.min_i) duMonth ," + 
				"(select EXTRACT(DAY FROM duDate) as duDay from r where r.i=s.min_i) duDay," + 
				"(select EXTRACT(YEAR FROM duDate) as duYear from r where r.i=s.min_i) duYear," + 
				"(select TO_CHAR(duDate, 'Month') as monthName  from r where r.i=s.min_i) monthName," + 
				"(select (EXTRACT(Month FROM duDate)||'0'||EXTRACT(Day FROM duDate)||'0'||EXTRACT(Year FROM duDate))  as Stamp  from r where r.i=s.min_i) Stamp " + 
				"from s";

		List<Map<String, Object>> rpoCode = jdbcTemplate.queryForList(distUpdatesql);


		for (Map row : rpoCode) {

			DistribtionUpdatesBean distUpdate = new DistribtionUpdatesBean();

			distUpdate.setDuDay((BigDecimal)(row.get("DUDAY")));
			distUpdate.setDistID((BigDecimal)(row.get("DISTUPDATEID")));
			distUpdate.setDuMonth((BigDecimal)(row.get("DUMONTH")));
			distUpdate.setDuYear((BigDecimal)(row.get("DUYEAR")));
			distUpdate.setDuText((String.valueOf(row.get("DUTEXT"))));

			finalList.add(distUpdate);
		} 
		
		if(finalList.size()==0){
			DistribtionUpdatesBean distUpdate = new DistribtionUpdatesBean();
			distUpdate.setDuDay(new BigDecimal(10));
			distUpdate.setDuMonth(new BigDecimal(10));
			distUpdate.setDuYear(new BigDecimal(2010));
			distUpdate.setDuText("temp");
			finalList.add(distUpdate);
		}
		

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM v_division d, v_vehicle v, v_region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  v.localecode="+localeCode+" and r.localecode="+localeCode+" and d.localecode="+localeCode+" and" +
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(finalList.size()>0){
			for (Map vehicleDetails : vehicle) {

				finalList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				finalList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				finalList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				finalList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				finalList.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				finalList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				finalList.get(0).setRegionID((BigDecimal) ((vehicleDetails.get("REGIONID"))));
				finalList.get(0).setLocaleCode((BigDecimal) ((vehicleDetails.get("LOCALECODE"))));


			}
			
		}
		else
		{
			DistribtionUpdatesBean distUpdate = new DistribtionUpdatesBean();
			finalList.add(distUpdate);
			for (Map vehicleDetails : vehicle) {

				finalList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				finalList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				finalList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				finalList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				finalList.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				finalList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				finalList.get(0).setRegionID((BigDecimal) ((vehicleDetails.get("REGIONID"))));
				finalList.get(0).setLocaleCode((BigDecimal) ((vehicleDetails.get("LOCALECODE"))));


			}
			
		}


	}






	public void setNumOfWeeks(String newNumOfWeeks) {
		numOfWeeks = Integer.parseInt(newNumOfWeeks);
		numOfDays = numOfWeeks*(7);
	}

	/** Set the number of months for the query
	 * @param newNumOfMonths input number of weeks
	 */	
	public void getNumOfMonths(String newNumOfMonths) {

		numOfDays = 0;
		numOfMonths = Integer.parseInt(newNumOfMonths);

		if (numOfMonths == 12) {
			numOfDays = 365;
			return;
		}

		Calendar cal = new GregorianCalendar();
		int numOfDaysInCurrentMonth = cal.get(Calendar.DAY_OF_MONTH);

		// Set the current year
		int year = cal.get(Calendar.YEAR);         
		// Set the month equal to the current month minus 1    
		int month = cal.get(Calendar.MONTH) - 1;  

		for (int i = numOfMonths - 1; i > 0; i--) {   
			// if past january go back a year and to december
			if (month == -1) {
				year = year - 1;
				month = 11;
			}
			cal.set(year, month, 1);
			numOfDays = numOfDays + cal.getActualMaximum(Calendar.DAY_OF_MONTH);
			month = month - 1;
		}
		numOfDays = numOfDays + numOfDaysInCurrentMonth;
	}


	public List<String> getAVehicles() {
		List<String> listVehicles = new ArrayList<String>();
		Query query = null;
		String sql = null;

		try{

			query = new Query();

			//sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 and VEHICLEID=17008";

			sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 AND REGIONID =14 ";
			jdbcTemplate = new JdbcTemplate(dataSource);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
			for (Map row : rows) {
				listVehicles.add((String.valueOf(row.get("VehicleID"))));
			}

			return listVehicles;
		}

		catch(Exception e ){
			System.out.println("Exception" +e);
		}
		return listVehicles;

	}







}
