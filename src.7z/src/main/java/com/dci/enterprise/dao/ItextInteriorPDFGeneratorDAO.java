package com.dci.enterprise.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dci.enterprise.model.StdEqpHelper;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextInteriorPDFGeneratorDAO {

	public void startInteriorPDFGeneration(Object[][] objects, Object[][] Test,List<HashMap<BigDecimal, ArrayList<String>>> 
	list,List<ArrayList<BigDecimal>> list2,
	List<StdEqpHelper> stdHelper, int PDFType);

	void onCloseDocument(PdfWriter writer, Document document);

	public void startInteriorPDFGeneration(Object[][] objects, Object[][] Test,List<HashMap<BigDecimal, ArrayList<String>>> 
	list,List<ArrayList<BigDecimal>> list2,
	List<StdEqpHelper> stdHelper, Document document,PdfWriter writer,int PDFType);
}
