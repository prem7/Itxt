package com.dci.enterprise.dao;

import java.util.List;

import com.dci.enterprise.model.DistribtionUpdatesBean;
import com.dci.enterprise.model.RpoCodesBean;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextDistributionUpdatesPDFGeneratorDAO {


	void onCloseDocument(PdfWriter writer, Document document);

	public void startDistUpdatePDFGeneration(List<DistribtionUpdatesBean> distUpdatesList, Document document, PdfWriter writer, int vehiclePrint);

	void startDistUpdatePDFGeneration(
			List<DistribtionUpdatesBean> vehicleItemsXML);
}
