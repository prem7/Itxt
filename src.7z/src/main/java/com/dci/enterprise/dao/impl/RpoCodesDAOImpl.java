package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.RpoCodesDAO;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.RpoCodesBean;

public class RpoCodesDAOImpl implements RpoCodesDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	static String vehicleID=null;
	List<RpoCodesBean> finalList;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	String getVehicle = null;
	public List<RpoCodesBean> getVehicleItemsXML( String vehicleID,int localeCode) {

		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		query = new Query();
		this.vehicleID= vehicleID;

		finalList= new ArrayList<RpoCodesBean>();


		try{

			getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d,vehicle v, region r WHERE " +
					" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
					" (v.divisionID = d.divisionID) and " +
					" (v.regionID = d.regionID) and " +
					" (d.regionID = r.regionID) ";

			List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
			boolean isCanada=false;
			boolean isVehicleActive=false;
			for (Map row : vehicle) {

				if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

					isCanada= true;
				}
				else{
					isCanada=false;
				}

				if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

					isVehicleActive= true;
				}
				else{
					isVehicleActive=false;
				}


			}

			if(isVehicleActive){
				if(isCanada)
				{
					log.info("VEHICLE is in Canadian Region");
					nonDomesticVehicles(vehicleID, localeCode);	
				}
				else{
					log.info("VEHICLE is in non-Canadian Region");
					domesticVehicles(vehicleID, localeCode);
				}


			}
			else{
				log.error("VEHICLE NOT ACTIVE");
			}


		}

		catch(Exception e ){
			System.out.println("Exception " +e);
		}
		return finalList;

	}

	private void domesticVehicles(String vehicleID2, int localeCode) {
		finalList= new ArrayList<RpoCodesBean>();

		String rpoCodeSql = "SELECT distinct oc.RPOID, oc.rpoName, oc.rpoDescBold,oc.rpoDesc, m.vehicleID FROM package p, model m, packageoptioncode poc, optioncode oc WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				" (p.modelID = m.modelID) and" +
				" (p.packageID = poc.packageID) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				" (oc.typeFlag = 1) " +
				" AND   ((SELECT COUNT (*) " +
				"  FROM   model m_c, PACKAGE p_c, packageoptioncode poc_c " +
				"  WHERE  p_c.modelid = m_c.modelid AND    poc_c.packageid = p_c.packageid " +
				"  AND    m_c.vehicleid = " + vehicleID +
				"  AND    poc_c.rpoid = oc.rpoid " +
				"  AND    poc_c.availablecodeid NOT IN (3, 7)) > 0) " +
				" order by oc.rpoName";


		List<Map<String, Object>> rpoCode = jdbcTemplate.queryForList(rpoCodeSql);


		for (Map row : rpoCode) {

			RpoCodesBean rpoCodesBean = new RpoCodesBean();

			rpoCodesBean.setRpoId((BigDecimal)(row.get("RPOID")));
			rpoCodesBean.setRpoName((String.valueOf(row.get("RPONAME"))));
			rpoCodesBean.setRpoDesc((String.valueOf(row.get("RPODESC"))));
			rpoCodesBean.setRpoDescBold((String.valueOf(row.get("RPODESCBOLD"))));
			finalList.add(rpoCodesBean);
		} 


		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v,region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  "+
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(finalList.size()>0){
			for (Map vehicleDetails : vehicle) {

				finalList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				finalList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				finalList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				finalList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				finalList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				finalList.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				finalList.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
				finalList.get(0).setRegionID((BigDecimal)(vehicleDetails.get("REGIONID")));
			}
		}



	}



	private void nonDomesticVehicles(String vehicleID2, int localeCode) {

		finalList= new ArrayList<RpoCodesBean>();
		String rpoCodeSql = "SELECT distinct oc.RPOID, oc.rpoName, oc.rpoDescBold,oc.rpoDesc, m.vehicleID FROM v_package p, v_model m, packageoptioncode poc, v_optioncode oc WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				" (p.modelID = m.modelID) AND p.localecode = "+localeCode+" and m.localecode = "+localeCode+" and oc.localecode = "+localeCode+" and" +
				" (p.packageID = poc.packageID) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				" (oc.typeFlag = 1)  AND oc.categoryid != 4  " +
				" AND   ((SELECT COUNT (*) " +
				"  FROM   v_model m_c, v_PACKAGE p_c, packageoptioncode poc_c " +
				"  WHERE  p_c.modelid = m_c.modelid and m_c.localecode= "+localeCode+" and p_c.localecode =  " +localeCode+"  AND    poc_c.packageid = p_c.packageid " +
				"  AND    m_c.vehicleid = " + vehicleID +
				"  AND    poc_c.rpoid = oc.rpoid " +
				"  AND    poc_c.availablecodeid NOT IN (3, 7)) > 0) " +
				" order by oc.rpoName";


		List<Map<String, Object>> rpoCode = jdbcTemplate.queryForList(rpoCodeSql);


		for (Map row : rpoCode) {

			RpoCodesBean rpoCodesBean = new RpoCodesBean();

			rpoCodesBean.setRpoId((BigDecimal)(row.get("RPOID")));
			rpoCodesBean.setRpoName((String.valueOf(row.get("RPONAME"))));
			rpoCodesBean.setRpoDesc((String.valueOf(row.get("RPODESC"))));
			rpoCodesBean.setRpoDescBold((String.valueOf(row.get("RPODESCBOLD"))));
			finalList.add(rpoCodesBean);
		} 


		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM v_division d, v_vehicle v, v_region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  v.localecode="+localeCode+" and r.localecode="+localeCode+" and d.localecode="+localeCode+" and" +
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(finalList.size()>0){
			for (Map vehicleDetails : vehicle) {

				finalList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				finalList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				finalList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				finalList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				finalList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				finalList.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				finalList.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
				finalList.get(0).setRegionID((BigDecimal)(vehicleDetails.get("REGIONID")));
			}
		}

	}


	public List<String> getAVehicles() {
		List<String> listVehicles = new ArrayList<String>();
		Query query = null;
		String sql = null;

		try{

			query = new Query();

			sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 AND REGIONID =14";
			jdbcTemplate = new JdbcTemplate(dataSource);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
			for (Map row : rows) {
				listVehicles.add((String.valueOf(row.get("VehicleID"))));
			}

			return listVehicles;
		}

		catch(Exception e ){
			System.out.println("Exception" +e);
		}
		return listVehicles;

	}




}
