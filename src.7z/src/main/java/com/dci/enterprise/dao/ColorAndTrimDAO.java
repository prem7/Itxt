package com.dci.enterprise.dao;

import java.util.ArrayList;
import java.util.List;

public interface ColorAndTrimDAO {
	
	public List<ArrayList<Object>> getVehicleItemsXML(int subCategoryID,String vehicle,int lang);

	public List<String> getAVehicles();
	


}
