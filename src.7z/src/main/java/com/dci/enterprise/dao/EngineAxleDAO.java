package com.dci.enterprise.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dci.enterprise.model.SpecsAndDimensionBean;
import com.dci.enterprise.model.StdEqpHelper;

public interface EngineAxleDAO {
	
	public List<ArrayList<Object>> getVehicleItemsXML (String vehicleID,int type, int lang);
	
	public List<String> getAVehicles();

}
