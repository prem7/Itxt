package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.ColorAndTrimDAO;
import com.dci.enterprise.model.ColorAndTrimBean;
import com.dci.enterprise.model.ColorAndTrimHelper;
import com.dci.enterprise.model.ColorRestrictionBean;
import com.dci.enterprise.model.ColorTrimAvailabliltiy;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.ExtraColumnsHeaderBean;
import com.dci.general.utilities.VehicleConstant;


public class ColorAndTrimImpl implements ColorAndTrimDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	List<ColorAndTrimHelper> seatInteriorList;
	List<ColorAndTrimBean> colorTrimSeatList;
	List<ColorAndTrimBean> tempColorTrimSeatList;
	List<ColorAndTrimBean> finalColorAndTrimAList = new ArrayList<ColorAndTrimBean>();
	List<ColorAndTrimBean> colorAndTrim_ExtList;
	List<ColorTrimAvailabliltiy> colorTrimAvailablitys;
	List<ExtraColumnsHeaderBean> extraHeaderAvailablitys;
	List<ColorTrimAvailabliltiy> colorList; 
	List<ColorRestrictionBean> colorRestrictionList ;

	//List< String, Multimap<String, String> > availableCode = new ArrayList< Multimap<String, String>>();
	public static HashSet colorHashset = new HashSet<String>();
	public static int numberOfcolor=0;
	List<Object> finaList;
	List<ArrayList<Object>> finaList_TypeID;
	static int lang=1;
	static String vehicleID=null;
	static boolean isCanada=false;
	static boolean isVehicleActive=false;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public List<ArrayList<Object>> getVehicleItemsXML(int subCategoryID,String vehicleID,int lang) {

		Query query = null;

		String getVehicle = null;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";




		this.lang = lang;

		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		query = new Query();
		this.vehicleID= vehicleID;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d,vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);

		for (Map row : vehicle) {

			if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

				isCanada= true;
			}
			else{
				isCanada=false;
			}

			if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

				isVehicleActive= true;
			}
			else{
				isVehicleActive=false;
			}


		}

		if(isVehicleActive){
			finaList_TypeID	= new ArrayList<ArrayList<Object>>();
			List<BigDecimal> listofTypeID; 
			if(isCanada)
			{
				listofTypeID	= getListofTypeID_fr();
				log.info("VEHICLE is in Canadian Region");
				for (int typeID = 0; typeID < listofTypeID.size(); typeID++) {
				//	if(listofTypeID.get(typeID).intValueExact()!=6) {
					finaList_TypeID.add(nonDomesticVehicles(  subCategoryID, vehicleID, lang, listofTypeID.get(typeID).intValueExact()));	
					//}
					}
			}
			else{
				listofTypeID	= getListofTypeID();
				log.info("VEHICLE is in non-Canadian Region");
				for (int typeID = 0; typeID < listofTypeID.size(); typeID++) {
				//	if(listofTypeID.get(typeID).intValueExact()!=6) {
					finaList_TypeID.add(domesticVehicles( subCategoryID, vehicleID, lang, listofTypeID.get(typeID).intValueExact()));
				//	}
				}

			}


		}
		else{
			log.error("VEHICLE NOT ACTIVE");
		}
		return finaList_TypeID;


	}


	
	private List<BigDecimal> getListofTypeID() {
		
		
		List<BigDecimal> tempList = new ArrayList<BigDecimal>();
		String sqlSubquery = "SELECT DISTINCT s.typeid FROM seat s " +
				" WHERE (s.VehicleID = " + vehicleID + ")";
		String listItemSql = "SELECT pdi.*, (select count(*) from vehicleprojecttype vpt where vpt.vehicleid=pdi.vehicleid and vpt.projecttypeid=5) SEO FROM pullDownItem pdi where " +
				" (pdi.VehicleID = " + vehicleID + ") "+
				" and (pdi.typeid IN (" + sqlSubquery + "))";

		List<Map<String, Object>> listDownItem = jdbcTemplate.queryForList(listItemSql);
		for (Map row : listDownItem) {
		if(!tempList.contains(((BigDecimal)(row.get("TYPEID"))))){
			tempList.add(((BigDecimal)(row.get("TYPEID"))));
		}
		}
		Collections.sort(tempList);
		return tempList;
	}
	private List<BigDecimal> getListofTypeID_fr() {
		List<BigDecimal> tempList = new ArrayList<BigDecimal>();
		
		String sqlSubquery = "SELECT DISTINCT s.typeid FROM seat s " +
				" WHERE (s.VehicleID = " + vehicleID + ")";
	
		String listItemSql  = "SELECT pdi.*, (select count(*) from vehicleprojecttype vpt where vpt.vehicleid=pdi.vehicleid and vpt.projecttypeid=5) SEO FROM v_pullDownItem pdi where " +
				" (pdi.VehicleID = " + vehicleID + ") AND pdi.localecode="+lang+" and" +
				" (pdi.typeid IN (" + sqlSubquery + "))";

		List<Map<String, Object>> listDownItem = jdbcTemplate.queryForList(listItemSql);
		for (Map row : listDownItem) {
		if(!tempList.contains(((BigDecimal)(row.get("TYPEID"))))){
			tempList.add(((BigDecimal)(row.get("TYPEID"))));
		}
		}
		Collections.sort(tempList);
		return tempList;
	}
	private ArrayList<Object>	nonDomesticVehicles(int subCategoryID,String vehicleID,int lang, int typeID){

		String getSeat = null;
		String getUpperExteriorColor = null;
		String getExtraColumnHeader = null;
		String getInterior = null;
		String getExteriorColor = null;
		String getVehicle = null;
		String getLowerExteriorColor = null;
		String getPullDownItem =  null;
		String getInteriorColor = null;
		String getExtraColumnHeaderInfo = null;
		String getInteriorColorInfo = null;
		String getSecondaryPullDownItem = null;
		String getRestriction = null;
		//int typeID = 4;
		String getColumnsOption = null;


		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM v_division d, v_vehicle v, v_region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  v.localecode="+lang+" and r.localecode="+lang+" and d.localecode="+lang+" and" +
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";


		getSeat = "SELECT s.*, st.* , im.* "
				+ " FROM v_seat s, v_seattrim st, v_Images im"
				+ " WHERE (s.VehicleID =" + vehicleID + ") AND s.localecode="+lang+" AND st.localecode="+lang+" and"
				+ " (s.typeID = " + typeID + ") AND"
				+ " (s.seattrimid = st.seattrimid) AND im.localecode ="+lang+"  AND"
				+ " (s.imageid = im.imageid(+)) order by s.SEATSORT";


		getInterior = "SELECT DISTINCT i.*, st.seattrim, si.*,s.*, si.restrictionid as restriction"
				+ " FROM  v_seat s, seatinterior si, v_seattrim st, v_interior i, interiorRestriction ir "
				+ " WHERE"
				+ " (s.VehicleID = " + vehicleID + ") AND "
				+ " (s.typeID = " + typeID + ") AND 	i.localecode="+lang+" and"
				+ " (s.seatid = si.seatid) AND (s.seattrimid = st.seattrimid) and st.localecode="+lang+" and "
				+ "	(si.interiorid = i.interiorid) AND "
				+ " (ir.VehicleID(+) = " + vehicleID + ") AND s.localecode="+lang+" and "
				+ " (ir.typeID(+) = " + typeID + ") AND "
				+ " (ir.interiorid(+) = i.interiorid) ";


		getExteriorColor =	"SELECT vhec.* "
				+ "FROM  v_vehicleHasExteriorColor vhec  WHERE "
				+ "(vhec.VehicleID =" + vehicleID + ") AND Vhec.localecode ="+lang+""
				+ "and (vhec.typeID = " + typeID + ") order by ExteriorColorSort";

		getUpperExteriorColor = "SELECT vhec.vehicleHasexteriorColorid,vhec.extratext, ec.*, vhec.newoptionflag,vhec.restrictionid "
				+ " FROM  v_vehicleHasExteriorColor vhec, v_exteriorColor ec "
				+ " WHERE (vhec.VehicleID = " + vehicleID + ") AND ec.localecode="+lang+""
				+ " and Vhec.localecode ="+lang+" and (vhec.typeID = " + typeID + ") AND "
				+ " (vhec.upperExteriorColorID = ec.exteriorColorID) order by vhec.exteriorcolorsort";


		getLowerExteriorColor = "SELECT vhec.vehicleHasexteriorColorid, ec.* "
				+ " FROM  v_vehicleHasExteriorColor vhec, v_exteriorColor ec WHERE"
				+ " (vhec.VehicleID =" + vehicleID + ") AND ec.localecode="+lang+" and"
				+ " Vhec.localecode ="+lang+"    and (vhec.typeID = " + typeID + ") AND "
				+ " (vhec.lowerExteriorColorID = ec.exteriorColorID) ";

		getExtraColumnHeader = "SELECT vhec.vehicleHasExteriorColorID, ec.*, ech.*"
				+ "FROM  v_vehicleHasExteriorColor vhec, v_extraColumns ec, v_extraColumnHeader ech"
				+ "WHERE (vhec.VehicleID = " + vehicleID + ") AND ec.localecode="+lang+""
				+ " and ech.localecode="+lang+" and (vhec.typeID = " + typeID + ") AND "
				+ "(vhec.vehicleHasExteriorColorID = ec.vehicleHasExteriorColorID) AND Vhec.localecode ="+lang+""
				+ " and (ec.extraColumnHeaderID = ech.extraColumnHeaderID) order by extraColumnHeaderSort";


		getInteriorColor  = "SELECT vhec.vehicleHasexteriorColorid, ecai.*, i.*, ac.availableCodeName"
				+ " FROM  v_vehicleHasExteriorColor vhec, exteriorColorAvailableInterior ecai, "
				+ "v_interior i, v_AvailableCode ac WHERE "
				+ "(vhec.VehicleID = " + vehicleID + ") AND  ac.localecode="+lang+" and i.localecode="+lang+" and "
				+ "Vhec.localecode ="+lang+" and (vhec.typeID = " + typeID + ") AND"
				+ "(vhec.vehicleHasExteriorColorID = ecai.vehicleHasExteriorColorID) AND"
				+ " (ac.availableCodeID = ecai.availableCodeID) AND (ecai.interiorid = i.interiorid)";


		getInteriorColorInfo = "SELECT DISTINCT i.intcolorname,i.interiorid,  ints.interiorsort, ir.restrictionid "
				+ " FROM  seat s, seatinterior si, v_interior i, interiorSort ints, InteriorRestriction ir "
				+ " WHERE (s.VehicleID =" + vehicleID + ") AND (s.typeID = " + typeID + ") AND i.localecode="+lang+" and"
				+ " (s.seatid = si.seatid) AND (si.interiorid = i.interiorid) AND "
				+ "ints.VehicleID(+) = " + vehicleID + " AND (ir.VehicleID(+) =" + vehicleID + ") AND (ir.typeID(+) =" + typeID + ") AND"
				+ " (ir.InteriorID(+) =  i.interiorID) AND (i.interiorid = ints.interiorid(+)) order by ints.interiorsort " ;

		getExtraColumnHeaderInfo = "SELECT DISTINCT vhec.vehicleID, ech.*, ph.parentheaderid, ph.parentheadertext1, ph.parentheadertext2, ph.restrictionID AS restrictionPID " +
				" FROM  v_vehicleHasExteriorColor vhec, v_extraColumns ec, v_extraColumnHeader ech, v_parentHeader ph " +
				" WHERE " +
				" (vhec.VehicleID = " + vehicleID + ") AND  ec.localecode="+lang+" and ech.localecode="+lang+" and ph.localecode="+lang+" and" +
				" (vhec.typeID = " + typeID + ") AND Vhec.localecode ="+lang +
				" and (vhec.vehicleHasExteriorColorID = ec.vehicleHasExteriorColorID) AND " +
				" (ec.extraColumnHeaderID = ech.extraColumnHeaderID) AND " +
				" (ech.parentHeaderID = ph.parentHeaderID(+))";

		String sqlSubquery = "SELECT DISTINCT s.typeid FROM seat s " +
				" WHERE (s.VehicleID = " + vehicleID + ")";
		getPullDownItem = "SELECT pdi.*, (select count(*) from vehicleprojecttype vpt where vpt.vehicleid=pdi.vehicleid and vpt.projecttypeid=5) SEO FROM v_pullDownItem pdi where " +
				" (pdi.VehicleID = " + vehicleID + ") AND   pdi.typeid =" +typeID+ " AND pdi.localecode="+lang+" and " +
				" (pdi.typeid IN (" + sqlSubquery + "))";



		String sqlSubquery1 = "SELECT DISTINCT s.typeid FROM seat s " +
				" WHERE (s.VehicleID = " + vehicleID + ")";
		getSecondaryPullDownItem = "SELECT spdi.*, i.imageName FROM SecondaryPullDownItem spdi, PullDownItem pdi, Images i where " +
				" (pdi.VehicleID = " + vehicleID + ") " +
				" AND (pdi.typeid IN (" + sqlSubquery1 + ")) AND (pdi.PullDownItemID = spdi.PullDownItemID) " +
				" AND spdi.ImageID = i.ImageID(+)";

		getRestriction = "SELECT DISTINCT r.restrictionid, r.restrictionText, r.vehicleid, LPAD(r.restrictionsort, 3, '0') AS restrictionsort " +
				" FROM v_Vehicle v, v_pulldownitem pdi, v_Restriction r WHERE " +
				" (pdi.VehicleID = " + vehicleID + ") AND r.vehicleid= "+vehicleID+" AND (pdi.typeID = " + typeID + ") AND v.localecode="+lang+" and pdi.localecode="+lang+" and r.localecode="+lang+" and " +
				" (pdi.PullDownItemID = r.PullDownItemID) " +
				" order by restrictionsort";

		jdbcTemplate = new JdbcTemplate(dataSource);

		//table 1 
		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		List<Map<String, Object>> seat = jdbcTemplate.queryForList(getSeat);
		List<Map<String, Object>> interior = jdbcTemplate.queryForList(getInterior);

		List<Map<String, Object>> exteriorColor = jdbcTemplate.queryForList(getExteriorColor);
		List<Map<String, Object>> pullDownItem = jdbcTemplate.queryForList(getPullDownItem);
		List<Map<String, Object>> upperExteriorColor = jdbcTemplate.queryForList(getUpperExteriorColor);
		List<Map<String, Object>> lowerExteriorColor = jdbcTemplate.queryForList(getLowerExteriorColor);
		List<Map<String, Object>> interiorColor = jdbcTemplate.queryForList(getInteriorColor);
		List<Map<String, Object>> colorInfo = jdbcTemplate.queryForList(getInteriorColorInfo);
		List<Map<String, Object>> secondaryPullDownItem = jdbcTemplate.queryForList(getSecondaryPullDownItem);
		List<Map<String, Object>> restriction = jdbcTemplate.queryForList(getRestriction);

		HashSet FinalcolorHashset = new HashSet();
		Map<Long, ColorAndTrimBean> linkedHash = new LinkedHashMap <Long, ColorAndTrimBean>();
		Map<Long, String[]> colorLinkedHash = new LinkedHashMap<Long, String[]>();
		int count=0;

		String[] finalColorList1 = null ;

		colorTrimSeatList = new ArrayList<ColorAndTrimBean>();
		tempColorTrimSeatList= new ArrayList<ColorAndTrimBean>();
		Map<Long, String[]> colorDictionary = new HashMap<Long, String[]>();
		for (Map row : seat) {

			/*finalColorList1	= new String [5];
				for (int i = 0; i < finalColorList1.length; i++) {
					finalColorList1[i]= "--";
				}*/
			ColorAndTrimBean colorAndTrimBean = new ColorAndTrimBean();
			colorAndTrimBean.setSeatType((String.valueOf(row.get("SEATTYPE"))));
			colorAndTrimBean.setDecorLevel((String.valueOf(row.get("DECORLEVEL"))));
			colorAndTrimBean.setSeatTrim((String.valueOf(row.get("SEATTRIM"))));
			colorAndTrimBean.setSeatCode((String.valueOf(row.get("SEATCODE"))));
			colorAndTrimBean.setSeatID( (BigDecimal) ((row.get("SEATID"))));
			colorAndTrimBean.setSeatTrimID((String.valueOf(row.get("SEATTRIMID"))));
			colorAndTrimBean.setSeatTrimCode((String.valueOf(row.get("SEATTRIMCODE"))));
			colorAndTrimBean.setSeatTypeRestriction( (BigDecimal) ((row.get("SEATTYPERESTRICTIONID"))));
			colorAndTrimBean.setSeatSort((String.valueOf(row.get("SEATSORT"))));
			colorAndTrimBean.setSeatCodeRestrictionID((BigDecimal)(row.get("SEATCODERESTRICTIONID")));
			colorAndTrimBean.setSeatDecorLevelRestrictionID((BigDecimal)(row.get("DECORLEVELRESTRICTIONID")));


			long hashCodeGen = ((String.valueOf(row.get("DECORLEVEL"))) + (String.valueOf(row.get("SEATTYPE"))) + (String.valueOf(row.get("SEATCODE")))+
					(String.valueOf(row.get("SEATTRIM")))).hashCode();
			
			colorAndTrimBean.setHashCodeGen(hashCodeGen);
			/*
				linkedHash.put(hashCodeGen, colorAndTrimBean);
				colorDictionary.put(hashCodeGen, finalColorList1);*/
			/*	FinalcolorHashset.add(hashCodeGen);
				colorLinkedHash.put(hashCodeGen, colorAndTrimBean);
				colorDictionary.put(hashCodeGen, finalColorList1);*/
			tempColorTrimSeatList.add(colorAndTrimBean);
			boolean hashExist = false;
			for(ColorAndTrimBean col : colorTrimSeatList)
			{
				if(col.getHashCodeGen()==hashCodeGen){
					if(colorAndTrimBean.getSeatCodeRestrictionID()!=null) {
					col.setSeatCodeRestrictionID(colorAndTrimBean.getSeatCodeRestrictionID());
					}
					if(colorAndTrimBean.getSeatDecorLevelRestrictionID()!=null) {
						col.setSeatDecorLevelRestrictionID(colorAndTrimBean.getSeatDecorLevelRestrictionID());
						}
					hashExist = true;
				}
			}

			if(!hashExist){
				colorTrimSeatList.add(colorAndTrimBean);
			}
		}





		seatInteriorList = new ArrayList<ColorAndTrimHelper>();
		for (Map row : interior) {
			ColorAndTrimHelper colorAndTrimHelper = new ColorAndTrimHelper();
			colorAndTrimHelper.setInteriorID((BigDecimal)((row.get("INTERIORID"))));
			colorAndTrimHelper.setIntColorName((String.valueOf(row.get("INTCOLORNAME"))));
			colorAndTrimHelper.setIntColorCode((String.valueOf(row.get("INTCOLORCODE"))));
			colorAndTrimHelper.setSeatID( (BigDecimal)(row.get("SEATID")));
			colorAndTrimHelper.setRestrictionID((BigDecimal)(row.get("RESTRICTION")));
			long hashCodeGen = ((String.valueOf(row.get("DECORLEVEL"))) + (String.valueOf(row.get("SEATTYPE"))) + 
					(String.valueOf(row.get("SEATCODE"))+(String.valueOf(row.get("SEATTRIM"))))).hashCode();
			
			colorAndTrimHelper.setHashCodeGen(hashCodeGen);
			seatInteriorList.add(colorAndTrimHelper);
		}



		for (Map row : interior) {
			for (int i = 0; i < colorTrimSeatList.size(); i++) {
				if(colorTrimSeatList.get(i).getSeatID().toString().equals(((BigDecimal) row.get("SEATID")).toString())){
					String a = colorTrimSeatList.get(i).getSeatTrimCode();
					String b = (String.valueOf(row.get("INTCOLORCODE")));
					colorTrimSeatList.get(i).setIntColorName((String.valueOf(row.get("INTCOLORNAME"))));
					colorTrimSeatList.get(i).setIntColorCode((String.valueOf(row.get("INTCOLORCODE"))));
					colorTrimSeatList.get(i).setRponame(b + ""+ a);
					colorTrimSeatList.get(i).setRestrictionID((BigDecimal) row.get("RESTRICTIONID"));
				}
			}

		}

		getColumnsOption = "select * from columnstable where VehicleID = "+vehicleID+" and PDFTYPE = "+VehicleConstant.COLOR_AND_TRIM;
		for (Map row : pullDownItem) {
			if(row!=null && !row.isEmpty()){
				seatInteriorList.get(0).setPageLabel(" - "+String.valueOf(row.get("PULLDOWNTEXT")));
				seatInteriorList.get(0).setPulldownText(
						String.valueOf(row.get("OPTIONALFOOTERNOTE1")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE2")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE3")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE4")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE5")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE6")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE7")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE9")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE10")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE11")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE12")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE13")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE14")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE15")).trim()+"\n\n");
			}
		}



		for (Map row : vehicle) {

			seatInteriorList.get(0).setVehicleId((BigDecimal)row.get("VEHICLEID"));
			seatInteriorList.get(0).setVehicleName(String.valueOf(row.get("VEHICLENAME")));
			seatInteriorList.get(0).setRegionName(String.valueOf(row.get("REGIONNAME")));
			seatInteriorList.get(0).setVehicleYear((BigDecimal)(row.get("VEHICLEYEAR")));
			seatInteriorList.get(0).setDivisionName(String.valueOf(row.get("DIVISIONNAME")));
			seatInteriorList.get(0).setLocaleCode((BigDecimal)(row.get("LOCALECODE")));
			seatInteriorList.get(0).setRegionID((BigDecimal)(row.get("REGIONID")));
			seatInteriorList.get(0).setDivisionID((BigDecimal)(row.get("DIVISIONID")));

		}
		List<Map<String, Object>> columnsOption = jdbcTemplate.queryForList(getColumnsOption);
		if(seatInteriorList.size()>0){
			for (Map vehicleDetails : columnsOption) {
				seatInteriorList.get(0).setColumnBreak((BigDecimal)(vehicleDetails.get("COLUMNSTOSPLIT")));
				seatInteriorList.get(0).setIsLandscape((BigDecimal)(vehicleDetails.get("LANDSCAPE")));
			}
		}

		colorAndTrim_ExtList= new ArrayList<ColorAndTrimBean>();
		ColorAndTrimBean colorAndTrim_ExteriorBean = null;
		for (Map row : upperExteriorColor) {

			/*		finalColorList1	= new String [4];
				for (int i = 0; i < finalColorList1.length; i++) {
					finalColorList1[i]= "--";
				}*/


			colorAndTrim_ExteriorBean = new ColorAndTrimBean();
			colorAndTrim_ExteriorBean.setVehicleHasExteriorColorID((BigDecimal)(row.get("VEHICLEHASEXTERIORCOLORID")));
			colorAndTrim_ExteriorBean.setExteriorColorName((String.valueOf(row.get("EXTERIORCOLORNAME"))));
			colorAndTrim_ExteriorBean.setExteriorColorWanNumber((String.valueOf(row.get("EXTERIORCOLORWANUMBER"))));
			colorAndTrim_ExteriorBean.setNewoptionFlag((BigDecimal)(row.get("NEWOPTIONFLAG")));
			colorAndTrim_ExteriorBean.setExteriorColorCode((String.valueOf(row.get("EXTERIORCOLORCODE"))));
			colorAndTrim_ExteriorBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			colorAndTrim_ExteriorBean.setExtraText(String.valueOf(row.get("EXTRATEXT")));
			colorAndTrim_ExteriorBean.setExteriorColorID((BigDecimal)(row.get("EXTERIORCOLORID")));
			colorAndTrim_ExtList.add(colorAndTrim_ExteriorBean);

		} 

		colorTrimAvailablitys	 = new ArrayList<ColorTrimAvailabliltiy>();
		for (Map row : interiorColor) {
			//ColorCodeAvailableCode  
			//	ColorCodeAvailableCode = ArrayListMultimap.create();
			ColorTrimAvailabliltiy colorTrimAvailabliltiy = new ColorTrimAvailabliltiy();

			colorTrimAvailabliltiy.setVehicleHasExteriorColorID((BigDecimal)(row.get("VEHICLEHASEXTERIORCOLORID")));
			colorTrimAvailabliltiy.setIntColorName(String.valueOf(row.get("INTCOLORNAME")));
			colorTrimAvailabliltiy.setAvailableCodeName((String.valueOf(row.get("AVAILABLECODENAME"))));
			colorTrimAvailabliltiy.setInteriorID(((BigDecimal)(row.get("INTERIORID"))));
			colorTrimAvailabliltiy.setAvailableCodeID(((BigDecimal)(row.get("AVAILABLECODEID"))));
			colorTrimAvailabliltiy.setAvExtraText(String.valueOf(row.get("AVAILEXTRATEXT")));
			colorTrimAvailabliltiy.setRestrictionID((BigDecimal)row.get("RESTRICTIONID"));
			colorTrimAvailablitys.add(colorTrimAvailabliltiy);

		} 
		colorList = new ArrayList<ColorTrimAvailabliltiy>();
		List<String> colorListTemp = new ArrayList<String>();
		for (Map row : colorInfo) {
			ColorTrimAvailabliltiy colorTrimAvailabliltiy = new ColorTrimAvailabliltiy();

			//colorTrimAvailabliltiy.setVehicleID((BigDecimal)(row.get("VEHICLEID")));
			colorTrimAvailabliltiy.setInteriorID(((BigDecimal)(row.get("INTERIORID"))));	
			colorTrimAvailabliltiy.setIntColorName(String.valueOf(row.get("INTCOLORNAME")));
			colorTrimAvailabliltiy.setIntSort(String.valueOf(row.get("INTERIORSORT")));
			colorTrimAvailabliltiy.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			//colorTrimAvailabliltiy.setIntColorCode((String.valueOf(row.get("INTCOLORCODE"))));
			if(!colorListTemp.contains(String.valueOf(row.get("INTCOLORNAME")))){
				colorList.add(colorTrimAvailabliltiy);
			}
			else if(colorListTemp.contains(String.valueOf(row.get("INTCOLORNAME")))) {
				for (ColorTrimAvailabliltiy colorTrim : colorList) {
					if(colorTrim.getIntColorName().equals(String.valueOf(row.get("INTCOLORNAME")))){
						
						if(colorTrim.getIntSort().compareTo(String.valueOf(row.get("INTERIORSORT")))>0) {
							colorTrim.setInteriorID(((BigDecimal)(row.get("INTERIORID"))));
							colorTrim.setIntSort(String.valueOf(row.get("INTERIORSORT")));
						}
						if((BigDecimal)(row.get("RESTRICTIONID"))!=null){
							colorTrim.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
						}
					}
				}
				
			}
			colorListTemp.add(String.valueOf(row.get("INTCOLORNAME")));

		} 
		
		


		colorRestrictionList = new 	ArrayList<ColorRestrictionBean>();



		for (Map row : restriction) {

			ColorRestrictionBean colorRestrictionBean = new ColorRestrictionBean();

			colorRestrictionBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			colorRestrictionBean.setRestriction(String.valueOf(row.get("RESTRICTIONTEXT")));

			colorRestrictionList.add(colorRestrictionBean);

		} 


		finaList = new ArrayList<Object>();
		//table 1
		finaList.add(seatInteriorList);//color right hand jet black
		finaList.add(linkedHash);//content foot bucket //common in both tables
		finaList.add(colorList);//distinct color list
		finaList.add(colorTrimSeatList);//seat avaialblilty

		//table 2 
		finaList.add(colorAndTrim_ExtList);//iridiscent pearl
		finaList.add(colorTrimAvailablitys);//availability  table = createTable2(colorAndTrim_ExtList, colorTrimAvailablitys, colorList);

		//footer
		finaList.add(colorRestrictionList);
		finaList.add(tempColorTrimSeatList);
		return (ArrayList<Object>) finaList;

	}



	private ArrayList<Object> domesticVehicles(int subCategoryID,String vehicleID,int lang,int typeID){

		String getSeat = null;
		String getUpperExteriorColor = null;
		String getExtraColumnHeader = null;
		String getInterior = null;
		String getExteriorColor = null;
		String getVehicle = null;
		String getLowerExteriorColor = null;
		String getPullDownItem =  null;
		String getInteriorColor = null;
		String getExtraColumnHeaderInfo = null;
		String getInteriorColorInfo = null;
		String getSecondaryPullDownItem = null;
		String getRestriction = null;
		String getColumnsOption = null;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";


		getSeat = "SELECT s.*, st.* , im.* "
				+ " FROM seat s, seattrim st, Images im"
				+ " WHERE (s.VehicleID =" + vehicleID + ") and  "
				+ " (s.typeID = " + typeID + ") AND"
				+ " (s.seattrimid = st.seattrimid)  AND"
				+ " (s.imageid = im.imageid(+)) order by s.SEATSORT";


		getInterior = "SELECT DISTINCT i.*, st.seattrim, si.*,s.*,si.restrictionid as restriction "
				+ " FROM  seat s, seatinterior si, seattrim st, interior i, interiorRestriction ir "
				+ " WHERE"
				+ " (s.VehicleID = " + vehicleID + ") AND "
				+ " (s.typeID = " + typeID + ") and "
				+ " (s.seatid = si.seatid) AND  (s.seattrimid = st.seattrimid) and "
				+ "	(si.interiorid = i.interiorid) AND "
				+ " (ir.VehicleID(+) = " + vehicleID + ") AND "
				+ " (ir.typeID(+) = " + typeID + ") AND "
				+ " (ir.interiorid(+) = i.interiorid) ";


		getExteriorColor =	"SELECT vhec.* "
				+ "FROM  vehicleHasExteriorColor vhec  WHERE "
				+ "(vhec.VehicleID =" + vehicleID + ") "
				+ "and (vhec.typeID = " + typeID + ") order by ExteriorColorSort";


		getUpperExteriorColor = "SELECT vhec.vehicleHasexteriorColorid,vhec.extratext, ec.*, vhec.newoptionflag,vhec.restrictionid "
				+ " FROM  vehicleHasExteriorColor vhec, exteriorColor ec "
				+ "WHERE (vhec.VehicleID = " + vehicleID + ") AND "
				+ "  (vhec.typeID = " + typeID + ") AND "
				+ "(vhec.upperExteriorColorID = ec.exteriorColorID) order by vhec.exteriorcolorsort";


		getLowerExteriorColor = "SELECT vhec.vehicleHasexteriorColorid, ec.* "
				+ " FROM  vehicleHasExteriorColor vhec, exteriorColor ec WHERE"
				+ " (vhec.VehicleID =" + vehicleID + ") and"
				+ " (vhec.typeID = " + typeID + ") AND "
				+ " (vhec.lowerExteriorColorID = ec.exteriorColorID) ";

		getExtraColumnHeader = "SELECT vhec.vehicleHasExteriorColorID, ec.*, ech.*"
				+ " FROM  vehicleHasExteriorColor vhec, extraColumns ec, extraColumnHeader ech"
				+ " WHERE (vhec.VehicleID = " + vehicleID + ") "
				+ "   and (vhec.typeID = " + typeID + ") AND "
				+ " (vhec.vehicleHasExteriorColorID = ec.vehicleHasExteriorColorID) AND "
				+ "  (ec.extraColumnHeaderID = ech.extraColumnHeaderID) order by extraColumnHeaderSort";


		getInteriorColor  = "SELECT vhec.vehicleHasexteriorColorid, ecai.*, i.intcolorname,i.intcolorcode, ac.availableCodeName"
				+ " FROM  vehicleHasExteriorColor vhec, exteriorColorAvailableInterior ecai, "
				+ " interior i, AvailableCode ac WHERE "
				+ "(vhec.VehicleID = " + vehicleID + ")  "
				+ " and (vhec.typeID = " + typeID + ") AND"
				+ "(vhec.vehicleHasExteriorColorID = ecai.vehicleHasExteriorColorID) AND"
				+ " (ac.availableCodeID = ecai.availableCodeID) AND (ecai.interiorid = i.interiorid)";

		getInteriorColorInfo = "SELECT DISTINCT s.vehicleid, i.*, ints.interiorSort, ir.restrictionID" +
				" FROM  seat s, seatinterior si, interior i, interiorSort ints, InteriorRestriction ir " +
				" WHERE " +
				" (s.VehicleID = " + vehicleID + ") AND " +
				" (s.typeID = " + typeID + ") AND " +
				" (s.seatid = si.seatid) AND " +
				" (si.interiorid = i.interiorid) AND " +
				" (ints.VehicleID(+) = " + vehicleID + ") AND " +
				" (ir.VehicleID(+) = " + vehicleID + ") AND " +
				" (ir.typeID(+) = " + typeID + ") AND " +
				" (ir.InteriorID(+) =  i.interiorID) AND " +
				" (i.interiorid = ints.interiorid(+)) ";

		getExtraColumnHeaderInfo = "SELECT DISTINCT vhec.vehicleID, ech.*, ph.parentheaderid, ph.parentheadertext1, ph.parentheadertext2, ph.restrictionID AS restrictionPID " +
				" FROM  vehicleHasExteriorColor vhec, extraColumns ec, extraColumnHeader ech, parentHeader ph " +
				" WHERE " +
				" (vhec.VehicleID = " + vehicleID + ")  and " +
				" (vhec.typeID = " + typeID + ") AND "+
				" and (vhec.vehicleHasExteriorColorID = ec.vehicleHasExteriorColorID) AND " +
				" (ec.extraColumnHeaderID = ech.extraColumnHeaderID) AND " +
				" (ech.parentHeaderID = ph.parentHeaderID(+))";

		String sqlSubquery = "SELECT DISTINCT s.typeid FROM seat s " +
				" WHERE (s.VehicleID = " + vehicleID + ")";


		getPullDownItem = "SELECT pdi.*, (select count(*) from vehicleprojecttype vpt where vpt.vehicleid=pdi.vehicleid and vpt.projecttypeid=5) SEO FROM pullDownItem pdi where " +
				" (pdi.VehicleID = " + vehicleID + ") AND   pdi.typeid =" +typeID+
				" and (pdi.typeid IN (" + sqlSubquery + "))";



		String sqlSubquery1 = "SELECT DISTINCT s.typeid FROM seat s " +
				" WHERE (s.VehicleID = " + vehicleID + ")";
		getSecondaryPullDownItem = "SELECT spdi.*, i.imageName FROM SecondaryPullDownItem spdi, PullDownItem pdi, Images i where " +
				" (pdi.VehicleID = " + vehicleID + ") " +
				" AND (pdi.typeid IN (" + sqlSubquery1 + ")) AND (pdi.PullDownItemID = spdi.PullDownItemID) " +
				" AND spdi.ImageID = i.ImageID(+)";

		getRestriction = "SELECT DISTINCT r.restrictionid, r.restrictionText, r.vehicleid, LPAD(r.restrictionsort, 3, '0') AS restrictionsort " +
				" FROM Vehicle v, pulldownitem pdi, Restriction r WHERE " +
				" (pdi.VehicleID = " + vehicleID + ") AND r.vehicleid= "+vehicleID+" AND  (pdi.typeID = " + typeID + ") AND  " +
				" (pdi.PullDownItemID = r.PullDownItemID) " +
				" order by restrictionsort";

		String getExtraColor = "SELECT  distinct ech.extracolumnheadertext1, extraColumnHeaderSort,ec.extracolumnheaderid,vhec.typeid "
				+ " FROM  vehicleHasExteriorColor vhec, extraColumns ec, extraColumnHeader ech"
				+ " WHERE	(vhec.VehicleID ="+vehicleID+") AND	 (vhec.typeID ="+typeID+") AND"
				+ " (vhec.vehicleHasExteriorColorID = ec.vehicleHasExteriorColorID) AND"
				+ " (ec.extraColumnHeaderID = ech.extraColumnHeaderID) order by extraColumnHeaderSort";

		jdbcTemplate = new JdbcTemplate(dataSource);

		//table 1 
		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		List<Map<String, Object>> seat = jdbcTemplate.queryForList(getSeat);
		List<Map<String, Object>> interior = jdbcTemplate.queryForList(getInterior);

		List<Map<String, Object>> exteriorColor = jdbcTemplate.queryForList(getExteriorColor);
		List<Map<String, Object>> pullDownItem = jdbcTemplate.queryForList(getPullDownItem);
		List<Map<String, Object>> upperExteriorColor = jdbcTemplate.queryForList(getUpperExteriorColor);
		List<Map<String, Object>> lowerExteriorColor = jdbcTemplate.queryForList(getLowerExteriorColor);
		List<Map<String, Object>> interiorColor = jdbcTemplate.queryForList(getInteriorColor);
		List<Map<String, Object>> colorInfo = jdbcTemplate.queryForList(getInteriorColorInfo);
		List<Map<String, Object>> secondaryPullDownItem = jdbcTemplate.queryForList(getSecondaryPullDownItem);
		List<Map<String, Object>> restriction = jdbcTemplate.queryForList(getRestriction);
		List<Map<String, Object>> extraColumnHeader = jdbcTemplate.queryForList(getExtraColumnHeader);
		List<Map<String, Object>> extraColor = jdbcTemplate.queryForList(getExtraColor);

		HashSet FinalcolorHashset = new HashSet();
		Map<Long, ColorAndTrimBean> linkedHash = new LinkedHashMap <Long, ColorAndTrimBean>();
		Map<Long, String[]> colorLinkedHash = new LinkedHashMap<Long, String[]>();
		int count=0;

		String[] finalColorList1 = null ;

		colorTrimSeatList = new ArrayList<ColorAndTrimBean>();
		tempColorTrimSeatList= new ArrayList<ColorAndTrimBean>();
		Map<Long, String[]> colorDictionary = new HashMap<Long, String[]>();
		for (Map row : seat) {

			/*finalColorList1	= new String [5];
				for (int i = 0; i < finalColorList1.length; i++) {
					finalColorList1[i]= "--";
				}*/
			ColorAndTrimBean colorAndTrimBean = new ColorAndTrimBean();
			colorAndTrimBean.setSeatType((String.valueOf(row.get("SEATTYPE"))));
			colorAndTrimBean.setDecorLevel((String.valueOf(row.get("DECORLEVEL"))));
			colorAndTrimBean.setSeatTrim((String.valueOf(row.get("SEATTRIM"))));
			colorAndTrimBean.setSeatCode((String.valueOf(row.get("SEATCODE"))));
			colorAndTrimBean.setSeatID( (BigDecimal) ((row.get("SEATID"))));
			colorAndTrimBean.setSeatTrimID((String.valueOf(row.get("SEATTRIMID"))));
			colorAndTrimBean.setSeatTrimCode((String.valueOf(row.get("SEATTRIMCODE"))));
			colorAndTrimBean.setSeatTypeRestriction( (BigDecimal) ((row.get("SEATTYPERESTRICTIONID"))));
			colorAndTrimBean.setSeatSort((String.valueOf(row.get("SEATSORT"))));
			colorAndTrimBean.setSeatCodeRestrictionID((BigDecimal)(row.get("SEATCODERESTRICTIONID")));
			colorAndTrimBean.setSeatDecorLevelRestrictionID((BigDecimal)(row.get("DECORLEVELRESTRICTIONID")));

			long hashCodeGen = ((String.valueOf(row.get("DECORLEVEL"))) + (String.valueOf(row.get("SEATTYPE"))) + (String.valueOf(row.get("SEATCODE")))+
					(String.valueOf(row.get("SEATTRIM")))).hashCode();

			colorAndTrimBean.setHashCodeGen(hashCodeGen);
			/*
				linkedHash.put(hashCodeGen, colorAndTrimBean);
				colorDictionary.put(hashCodeGen, finalColorList1);*/
			/*	FinalcolorHashset.add(hashCodeGen);
				colorLinkedHash.put(hashCodeGen, colorAndTrimBean);
				colorDictionary.put(hashCodeGen, finalColorList1);*/
			tempColorTrimSeatList.add(colorAndTrimBean);
			boolean hashExist = false;
			for(ColorAndTrimBean col : colorTrimSeatList)
			{
				if(col.getHashCodeGen()==hashCodeGen){
					if(colorAndTrimBean.getSeatCodeRestrictionID()!=null) {
					col.setSeatCodeRestrictionID(colorAndTrimBean.getSeatCodeRestrictionID());
					}
					if(colorAndTrimBean.getSeatDecorLevelRestrictionID()!=null) {
						col.setSeatDecorLevelRestrictionID(colorAndTrimBean.getSeatDecorLevelRestrictionID());
						}
					hashExist = true;
				}
			}

			if(!hashExist){
				colorTrimSeatList.add(colorAndTrimBean);
			}
		}




		seatInteriorList = new ArrayList<ColorAndTrimHelper>();
		for (Map row : interior) {
			ColorAndTrimHelper colorAndTrimHelper = new ColorAndTrimHelper();
			colorAndTrimHelper.setInteriorID((BigDecimal)((row.get("INTERIORID"))));
			colorAndTrimHelper.setIntColorName((String.valueOf(row.get("INTCOLORNAME"))));
			colorAndTrimHelper.setIntColorCode((String.valueOf(row.get("INTCOLORCODE"))));
			colorAndTrimHelper.setSeatID( (BigDecimal)(row.get("SEATID")));
			colorAndTrimHelper.setRestrictionID((BigDecimal)(row.get("RESTRICTION")));
			long hashCodeGen = ((String.valueOf(row.get("DECORLEVEL"))) + (String.valueOf(row.get("SEATTYPE"))) + 
					(String.valueOf(row.get("SEATCODE"))+(String.valueOf(row.get("SEATTRIM"))))).hashCode();

			colorAndTrimHelper.setHashCodeGen(hashCodeGen);
			seatInteriorList.add(colorAndTrimHelper);
		}



		for (Map row : interior) {
			for (int i = 0; i < colorTrimSeatList.size(); i++) {
				if(colorTrimSeatList.get(i).getSeatID().toString().equals(((BigDecimal) row.get("SEATID")).toString())){
					String a = colorTrimSeatList.get(i).getSeatTrimCode();
					String b = (String.valueOf(row.get("INTCOLORCODE")));
					colorTrimSeatList.get(i).setIntColorName((String.valueOf(row.get("INTCOLORNAME"))));
					colorTrimSeatList.get(i).setIntColorCode((String.valueOf(row.get("INTCOLORCODE"))));
					colorTrimSeatList.get(i).setRponame(b + ""+ a);
					colorTrimSeatList.get(i).setRestrictionID((BigDecimal) row.get("RESTRICTIONID"));
				}
			}

		}

		getColumnsOption = "select * from columnstable where VehicleID = "+vehicleID+" and PDFTYPE = "+VehicleConstant.COLOR_AND_TRIM;

		for (Map row : pullDownItem) {
			if(row!=null && !row.isEmpty()){
				seatInteriorList.get(0).setPageLabel(" - "+String.valueOf(row.get("PULLDOWNTEXT")));
				seatInteriorList.get(0).setPulldownText(
						String.valueOf(row.get("OPTIONALFOOTERNOTE1")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE2")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE3")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE4")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE5")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE6")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE7")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE9")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE10")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE11")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE12")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE13")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE14")).trim()+"\n\n"+
								String.valueOf(row.get("OPTIONALFOOTERNOTE15")).trim()+"\n\n");
			}
		}

		for (Map row : vehicle) {
			if(seatInteriorList.size()>0){
				seatInteriorList.get(0).setVehicleId((BigDecimal)row.get("VEHICLEID"));
				seatInteriorList.get(0).setVehicleName(String.valueOf(row.get("VEHICLENAME")));
				seatInteriorList.get(0).setRegionName(String.valueOf(row.get("REGIONNAME")));
				seatInteriorList.get(0).setVehicleYear((BigDecimal)(row.get("VEHICLEYEAR")));
				seatInteriorList.get(0).setDivisionName(String.valueOf(row.get("DIVISIONNAME")));
				seatInteriorList.get(0).setLocaleCode((BigDecimal)(row.get("LOCALECODE")));
				seatInteriorList.get(0).setRegionID((BigDecimal)(row.get("REGIONID")));
				seatInteriorList.get(0).setDivisionID((BigDecimal)(row.get("DIVISIONID")));
			}
		}
		List<Map<String, Object>> columnsOption = jdbcTemplate.queryForList(getColumnsOption);
		if(seatInteriorList.size()>0){
			for (Map vehicleDetails : columnsOption) {
				seatInteriorList.get(0).setColumnBreak((BigDecimal)(vehicleDetails.get("COLUMNSTOSPLIT")));
				seatInteriorList.get(0).setIsLandscape((BigDecimal)(vehicleDetails.get("LANDSCAPE")));
			}
		}

		colorAndTrim_ExtList= new ArrayList<ColorAndTrimBean>();
		ColorAndTrimBean colorAndTrim_ExteriorBean = null;
		for (Map row : upperExteriorColor) {

			/*		finalColorList1	= new String [4];
				for (int i = 0; i < finalColorList1.length; i++) {
					finalColorList1[i]= "--";
				}*/


			colorAndTrim_ExteriorBean = new ColorAndTrimBean();
			colorAndTrim_ExteriorBean.setVehicleHasExteriorColorID((BigDecimal)(row.get("VEHICLEHASEXTERIORCOLORID")));
			colorAndTrim_ExteriorBean.setExteriorColorName((String.valueOf(row.get("EXTERIORCOLORNAME"))));
			colorAndTrim_ExteriorBean.setExteriorColorWanNumber((String.valueOf(row.get("EXTERIORCOLORWANUMBER"))));
			colorAndTrim_ExteriorBean.setNewoptionFlag((BigDecimal)(row.get("NEWOPTIONFLAG")));
			colorAndTrim_ExteriorBean.setExtraText(String.valueOf(row.get("EXTRATEXT")));
			colorAndTrim_ExteriorBean.setExteriorColorCode((String.valueOf(row.get("EXTERIORCOLORCODE"))));
			colorAndTrim_ExteriorBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			

			colorAndTrim_ExtList.add(colorAndTrim_ExteriorBean);

		} 

		colorTrimAvailablitys	 = new ArrayList<ColorTrimAvailabliltiy>();
		for (Map row : interiorColor) {
			//ColorCodeAvailableCode  
			//	ColorCodeAvailableCode = ArrayListMultimap.create();
			ColorTrimAvailabliltiy colorTrimAvailabliltiy = new ColorTrimAvailabliltiy();

			colorTrimAvailabliltiy.setVehicleHasExteriorColorID((BigDecimal)(row.get("VEHICLEHASEXTERIORCOLORID")));
			colorTrimAvailabliltiy.setIntColorName(String.valueOf(row.get("INTCOLORNAME")));
			colorTrimAvailabliltiy.setAvailableCodeName((String.valueOf(row.get("AVAILABLECODENAME"))));
			colorTrimAvailabliltiy.setAvailableCodeID(((BigDecimal)(row.get("AVAILABLECODEID"))));
			colorTrimAvailabliltiy.setInteriorID(((BigDecimal)(row.get("INTERIORID"))));
			colorTrimAvailabliltiy.setAvExtraText(String.valueOf(row.get("AVAILEXTRATEXT")));
			colorTrimAvailabliltiy.setRestrictionID((BigDecimal)row.get("RESTRICTIONID"));
			colorTrimAvailablitys.add(colorTrimAvailabliltiy);

		} 
		colorList = new ArrayList<ColorTrimAvailabliltiy>();
		List<String> colorListTemp = new ArrayList<String>();
		
		for (Map row : colorInfo) {
			ColorTrimAvailabliltiy colorTrimAvailabliltiy = new ColorTrimAvailabliltiy();

			//colorTrimAvailabliltiy.setVehicleID((BigDecimal)(row.get("VEHICLEID")));
			colorTrimAvailabliltiy.setInteriorID(((BigDecimal)(row.get("INTERIORID"))));	
			colorTrimAvailabliltiy.setIntColorName(String.valueOf(row.get("INTCOLORNAME")));
			colorTrimAvailabliltiy.setIntSort(String.valueOf(row.get("INTERIORSORT")));
			colorTrimAvailabliltiy.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			//colorTrimAvailabliltiy.setIntColorCode((String.valueOf(row.get("INTCOLORCODE"))));
			if(!colorListTemp.contains(String.valueOf(row.get("INTCOLORNAME")))){
				colorList.add(colorTrimAvailabliltiy);
			}
			//additional internalsorting
			else if(colorListTemp.contains(String.valueOf(row.get("INTCOLORNAME")))) {
				for (ColorTrimAvailabliltiy colorTrim : colorList) {
					if(colorTrim.getIntColorName().equals(String.valueOf(row.get("INTCOLORNAME")))){
						
						if(colorTrim.getIntSort().compareTo(String.valueOf(row.get("INTERIORSORT")))>0) {
							colorTrim.setInteriorID(((BigDecimal)(row.get("INTERIORID"))));
							colorTrim.setIntSort(String.valueOf(row.get("INTERIORSORT")));
						}
						if((BigDecimal)(row.get("RESTRICTIONID"))!=null){
							colorTrim.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
						}
					}
				}
				
			}
			colorListTemp.add(String.valueOf(row.get("INTCOLORNAME")));

		} 

		for (Map row : extraColor) {
			ColorTrimAvailabliltiy colorTrimAvailabliltiy = new ColorTrimAvailabliltiy();

			colorTrimAvailabliltiy.setIntColorName(String.valueOf(row.get("EXTRACOLUMNHEADERTEXT1")));
			colorTrimAvailabliltiy.setIntSort(String.valueOf(row.get("EXTRACOLUMNHEADERSORT")));
			colorTrimAvailabliltiy.setInteriorID(((BigDecimal)(row.get("EXTRACOLUMNHEADERID"))));	
			colorTrimAvailabliltiy.setTypeId(((BigDecimal)(row.get("TYPEID"))));
			colorTrimAvailabliltiy.setAvailableCodeName(String.valueOf(row.get("EXTRACOLUMNTEXT1")));
			colorTrimAvailabliltiy.setExtraColumn(true);
			if(!colorListTemp.contains(String.valueOf(row.get("EXTRACOLUMNHEADERTEXT1")))){
				colorList.add(colorTrimAvailabliltiy);
			}

		}

		colorRestrictionList = new 	ArrayList<ColorRestrictionBean>();



		for (Map row : restriction) {

			ColorRestrictionBean colorRestrictionBean = new ColorRestrictionBean();

			colorRestrictionBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			colorRestrictionBean.setRestriction(String.valueOf(row.get("RESTRICTIONTEXT")));

			colorRestrictionList.add(colorRestrictionBean);

		} 




		extraHeaderAvailablitys =  new 	ArrayList<ExtraColumnsHeaderBean>();
		for (Map row : extraColumnHeader) {
			//ColorCodeAvailableCode  
			//	ColorCodeAvailableCode = ArrayListMultimap.create();
			ColorTrimAvailabliltiy colorTrimAvailabliltiy = new ColorTrimAvailabliltiy();

			colorTrimAvailabliltiy.setVehicleHasExteriorColorID((BigDecimal)(row.get("VEHICLEHASEXTERIORCOLORID")));
			colorTrimAvailabliltiy.setIntColorName(String.valueOf(row.get("EXTRACOLUMNHEADERTEXT")));
			//colorTrimAvailabliltiy.setAvailableCodeName((String.valueOf(row.get("AVAILABLECODENAME"))));
			colorTrimAvailabliltiy.setAvailableCodeID(((BigDecimal)(row.get("AVAILABLECODEID"))));
			colorTrimAvailabliltiy.setInteriorID(((BigDecimal)(row.get("EXTRACOLUMNHEADERID"))));
			colorTrimAvailabliltiy.setAvExtraText(String.valueOf(row.get("AVAILEXTRATEXT")));
			colorTrimAvailabliltiy.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			colorTrimAvailabliltiy.setAvailableCodeName(String.valueOf(row.get("EXTRACOLUMNTEXT1")));

			colorTrimAvailablitys.add(colorTrimAvailabliltiy);

		}

		/*	
			for (Map row : extraColumnHeader) {

				ExtraColumnsHeaderBean extraColumnsHeaderBean = new ExtraColumnsHeaderBean();

				extraColumnsHeaderBean.setVehicleHasExteriorColorID((BigDecimal)(row.get("VEHICLEHASEXTERIORCOLORID")));
				extraColumnsHeaderBean.setExtraColumnText(String.valueOf(row.get("VEHICLEHASEXTERIORCOLORID")));
				extraColumnsHeaderBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
				extraColumnsHeaderBean.setExtraColumnHeaderID((BigDecimal)(row.get("EXTRACOLUMNHEADERID")));
				extraColumnsHeaderBean.setExtraColumnText(String.valueOf(row.get("EXTRACOLUMNTEXT")));
				extraColumnsHeaderBean.setExtraHeaderText(String.valueOf(row.get("EXTRACOLUMNHEADERTEXT")));
			//	extraColumnsHeaderBean.setRestriction(String.valueOf(row.get("RESTRICTIONTEXT")));
				extraHeaderAvailablitys.add(extraColumnsHeaderBean);

			}*/ 

		finaList = new ArrayList<Object>();
		//table 1
		finaList.add(seatInteriorList);//color right hand jet black
		finaList.add(linkedHash);//content foot bucket //common in both tables
		finaList.add(colorList);//distinct color list
		finaList.add(colorTrimSeatList);//seat avaialblilty

		//table 2 
		finaList.add(colorAndTrim_ExtList);//iridiscent pearl
		finaList.add(colorTrimAvailablitys);//availability  table = createTable2(colorAndTrim_ExtList, colorTrimAvailablitys, colorList);

		//footer
		finaList.add(colorRestrictionList);
		finaList.add(tempColorTrimSeatList);
		//	finaList.add(extraHeaderAvailablitys);
		return (ArrayList<Object>) finaList;



	}



	public List<String> getAVehicles() {
		List<String> listVehicles = new ArrayList<String>();
		Query query = null;
		String sql = null;

		try{

			query = new Query();

			//sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 and VEHICLEID=17008";

			sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 AND REGIONID =14";
			jdbcTemplate = new JdbcTemplate(dataSource);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
			for (Map row : rows) {
				listVehicles.add((String.valueOf(row.get("VehicleID"))));
			}

			return listVehicles;
		}

		catch(Exception e ){
			System.out.println("Exception" +e);
		}
		return listVehicles;

	}


}
