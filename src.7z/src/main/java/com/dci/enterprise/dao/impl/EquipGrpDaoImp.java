package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.EqpGrpDAO;
import com.dci.enterprise.dao.StandardEqpDAO;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.StandardEqpBean;
import com.dci.enterprise.model.StdEqpHelper;
import com.dci.general.utilities.VehicleConstant;

public class EquipGrpDaoImp implements EqpGrpDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private int pageNumber = 1;
	List<StandardEqpBean> standardEqpBeanHeaderlist = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentlist1 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentlist2 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentlist3 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentlist4 = new ArrayList<StandardEqpBean>();

	List<StdEqpHelper> stdEqpHelperList = new ArrayList<StdEqpHelper>();

	List<StandardEqpBean> standardEqpBeanContentAvailabilty1 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentAvailabilty2 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentAvailabilty3 = new ArrayList<StandardEqpBean>();
	List<StandardEqpBean> standardEqpBeanContentAvailabilty4 = new ArrayList<StandardEqpBean>();
	static public List<ArrayList<BigDecimal>> modelList = null;
	static public List<ArrayList<BigDecimal>> ListPackage= null;
	static	HashMap<BigDecimal,ArrayList<String>>  packageDescTextMap = new HashMap<BigDecimal, ArrayList<String>>();
	static List<HashMap <BigDecimal,ArrayList<String>>> packageNameMap =null;
	static	Object [][] standardEqpBeanArr =null;
	static public ArrayList<BigDecimal> modelListTemp = null;
	static String vehicleID=null;
	List<List<StandardEqpBean>> finalList = new ArrayList<List<StandardEqpBean>>();
	static boolean isCanada=false;
	static boolean isVehicleActive=false;
	static int lang=1;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	String getVehicle = null;
	String getColumnsOption = null;
	public Object[][] getVehicleItemsXML(int subCategoryID, String availCode_SQLCondition,String availCode_Sort, String vehicleID,int lang) {

		this.lang = lang;

		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		query = new Query();
		this.vehicleID= vehicleID;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d,vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);

		for (Map row : vehicle) {

			if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

				isCanada= true;
			}
			else{
				isCanada=false;
			}

			if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

				isVehicleActive= true;
			}
			else{
				isVehicleActive=false;
			}


		}

		if(isVehicleActive){
			if(isCanada)
			{
				log.info("VEHICLE is in Canadian Region");
				nonDomesticVehicles(subCategoryID, availCode_SQLCondition, availCode_Sort,  vehicleID, lang);	

			}
			else{
				log.info("VEHICLE is in non-Canadian Region");
				domesticVehicles(subCategoryID, availCode_SQLCondition, availCode_Sort,  vehicleID, lang);	
			}


		}
		else{
			log.error("VEHICLE NOT ACTIVE");
		}
		return standardEqpBeanArr;

	}




	private void tableContent( String vehicleID2, int lang,
			String availCode_SQLCondition, String availCode_Sort) {
		List<StandardEqpBean> standardEqpBeanContentAvailabilty1 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentAvailabilty2 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentAvailabilty3 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentAvailabilty4 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist1 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist2 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist3 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist4 = new ArrayList<StandardEqpBean>();
	}





	public ArrayList<String> getPackageName(BigDecimal modelId,String vehicleID){
		ArrayList<String> arrayList = new ArrayList<String>();
		String getpackageNames = "  SELECT DISTINCT m.*, p.*, pl.*, pd.*, pr.*  " 
				+ " FROM v_package p, v_model m, v_pagelabel pl, v_packagedesc pd, v_packagerestriction pr WHERE "
				+ " (m.VehicleID = "+vehicleID+") AND "
				+ " (p.modelID = m.modelID)  AND m.localecode="+lang+" and "
				+ " pl.localecode="+lang+" and pd.localecode(+)="+lang+" and p.localecode="+lang+" and pr.localecode(+)="+lang+" and " 
				+ " (p.pagelabelid = pl.pagelabelid) AND p.packageDescid ="+modelId 
				+ " and (p.packageDescid = pd.packageDescid(+)) AND"
				+ " (p.packageRestrictionid = pr.packageRestrictionid(+))"
				+ "ORDER BY p.pageNumber, pd.packagedescsort, p.packagesort";

		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getpackageNames);
		for (Map row : modelIDList) {
			arrayList.add((String.valueOf(row.get("PACKAGENAME"))));	

		}
		return arrayList; 
	}


	public List<ArrayList<BigDecimal>> getModelList(){
		return modelList;
	}

	public Object[][] getAvaialableCode() {

		return standardEqpBeanArr;

	}

	public List<HashMap<BigDecimal, ArrayList<String>>>  getPackageList(){
		return packageNameMap;
	}

	public List<StdEqpHelper>  getPackageDescText(){
		String getpackageNames= null;
		stdEqpHelperList = new ArrayList<StdEqpHelper>();

		if(isVehicleActive){

			if(isCanada){
				getpackageNames = "  SELECT DISTINCT m.*, p.*, pl.*, pd.*, pr.*  " 
						+ " FROM v_package p, v_model m, v_pagelabel pl, v_packagedesc pd, v_packagerestriction pr WHERE "
						+ " (m.VehicleID = "+vehicleID+") AND "
						+ " (p.modelID = m.modelID)  AND m.localecode="+lang+" and "
						+ " pl.localecode="+lang+" and pd.localecode(+)="+lang+" and p.localecode="+lang+" and pr.localecode(+)="+lang+" and " 
						+ " (p.pagelabelid = pl.pagelabelid) "
						+ " and (p.packageDescid = pd.packageDescid(+)) AND"
						+ " (p.packageRestrictionid = pr.packageRestrictionid(+)) ORDER BY p.pageNumber, pd.packagedescsort, p.packagesort";

			}

			else
			{
				getpackageNames = "SELECT DISTINCT m.*, p.*, pl.*, pd.*, pr.* " +
						" FROM package p, model m, pagelabel pl, packageDesc pd, packageRestriction pr WHERE " +
						" (m.VehicleID = " + vehicleID + ") AND" +
						" (p.modelID = m.modelID) AND " +
						" (p.pagelabelid = pl.pagelabelid) AND" +
						" (p.packageDescid = pd.packageDescid(+)) AND " +
						" (p.packageRestrictionid = pr.packageRestrictionid(+)) " +
						" ORDER BY p.pageNumber, pd.packagedescsort, p.packagesort";

			}

		}


		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getpackageNames);
		for (Map row : modelIDList) {
			StdEqpHelper stdEqpHelper = new StdEqpHelper();
			stdEqpHelper.setPackageDesc1(String.valueOf(row.get("PACKAGEDESCTEXT")));
			stdEqpHelper.setModelID((BigDecimal)(row.get("MODELID")));
			stdEqpHelper.setModelDesc(String.valueOf(row.get("MODELDESC")));
			stdEqpHelper.setPackageName(String.valueOf(row.get("PACKAGENAME")));
			stdEqpHelper.setPageNumber((BigDecimal)(row.get("PAGENUMBER")));
			stdEqpHelper.setPackageSort((BigDecimal)(row.get("PACKAGESORT")));
			stdEqpHelper.setPackageID((BigDecimal)(row.get("PACKAGEID")));
			stdEqpHelper.setPackageDescID((BigDecimal)(row.get("PACKAGEDESCID")));
			stdEqpHelper.setTrimName(String.valueOf(row.get("TRIMNAME")));
			stdEqpHelper.setModelName(String.valueOf(row.get("MODELNAME")));
			stdEqpHelper.setPackageRestrictionDesc(String.valueOf(row.get("PACKAGERESTRICTIONDESC")));
			stdEqpHelper.setPackageDesc2(String.valueOf(row.get("PACKAGEDESCTEXT2")));
			stdEqpHelper.setRestriction(String.valueOf(row.get("PAGENUMBER")));
			stdEqpHelper.setPageNumber((BigDecimal)(row.get("PAGENUMBER")));
			stdEqpHelper.setPageLabel(String.valueOf(row.get("PAGELABEL")));
			stdEqpHelper.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			stdEqpHelper.setPackageRestrictionID((BigDecimal)(row.get("PACKAGERESTRICTIONID")));

			stdEqpHelperList.add(stdEqpHelper);
		}
		
		
		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM v_division d, v_vehicle v, v_region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  v.localecode="+lang+" and r.localecode="+lang+" and d.localecode="+lang+" and" +
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";
		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(stdEqpHelperList.size()>0){
			for (Map vehicleDetails : vehicle) {

				stdEqpHelperList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				stdEqpHelperList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				stdEqpHelperList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				stdEqpHelperList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				stdEqpHelperList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				stdEqpHelperList.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				stdEqpHelperList.get(0).setDivisionID((BigDecimal)(vehicleDetails.get("DIVISIONID")));
				stdEqpHelperList.get(0).setRegionID((BigDecimal)(vehicleDetails.get("REGIONID")));
				stdEqpHelperList.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
			}
		}
		return stdEqpHelperList;


	}


	private void domesticVehicles(int subCategoryID, String availCode_SQLCondition,String availCode_Sort, String vehicleID,int lang) {

		standardEqpBeanContentAvailabilty1 = new ArrayList<StandardEqpBean>();
		standardEqpBeanContentAvailabilty2 = new ArrayList<StandardEqpBean>();
		standardEqpBeanContentAvailabilty3 = new ArrayList<StandardEqpBean>();

		String getModel = "SELECT DISTINCT p.packagedescid , p.packagesort" +
				" FROM package p, model m, pagelabel pl, packageDesc pd, packageRestriction pr WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				" (p.modelID = m.modelID) AND " +
				" (p.pagelabelid = pl.pagelabelid) AND" +
				" (p.packageDescid = pd.packageDescid(+)) AND " +
				" (p.packageRestrictionid = pr.packageRestrictionid(+)) order by p.packagesort";

		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getModel);
		modelList=	getModel();



		int i=0;
		standardEqpBeanArr =  new Object[3][2];

		List<StandardEqpBean> standardEqpBeanContentAvailabilty1 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentAvailabilty2 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentAvailabilty3 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist1 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist2 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist3 = new ArrayList<StandardEqpBean>();

		String getOption = "SELECT DISTINCT oc.*,p.pagenumber, c.categoryname, c.categorydesc, c.categorysorter, sc.subcategoryid, sc.subcategoryname, sc.subcategorydesc, sc.subcategorynote, sc.subcategorysorter, m.vehicleID, oced.optionCodeSort, oced.newOptionFlag, oced.link_indicator, oced.pdf_filename, ed.EXTENDEDDESC,ed.EXTENDEDDESCID,ed.WORKITEMID, gt.* " +
				" FROM package p, model m, packageoptioncode poc, optioncode oc, optCodeExtDesc oced, extendedDesc ed, category c, subcategory sc, graytabtype gt WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				//" (p.pageNumber = " + pageNumber + ") AND" +
				" (p.modelID = m.modelID) AND " +
				" (p.packageID = poc.packageID) AND " +
				" (oc.subcategoryID = sc.subcategoryID(+)) AND " +
				" (oc.categoryID = c.categoryID(+)) AND " +
				" (oc.graytabtypeID = gt.graytabtypeID(+)) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				availCode_SQLCondition + " AND " +
				" (" + vehicleID + " = oced.vehicleid(+)) AND (oc.rpoid = oced.rpoid(+)) AND (oced.extendedDescID = ed.extendedDescID(+))" +
				" order by " +  availCode_Sort;
		
		


		String sqlSubquery = "SELECT DISTINCT oc.rpoid " +
				" FROM package p, model m, packageoptioncode poc, optioncode oc WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND" +
			//	" (p.pageNumber = " + pageNumber + ") AND" +
				" (p.modelID = m.modelID) AND " +
				" (p.packageID = poc.packageID) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				availCode_SQLCondition;

		String	getPackage = "SELECT DISTINCT oc.rpoid, pd.packagedescsort, oced.optionCodeSort, p.*, poc.*, r.rDescription, rh.restrictionHeaderDesc, a.* " +
				" FROM package p, packagedesc pd, model m, OptCodeExtDesc oced, packageoptioncode poc, optioncode oc, availableCode a, optionRestriction r, optionRestrictionHeader rh WHERE " +
				" oc.RPOID IN (" + sqlSubquery + ") AND " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				" (p.modelID = m.modelID) AND " +
				//" (p.pageNumber = " + pageNumber + ") AND" +
				" (oced.vehicleId = " + vehicleID + ") AND" +
				" (p.packageID = poc.packageID) AND " +
				" (p.packagedescid = pd.packagedescid) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				" (oced.rpoId = oc.rpoId) AND" + 
				" (poc.restrictionID = r.OptionRestrictionID(+)) AND " +
				" (" + vehicleID + " = r.VehicleID(+)) AND " +
				" (r.RestrictionHeaderID = rh.OptionRestrictionHeaderID(+)) AND " +
				" (poc.availablecodeID = a.availablecodeID(+)) " +
				" ORDER BY oced.optionCodeSort, pd.packagedescsort, p.packageSort";




		


		List<Map<String, Object>> packageI = jdbcTemplate.queryForList(getPackage);

		List<Map<String, Object>> option = jdbcTemplate.queryForList(getOption);
	
		for (Map row : option) {

			StandardEqpBean standardEquipmentContents = new StandardEqpBean();

			standardEquipmentContents.setRpoId((BigDecimal)(row.get("RPOID")));
			standardEquipmentContents.setRpoName((String.valueOf(row.get("RPONAME"))));
			standardEquipmentContents.setRpoDesc((String.valueOf(row.get("RPODESC"))));
			standardEquipmentContents.setRpoDescBold((String.valueOf(row.get("RPODESCBOLD"))));
			standardEquipmentContents.setExtendedDesc((String.valueOf(row.get("EXTENDEDDESC"))));
			standardEquipmentContents.setTypeFlag(((BigDecimal)(row.get("TYPEFLAG"))));
			standardEquipmentContents.setNewOptionFLag(((BigDecimal)(row.get("NEWOPTIONFLAG"))));
			standardEquipmentContents.setPageNumber(((BigDecimal)(row.get("PAGENUMBER"))));


			if((standardEquipmentContents.getPageNumber().intValueExact())==1){
				standardEqpBeanContentlist1.add(standardEquipmentContents);
			}
			if((standardEquipmentContents.getPageNumber().intValueExact())==2){
				standardEqpBeanContentlist2.add(standardEquipmentContents);
			}
			if((standardEquipmentContents.getPageNumber().intValueExact())==3){
				standardEqpBeanContentlist3.add(standardEquipmentContents);
			}


		} 

		for (Map row1 : packageI) {

			StandardEqpBean standardEquipmentAvailability = new StandardEqpBean();
			standardEquipmentAvailability.setPageNumber(((BigDecimal)(row1.get("PAGENUMBER"))));
			standardEquipmentAvailability.setRpoId((BigDecimal)(row1.get("RPOID")));
			standardEquipmentAvailability.setPackageName((String.valueOf(row1.get("PACKAGENAME"))));
			standardEquipmentAvailability.setrDescription((String.valueOf(row1.get("RDESCRIPTION"))));
			standardEquipmentAvailability.setAvailableCode((String.valueOf(row1.get("AVAILABLECODENAME"))));
			standardEquipmentAvailability.setRestrictionID((BigDecimal)(row1.get("RESTRICTIONID")));
			standardEquipmentAvailability.setAvailableCodeID((BigDecimal)(row1.get("AVAILABLECODEID")));
			standardEquipmentAvailability.setPackageID((BigDecimal)(row1.get("PACKAGEID")));
			standardEquipmentAvailability.setPackageDescID((BigDecimal)(row1.get("PACKAGEDESCID")));


			if(standardEquipmentAvailability.getPageNumber().intValueExact()==1){
				standardEqpBeanContentAvailabilty1.add(standardEquipmentAvailability);
			}
			if(standardEquipmentAvailability.getPageNumber().intValueExact()==2){
				standardEqpBeanContentAvailabilty2.add(standardEquipmentAvailability);
			}
			if(standardEquipmentAvailability.getPageNumber().intValueExact()==3){
				standardEqpBeanContentAvailabilty3.add(standardEquipmentAvailability);
			}


		} 


		getColumnsOption = "select * from columnstable where VehicleID = "+vehicleID+" and PDFTYPE = "+VehicleConstant.STD_EQUIPMENT;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);

		if(standardEqpBeanContentlist1.size()>0){
			for (Map vehicleDetails : vehicle) {

				standardEqpBeanContentlist1.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				standardEqpBeanContentlist1.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				standardEqpBeanContentlist1.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				standardEqpBeanContentlist1.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				standardEqpBeanContentlist1.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				standardEqpBeanContentlist1.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				standardEqpBeanContentlist1.get(0).setDivisionID((BigDecimal)(vehicleDetails.get("DIVISIONID")));
				standardEqpBeanContentlist1.get(0).setRegionID((BigDecimal)(vehicleDetails.get("REGIONID")));
				standardEqpBeanContentlist1.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
			}
		}

		if(standardEqpBeanContentlist2.size()>0){
			for (Map vehicleDetails : vehicle) {

				standardEqpBeanContentlist2.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				standardEqpBeanContentlist2.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				standardEqpBeanContentlist2.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				standardEqpBeanContentlist2.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				standardEqpBeanContentlist2.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				standardEqpBeanContentlist2.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				standardEqpBeanContentlist2.get(0).setDivisionID((BigDecimal)(vehicleDetails.get("DIVISIONID")));
				standardEqpBeanContentlist2.get(0).setRegionID((BigDecimal)(vehicleDetails.get("REGIONID")));
				standardEqpBeanContentlist2.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
			}
		}

		if(standardEqpBeanContentlist3.size()>0){
			for (Map vehicleDetails : vehicle) {

				standardEqpBeanContentlist3.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				standardEqpBeanContentlist3.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				standardEqpBeanContentlist3.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				standardEqpBeanContentlist3.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				standardEqpBeanContentlist3.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				standardEqpBeanContentlist3.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				standardEqpBeanContentlist3.get(0).setDivisionID((BigDecimal)(vehicleDetails.get("DIVISIONID")));
				standardEqpBeanContentlist3.get(0).setRegionID((BigDecimal)(vehicleDetails.get("REGIONID")));
				standardEqpBeanContentlist3.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
			}
		}

		List<Map<String, Object>> columnsOption = jdbcTemplate.queryForList(getColumnsOption);
		if(standardEqpBeanContentlist1.size()>0){
			for (Map vehicleDetails : columnsOption) {
				standardEqpBeanContentlist1.get(0).setColumnBreak((BigDecimal)(vehicleDetails.get("COLUMNSTOSPLIT")));
				standardEqpBeanContentlist1.get(0).setIsLandscape((BigDecimal)(vehicleDetails.get("LANDSCAPE")));
			}
		}
		ListPackage = new ArrayList<ArrayList<BigDecimal>>();
		for (int p = 1; p <=3 ; p++) {
			ListPackage.add(getPackageIDList(vehicleID,p));
		}
		if(standardEqpBeanContentlist1.size()>0){
			standardEqpBeanContentlist1.get(0).setTempPackageList(ListPackage.get(0));
		}
		if(standardEqpBeanContentlist2.size()>0){
			standardEqpBeanContentlist2.get(0).setTempPackageList(ListPackage.get(1));
		}
		if(standardEqpBeanContentlist3.size()>0){
			standardEqpBeanContentlist3.get(0).setTempPackageList(ListPackage.get(2));
		}
		standardEqpBeanArr[0][0]= standardEqpBeanContentlist1;
		standardEqpBeanArr[0][1]= standardEqpBeanContentAvailabilty1;
		standardEqpBeanArr[1][0]= standardEqpBeanContentlist2;
		standardEqpBeanArr[1][1]= standardEqpBeanContentAvailabilty2;
		standardEqpBeanArr[2][0]= standardEqpBeanContentlist3;
		standardEqpBeanArr[2][1]= standardEqpBeanContentAvailabilty3;



	}
	public List<ArrayList<BigDecimal>> getModel(){
		List<ArrayList<BigDecimal>> finalList = new ArrayList<ArrayList<BigDecimal>>();
		packageNameMap=	 new ArrayList<HashMap<BigDecimal, ArrayList<String>>>(3);
		HashMap <BigDecimal,ArrayList<String>> tempPackageNameMap;
		for(int i = 0; i<3;i++){

			String getModel = "SELECT DISTINCT p.packagedescid , p.packagesort " +
					" FROM package p, model m, pagelabel pl, packageDesc pd, packageRestriction pr WHERE " +
					" (m.VehicleID = " + vehicleID + ") AND  p.pagenumber= "+(i+1) +
					" and (p.modelID = m.modelID) AND " +
					" (p.pagelabelid = pl.pagelabelid) AND" +
					" (p.packageDescid = pd.packageDescid(+)) AND " +
					" (p.packageRestrictionid = pr.packageRestrictionid(+)) order by p.packagesort";
			List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getModel);
			modelListTemp=	new ArrayList<BigDecimal>();
			tempPackageNameMap=	 new HashMap<BigDecimal, ArrayList<String>>();
			for (Map row : modelIDList) {
				if(row.get("PACKAGEDESCID")!=null && !modelListTemp.contains(row.get("PACKAGEDESCID")))
				{

					modelListTemp.add((BigDecimal)(row.get("PACKAGEDESCID")));	
				}	

			} 


			for (int j = 0; j < modelListTemp.size(); j++) {

				//	tempPackageNameMap.put(modelListTemp.get(j), getPackageName_NC(modelListTemp.get(j), vehicleID));
					
					for (int pageNumber = 1; pageNumber <=3; pageNumber++) {
				ArrayList<String> temp = getPackageName_NC(modelListTemp.get(j), pageNumber, vehicleID);
				tempPackageNameMap.put(modelListTemp.get(j),temp);
					}
					
				}
			packageNameMap.add(tempPackageNameMap);
			finalList.add(modelListTemp);
		}
		

		return finalList;


	}
	
	
	public List<Object> getRegOption(){
		List<Object> objList=  new ArrayList<Object>();
		standardEqpBeanContentAvailabilty1 = new ArrayList<StandardEqpBean>(); 
		standardEqpBeanContentlist1 = new ArrayList<StandardEqpBean>();
		
		String availCode_SQLCondition =" ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.regulatoryFlag = 1)  ";
		
		
		String getOption_add = "SELECT DISTINCT oc.*,p.pagenumber, c.categoryname, c.categorydesc, c.categorysorter, sc.subcategoryid, sc.subcategoryname, sc.subcategorydesc, sc.subcategorynote, sc.subcategorysorter, m.vehicleID, oced.optionCodeSort, oced.newOptionFlag, oced.link_indicator, oced.pdf_filename, ed.EXTENDEDDESC,ed.EXTENDEDDESCID,ed.WORKITEMID, gt.* " +
				" FROM v_package p, v_model m, packageoptioncode poc, v_optioncode oc, optCodeExtDesc oced, v_extendeddesc ed, v_category c, v_subcategory sc, v_graytabtype gt WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND " +
				" (p.modelID = m.modelID) AND  oc.localecode(+)="+lang+ " and ed.localecode(+)="+lang+ " and gt.localecode(+)="+lang+ " and sc.localecode(+)="+lang+" and c.localecode(+)="+lang+ " and p.localecode="+lang+ " and " +
				" (p.packageID = poc.packageID) AND " +
				" (oc.subcategoryID = sc.subcategoryID(+)) AND " +
				" (oc.categoryID = c.categoryID(+)) AND " +
				" (oc.graytabtypeID = gt.graytabtypeID(+)) AND " +
				" (oc.RPOID = poc.RPOID) AND m.localecode="+lang+ " and " +
				availCode_SQLCondition + " AND  "+
				" (" + vehicleID + " = oced.vehicleid(+)) AND (oc.rpoid = oced.rpoid(+)) AND (oced.extendedDescID = ed.extendedDescID(+))" +
				" order by oc.rpoDescBold" ;
		
		String sqlSubquery_add = "SELECT DISTINCT oc.rpoid " +
				" FROM package p, model m, packageoptioncode poc, optioncode oc WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				" (p.pageNumber = " + pageNumber + ") AND" +
				" (p.modelID = m.modelID) AND " +
				" (p.packageID = poc.packageID) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				availCode_SQLCondition;

		String	getPackage_add = "SELECT DISTINCT oc.rpoid, pd.packagedescsort, oced.optionCodeSort, p.*, poc.*, r.rDescription, rh.restrictionHeaderDesc, a.* " +
				" FROM package p, packagedesc pd, model m, OptCodeExtDesc oced, packageoptioncode poc, optioncode oc, availableCode a, optionRestriction r, optionRestrictionHeader rh WHERE " +
				" oc.RPOID IN (" + sqlSubquery_add + ") AND " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				" (p.modelID = m.modelID) AND " +
				" (p.pageNumber = " + pageNumber + ") AND" +
				" (oced.vehicleId = " + vehicleID + ") AND" +
				" (p.packageID = poc.packageID) AND " +
				" (p.packagedescid = pd.packagedescid) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				" (oced.rpoId = oc.rpoId) AND" + 
				" (poc.restrictionID = r.OptionRestrictionID(+)) AND " +
				" (" + vehicleID + " = r.VehicleID(+)) AND " +
				" (r.RestrictionHeaderID = rh.OptionRestrictionHeaderID(+)) AND " +
				" (poc.availablecodeID = a.availablecodeID(+)) " +
				" ORDER BY oced.optionCodeSort, pd.packagedescsort, p.packageSort";
		
		List<Map<String, Object>> option_add = jdbcTemplate.queryForList(getOption_add);

		for (Map row : option_add) {

			StandardEqpBean standardEquipmentContents = new StandardEqpBean();

			standardEquipmentContents.setRpoId((BigDecimal)(row.get("RPOID")));
			standardEquipmentContents.setRpoName((String.valueOf(row.get("RPONAME"))));
			standardEquipmentContents.setRpoDesc((String.valueOf(row.get("RPODESC"))));
			standardEquipmentContents.setRpoDescBold((String.valueOf(row.get("RPODESCBOLD"))));
			standardEquipmentContents.setExtendedDesc((String.valueOf(row.get("EXTENDEDDESC"))));
			standardEquipmentContents.setTypeFlag(((BigDecimal)(row.get("TYPEFLAG"))));
			standardEquipmentContents.setNewOptionFLag(((BigDecimal)(row.get("NEWOPTIONFLAG"))));
			standardEquipmentContents.setPageNumber(((BigDecimal)(row.get("PAGENUMBER"))));
			
				standardEqpBeanContentlist1.add(standardEquipmentContents);
		}
		
		
		
		List<Map<String, Object>> packageI_add = jdbcTemplate.queryForList(getPackage_add);
				

				for (Map row1 : packageI_add) {

					StandardEqpBean standardEquipmentAvailability = new StandardEqpBean();
					standardEquipmentAvailability.setPageNumber(((BigDecimal)(row1.get("PAGENUMBER"))));
					standardEquipmentAvailability.setRpoId((BigDecimal)(row1.get("RPOID")));
					standardEquipmentAvailability.setPackageName((String.valueOf(row1.get("PACKAGENAME"))));
					standardEquipmentAvailability.setrDescription((String.valueOf(row1.get("RDESCRIPTION"))));
					standardEquipmentAvailability.setAvailableCode((String.valueOf(row1.get("AVAILABLECODENAME"))));
					standardEquipmentAvailability.setRestrictionID((BigDecimal)(row1.get("RESTRICTIONID")));
					standardEquipmentAvailability.setAvailableCodeID((BigDecimal)(row1.get("AVAILABLECODEID")));
					standardEquipmentAvailability.setPackageID((BigDecimal)(row1.get("PACKAGEID")));
					standardEquipmentAvailability.setPackageDescID((BigDecimal)(row1.get("PACKAGEDESCID")));
					
					standardEqpBeanContentAvailabilty1.add(standardEquipmentAvailability);
				}
				
				objList.add(standardEqpBeanContentlist1);
				objList.add(standardEqpBeanContentAvailabilty1);
		return objList;
		
	}

	public List<ArrayList<BigDecimal>> getModel_fr(){
		List<ArrayList<BigDecimal>> finalList = new ArrayList<ArrayList<BigDecimal>>();
		packageNameMap=	 new ArrayList<HashMap<BigDecimal, ArrayList<String>>>(3);
		HashMap <BigDecimal,ArrayList<String>> tempPackageNameMap;
		for(int i = 0; i<3;i++){

			String getModel = "SELECT DISTINCT p.packagedescid , p.packagesort " +
					" FROM v_package p, v_model m, v_pagelabel pl, v_packageDesc pd, v_packageRestriction pr WHERE " +
					" (m.VehicleID = " + vehicleID + ") AND  p.pagenumber= "+(i+1) +
					" and (p.modelID = m.modelID) AND m.localecode=1 and "+
					" pl.localecode="+lang+" and pd.localecode(+)="+lang+" and p.localecode="+lang+" and pr.localecode(+)="+lang+" and " +
					" (p.pagelabelid = pl.pagelabelid) AND" +
					" (p.packageDescid = pd.packageDescid(+)) AND " +
					" (p.packageRestrictionid = pr.packageRestrictionid(+)) order by p.packagesort";
			List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getModel);
			modelListTemp=	new ArrayList<BigDecimal>();
			tempPackageNameMap=	 new HashMap<BigDecimal, ArrayList<String>>();
			for (Map row : modelIDList) {
				if(row.get("PACKAGEDESCID")!=null && !modelListTemp.contains(row.get("PACKAGEDESCID")))
				{

					modelListTemp.add((BigDecimal)(row.get("PACKAGEDESCID")));	
				}	

			} 


			for (int j = 0; j < modelListTemp.size(); j++) {

				tempPackageNameMap.put(modelListTemp.get(j), getPackageName(modelListTemp.get(j), vehicleID));
			}
			packageNameMap.add(tempPackageNameMap);
			finalList.add(modelListTemp);
		}


		return finalList;


	}


	private void nonDomesticVehicles(int subCategoryID, String availCode_SQLCondition,String availCode_Sort, String vehicleID,int lang) {
		standardEqpBeanContentAvailabilty1 = new ArrayList<StandardEqpBean>();
		standardEqpBeanContentAvailabilty2 = new ArrayList<StandardEqpBean>();
		standardEqpBeanContentAvailabilty3 = new ArrayList<StandardEqpBean>();
		standardEqpBeanContentAvailabilty4 = new ArrayList<StandardEqpBean>();
		
		modelList= getModel_fr();

		int i=0;
		standardEqpBeanArr =  new Object[3][2];

		List<StandardEqpBean> standardEqpBeanContentAvailabilty1 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentAvailabilty2 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentAvailabilty3 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentAvailabilty4 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist1 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist2 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist3 = new ArrayList<StandardEqpBean>();
		List<StandardEqpBean> standardEqpBeanContentlist4 = new ArrayList<StandardEqpBean>();

		String getOption = "SELECT DISTINCT oc.*,p.pagenumber, c.categoryname, c.categorydesc, c.categorysorter, sc.subcategoryid, sc.subcategoryname, sc.subcategorydesc, sc.subcategorynote, sc.subcategorysorter, m.vehicleID, oced.optionCodeSort, oced.newOptionFlag, oced.link_indicator, oced.pdf_filename, ed.EXTENDEDDESC,ed.EXTENDEDDESCID,ed.WORKITEMID, gt.* " +
				" FROM v_package p, v_model m, packageoptioncode poc, v_optioncode oc, optCodeExtDesc oced, v_extendeddesc ed, v_category c, v_subcategory sc, v_graytabtype gt WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND " +
				" (p.modelID = m.modelID) AND  oc.localecode(+)="+lang+ " and ed.localecode(+)="+lang+ " and gt.localecode(+)="+lang+ " and sc.localecode(+)="+lang+" and c.localecode(+)="+lang+ " and p.localecode="+lang+ " and " +
				" (p.packageID = poc.packageID) AND " +
				" (oc.subcategoryID = sc.subcategoryID(+)) AND " +
				" (oc.categoryID = c.categoryID(+)) AND " +
				" (oc.graytabtypeID = gt.graytabtypeID(+)) AND " +
				" (oc.RPOID = poc.RPOID) AND m.localecode="+lang+ " and " +
				availCode_SQLCondition + " AND  "+
				" (" + vehicleID + " = oced.vehicleid(+)) AND (oc.rpoid = oced.rpoid(+)) AND (oced.extendedDescID = ed.extendedDescID(+))" +
				" order by " +  availCode_Sort;


		String sqlSubquery = "SELECT DISTINCT oc.rpoid " +
				" FROM v_package p, v_model m, packageoptioncode poc, v_optioncode oc WHERE " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				"  P.localecode="+lang+" AND oc.localecode="+lang+" AND" +
				" (p.modelID = m.modelID) AND m.localecode="+lang+ " and" +
				" (p.packageID = poc.packageID) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				availCode_SQLCondition;

		String	getPackage = "SELECT DISTINCT oc.rpoid, pd.packagedescsort, oced.optionCodeSort, p.*, Poc.Availablecodeid, Poc.Rpoid,Poc.Vehicleid,Poc.Workitemid, R.Optionrestrictionid restrictionid, r.rDescription, rh.restrictionHeaderDesc, a.* " +
				" FROM v_package p, v_packagedesc pd, v_model m, OptCodeExtDesc oced, packageoptioncode poc, v_optioncode oc,  availableCode a, v_optionRestriction r, optionRestrictionHeader rh WHERE " +
				" oc.RPOID IN (" + sqlSubquery + ") AND " +
				" (m.VehicleID = " + vehicleID + ") AND" +
				" (p.modelID = m.modelID) AND " +
				" pd.localecode="+lang+ " and m.localecode="+lang+ " AND p.localecode="+lang+ " and oc.localecode="+lang+ "  and  " +
				" (oced.vehicleId = " + vehicleID + ") AND" +
				" (p.packageID = poc.packageID) AND " +
				" (p.packagedescid = pd.packagedescid) AND " +
				" (oc.RPOID = poc.RPOID) AND " +
				" (oced.rpoId = oc.rpoId) AND" + 
				" (poc.restrictionID = r.OptionRestrictionID(+)) AND " +
				" (" + vehicleID + " = r.VehicleID(+)) AND " +
				" (r.RestrictionHeaderID = rh.OptionRestrictionHeaderID(+)) AND (r.localecode(+)="+lang+" ) and" +
				" (poc.availablecodeID = a.availablecodeID(+)) " +
				" ORDER BY oced.optionCodeSort, pd.packagedescsort, p.packageSort";


		List<Map<String, Object>> packageI = jdbcTemplate.queryForList(getPackage);

		List<Map<String, Object>> option = jdbcTemplate.queryForList(getOption);

		for (Map row : option) {

			StandardEqpBean standardEquipmentContents = new StandardEqpBean();

			standardEquipmentContents.setRpoId((BigDecimal)(row.get("RPOID")));
			standardEquipmentContents.setRpoName((String.valueOf(row.get("RPONAME"))));
			standardEquipmentContents.setRpoDesc((String.valueOf(row.get("RPODESC"))));
			standardEquipmentContents.setRpoDescBold((String.valueOf(row.get("RPODESCBOLD"))));
			standardEquipmentContents.setExtendedDesc((String.valueOf(row.get("EXTENDEDDESC"))));
			standardEquipmentContents.setTypeFlag(((BigDecimal)(row.get("TYPEFLAG"))));
			standardEquipmentContents.setNewOptionFLag(((BigDecimal)(row.get("NEWOPTIONFLAG"))));
			standardEquipmentContents.setPageNumber(((BigDecimal)(row.get("PAGENUMBER"))));


			if((standardEquipmentContents.getPageNumber().intValueExact())==1){
				standardEqpBeanContentlist1.add(standardEquipmentContents);
			}
			if((standardEquipmentContents.getPageNumber().intValueExact())==2){
				standardEqpBeanContentlist2.add(standardEquipmentContents);
			}
			if((standardEquipmentContents.getPageNumber().intValueExact())==3){
				standardEqpBeanContentlist3.add(standardEquipmentContents);
			}

			if((standardEquipmentContents.getPageNumber().intValueExact())==4){
				standardEqpBeanContentlist4.add(standardEquipmentContents);
			}
		} 

		for (Map row1 : packageI) {

			StandardEqpBean standardEquipmentAvailability = new StandardEqpBean();
			standardEquipmentAvailability.setPageNumber(((BigDecimal)(row1.get("PAGENUMBER"))));
			standardEquipmentAvailability.setRpoId((BigDecimal)(row1.get("RPOID")));
			standardEquipmentAvailability.setModelID((BigDecimal)(row1.get("MODELID")));
			standardEquipmentAvailability.setPackageName((String.valueOf(row1.get("PACKAGENAME"))));
			standardEquipmentAvailability.setrDescription((String.valueOf(row1.get("RDESCRIPTION"))));
			standardEquipmentAvailability.setAvailableCode((String.valueOf(row1.get("AVAILABLECODENAME"))));
			standardEquipmentAvailability.setRestrictionID((BigDecimal)(row1.get("RESTRICTIONID")));
			standardEquipmentAvailability.setAvailableCodeID((BigDecimal)(row1.get("AVAILABLECODEID")));
			standardEquipmentAvailability.setPackageID((BigDecimal)(row1.get("PACKAGEID")));
			standardEquipmentAvailability.setPackageDescID((BigDecimal)(row1.get("PACKAGEDESCID")));
			if(standardEquipmentAvailability.getPageNumber().intValueExact()==1){
				standardEqpBeanContentAvailabilty1.add(standardEquipmentAvailability);
			}
			if(standardEquipmentAvailability.getPageNumber().intValueExact()==2){
				standardEqpBeanContentAvailabilty2.add(standardEquipmentAvailability);
			}
			if(standardEquipmentAvailability.getPageNumber().intValueExact()==3){
				standardEqpBeanContentAvailabilty3.add(standardEquipmentAvailability);
			}
			if(standardEquipmentAvailability.getPageNumber().intValueExact()==4){
				standardEqpBeanContentAvailabilty4.add(standardEquipmentAvailability);
			}


		} 
		getColumnsOption = "select * from columnstable where VehicleID = "+vehicleID+ " and PDFTYPE = "+VehicleConstant.STD_EQUIPMENT;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM v_division d, v_vehicle v, v_region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  v.localecode="+lang+" and r.localecode="+lang+" and d.localecode="+lang+" and" +
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(standardEqpBeanContentlist1.size()>0){
			for (Map vehicleDetails : vehicle) {

				standardEqpBeanContentlist1.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				standardEqpBeanContentlist1.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				standardEqpBeanContentlist1.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				standardEqpBeanContentlist1.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				standardEqpBeanContentlist1.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				standardEqpBeanContentlist1.get(0).setDivision(String.valueOf(vehicleDetails.get("DIVISIONID")));
				standardEqpBeanContentlist1.get(0).setDivisionID((BigDecimal)(vehicleDetails.get("DIVISIONID")));
				standardEqpBeanContentlist1.get(0).setRegionID((BigDecimal)(vehicleDetails.get("REGIONID")));
				standardEqpBeanContentlist1.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
			}
		}

		List<Map<String, Object>> columnsOption = jdbcTemplate.queryForList(getColumnsOption);
		if(standardEqpBeanContentlist1.size()>0){
			for (Map vehicleDetails : columnsOption) {
				standardEqpBeanContentlist1.get(0).setColumnBreak((BigDecimal)(vehicleDetails.get("COLUMNSTOSPLIT")));
				standardEqpBeanContentlist1.get(0).setIsLandscape((BigDecimal)(vehicleDetails.get("LANDSCAPE")));
			}
		}

		ListPackage = new ArrayList<ArrayList<BigDecimal>>();
		for (int p = 1; p <=3 ; p++) {
			ListPackage.add(getPackageIDList_fr(vehicleID,p));
		}
		if(standardEqpBeanContentlist1.size()>0){
			standardEqpBeanContentlist1.get(0).setTempPackageList(ListPackage.get(0));
		}
		if(standardEqpBeanContentlist2.size()>0){
			standardEqpBeanContentlist2.get(0).setTempPackageList(ListPackage.get(1));
		}
		if(standardEqpBeanContentlist3.size()>0){
			standardEqpBeanContentlist3.get(0).setTempPackageList(ListPackage.get(2));
		}
		if(standardEqpBeanContentlist4.size()>0){
			standardEqpBeanContentlist4.get(0).setTempPackageList(ListPackage.get(3));
		}
		
		standardEqpBeanArr[0][0]= standardEqpBeanContentlist1;
		standardEqpBeanArr[0][1]= standardEqpBeanContentAvailabilty1;
		standardEqpBeanArr[1][0]= standardEqpBeanContentlist2;
		standardEqpBeanArr[1][1]= standardEqpBeanContentAvailabilty2;
		standardEqpBeanArr[2][0]= standardEqpBeanContentlist3;
		standardEqpBeanArr[2][1]= standardEqpBeanContentAvailabilty3;
		standardEqpBeanArr[3][0]= standardEqpBeanContentlist4;
		standardEqpBeanArr[3][1]= standardEqpBeanContentAvailabilty4;


	}



	private ArrayList<BigDecimal> getPackageIDList(String vehicleID, int i) {


		ArrayList<BigDecimal> arrayList = new ArrayList<BigDecimal>();
		String getpackageNames = "SELECT DISTINCT p.* " 
				+ " FROM package p, model m, pagelabel pl, packageDesc pd, packageRestriction pr WHERE  "
				+ " (m.VehicleID = "+vehicleID+") AND p.pagenumber = "+ i + " and "
				+ " (p.modelID = m.modelID) and " 
				+ " (p.pagelabelid = pl.pagelabelid) AND "
				+ " (p.packageDescid = pd.packageDescid(+)) AND "
				+" (p.packageRestrictionid = pr.packageRestrictionid(+)) "
				+ "	 ORDER BY p.pageNumber, p.packagesort";

		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getpackageNames);
		for (Map row : modelIDList) {
			arrayList.add((BigDecimal)(row.get("PACKAGEID")));	

		}
		return arrayList; 


	}
	public ArrayList<String> getPackageName_NC(BigDecimal modelId,String vehicleID){
		ArrayList<String> arrayList = new ArrayList<String>();
		String getpackageNames = "  SELECT DISTINCT m.*, p.*, pl.*, pd.*, pr.*  " 
				+ " FROM package p, model m, pagelabel pl, packageDesc pd, packageRestriction pr WHERE "
				+ " (m.VehicleID = "+vehicleID+") AND "
				+ " (p.modelID = m.modelID)  AND "
				+ " (p.pagelabelid = pl.pagelabelid)   AND p.modelID = "+ modelId
				+ " and (p.packageDescid = pd.packageDescid(+)) AND"
				+ " (p.packageRestrictionid = pr.packageRestrictionid(+))";

		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getpackageNames);
		for (Map row : modelIDList) {
			arrayList.add((String.valueOf(row.get("PACKAGENAME"))));	

		}
		return arrayList; 
	}
	
	public ArrayList<String> getPackageName_NC(BigDecimal modelId,int pageNumber, String vehicleID){
		ArrayList<String> arrayList = new ArrayList<String>();
		String getpackageNames = "  SELECT DISTINCT m.*, p.*, pl.*, pd.*, pr.*  " 
				+ " FROM package p, model m, pagelabel pl, packagedesc pd, packagerestriction pr WHERE "
				+ " (m.VehicleID = "+vehicleID+") AND "
				+ " (p.modelID = m.modelID)  and"
				+ " (p.pagelabelid = pl.pagelabelid) AND p.packageDescid ="+modelId 
				+ " and (p.packageDescid = pd.packageDescid(+)) AND"
				+ " (p.packageRestrictionid = pr.packageRestrictionid(+)) and p.pagenumber=1"
				+ "ORDER BY p.pageNumber, pd.packagedescsort, p.packagesort";

		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getpackageNames);
		for (Map row : modelIDList) {
			arrayList.add((String.valueOf(row.get("PACKAGENAME"))));	

		}
		return arrayList; 
	}


	public ArrayList<BigDecimal> getPackageIDList_fr(String vehicleID, int i){


		ArrayList<BigDecimal> arrayList = new ArrayList<BigDecimal>();
		String getpackageNames = "SELECT DISTINCT p.* " 
				+ " FROM v_package p, v_model m, v_pagelabel pl, v_packageDesc pd, v_packageRestriction pr WHERE  "
				+ " (m.VehicleID = "+vehicleID+") AND p.pagenumber = "+ i + " and "
				+ "(p.modelID = m.modelID)  AND m.localecode="+lang+" and pl.localecode="+lang+" and pd.localecode(+)="+lang
				+ "and p.localecode="+lang+" and pr.localecode(+)="+lang+" and "
				+ " (p.pagelabelid = pl.pagelabelid) AND "
				+ " (p.packageDescid = pd.packageDescid(+)) AND "
				+" (p.packageRestrictionid = pr.packageRestrictionid(+)) "
				+ "	 ORDER BY p.pageNumber, p.packagesort";

		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getpackageNames);
		for (Map row : modelIDList) {
			arrayList.add((BigDecimal)(row.get("PACKAGEID")));	

		}
		return arrayList; 


	}



	public List<String> getAVehicles() {
		List<String> listVehicles = new ArrayList<String>();
		Query query = null;
		String sql = null;

		try{

			query = new Query();


			sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 AND REGIONID =14 and VEHICLEID=16303";
			jdbcTemplate = new JdbcTemplate(dataSource);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
			for (Map row : rows) {
				listVehicles.add((String.valueOf(row.get("VehicleID"))));
			}

			return listVehicles;
		}

		catch(Exception e ){
			System.out.println("Exception" +e);
		}
		return listVehicles;

	}


}
