package com.dci.enterprise.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dci.enterprise.model.StandardEqpBean;
import com.dci.enterprise.model.StdEqpHelper;
import com.dci.enterprise.model.WheelsAndRadiosBean;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextEquipGrpPDFGeneratorDAO {

	public void startStdEquipPDFGeneration(Object[][] objects, Object[][] Test,HashMap<BigDecimal, ArrayList<String>>
	list,ArrayList<BigDecimal> list2,
	List<StdEqpHelper> stdHelper,int pageNum);

	void onCloseDocument(PdfWriter writer, Document document);

	public void startStdEquipPDFGeneration(Object[][] objects, Object[][] availableCodeList,
			HashMap<BigDecimal, ArrayList<String>> packageNameMap,
			ArrayList<BigDecimal> modelList, List<StdEqpHelper> stdHelper,int pageNum, int currentPage, Document document,PdfWriter writer, int isPog, List<Object> list,int lang);
	
	public void startStdEquipPDFGeneration(Object[][] objects, Object[][] Test,HashMap<BigDecimal, ArrayList<String>>
	list,ArrayList<BigDecimal> list2,
	List<StdEqpHelper> stdHelper,List<Object> regOptions,int pageNum);

}
