package com.dci.enterprise.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dci.enterprise.model.SpecsAndDimensionBean;
import com.dci.enterprise.model.StdEqpHelper;

public interface SpecsAndDimensionDAO {
	
	public List<ArrayList<Object>> getVehicleItemsXML (String vehicleID,int type, int lang);
	
	public List<String> getAVehicles();
	//public void startStdEqPDFGeneration(List<StandardEqpBean> vehicleItemsXML);

//	public void getModelList(List<StandardEqpBean> vehicleItemsXML);

}
