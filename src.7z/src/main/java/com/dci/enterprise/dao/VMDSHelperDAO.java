package com.dci.enterprise.dao;

public interface VMDSHelperDAO {
	public void startVMDSCheck();
}
