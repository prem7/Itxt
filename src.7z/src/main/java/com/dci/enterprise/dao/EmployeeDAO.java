package com.dci.enterprise.dao;

import com.dci.enterprise.model.Employee;

public interface EmployeeDAO {

		public void insert(Employee employee);
		public Employee findById(int id);
}
