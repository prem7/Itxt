package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.TraileringSpecsDAO;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.StdEqpHelper;
import com.dci.enterprise.model.TraileringSpecsBean;
import com.dci.enterprise.model.TraileringSpecsBeanRestriction;
import com.dci.enterprise.model.TraileringSpecsContentBean;
import com.dci.enterprise.model.TraileringSpecsGCWRBean;
import com.dci.enterprise.model.TraileringSpecsGCWRContent;
import com.dci.enterprise.model.TraileringSpecsGCWRHeaderBean;

public class TraileringSpecsDAOImpl implements TraileringSpecsDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private final String CONVERSION_FACTOR = "0.4536";
	private String vehicleID=null;
	private	List<Object> finalList;
	List<ArrayList<Object>> finaList_TypeID;
	static int lang=1;
	static boolean isCanada=false;
	static boolean isVehicleActive=false;
	private List<TraileringSpecsBean> traileringSpecsHeaderList;
	private List<TraileringSpecsContentBean> traileringSpecsContentBeansList;
	private List<TraileringSpecsGCWRBean> traileringSpecsGCWRBeanList;
	private List<TraileringSpecsGCWRContent> traileringSpecsGCWRContentList;
	private List<TraileringSpecsGCWRHeaderBean> traileringSpecsGCWRHeaderBeansList;
	private List<TraileringSpecsBeanRestriction> traileringSpecsBeanRestrictions;
	private List<TraileringSpecsBeanRestriction> traileringSpecsBeanRestrictions2;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	String getVehicle = null;
	public List<ArrayList<Object>> getVehicleItemsXML(int subCategoryID, String vehicleID,
			int lang) {
		this.lang = lang;

		traileringSpecsHeaderList = new ArrayList<TraileringSpecsBean>();
		traileringSpecsContentBeansList = new ArrayList<TraileringSpecsContentBean>();
		traileringSpecsGCWRBeanList =new ArrayList<TraileringSpecsGCWRBean>();
		traileringSpecsGCWRContentList = new ArrayList<TraileringSpecsGCWRContent>();
		traileringSpecsGCWRHeaderBeansList =new ArrayList<TraileringSpecsGCWRHeaderBean>(); 
		traileringSpecsBeanRestrictions = new ArrayList<TraileringSpecsBeanRestriction>();
		traileringSpecsBeanRestrictions2 = new ArrayList<TraileringSpecsBeanRestriction>();
		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		query = new Query();
		this.vehicleID= vehicleID;
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		finalList= new ArrayList<Object>();

		// Get vehicle
		String   vehicleSql = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, Region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID)  and" +
				" (v.regionID = d.regionID)  and" +
				" (v.regionID = r.regionID)";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(vehicleSql);


		for (Map row : vehicle) {

			if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

				isCanada= true;
			}
			else{
				isCanada=false;
			}

			if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

				isVehicleActive= true;
			}
			else{
				isVehicleActive=false;
			}


		}

		if(isVehicleActive){
			finaList_TypeID	= new ArrayList<ArrayList<Object>>();
			if(isCanada)
			{
				log.info("VEHICLE is in Canadian Region");

				for (int pageNumber = 1; pageNumber <= 3; pageNumber++) {
					finaList_TypeID.add(nonDomesticVehicles(subCategoryID,  vehicleID, lang, pageNumber));
				}

			}
			else{
				log.info("VEHICLE is in non-Canadian Region");
				for (int pageNumber = 1; pageNumber <= 3; pageNumber++) {
					finaList_TypeID.add(domesticVehicles(subCategoryID,  vehicleID, lang, pageNumber));
				}
			}


		}
		else{
			log.error("VEHICLE NOT ACTIVE");
		}

		return finaList_TypeID;
	}


	private ArrayList<Object> domesticVehicles(int subCategoryID, String vehicleID,int lang, int pageNumber) {
		finalList = new ArrayList<Object>();
		traileringSpecsHeaderList = new ArrayList<TraileringSpecsBean>();
		traileringSpecsContentBeansList = new ArrayList<TraileringSpecsContentBean>();
		traileringSpecsGCWRBeanList =new ArrayList<TraileringSpecsGCWRBean>();
		traileringSpecsGCWRContentList = new ArrayList<TraileringSpecsGCWRContent>();
		traileringSpecsGCWRHeaderBeansList =new ArrayList<TraileringSpecsGCWRHeaderBean>(); 
		traileringSpecsBeanRestrictions = new ArrayList<TraileringSpecsBeanRestriction>();
		traileringSpecsBeanRestrictions2 = new ArrayList<TraileringSpecsBeanRestriction>();
		
		String   vehicleSql = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, Region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (v.regionID = r.regionID)";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(vehicleSql);

		String traileringHeaderSQL = "SELECT distinct th.*, e.engineDescription, tc.vehicleId, oc.typeFlag, e.engineRPO as rpoName FROM " +
				" OptionCode oc, TraileringHeader th, Engine e, TraileringCategoryHeader tch, TraileringCategory tc, PullDownItem pdi " +
				" WHERE  th.TraileringHeaderID = tch.TraileringHeaderID AND " +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" e.EngineID = th.EngineID AND " +
				" e.RPOID = oc.RPOID AND " +
				" tc.VehicleID = " + vehicleID +
				" AND th.pageNumber = " + pageNumber +
				" ORDER BY th.engineSort";


		String traileringCategorySQL  = " SELECT "   +
				"   distinct tc.*, tcr.restrictionID, "   +
				"   tch2.maxRows, m.ModelID, m.ModelName, m.ModelDesc "   +
				" FROM "   +
				"   TraileringHeader th,"   +
				"   TraileringCategoryHeader tch,"   +
				"   TraileringCategoryRestriction tcr, " +
				"   TraileringCategory tc,"   +
				"   Model m,"   +
				"   PullDownItem pdi,"   +
				"   (SELECT greatest(count(tch2.axleRatio),1)  as maxRows "   +
				"    FROM TraileringCategoryHeader tch2 Join Traileringcategory Tc2 On Tc2.Traileringcategoryid=Tch2.Traileringcategoryid  Where Tc2.Vehicleid= " + vehicleID  +
				"    group by tch2.TraileringHeaderID, tch2.TraileringCategoryID     )  tch2"   +
				" WHERE "   +
				"   th.TraileringHeaderID = tch.TraileringHeaderID AND"   +
				"   tc.TraileringCategoryID = tch.TraileringCategoryID AND"   +
				"   tc.ModelID = m.ModelID (+) AND"   +
				"   th.PullDownItemID = pdi.PullDownItemID AND"   +
				"   tc.VehicleID = " + vehicleID + " AND"   +
				"   th.pageNumber = " + pageNumber   +
				"   and tcr.pageNumber(+) = " + pageNumber +
				"   and  tcr.traileringcategoryid(+) = tc.traileringcategoryid  " +
				"   and tch2.maxRows = (SELECT greatest(max(count(tch3.axleRatio)),1)  as maxRows "   +
				"    FROM TraileringCategoryHeader tch3, TraileringHeader th3 "   +
				"    where tch3.traileringcategoryid = tc.traileringcategoryid     "   +
				"    and tch3.traileringheaderid = th3.traileringheaderid     "   +
				"    and th3.pageNumber = " + pageNumber   +
				"    group by tch3.TraileringHeaderID    )"   +
				" ORDER BY tc.tcSort"  ;

		String traileringEntrySQL  ="SELECT distinct tch.*, tch.maxTrailerWeight * " + CONVERSION_FACTOR +
				" AS maxTrailerWeightMetric, tc.tcSort, th.engineSort FROM " +
				" TraileringHeader th, TraileringCategoryHeader tch, TraileringCategory tc, PullDownItem pdi " +
				" WHERE  th.TraileringHeaderID = tch.TraileringHeaderID AND " +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" tc.VehicleID = " + vehicleID +
				" AND th.pageNumber = " + pageNumber +
				" ORDER BY tc.tcSort, th.engineSort, tch.axleRatio";

		String GCWRSql = "SELECT distinct thg.*, tg.GCWR AS GCWRValue, th.engineSort FROM " +
				" TraileringHeaderGCWRRatings thg, TraileringGCWRRatings tg, TraileringHeader th, TraileringCategoryHeader tch, TraileringCategory tc, PullDownItem pdi " +
				" WHERE  th.TraileringHeaderID = tch.TraileringHeaderID AND " +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" tc.VehicleID = " + vehicleID +
				" AND th.pageNumber = " + pageNumber +
				" AND th.TraileringHeaderID = thg.TraileringHeaderID " +
				" AND thg.TraileringGCWRRatingsID = tg.TraileringGCWRRatingsID " +
				" ORDER BY  tg.GCWR";

		String GCWRHeaderSQl = "SELECT distinct " + vehicleID +
				" as VehicleID, tg.GCWR AS GCWRValue, tg.GCWR * " + CONVERSION_FACTOR +
				" AS GCWRValueMetric FROM " +
				" TraileringHeaderGCWRRatings thg, TraileringGCWRRatings tg, TraileringHeader th, TraileringCategoryHeader tch, TraileringCategory tc, PullDownItem pdi " +
				" WHERE  th.TraileringHeaderID = tch.TraileringHeaderID AND " +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" tc.VehicleID = " + vehicleID +
				" AND th.pageNumber = " + pageNumber +
				" AND th.TraileringHeaderID = thg.TraileringHeaderID " +
				" AND thg.TraileringGCWRRatingsID = tg.TraileringGCWRRatingsID " +
				" ORDER BY tg.GCWR";

		String pullDownItemSQL  = "SELECT distinct pdi.*, th.pageNumber, t.* FROM PullDownItem pdi, " +
				" TraileringHeader th, Type t, TraileringCategoryHeader tch, TraileringCategory tc WHERE " +
				" th.TraileringHeaderID = tch.TraileringHeaderID AND " +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" t.TypeID = pdi.TypeID AND th.pageNumber = " +pageNumber+
				"  and tc.VehicleID = " + vehicleID +
				" ORDER BY th.pageNumber";

		String restrictionSql = "SELECT  DISTINCT r.restrictionid, r.restrictionText, r.vehicleid " +
				"  FROM Vehicle v, TraileringHeader th, Restriction r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (r.VehicleID = v.VehicleID) AND " +
				" (th.pageNumber = " + pageNumber + ") AND" +
				" (th.PullDownItemID = r.PullDownItemID) " +
				" order by r.restrictionid";


		List<Map<String, Object>> traileringHeader = jdbcTemplate.queryForList(traileringHeaderSQL);

		for (Map row : traileringHeader) {

			TraileringSpecsBean traileringSpecsBean = new TraileringSpecsBean();

			traileringSpecsBean.setTraileringHeaderID((BigDecimal)(row.get("TRAILERINGHEADERID")));
			traileringSpecsBean.setPulldownItemID((BigDecimal)(row.get("PULLDOWNITEMID")));
			traileringSpecsBean.setPageNumber((BigDecimal)(row.get("PAGENUMBER")));
			traileringSpecsBean.setEngineID((BigDecimal)(row.get("ENGINEID")));
			traileringSpecsBean.setEngineSort((BigDecimal)(row.get("ENGINESORT")));
			traileringSpecsBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			traileringSpecsBean.setEngineDescription(String.valueOf(row.get("ENGINEDESCRIPTION")));
			traileringSpecsBean.setRpoName(String.valueOf(row.get("RPONAME")));

			traileringSpecsHeaderList.add(traileringSpecsBean);

		}




		List<Map<String, Object>> traileringCategory = jdbcTemplate.queryForList(traileringCategorySQL);

		for (Map row : traileringCategory) {

			TraileringSpecsContentBean traileringSpecsContentBean = new TraileringSpecsContentBean();

			traileringSpecsContentBean.setTraileringCategoryID((BigDecimal)(row.get("TRAILERINGCATEGORYID")));
			traileringSpecsContentBean.setTCName((String.valueOf(row.get("TCNAME"))));
			traileringSpecsContentBean.setTCSort((BigDecimal)(row.get("TCSORT")));
			traileringSpecsContentBean.setModelID((BigDecimal)(row.get("MODELID")));
			traileringSpecsContentBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			traileringSpecsContentBean.setModelName(String.valueOf(row.get("MODELNAME")));
			traileringSpecsContentBean.setModeldesc(String.valueOf(row.get("MODELDESC")));
			traileringSpecsContentBean.setMaxRows((BigDecimal)(row.get("MAXROWS")));
			traileringSpecsContentBeansList.add(traileringSpecsContentBean);

		}



		List<Map<String, Object>> GCWR = jdbcTemplate.queryForList(GCWRSql);

		for (Map row : GCWR) {

			TraileringSpecsGCWRBean traileringSpecsGCWRBean = new TraileringSpecsGCWRBean();

			traileringSpecsGCWRBean.setTraileringHeaderID((BigDecimal)(row.get("TRAILERINGHEADERID")));
			traileringSpecsGCWRBean.setTraileringGGCWRRatingsID((BigDecimal)(row.get("TRAILERINGGCWRRATINGSID")));
			traileringSpecsGCWRBean.setRearAxleRatio((BigDecimal)(row.get("REARAXLERATIO")));
			traileringSpecsGCWRBean.setRaRatioText(String.valueOf(row.get("RARATIOTEXT")));
			traileringSpecsGCWRBean.setRestricionID((BigDecimal)(row.get("RESTRICTIONID")));
			traileringSpecsGCWRBean.setGCWRValue((BigDecimal)(row.get("GCWRVALUE")));
			traileringSpecsGCWRBean.setEngineSort((BigDecimal)(row.get("ENGINESORT")));
			traileringSpecsGCWRBeanList.add(traileringSpecsGCWRBean);

		}



		List<Map<String, Object>> traileringEntry = jdbcTemplate.queryForList(traileringEntrySQL);

		for (Map row : traileringEntry) {
			TraileringSpecsGCWRContent traileringSpecsGCWRContent = new TraileringSpecsGCWRContent();
			traileringSpecsGCWRContent.setTraileringCategoryHeaderID((BigDecimal)(row.get("TRAILERINGCATEGORYHEADERID")));
			traileringSpecsGCWRContent.setMaxTraileringWeight((BigDecimal)(row.get("MAXTRAILERWEIGHT")));
			traileringSpecsGCWRContent.setAxleRatio((BigDecimal)(row.get("AXLERATIO")));
			traileringSpecsGCWRContent.setTraileringCateogoryID((BigDecimal)(row.get("TRAILERINGCATEGORYID")));
			traileringSpecsGCWRContent.setTraileringHeaderID((BigDecimal)(row.get("TRAILERINGHEADERID")));
			traileringSpecsGCWRContent.setAxleRatioRestrictionID((BigDecimal)(row.get("AXLERATIORESTRICTIONID")));
			traileringSpecsGCWRContent.setMaxTraileringWeightMetric((BigDecimal)(row.get("MAXTRAILERWEIGHTMETRIC")));
			traileringSpecsGCWRContent.setEngineSort((BigDecimal)(row.get("ENGINESORT")));
			traileringSpecsGCWRContent.setMaxTraileringWeightRestricionID((BigDecimal)(row.get("MAXTRAILERWEIGHTRESTRICTIONID")));
			traileringSpecsGCWRContentList.add(traileringSpecsGCWRContent);
		}


		List<Map<String, Object>> GCWRHeader = jdbcTemplate.queryForList(GCWRHeaderSQl);

		for (Map row : GCWRHeader) {

			TraileringSpecsGCWRHeaderBean traileringSpecsGCWRHeaderBean = new TraileringSpecsGCWRHeaderBean();

			traileringSpecsGCWRHeaderBean.setVehicleID((BigDecimal)(row.get("VEHICLEID")));
			traileringSpecsGCWRHeaderBean.setGCWRValue((BigDecimal)(row.get("GCWRVALUE")));
			traileringSpecsGCWRHeaderBean.setGCWRValueMetric((BigDecimal)(row.get("GCWRVALUEMETRIC")));
			traileringSpecsGCWRHeaderBeansList.add(traileringSpecsGCWRHeaderBean);

		}

		//	List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(vehicleSql);
		if(traileringSpecsHeaderList.size()>0){
			for (Map row : vehicle) {

				traileringSpecsHeaderList.get(0).setVehicleId((BigDecimal)row.get("VEHICLEID"));
				traileringSpecsHeaderList.get(0).setDivisionName(String.valueOf(row.get("DIVISIONNAME")));
				traileringSpecsHeaderList.get(0).setVehicleName(String.valueOf(row.get("VEHICLENAME")));
				traileringSpecsHeaderList.get(0).setRegionName(String.valueOf(row.get("REGIONNAME")));
				traileringSpecsHeaderList.get(0).setVehicleYear((BigDecimal)(row.get("VEHICLEYEAR")));
				traileringSpecsHeaderList.get(0).setDivisionID((BigDecimal)(row.get("DIVISIONID")));
				traileringSpecsHeaderList.get(0).setRegionID((BigDecimal)(row.get("REGIONID")));
				traileringSpecsHeaderList.get(0).setLocaleCode((BigDecimal)(row.get("LOCALECODE")));

			}

		}
		List<Map<String, Object>> pullDownItem = jdbcTemplate.queryForList(pullDownItemSQL);

		for (Map row : pullDownItem) {
			TraileringSpecsBeanRestriction traileringSpecsBeanRestriction = new TraileringSpecsBeanRestriction();
			if(traileringSpecsHeaderList.size()>0){
				traileringSpecsHeaderList.get(0).setPulldownText(" - "+String.valueOf(row.get("PULLDOWNTEXT")));
			}
			traileringSpecsBeanRestriction.setPulldownItemID((BigDecimal)row.get("PULLDOWNITEMID"));
			traileringSpecsBeanRestriction.setPullDownText(String.valueOf(row.get("PULLDOWNTEXT")));
			traileringSpecsBeanRestriction.setVehicleId((BigDecimal)row.get("VEHICLEID"));
			traileringSpecsBeanRestriction.setTypeID((BigDecimal)row.get("TYPEID"));
			traileringSpecsBeanRestriction.setOptionalFooterNote1(String.valueOf(row.get("OPTIONALFOOTERNOTE1")).trim()+"\n\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE2")).trim()+"\n\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE3")).trim()+"\n\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE4")).trim()+"\n\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE5")).trim()+"\n\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE6")).trim()+"\n\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE7")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE8")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE9")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE10")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE11")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE12")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE13")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE14")).trim()
					);

			traileringSpecsBeanRestriction.setType(String.valueOf(row.get("TYPE")));
			traileringSpecsBeanRestriction.setType2(String.valueOf(row.get("TYPE2")));
			traileringSpecsBeanRestriction.setOptionalTypeDescription(String.valueOf(row.get("OPTIONALTYPEDESCRIPTION")));
			traileringSpecsBeanRestrictions.add(traileringSpecsBeanRestriction);

		}


		List<Map<String, Object>> restriction= jdbcTemplate.queryForList(restrictionSql);
		for (Map row : restriction) {
			TraileringSpecsBeanRestriction traileringSpecsBeanRestriction = new TraileringSpecsBeanRestriction();
			traileringSpecsBeanRestriction.setRestrictionID((BigDecimal)row.get("RESTRICTIONID"));
			traileringSpecsBeanRestriction.setRestrictionText(String.valueOf(row.get("RESTRICTIONTEXT")));
			traileringSpecsBeanRestrictions2.add(traileringSpecsBeanRestriction);
		}

		finalList.add(traileringSpecsHeaderList);
		finalList.add(traileringSpecsContentBeansList);
		finalList.add(traileringSpecsGCWRBeanList);
		finalList.add(traileringSpecsGCWRContentList);
		finalList.add(traileringSpecsGCWRHeaderBeansList);
		finalList.add(traileringSpecsBeanRestrictions);
		finalList.add(traileringSpecsBeanRestrictions2);
		return (ArrayList<Object>) finalList;




	}


	private ArrayList<Object> nonDomesticVehicles(int subCategoryID, String vehicleID,
			int lang, int pageNumber ) {
		finalList = new ArrayList<Object>();
		traileringSpecsHeaderList = new ArrayList<TraileringSpecsBean>();
		traileringSpecsContentBeansList = new ArrayList<TraileringSpecsContentBean>();
		traileringSpecsGCWRBeanList =new ArrayList<TraileringSpecsGCWRBean>();
		traileringSpecsGCWRContentList = new ArrayList<TraileringSpecsGCWRContent>();
		traileringSpecsGCWRHeaderBeansList =new ArrayList<TraileringSpecsGCWRHeaderBean>(); 
		traileringSpecsBeanRestrictions = new ArrayList<TraileringSpecsBeanRestriction>();
		traileringSpecsBeanRestrictions2 = new ArrayList<TraileringSpecsBeanRestriction>();

		String   vehicleSql = "SELECT v.*, d.divisionName, r.regionName FROM v_division d, v_vehicle v, v_Region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID) and v.localecode="+lang+" and" +
				" (v.regionID = d.regionID) and r.localecode="+lang+" and d.localecode="+lang+" and" +
				" (v.regionID = r.regionID)";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(vehicleSql);

		String traileringHeaderSQL = "SELECT distinct th.*, e.engineDescription, tc.vehicleId, oc.typeFlag, e.engineRPO as rpoName FROM " +
				" v_OptionCode oc, TraileringHeader th, v_Engine e, TraileringCategoryHeader tch, v_TraileringCategory tc, v_PullDownItem pdi " +
				" WHERE  th.TraileringHeaderID = tch.TraileringHeaderID AND e.localecode="+lang+" and" +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" e.EngineID = th.EngineID AND " +
				" e.RPOID = oc.RPOID AND " +
				" tc.VehicleID = " + vehicleID +
				" AND th.pagenumber = " + pageNumber +
				" ORDER BY th.engineSort";


		String traileringCategorySQL = " SELECT "   +
				"   distinct tc.*, tcr.restrictionID, "   +
				"   tch2.maxRows, m.ModelID, m.ModelName, m.ModelDesc "   +
				" FROM "   +
				"   TraileringHeader th,"   +
				"   TraileringCategoryHeader tch,"   +
				"   TraileringCategoryRestriction tcr, " +
				"   v_TraileringCategory tc,"   +
				"   v_Model m,"   +
				"   v_PullDownItem pdi,"   +
				"   (SELECT greatest(count(tch2.axleRatio),1)  as maxRows "   +
				"    FROM TraileringCategoryHeader tch2     "   +
				"    group by tch2.TraileringHeaderID, tch2.TraileringCategoryID     )  tch2"   +
				" WHERE "   +
				"   th.TraileringHeaderID = tch.TraileringHeaderID AND  tc.localecode="+lang+" and"   +
				"   tc.TraileringCategoryID = tch.TraileringCategoryID AND"   +
				"   tc.ModelID = m.ModelID (+) AND m.localecode="+lang+" and pdi.localecode="+lang+" and"   +
				"   th.PullDownItemID = pdi.PullDownItemID AND"   +
				"   tc.VehicleID = " + vehicleID + " AND"   +
				"   th.pagenumber = " + pageNumber   +
				"   and tcr.pagenumber(+) = " + pageNumber +
				"   and  tcr.traileringcategoryid(+) = tc.traileringcategoryid  " +
				"   and tch2.maxRows = (SELECT greatest(max(count(tch3.axleRatio)),1)  as maxRows "   +
				"    FROM TraileringCategoryHeader tch3, TraileringHeader th3 "   +
				"    where tch3.traileringcategoryid = tc.traileringcategoryid     "   +
				"    and tch3.traileringheaderid = th3.traileringheaderid     "   +
				"    and th3.pagenumber = " + pageNumber   +
				"    group by tch3.TraileringHeaderID    )"   +
				" ORDER BY tc.tcSort"  ;

		String traileringEntrySQL  = "SELECT distinct tch.*, tch.maxTrailerWeight * " + CONVERSION_FACTOR +
				" AS maxTrailerWeightMetric, tc.tcSort, th.engineSort FROM " +
				" TraileringHeader th, TraileringCategoryHeader tch, v_TraileringCategory tc, v_PullDownItem pdi " +
				" WHERE  th.TraileringHeaderID = tch.TraileringHeaderID AND tc.localecode="+lang+"and" +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" tc.VehicleID = " + vehicleID +
				" AND th.pagenumber = " + pageNumber +
				" ORDER BY tc.tcSort, th.engineSort, tch.axleRatio";

		String GCWRSql = "SELECT distinct thg.*, tg.GCWR AS GCWRValue, th.engineSort FROM " +
				" TraileringHeaderGCWRRatings thg, TraileringGCWRRatings tg, TraileringHeader th, TraileringCategoryHeader tch, v_TraileringCategory tc, v_PullDownItem pdi " +
				" WHERE  th.TraileringHeaderID = tch.TraileringHeaderID AND tc.localecode="+lang+" and  " +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" tc.VehicleID = " + vehicleID +
				" AND th.pagenumber = " + pageNumber +
				" AND th.TraileringHeaderID = thg.TraileringHeaderID " +
				" AND thg.TraileringGCWRRatingsID = tg.TraileringGCWRRatingsID " +
				" ORDER BY tg.GCWR";

		String GCWRHeaderSQl = "SELECT distinct " + vehicleID +
				" as VehicleID, tg.GCWR AS GCWRValue, tg.GCWR * " + CONVERSION_FACTOR +
				" AS GCWRValueMetric FROM " +
				" TraileringHeaderGCWRRatings thg, TraileringGCWRRatings tg, TraileringHeader th, TraileringCategoryHeader tch, v_TraileringCategory tc, v_PullDownItem pdi " +
				" WHERE  th.TraileringHeaderID = tch.TraileringHeaderID AND " +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND tc.localecode="+lang+" and" +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" tc.VehicleID = " + vehicleID +
				" AND th.pagenumber = " + pageNumber +
				" AND th.TraileringHeaderID = thg.TraileringHeaderID " +
				" AND thg.TraileringGCWRRatingsID = tg.TraileringGCWRRatingsID " +
				" ORDER BY tg.GCWR";

		String pullDownItemSQL  = "SELECT distinct pdi.*, th.pageNumber, t.* FROM v_PullDownItem pdi, " +
				" v_TraileringHeader th, v_Type t, TraileringCategoryHeader tch, v_TraileringCategory tc WHERE " +
				" th.TraileringHeaderID = tch.TraileringHeaderID AND t.localecode="+lang+" and th.localecode="+lang+" and" +
				" tc.TraileringCategoryID = tch.TraileringCategoryID AND tc.localecode="+lang+" and " +
				" th.PullDownItemID = pdi.PullDownItemID AND " +
				" t.TypeID = pdi.TypeID AND PDI.localecode="+lang+" and th.pageNumber = " +pageNumber+
				" and tc.VehicleID = " + vehicleID +
				" ORDER BY th.pagenumber";

		String restrictionSql = "SELECT  DISTINCT r.restrictionid, r.restrictionText, r.vehicleid " +
				"  FROM v_Vehicle v, v_TraileringHeader th, v_Restriction r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (r.VehicleID = v.VehicleID) AND v.localecode="+lang+" and r.localecode="+lang+" and th.localecode="+lang+" and" +
				" (th.pagenumber = " + pageNumber + ") AND" +
				" (th.PullDownItemID = r.PullDownItemID) " +
				" order by r.restrictionid";


		List<Map<String, Object>> traileringHeader = jdbcTemplate.queryForList(traileringHeaderSQL);

		for (Map row : traileringHeader) {

			TraileringSpecsBean traileringSpecsBean = new TraileringSpecsBean();

			traileringSpecsBean.setTraileringHeaderID((BigDecimal)(row.get("TRAILERINGHEADERID")));
			traileringSpecsBean.setPulldownItemID((BigDecimal)(row.get("PULLDOWNITEMID")));
			traileringSpecsBean.setPageNumber((BigDecimal)(row.get("PAGENUMBER")));
			traileringSpecsBean.setEngineID((BigDecimal)(row.get("ENGINEID")));
			traileringSpecsBean.setEngineSort((BigDecimal)(row.get("ENGINESORT")));
			traileringSpecsBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			traileringSpecsBean.setEngineDescription(String.valueOf(row.get("ENGINEDESCRIPTION")));
			traileringSpecsBean.setRpoName(String.valueOf(row.get("RPONAME")));

			traileringSpecsHeaderList.add(traileringSpecsBean);

		}




		List<Map<String, Object>> traileringCategory = jdbcTemplate.queryForList(traileringCategorySQL);

		for (Map row : traileringCategory) {

			TraileringSpecsContentBean traileringSpecsContentBean = new TraileringSpecsContentBean();

			traileringSpecsContentBean.setTraileringCategoryID((BigDecimal)(row.get("TRAILERINGCATEGORYID")));
			traileringSpecsContentBean.setTCName((String.valueOf(row.get("TCNAME"))));
			traileringSpecsContentBean.setTCSort((BigDecimal)(row.get("TCSORT")));
			traileringSpecsContentBean.setModelID((BigDecimal)(row.get("MODELID")));
			traileringSpecsContentBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			traileringSpecsContentBean.setModelName(String.valueOf(row.get("MODELNAME")));
			traileringSpecsContentBean.setModeldesc(String.valueOf(row.get("MODELDESC")));
			traileringSpecsContentBean.setMaxRows((BigDecimal)(row.get("MAXROWS")));
			traileringSpecsContentBeansList.add(traileringSpecsContentBean);

		}



		List<Map<String, Object>> GCWR = jdbcTemplate.queryForList(GCWRSql);

		for (Map row : GCWR) {

			TraileringSpecsGCWRBean traileringSpecsGCWRBean = new TraileringSpecsGCWRBean();

			traileringSpecsGCWRBean.setTraileringHeaderID((BigDecimal)(row.get("TRAILERINGHEADERID")));
			traileringSpecsGCWRBean.setTraileringGGCWRRatingsID((BigDecimal)(row.get("TRAILERINGGCWRRATINGSID")));
			traileringSpecsGCWRBean.setRearAxleRatio((BigDecimal)(row.get("REARAXLERATIO")));
			traileringSpecsGCWRBean.setRaRatioText(String.valueOf(row.get("RARATIOTEXT")));
			traileringSpecsGCWRBean.setRestricionID((BigDecimal)(row.get("RESTRICTIONID")));
			traileringSpecsGCWRBean.setGCWRValue((BigDecimal)(row.get("GCWRVALUE")));
			traileringSpecsGCWRBean.setEngineSort((BigDecimal)(row.get("ENGINESORT")));
			traileringSpecsGCWRBeanList.add(traileringSpecsGCWRBean);

		}



		List<Map<String, Object>> traileringEntry = jdbcTemplate.queryForList(traileringEntrySQL);

		for (Map row : traileringEntry) {
			TraileringSpecsGCWRContent traileringSpecsGCWRContent = new TraileringSpecsGCWRContent();
			traileringSpecsGCWRContent.setTraileringCategoryHeaderID((BigDecimal)(row.get("TRAILERINGCATEGORYHEADERID")));
			traileringSpecsGCWRContent.setMaxTraileringWeight((BigDecimal)(row.get("MAXTRAILERWEIGHT")));
			traileringSpecsGCWRContent.setAxleRatio((BigDecimal)(row.get("AXLERATIO")));
			traileringSpecsGCWRContent.setTraileringCateogoryID((BigDecimal)(row.get("TRAILERINGCATEGORYID")));
			traileringSpecsGCWRContent.setTraileringHeaderID((BigDecimal)(row.get("TRAILERINGHEADERID")));
			traileringSpecsGCWRContent.setAxleRatioRestrictionID((BigDecimal)(row.get("AXLERATIORESTRICTIONID")));
			traileringSpecsGCWRContent.setMaxTraileringWeightMetric((BigDecimal)(row.get("MAXTRAILERWEIGHTMETRIC")));
			traileringSpecsGCWRContent.setEngineSort((BigDecimal)(row.get("ENGINESORT")));
			traileringSpecsGCWRContent.setMaxTraileringWeightRestricionID((BigDecimal)(row.get("MAXTRAILERWEIGHTRESTRICTIONID")));
			traileringSpecsGCWRContentList.add(traileringSpecsGCWRContent);
		}


		List<Map<String, Object>> GCWRHeader = jdbcTemplate.queryForList(GCWRHeaderSQl);

		for (Map row : GCWRHeader) {

			TraileringSpecsGCWRHeaderBean traileringSpecsGCWRHeaderBean = new TraileringSpecsGCWRHeaderBean();

			traileringSpecsGCWRHeaderBean.setVehicleID((BigDecimal)(row.get("VEHICLEID")));
			traileringSpecsGCWRHeaderBean.setGCWRValue((BigDecimal)(row.get("GCWRVALUE")));
			traileringSpecsGCWRHeaderBean.setGCWRValueMetric((BigDecimal)(row.get("GCWRVALUEMETRIC")));
			traileringSpecsGCWRHeaderBeansList.add(traileringSpecsGCWRHeaderBean);

		}

		//	List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(vehicleSql);
		if(traileringSpecsHeaderList.size()>0){
			for (Map row : vehicle) {

				traileringSpecsHeaderList.get(0).setVehicleId((BigDecimal)row.get("VEHICLEID"));
				traileringSpecsHeaderList.get(0).setDivisionName(String.valueOf(row.get("DIVISIONNAME")));
				traileringSpecsHeaderList.get(0).setVehicleName(String.valueOf(row.get("VEHICLENAME")));
				traileringSpecsHeaderList.get(0).setRegionName(String.valueOf(row.get("REGIONNAME")));
				traileringSpecsHeaderList.get(0).setVehicleYear((BigDecimal)(row.get("VEHICLEYEAR")));
				traileringSpecsHeaderList.get(0).setDivisionID((BigDecimal)(row.get("DIVISIONID")));
				traileringSpecsHeaderList.get(0).setRegionID((BigDecimal)(row.get("REGIONID")));
				traileringSpecsHeaderList.get(0).setLocaleCode((BigDecimal)(row.get("LOCALECODE")));


			}

		}

		List<Map<String, Object>> pullDownItem = jdbcTemplate.queryForList(pullDownItemSQL);

		for (Map row : pullDownItem) {
			TraileringSpecsBeanRestriction traileringSpecsBeanRestriction = new TraileringSpecsBeanRestriction();
			if(traileringSpecsHeaderList.size()>0){
				traileringSpecsHeaderList.get(0).setPulldownText(" - "+String.valueOf(row.get("PULLDOWNTEXT")));
			}
			traileringSpecsBeanRestriction.setPulldownItemID((BigDecimal)row.get("PULLDOWNITEMID"));
			traileringSpecsBeanRestriction.setPullDownText(String.valueOf(row.get("PULLDOWNTEXT")));
			traileringSpecsBeanRestriction.setVehicleId((BigDecimal)row.get("VEHICLEID"));
			traileringSpecsBeanRestriction.setTypeID((BigDecimal)row.get("TYPEID"));
			traileringSpecsBeanRestriction.setOptionalFooterNote1(String.valueOf(row.get("OPTIONALFOOTERNOTE1")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE2")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE3")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE4")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE5")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE6")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE7")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE8")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE9")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE10")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE11")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE12")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE13")).trim()+"\n"+
					String.valueOf(row.get("OPTIONALFOOTERNOTE14")).trim()
					);

			traileringSpecsBeanRestriction.setType(String.valueOf(row.get("TYPE")));
			traileringSpecsBeanRestriction.setType2(String.valueOf(row.get("TYPE2")));
			traileringSpecsBeanRestriction.setOptionalTypeDescription(String.valueOf(row.get("OPTIONALTYPEDESCRIPTION")));
			traileringSpecsBeanRestrictions.add(traileringSpecsBeanRestriction);

		}


		List<Map<String, Object>> restriction= jdbcTemplate.queryForList(restrictionSql);
		for (Map row : restriction) {
			TraileringSpecsBeanRestriction traileringSpecsBeanRestriction = new TraileringSpecsBeanRestriction();
			traileringSpecsBeanRestriction.setRestrictionID((BigDecimal)row.get("RESTRICTIONID"));
			traileringSpecsBeanRestriction.setRestrictionText(String.valueOf(row.get("RESTRICTIONTEXT")));
			traileringSpecsBeanRestrictions2.add(traileringSpecsBeanRestriction);
		}

		finalList.add(traileringSpecsHeaderList);
		finalList.add(traileringSpecsContentBeansList);
		finalList.add(traileringSpecsGCWRBeanList);
		finalList.add(traileringSpecsGCWRContentList);
		finalList.add(traileringSpecsGCWRHeaderBeansList);
		finalList.add(traileringSpecsBeanRestrictions);
		finalList.add(traileringSpecsBeanRestrictions2);
		return (ArrayList<Object>) finalList;
	}

	public boolean isRequired(int pdfType,String vehicle) {
		String getButtonList= null;
		
		getButtonList ="SELECT b.* FROM button b, vehiclebutton vb WHERE " +
			            " (vb.VehicleID = " + vehicle + ") and" +
			            " (b.ButtonID = vb.ButtonID) and" +
			            " (b.parentbuttonID is not null) order by b.buttonsort";
		jdbcTemplate = new JdbcTemplate(dataSource);
		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getButtonList);
		List<BigDecimal> tempList = new ArrayList<BigDecimal>();
		for (Map row : modelIDList) {
			tempList.add((BigDecimal)(row.get("BUTTONID")));
		}
		
		getButtonList="	SELECT b.*, vb.VehicleID FROM button b, vehiclebutton vb WHERE"
				+ " (vb.VehicleID = " + vehicle + ") and   (b.ButtonID = vb.ButtonID) and  "
						+ " (b.ButtonLocation = 0)   and"
				+ "  (b.parentbuttonID is null) order by b.buttonsort";       
		
		List<Map<String, Object>> buttonList = jdbcTemplate.queryForList(getButtonList);
		List<BigDecimal> button_List = new ArrayList<BigDecimal>();
		for (Map row : buttonList) {
			button_List.add((BigDecimal)(row.get("BUTTONID")));
		}
		
		
		if(tempList.contains(new BigDecimal(pdfType)) || button_List.contains(new BigDecimal(pdfType)))
		{
			return true;
		}		
		
		return false;


	}


}
