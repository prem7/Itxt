package com.dci.enterprise.dao;

import java.util.ArrayList;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextPDFGeneratorDAO {
	public void startRadioPDFGeneration(int id);

	public void startColorAndTrimPDFGeneration(List<ArrayList<Object>> vehicleItemsXML,int pdfType);

	

	public void startColorAndTrimPDFGeneration(List<ArrayList<Object>> vehicleItemsXML,
			Document document, PdfWriter writer, int pdfType);
	
	//public void startRadioPDFGeneration(List<List<WheelsAndRadiosBean>> vehicleItemsXML);
}
