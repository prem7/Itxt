package com.dci.enterprise.dao;

import java.util.List;

import com.dci.enterprise.model.WheelsAndRadiosBean;

public interface WheelsAndRadiosDao {
	
	public List<WheelsAndRadiosBean> getVehicleItemsXML(int subCategoryID, String vehicleID,int localeCode);


}
