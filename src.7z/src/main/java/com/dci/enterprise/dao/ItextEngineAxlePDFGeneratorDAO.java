package com.dci.enterprise.dao;

import java.util.ArrayList;
import java.util.List;

import com.dci.enterprise.model.RpoCodesBean;
import com.dci.enterprise.model.SpecsAndDimensionBean;
import com.dci.general.utilities.VehicleConstant;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextEngineAxlePDFGeneratorDAO {


	void onCloseDocument(PdfWriter writer, Document document);

	public void startSpecsAndDimPDFGeneration(List<ArrayList<Object>> list);

	void startSpecsAndDimPDFGeneration(List<ArrayList<Object>> list,
			Document document, PdfWriter writer,int pdfType);

}
