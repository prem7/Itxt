package com.dci.enterprise.dao.impl;
//package com.dci.enterprise.model.dao.impl;
//
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//
//import javax.management.Query;
//import javax.sql.DataSource;
//
//import org.springframework.jdbc.core.JdbcTemplate;
//
//import com.dci.enterprise.model.ColorAndTrimBean;
//import com.dci.enterprise.model.dao.ColorAndTrimDAO;
//
//public class CopyOfWheelsAndRadioDAOImpl implements ColorAndTrimDAO{
//
//	private DataSource dataSource;
//	private JdbcTemplate jdbcTemplate;
//	List<ColorAndTrimBean> modelList = new ArrayList<ColorAndTrimBean>();
//
//	public void setDataSource(DataSource dataSource) {
//		this.dataSource = dataSource;
//	}
//	public List<ColorAndTrimBean> getVehicleItemsXML(int subCategoryID, String queryType,String vehicleID) {
//		Query query = null;
//		String sql = null;
//		String Testsql = null;
//		String Testsql1 = null;
//		try{
//
//			query = new Query();
//			Testsql = "SELECT DISTINCT oc.*, c.categoryname, c.categorydesc, c.categorysorter, sc.subcategoryid, sc.subcategoryname, sc.subcategorydesc, sc.subcategorynote, sc.subcategorysorter, m.vehicleID, oced.optionCodeSort, oced.newOptionFlag, oced.link_indicator, oced.pdf_filename, ed.*, gt.* " +
//					" FROM package p, model m, packageoptioncode poc, optioncode oc, optCodeExtDesc oced, extendedDesc ed, category c, subcategory sc, graytabtype gt WHERE " +
//					" (m.VehicleID = " + vehicleID + ") AND" +
//					" (p.pageNumber = 1) AND" +
//					" (p.modelID = m.modelID) AND " +
//					" (p.packageID = poc.packageID) AND " +
//					" (oc.subcategoryID = sc.subcategoryID(+)) AND " +
//					" (oc.categoryID = c.categoryID(+)) AND " +
//					" (oc.graytabtypeID = gt.graytabtypeID(+)) AND " +
//					" (oc.RPOID = poc.RPOID) AND "+
//					"(poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) AND " +
//					" (" + vehicleID + " = oced.vehicleid(+)) AND (oc.rpoid = oced.rpoid(+)) AND (oced.extendedDescID = ed.extendedDescID(+))" +
//					" order by " +  " oced.optionCodeSort ";
//
//			String sqlSubquery = "SELECT DISTINCT oc.rpoid " +
//					" FROM package p, model m, packageoptioncode poc, optioncode oc WHERE " +
//					" (m.VehicleID = " + vehicleID + ") AND" +
//					" (p.pageNumber =  1 ) AND" +
//					" (p.modelID = m.modelID) AND " +
//					" (p.packageID = poc.packageID) AND " +
//					" (oc.RPOID = poc.RPOID) AND " +
//					"(poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ";
//
//			Testsql1 = "SELECT DISTINCT oc.rpoid, pd.packagedescsort, oced.optionCodeSort, p.*, poc.*, r.rDescription, rh.restrictionHeaderDesc, a.* " +
//					" FROM package p, packagedesc pd, model m, OptCodeExtDesc oced, packageoptioncode poc, optioncode oc, availableCode a, optionRestriction r, optionRestrictionHeader rh WHERE " +
//					" oc.RPOID IN (" + sqlSubquery + ") AND " +
//					" (m.VehicleID = " + vehicleID + ") AND" +
//					" (p.modelID = m.modelID) AND " +
//					" (p.pageNumber = 1) AND" +
//					" (oced.vehicleId = " + vehicleID + ") AND" +
//					" (p.packageID = poc.packageID) AND " +
//					" (p.packagedescid = pd.packagedescid) AND " +
//					" (oc.RPOID = poc.RPOID) AND " +
//					" (oced.rpoId = oc.rpoId) AND" + 
//					" (poc.restrictionID = r.OptionRestrictionID(+)) AND " +
//					" (" + vehicleID + " = r.VehicleID(+)) AND " +
//					" (r.RestrictionHeaderID = rh.OptionRestrictionHeaderID(+)) AND " +
//					" (poc.availablecodeID = a.availablecodeID(+)) " +
//					" ORDER BY oced.optionCodeSort, pd.packagedescsort, p.packageSort";
//
//			sql = "SELECT DISTINCT m.vehicleid, ("+ 1+") AS rowNumber, i.*, ic.*, oc.*, c.*, sc.*, ed.*, oced.optionCodeSecSort  " +
//					" FROM package p, model m, packageoptioncode poc, optioncode oc, optCodeExtDesc oced, extendedDesc ed, category c, subcategory sc, optionimage oi, images i, imagecategory ic  WHERE " +
//					" (m.VehicleID ="+vehicleID+") AND" +
//					" (oc.subcategoryID = 1) AND" +
//					" (p.modelID = m.modelID) AND " +
//					" (p.packageID = poc.packageID) AND " +
//					" (oc.subcategoryID = sc.subcategoryID(+)) AND " +
//					" (oc.categoryID = c.categoryID(+)) AND " +
//					" (oc.RPOID = poc.RPOID) AND " +
//					" ("+vehicleID+" = oced.vehicleid(+)) AND (oc.rpoid = oced.rpoid(+)) AND (oced.extendedDescID = ed.extendedDescID(+)) AND " +
//					" (oi.VehicleID(+) = "+vehicleID+") AND" +
//					" (oi.imageid = i.imageid(+)) AND " +
//					" (i.imageCategoryid = ic.imageCategoryid(+)) AND " +
//					" (oc.rpoid = oi.rpoid(+)) " +
//					" ORDER BY oced.optionCodeSecSort, oc.rpoid";
//
//			jdbcTemplate = new JdbcTemplate(dataSource);
//			//List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
//		//	List<Map<String, Object>> newrows = jdbcTemplate.queryForList(Testsql);
//			List<Map<String, Object>> grows = jdbcTemplate.queryForList(Testsql);
//			
//			for (Map row : grows) {
//				ColorAndTrimBean colorAndTrimBean = new ColorAndTrimBean();
//				//colorTrimSeatList.clear();
//			//	model.setModelDesc((String.valueOf(row.get("IMAGENAME"))));
//				//model.setVehicleId(Integer.parseInt(String.valueOf(row.get("VEHICLEID"))));
//				//model.setModelName((String.valueOf(row.get("IMAGEID"))));
//				colorAndTrimBean.setRegionName("Canada");
//				colorAndTrimBean.setVehicleName("TestingVehicle");
//				colorAndTrimBean.setRpodesc((String.valueOf(row.get("RPODESC"))));
//				colorAndTrimBean.setRponame((String.valueOf(row.get("RPONAME"))));
//				//model.setRpodescbold((String.valueOf(row.get("RPODESCBOLD"))));
//				modelList.add(colorAndTrimBean);
//			}
//
//			return modelList;
//		}
//
//		catch(Exception e ){
//			System.out.println("Exception" +e);
//		}
//		return modelList;
//
//	}
//
//
//
//
//	public List<String> getAVehicles() {
//		List<String> listVehicles = new ArrayList<String>();
//		Query query = null;
//		String sql = null;
//
//		try{
//
//			query = new Query();
//
//			sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 and VEHICLEID=17008";
//
//
//			jdbcTemplate = new JdbcTemplate(dataSource);
//			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
//			for (Map row : rows) {
//				listVehicles.add((String.valueOf(row.get("VehicleID"))));
//			}
//
//			return listVehicles;
//		}
//
//		catch(Exception e ){
//			System.out.println("Exception" +e);
//		}
//		return listVehicles;
//
//	}
//	public HashSet getNColor() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//}
