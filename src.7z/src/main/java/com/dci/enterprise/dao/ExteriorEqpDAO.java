package com.dci.enterprise.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dci.enterprise.model.StdEqpHelper;

public interface ExteriorEqpDAO {
	
	public Object[][] getVehicleItemsXML(int subCategoryID,int categoryID,  String availCode_SQLCondition,String availCode_Sort, String vehicleID,int lang);
	
	public Object[][] getAvaialableCode();
	public HashMap <BigDecimal,ArrayList<String>>  getPackageList();
	public List<StdEqpHelper>  getPackageDescText();
	public ArrayList<BigDecimal> getModelList ();
	public List<String> getAVehicles();
	//public void startStdEqPDFGeneration(List<StandardEqpBean> vehicleItemsXML);

//	public void getModelList(List<StandardEqpBean> vehicleItemsXML);

}
