package com.dci.enterprise.dao.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.TranslationHelperDAO;
import com.dci.enterprise.model.ColorAndTrimBean;
import com.dci.enterprise.model.ColorAndTrimHelper;
import com.dci.enterprise.model.ColorRestrictionBean;
import com.dci.enterprise.model.ColorTrimAvailabliltiy;
import com.dci.enterprise.model.ExtraColumnsHeaderBean;
import com.dci.translationChecker.TranslationChecker;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;


public class TranslationHelperImpl implements TranslationHelperDAO {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	public boolean checkTranslation(String keyColumns, String keyValues,
			String vehicleID) {

		Query query = null;

		String getVehicle = null;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(TranslationChecker.class.getName());
		query = new Query();

		getVehicle = "select * from localizationqueue where keycolumnnames = '"+keyColumns+"' and keyvalues in ( "+keyValues+" ) and statusid !=7";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(!vehicle.isEmpty())
			return true;
		else
			return false;



	}





}
