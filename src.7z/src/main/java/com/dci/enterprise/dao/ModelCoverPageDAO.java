package com.dci.enterprise.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dci.enterprise.model.ModelCoverPageBean;
import com.dci.enterprise.model.StandardEqpBean;
import com.dci.enterprise.model.StdEqpHelper;

public interface ModelCoverPageDAO {
	
	public ModelCoverPageBean getVehicleItemsXML(int subCategoryID, String availCode_SQLCondition,int lang);
	
	public Object[][] getAvaialableCode();
	public List<HashMap<BigDecimal, ArrayList<String>>>  getPackageList();
	public List<StdEqpHelper>  getPackageDescText();
	public List<ArrayList<BigDecimal>> getModelList ();
	public List<String> getAVehicles();
	public List<Object> getRegOption();
	public boolean isRequired(int pegStairstep, String vehicle);
	
	//public void startStdEqPDFGeneration(List<StandardEqpBean> vehicleItemsXML);

//	public void getModelList(List<StandardEqpBean> vehicleItemsXML);

}
