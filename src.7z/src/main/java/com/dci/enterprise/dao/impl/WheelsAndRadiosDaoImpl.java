package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.WheelsAndRadiosDao;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.WheelsAndRadiosBean;

public class WheelsAndRadiosDaoImpl implements WheelsAndRadiosDao{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private List<WheelsAndRadiosBean> listWheelsAndRadiosBeans;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public List<WheelsAndRadiosBean> getVehicleItemsXML(int subCategoryID,String vehicleID,int localeCode) {
	//	localeCode=2;
		
	
		String getVehicle = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		try{

			getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d,vehicle v, region r WHERE " +
					" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
					" (v.divisionID = d.divisionID) and " +
					" (v.regionID = d.regionID) and " +
					" (d.regionID = r.regionID) ";

			List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
			boolean isCanada=false;
			boolean isVehicleActive=false;
			for (Map row : vehicle) {

				if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

					isCanada= true;
				}
				else{
					isCanada=false;
				}

				if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

					isVehicleActive= true;
				}
				else{
					isVehicleActive=false;
				}


			}

if(isVehicleActive){
	if(isCanada)
	{
		log.info("VEHICLE is in Canadian Region");
		nonDomesticVehicles(subCategoryID, vehicleID, localeCode);	
	}
	else{
		log.info("VEHICLE is in non-Canadian Region");
		domesticVehicles(subCategoryID, vehicleID, localeCode);
	}
	

}
else{
	log.error("VEHICLE NOT ACTIVE");
}

			
		}

		catch(Exception e ){
			System.out.println("Exception " +e);
		}
		return listWheelsAndRadiosBeans;




	}
	private void domesticVehicles(int subCategoryID, String vehicleID, int localeCode) {
		String getWheelsAndRadios = null;
		String getVehicle = null;
		listWheelsAndRadiosBeans= new ArrayList<WheelsAndRadiosBean>();
		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
                " (v.VehicleID = " + vehicleID + ") AND " +
                " (v.divisionID = d.divisionID) and " +
                " (v.regionID = d.regionID) and " + 
                " (v.regionID = r.regionID)";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		
		String sqlSubquery ="SELECT COUNT (DISTINCT oced2.optionCodeSecSort) " + //oc2.rpoid) " +
	            " FROM optioncode oc2, package p2, model m2, packageoptioncode poc2, optcodeextdesc oced2  " +
	            " WHERE " +
	            " (m2.VehicleID = " + vehicleID + ") AND" +
	            " (oc2.subcategoryID = " + subCategoryID + ") AND" +
	            " (p2.modelID = m2.modelID) AND " +
	            " (p2.packageID = poc2.packageID) AND " +
				" (oc2.RPOID = oced2.RPOID) AND " +
				" (oced2.vehicleid = " + vehicleID + ") AND " +
	            " (oced2.optionCodeSecSort <= oced.optionCodeSecSort)";

		getWheelsAndRadios = "SELECT DISTINCT m.vehicleid, (" + sqlSubquery + ") AS rowNumber, i.*, ic.*, oc.*, c.*, sc.*, ed.*, oced.optionCodeSecSort  " +
	            " FROM package p, model m, packageoptioncode poc, optioncode oc, optCodeExtDesc oced, extendedDesc ed, category c, subcategory sc, optionimage oi, images i, imagecategory ic  WHERE " +
	            " (m.VehicleID = " + vehicleID + ") AND" +
	            " (oc.subcategoryID = " + subCategoryID + ") AND" +
	            " (p.modelID = m.modelID) AND " +
	            " (p.packageID = poc.packageID) AND " +
	            " (oc.subcategoryID = sc.subcategoryID(+)) AND " +
	            " (oc.categoryID = c.categoryID(+)) AND " +
	            " (oc.RPOID = poc.RPOID) AND " +
	            " (" + vehicleID + " = oced.vehicleid(+)) AND (oc.rpoid = oced.rpoid(+)) AND (oced.extendedDescID = ed.extendedDescID(+)) AND " +
	            
	            " (oi.VehicleID(+) = " + vehicleID + ") AND" +
	            " (oi.imageid = i.imageid(+)) AND " +
	            " (i.imageCategoryid = ic.imageCategoryid(+)) AND " +
	            " (oc.rpoid = oi.rpoid(+)) " +
	            
	            " ORDER BY oced.optionCodeSecSort, oc.rpoid";



		List<Map<String, Object>> wheelsAndRadios = jdbcTemplate.queryForList(getWheelsAndRadios);





		for (Map row : wheelsAndRadios) {

			WheelsAndRadiosBean wheelsAndRadiosBean = new WheelsAndRadiosBean();

			wheelsAndRadiosBean.setImageName((String.valueOf(row.get("IMAGENAME"))));

			if((String.valueOf(row.get("TYPEFLAG"))).equals("1")){
				wheelsAndRadiosBean.setRpoName((String.valueOf(row.get("RPONAME"))));
			}
			else{
				wheelsAndRadiosBean.setRpoName("");
			}
			if((String.valueOf(row.get("RPODESC"))).equals("null")){
				wheelsAndRadiosBean.setRpoDesc("");
			}else{
				wheelsAndRadiosBean.setRpoDesc((String.valueOf(row.get("RPODESC"))));
			}

			if((String.valueOf(row.get("RPODESCBOLD"))).equals("null")){
				wheelsAndRadiosBean.setRpoDescBold("");
			}else{
				wheelsAndRadiosBean.setRpoDescBold((String.valueOf(row.get("RPODESCBOLD"))));
			}

			if((String.valueOf(row.get("EXTENDEDDESC"))).equals("null")){
				wheelsAndRadiosBean.setExtendedDesc("");
			}else{
				wheelsAndRadiosBean.setExtendedDesc((String.valueOf(row.get("EXTENDEDDESC"))));
			}
			/*colorAndTrimBean.setSeatType((String.valueOf(row.get("SEATTYPE"))));
		colorAndTrimBean.setDecorLevel((String.valueOf(row.get("DECORLEVEL"))));
		colorAndTrimBean.setSeatTrim((String.valueOf(row.get("SEATTRIM"))));
		colorAndTrimBean.setSeatCode((String.valueOf(row.get("SEATCODE"))));
		colorAndTrimBean.setSeatID( (BigDecimal) ((row.get("SEATID"))));
		colorAndTrimBean.setSeatTrimID((String.valueOf(row.get("SEATTRIMID"))));
		colorAndTrimBean.setSeatTrimCode((String.valueOf(row.get("SEATTRIMCODE"))));*/

			listWheelsAndRadiosBeans.add(wheelsAndRadiosBean);
		} 


		for (Map row : vehicle) {
			for (int i = 0; i < listWheelsAndRadiosBeans.size(); i++) {

				listWheelsAndRadiosBeans.get(i).setVehicleID(((BigDecimal)(row.get("VEHICLEID"))));
				listWheelsAndRadiosBeans.get(i).setVehicleYear((BigDecimal)(row.get("VEHICLEYEAR")));
				listWheelsAndRadiosBeans.get(i).setVehicleName((String.valueOf(row.get("VEHICLENAME"))));
				listWheelsAndRadiosBeans.get(i).setRegionName((String.valueOf(row.get("REGIONNAME"))));
				listWheelsAndRadiosBeans.get(i).setDivisionName((String.valueOf(row.get("DIVISIONNAME"))));
				listWheelsAndRadiosBeans.get(i).setDivisionID(((BigDecimal)(row.get("DIVISIONID"))));
				listWheelsAndRadiosBeans.get(i).setvActiveflag((BigDecimal) ((row.get("VEHICLEACTIVEFLAG"))));
				listWheelsAndRadiosBeans.get(i).setRegionID((BigDecimal) ((row.get("REGIONID"))));
				listWheelsAndRadiosBeans.get(i).setLocaleCode((BigDecimal) ((row.get("LOCALECODE"))));
			}

		}
	}
	private void nonDomesticVehicles(int subCategoryID, String vehicleID, int localeCode) {
		listWheelsAndRadiosBeans= new ArrayList<WheelsAndRadiosBean>();
		String getWheelsAndRadios = null;
		String getVehicle = null;
		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM v_division d,v_vehicle v, v_region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and v.localecode="+localeCode+" and r.localecode="+localeCode+" and d.localecode="+localeCode+" and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		
		String sqlSubquery ="SELECT COUNT (DISTINCT oced2.optionCodeSecSort) " + //oc2.rpoid) " +
	            " FROM v_optioncode oc2, v_package p2, v_model m2, packageoptioncode poc2, optcodeextdesc oced2  " +
	            " WHERE " +
	            " (m2.VehicleID = " + vehicleID + ") AND" +
	            " (oc2.subcategoryID = " + subCategoryID + ") AND" +
	            " (p2.modelID = m2.modelID) AND " +
	            " (p2.packageID = poc2.packageID) AND " +
				" (oc2.RPOID = oced2.RPOID) AND " +
				" (oced2.vehicleid = " + vehicleID + ") AND " +
	            " (oced2.optionCodeSecSort <= oced.optionCodeSecSort)";

		getWheelsAndRadios = "SELECT DISTINCT m.vehicleid, (" + sqlSubquery + ") AS rowNumber, i.*, ic.*, oc.*, c.*, sc.*, ed.*, oced.optionCodeSecSort  " +
	            " FROM v_package p, v_model m, packageoptioncode poc, v_optioncode oc, optCodeExtDesc oced, v_extendedDesc ed, category c, subcategory sc, optionimage oi, v_images i, imagecategory ic  WHERE " +
	            " (m.VehicleID = " + vehicleID + ") AND" +
	            " (oc.subcategoryID = " + subCategoryID + ") AND i.localecode(+)="+localeCode+" and" +
	            " (p.modelID = m.modelID) AND m.localecode="+localeCode+" and oc.localecode="+localeCode+" and p.localecode="+localeCode+" and ed.localecode(+)="+localeCode+" and" +
	            " (p.packageID = poc.packageID) AND " +
	            " (oc.subcategoryID = sc.subcategoryID(+)) AND " +
	            " (oc.categoryID = c.categoryID(+)) AND " +
	            " (oc.RPOID = poc.RPOID) AND " +
	            " (" + vehicleID + " = oced.vehicleid(+)) AND (oc.rpoid = oced.rpoid(+)) AND (oced.extendedDescID = ed.extendedDescID(+)) AND " +
	            " (oi.VehicleID(+) = " + vehicleID + ") AND" +
	            " (oi.imageid = i.imageid(+)) AND " +
	            " (i.imageCategoryid = ic.imageCategoryid(+)) AND " +
	            " (oc.rpoid = oi.rpoid(+)) " +
	            
	            " ORDER BY oced.optionCodeSecSort, oc.rpoid";



		List<Map<String, Object>> wheelsAndRadios = jdbcTemplate.queryForList(getWheelsAndRadios);





		for (Map row : wheelsAndRadios) {

			WheelsAndRadiosBean wheelsAndRadiosBean = new WheelsAndRadiosBean();

			wheelsAndRadiosBean.setImageName((String.valueOf(row.get("IMAGENAME"))));

			if((String.valueOf(row.get("TYPEFLAG"))).equals("1")){
				wheelsAndRadiosBean.setRpoName((String.valueOf(row.get("RPONAME"))));
			}
			else{
				wheelsAndRadiosBean.setRpoName("");
			}
			if((String.valueOf(row.get("RPODESC"))).equals("null")){
				wheelsAndRadiosBean.setRpoDesc("");
			}else{
				wheelsAndRadiosBean.setRpoDesc((String.valueOf(row.get("RPODESC"))));
			}

			if((String.valueOf(row.get("RPODESCBOLD"))).equals("null")){
				wheelsAndRadiosBean.setRpoDescBold("");
			}else{
				wheelsAndRadiosBean.setRpoDescBold((String.valueOf(row.get("RPODESCBOLD"))));
			}

			if((String.valueOf(row.get("EXTENDEDDESC"))).equals("null")){
				wheelsAndRadiosBean.setExtendedDesc("");
			}else{
				wheelsAndRadiosBean.setExtendedDesc((String.valueOf(row.get("EXTENDEDDESC"))));
			}
			/*colorAndTrimBean.setSeatType((String.valueOf(row.get("SEATTYPE"))));
		colorAndTrimBean.setDecorLevel((String.valueOf(row.get("DECORLEVEL"))));
		colorAndTrimBean.setSeatTrim((String.valueOf(row.get("SEATTRIM"))));
		colorAndTrimBean.setSeatCode((String.valueOf(row.get("SEATCODE"))));
		colorAndTrimBean.setSeatID( (BigDecimal) ((row.get("SEATID"))));
		colorAndTrimBean.setSeatTrimID((String.valueOf(row.get("SEATTRIMID"))));
		colorAndTrimBean.setSeatTrimCode((String.valueOf(row.get("SEATTRIMCODE"))));*/

			listWheelsAndRadiosBeans.add(wheelsAndRadiosBean);
		} 


		for (Map row : vehicle) {
			for (int i = 0; i < listWheelsAndRadiosBeans.size(); i++) {

				listWheelsAndRadiosBeans.get(i).setVehicleID(((BigDecimal)(row.get("VEHICLEID"))));
				listWheelsAndRadiosBeans.get(i).setVehicleYear((BigDecimal)(row.get("VEHICLEYEAR")));
				listWheelsAndRadiosBeans.get(i).setVehicleName((String.valueOf(row.get("VEHICLENAME"))));
				listWheelsAndRadiosBeans.get(i).setRegionName((String.valueOf(row.get("REGIONNAME"))));
				listWheelsAndRadiosBeans.get(i).setDivisionName((String.valueOf(row.get("DIVISIONNAME"))));
				listWheelsAndRadiosBeans.get(i).setDivisionID(((BigDecimal)(row.get("DIVISIONID"))));
				listWheelsAndRadiosBeans.get(i).setvActiveflag((BigDecimal) ((row.get("VEHICLEACTIVEFLAG"))));
				listWheelsAndRadiosBeans.get(i).setRegionID((BigDecimal) ((row.get("REGIONID"))));
				listWheelsAndRadiosBeans.get(i).setLocaleCode((BigDecimal) ((row.get("LOCALECODE"))));

			}

		}
	
		
		
		
	}

}
