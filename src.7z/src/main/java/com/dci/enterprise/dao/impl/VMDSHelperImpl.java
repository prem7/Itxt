package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.VMDSHelperDAO;
import com.dci.translationChecker.TranslationChecker;


public class VMDSHelperImpl implements VMDSHelperDAO {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	static int totalEntryCount = 0;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	public void startVMDSCheck() {

		Query query = null;
		List<BigDecimal> vehicleList = new ArrayList<BigDecimal>();

		String getVehicle = null;

		getVehicle = "select unique vehicleid from vmds_cfd_trans_entry_veh";

		/*
		String getAllDescPerVehicle = "select * from vmds_cfd_trans_entry vmen,"
				+ " vmds_cfd_trans_entry_veh vmveh where vmveh.transid = vmen.id "
				+ "and vmveh.vehicleid = "+vehicleID;*/

		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(TranslationChecker.class.getName());
		query = new Query();

		List<Map<String, Object>> vehicle_List = jdbcTemplate.queryForList(getVehicle);
		for (Map row1 : vehicle_List) {
			if(!vehicle_List.isEmpty()){
				vehicleList.add((BigDecimal) row1.get("VEHICLEID"));
			}
		}
		for (BigDecimal vehicle : vehicleList) {
			startCount(vehicle);
		}

		//System.out.println("TOTAL Entry count " + totalEntryCount);
		gettotalWordscount();


	}

	private void gettotalWordscount() {
		long totalWordsCount =0;
		int temp=0;
		String getAllDescPerVehicle = "select * from vmds_cfd_trans_entry";

		List<Map<String, Object>> vehicle_List = jdbcTemplate.queryForList(getAllDescPerVehicle);
		for (Map row1 : vehicle_List) {
			if(!vehicle_List.isEmpty()){
				totalWordsCount += countWords(html2text(String.valueOf(row1.get("TEXT"))));
				temp++;
			}
		}

		System.out.println("TOTAL words count " + totalWordsCount);
		System.out.println("TOTAL Entry count " + temp);
	}


	private int startCount(BigDecimal vehicleID) {

		String getAllDescPerVehicle = "select * from vmds_cfd_trans_entry vmen,"
				+ " vmds_cfd_trans_entry_veh vmveh where vmveh.transid = vmen.id "
				+ "and vmveh.vehicleid = "+vehicleID;
		String getvehicleName = "select vehiclename from vehicle where vehicleid  = "+vehicleID;

		int count =0;
		String vehicleName = "";
		int entryCount = 0;
		List<Map<String, Object>> vehicle_List = jdbcTemplate.queryForList(getAllDescPerVehicle);
		List<Map<String, Object>> vehicle_Name = jdbcTemplate.queryForList(getvehicleName);

		for (Map row1 : vehicle_List) {
			if(!vehicle_List.isEmpty()){
				entryCount++;
				count += countWords(html2text(String.valueOf(row1.get("TEXT"))));
			}
		}
		for (Map row1 : vehicle_Name) {
			if(!vehicle_Name.isEmpty()){
				vehicleName = String.valueOf(row1.get("VEHICLENAME"));
			}
		}
		totalEntryCount+=entryCount;
		System.out.println("Word Count for vehicle -"+" "+vehicleName +"("+vehicleID+")" +" -- "+ count+", Entry Count - "+entryCount );
		return count;
	}


	public static String html2text(String html) {
		return "";
	}

	public static int countWords(String str)
	{
		String words[]=str.split(" ");
		int count=words.length;
		return count;
	}




}
