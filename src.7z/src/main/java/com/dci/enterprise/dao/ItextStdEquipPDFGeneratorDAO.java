package com.dci.enterprise.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dci.enterprise.model.StandardEqpBean;
import com.dci.enterprise.model.StdEqpHelper;
import com.dci.enterprise.model.WheelsAndRadiosBean;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextStdEquipPDFGeneratorDAO {

	public void startStdEquipPDFGeneration(Object[][] objects, Object[][] Test,List<HashMap<BigDecimal, ArrayList<String>>> 
	list,List<ArrayList<BigDecimal>> list2,
	List<StdEqpHelper> stdHelper);

	void onCloseDocument(PdfWriter writer, Document document);

	public void startStdEquipPDFGeneration(Object[][] objects, Object[][] availableCodeList,
			List<HashMap<BigDecimal, ArrayList<String>>> packageNameMap,
			List<ArrayList<BigDecimal>> modelList, List<StdEqpHelper> stdHelper, Document document,PdfWriter writer, int isPog, List<Object> list);
	
	public void startStdEquipPDFGeneration(Object[][] objects, Object[][] Test,List<HashMap<BigDecimal, ArrayList<String>>> 
	list,List<ArrayList<BigDecimal>> list2,
	List<StdEqpHelper> stdHelper,List<Object> regOptions);

}
