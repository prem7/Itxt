package com.dci.enterprise.dao;

import java.util.ArrayList;
import java.util.List;

public interface TraileringSpecsDAO {
	
	public List<ArrayList<Object>> getVehicleItemsXML(int subCategoryID,String vehicle,int lang);
	public boolean isRequired(int pegStairstep, String vehicle);
}
