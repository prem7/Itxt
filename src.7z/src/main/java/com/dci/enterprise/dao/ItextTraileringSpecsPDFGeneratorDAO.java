package com.dci.enterprise.dao;

import java.util.ArrayList;
import java.util.List;

import com.dci.enterprise.model.WheelsAndRadiosBean;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextTraileringSpecsPDFGeneratorDAO {
	

	void onCloseDocument(PdfWriter writer, Document document);

	void startRadioPDFGeneration(List<ArrayList<Object>> vehicleItemsXML,Document document,
			PdfWriter writer, int vehiclePrint);
	
	
}
