package com.dci.enterprise.dao;

import java.util.List;

import com.dci.enterprise.model.DistribtionUpdatesBean;
import com.dci.enterprise.model.RpoCodesBean;

public interface DistributionUpdatesDAO {
	
	public List<DistribtionUpdatesBean> getVehicleItemsXML(String vehicleID,int lang);
	
	public List<String> getAVehicles();


}
