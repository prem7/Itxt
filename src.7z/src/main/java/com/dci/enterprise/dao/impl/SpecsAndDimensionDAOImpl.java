package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.SpecsAndDimensionDAO;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.SpecsAndDimBeanContent;
import com.dci.enterprise.model.SpecsAndDimHelper;
import com.dci.enterprise.model.SpecsAndDimensionBean;
import com.dci.general.utilities.VehicleConstant;

public class SpecsAndDimensionDAOImpl implements SpecsAndDimensionDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	static String vehicleID=null;
	List<Object> finalList ;
	List<SpecsAndDimensionBean> rowHeaderList;
	List<SpecsAndDimBeanContent> contentList;
	List<SpecsAndDimHelper> columnHeaderList;
	List<ArrayList<Object>> finaList_TypeID;
	//private int pageNumber=1;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	String getColumnsOption = null;
	String getVehicle = null;
	public List<ArrayList<Object>> getVehicleItemsXML(String vehicleID,int type, int lang) {

		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		query = new Query();
		String getVehicle = null;

		this.vehicleID= vehicleID;
		finalList = new ArrayList<Object>();
		rowHeaderList= new ArrayList<SpecsAndDimensionBean>();
		contentList= new ArrayList<SpecsAndDimBeanContent>();
		columnHeaderList= new ArrayList<SpecsAndDimHelper>();





		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d,vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";


		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);


		boolean isCanada=false;
		boolean isVehicleActive=false;
		for (Map row : vehicle) {

			if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

				isCanada= true;
			}
			else{
				isCanada=false;
			}

			if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

				isVehicleActive= true;
			}
			else{
				isVehicleActive=false;
			}


		}


		if(isVehicleActive){
			int pulldownitemID;
			finaList_TypeID	= new ArrayList<ArrayList<Object>>();
			if(isCanada)
			{
				log.info("VEHICLE is in Canadian Region");
				for (int pageNumber = 1; pageNumber <= 4; pageNumber++) {
					pulldownitemID = getpulldownItem(type, pageNumber);
					finaList_TypeID.add(nonDomesticVehicles(vehicleID,type, lang, pageNumber,pulldownitemID));
				}
			}
			else{
				log.info("VEHICLE is in non-Canadian Region");
				for (int pageNumber = 1; pageNumber <= 4; pageNumber++) {
					pulldownitemID = getpulldownItem(type, pageNumber);
					finaList_TypeID.add(domesticVehicles(vehicleID,type, lang, pageNumber,pulldownitemID));
				}
			}


		}
		else{
			log.error("VEHICLE NOT ACTIVE");
		}


		return finaList_TypeID;
	}


	private int getpulldownItem(int type, int pageNumber) {
		BigDecimal temp = new BigDecimal(10);
		String pullDownItemSql = "SELECT distinct pdi.*, ch.pageNumber, t.* FROM PullDownItem pdi, " +
				" ColumnHeader ch, Type t, Cell, RowHeader rh WHERE " + 
				" rh.RowHeaderID = Cell.RowHeaderID AND " + 
				" ch.ColumnHeaderID = Cell.ColumnHeaderID AND " + 
				" ch.PullDownItemID = pdi.PullDownItemID AND " + 
				" t.TypeID = pdi.TypeID AND  ch.pageNumber = "+pageNumber
				+ " and ch.VehicleID = " + vehicleID +
				" AND rh.typeID =  " + type +  
				" ORDER BY ch.pageNumber";

		List<Map<String, Object>> PullDownItem = jdbcTemplate.queryForList(pullDownItemSql);
		for (Map row : PullDownItem) {
			temp = ((BigDecimal)(row.get("PULLDOWNITEMID")));
		}
		
		return temp.intValueExact();
	}


	private ArrayList<Object> domesticVehicles(String vehicleID, int type, int lang, int pageNumber, int pulldownitemID) {
		finalList = new ArrayList<Object>();
		rowHeaderList= new ArrayList<SpecsAndDimensionBean>();
		contentList= new ArrayList<SpecsAndDimBeanContent>();
		columnHeaderList= new ArrayList<SpecsAndDimHelper>();
	/*	String rowHeaderSql ="SELECT distinct rh.RowHeaderID, rh.rowCode, rh.rowHeaderSort, rh.rowBoldDescription, rh.rowDescription1, rh.rowDescription2, rh.rowRestrictionText, ch.VehicleID, conv.*, t.*, rc.* " + 
				" FROM RowHeader rh, RowCategory rc, Cell, " + 
				" ColumnHeader ch, Conversion conv, Type t WHERE " + 
				" rh.RowHeaderID = Cell.RowHeaderID AND " + 
				" rh.RowCategoryID = rc.RowCategoryID AND " + 
				" ch.ColumnHeaderID = Cell.ColumnHeaderID AND " + 
				" ch.VehicleID = " + vehicleID + 
				" AND conv.ConversionID(+) = rh.ConversionID " + 
				" AND ch.pageNumber =  " + pageNumber +  
				" AND rh.typeID =  " + type +  
				" AND t.TypeID = rh.TypeID ORDER BY rc.rowCategorySort, rh.rowHeaderSort";*/


		String rowHeaderSql =	"select distinct ch.pulldownitemid"
				+", rh.rowheaderid , rh.rowcode, rh.rowheadersort "
				+" , rh.rowbolddescription"
				+", rh.rowDescription1"
				+" , rh.rowDescription2"
				+", ch.pagenumber"
				+" , rh.rowRestrictionText"
				+", ch.vehicleid ,conv.*, rh.rowcategoryid"
				+" from ColumnHeader ch"
				+" join Cell cell"
				+" on cell.COLUMNHEADERID=ch.columnheaderid "
				+" and (cell.CELLVALUENUMBER is not null or cell.CELLVALUESTRING is not null)"
				+" join RowHeader rh"
				+" on rh.ROWHEADERID=cell.rowheaderid"
				+" join RowCategory rc"
				+" on rc.ROWCATEGORYID=rh.ROWCATEGORYID"
				+" left outer join conversion conv"
				+" on conv.CONVERSIONID=rh.CONVERSIONID"
				+" join type t on rh.typeid = t.typeid and" 
				+" t.typeid= "+type
				+" where ch.vehicleid= "+vehicleID+""
				+ " and ch.pagenumber=" +pageNumber +" and ch.pulldownitemid= "+pulldownitemID +" ORDER BY rh.rowHeaderSort";



		List<Map<String, Object>> rowHeader = jdbcTemplate.queryForList(rowHeaderSql);


		for (Map row : rowHeader) {

			SpecsAndDimensionBean specsAndDimensionBean = new SpecsAndDimensionBean();
			specsAndDimensionBean.setRowBoldDesc((String.valueOf(row.get("ROWBOLDDESCRIPTION"))));
			specsAndDimensionBean.setRowHeaderID((BigDecimal)(row.get("ROWHEADERID")));
			specsAndDimensionBean.setRowCode((String.valueOf(row.get("ROWCODE"))));
			specsAndDimensionBean.setRowDesctiption1(String.valueOf(row.get("ROWDESCRIPTION1")));
			specsAndDimensionBean.setFromUnit((String.valueOf(row.get("FROMUNIT1"))));
			specsAndDimensionBean.setColumnHeaderID((BigDecimal)(row.get("ROWHEADERID")));
			specsAndDimensionBean.setToUnit((String.valueOf(row.get("TOUNIT2"))));
			specsAndDimensionBean.setRowCategoryID((BigDecimal)(row.get("ROWCATEGORYID")));
			specsAndDimensionBean.setMultiplier((BigDecimal)(row.get("MULTIPLIER")));
			specsAndDimensionBean.setFromUnitDecimals((BigDecimal)(row.get("UNIT1DECIMALPLACES")));
			specsAndDimensionBean.setToUnitDecimals((BigDecimal)(row.get("UNIT2DECIMALPLACES")));
			specsAndDimensionBean.setRestrictionText((String.valueOf(row.get("ROWRESTRICTIONTEXT"))));
			rowHeaderList.add(specsAndDimensionBean);

		}


		String cellSql = "SELECT Cell.ColumnHeaderID, Cell.RowHeaderID, Cell.cellValueNumber, " +
				" (Cell.cellValueNumber * conv.multiplier) AS cellValueNumberMetric,  " + 
				" Cell.cellValueString FROM Cell, RowHeader rh, ColumnHeader ch, Conversion conv " +
				" WHERE rh.RowHeaderID = Cell.RowHeaderID AND " + 
				" ch.ColumnHeaderID = Cell.ColumnHeaderID AND " + 
				" ch.VehicleID = " + vehicleID + 
				" AND ch.pageNumber =  " + pageNumber +  
				" AND rh.typeID =  " + type +  
				" AND conv.ConversionID(+) = rh.ConversionID ORDER BY rh.rowHeaderSort, ch.colHeaderSort";

		List<Map<String, Object>> cell = jdbcTemplate.queryForList(cellSql);



		for (Map row : cell) {
			SpecsAndDimBeanContent specsAndDimensionContent = new SpecsAndDimBeanContent();

			specsAndDimensionContent.setRowHeaderID((BigDecimal)(row.get("ROWHEADERID")));
			specsAndDimensionContent.setColumnHeaderID((BigDecimal)(row.get("COLUMNHEADERID")));
			specsAndDimensionContent.setCellValueNumber(String.valueOf(row.get("CELLVALUENUMBER")));
			specsAndDimensionContent.setCellValueNumberMetric(String.valueOf(row.get("CELLVALUENUMBERMETRIC")));
			specsAndDimensionContent.setCellvalueString(String.valueOf(row.get("CELLVALUESTRING")));
			contentList.add(specsAndDimensionContent);
		}



		String columnHeaderSql ="SELECT distinct ch.*, m.ModelID, m.ModelName, m.ModelDesc FROM " + 
				" ColumnHeader ch, Cell, RowHeader rh, Model m WHERE " + 
				" rh.RowHeaderID = Cell.RowHeaderID AND " + 
				" ch.ColumnHeaderID = Cell.ColumnHeaderID AND " + 
				" ch.ModelID = m.ModelID (+) AND " +
				" ch.VehicleID = " + vehicleID + 
				" AND ch.pageNumber =  " + pageNumber +  
				" AND rh.typeID =  " + type +  
				" ORDER BY ch.colHeaderSort";





		List<Map<String, Object>> columnHeader = jdbcTemplate.queryForList(columnHeaderSql);

		for (Map row : columnHeader) {

			SpecsAndDimHelper specsAndDimHelper = new SpecsAndDimHelper();

			specsAndDimHelper.setColumnHeaderID((BigDecimal)(row.get("COLUMNHEADERID")));
			specsAndDimHelper.setModelDesc(String.valueOf(row.get("MODELDESC")));
			specsAndDimHelper.setModelID((BigDecimal)(row.get("MODELID")));
			specsAndDimHelper.setModelName(String.valueOf(row.get("MODELNAME")));
			specsAndDimHelper.setColHeader1((String.valueOf(row.get("COLHEADER1"))+""+String.valueOf(row.get("COLHEADER2"))+""+String.valueOf(row.get("COLHEADER3"))).replace("null", ""));

			columnHeaderList.add(specsAndDimHelper);

		}


		String pullDownItemSql = "SELECT distinct pdi.*, ch.pageNumber, t.* FROM PullDownItem pdi, " +
				" ColumnHeader ch, Type t, Cell, RowHeader rh WHERE " + 
				" rh.RowHeaderID = Cell.RowHeaderID AND " + 
				" ch.ColumnHeaderID = Cell.ColumnHeaderID AND " + 
				" ch.PullDownItemID = pdi.PullDownItemID AND " + 
				" t.TypeID = pdi.TypeID AND ch.VehicleID = " + vehicleID +
				" AND rh.typeID =  " + type +  
				" ORDER BY ch.pageNumber";


		List<Map<String, Object>> PullDownItem = jdbcTemplate.queryForList(pullDownItemSql);




		String footerNote = "SELECT distinct pdi.*, ch.pageNumber, t.* FROM PullDownItem pdi, " +
				" ColumnHeader ch, Type t, Cell, RowHeader rh WHERE " + 
				" rh.RowHeaderID = Cell.RowHeaderID AND " + 
				" ch.ColumnHeaderID = Cell.ColumnHeaderID AND " + 
				" ch.PullDownItemID = pdi.PullDownItemID AND ch.pageNumber = " +pageNumber+ 
				"  and t.TypeID = pdi.TypeID AND ch.VehicleID = " + vehicleID +
				" AND rh.typeID =  " + type +  
				" ORDER BY ch.pageNumber";

		List<Map<String, Object>> footerNoteL = jdbcTemplate.queryForList(footerNote);

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " + 
				" (v.regionID = r.regionID)";

		getColumnsOption = "select * from columnstable"
				+ " where VehicleID = "+vehicleID+
				" and PDFTYPE = "+VehicleConstant.SPECS;


		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(rowHeaderList.size()>0){
			for (Map vehicleDetails : vehicle) {
				rowHeaderList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				rowHeaderList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				rowHeaderList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				rowHeaderList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				rowHeaderList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				rowHeaderList.get(0).setRegionID((BigDecimal) ((vehicleDetails.get("REGIONID"))));
				rowHeaderList.get(0).setLocaleCode((BigDecimal) ((vehicleDetails.get("LOCALECODE"))));
			}
		}

		List<Map<String, Object>> columnsOption = jdbcTemplate.queryForList(getColumnsOption);
		if(rowHeaderList.size()>0){
			for (Map vehicleDetails : columnsOption) {
				rowHeaderList.get(0).setColumnBreak((BigDecimal)(vehicleDetails.get("COLUMNSTOSPLIT")));
				rowHeaderList.get(0).setIsLandscape((BigDecimal)(vehicleDetails.get("LANDSCAPE")));
			}
		}

		if(rowHeaderList.size()>0){
			for (Map footerNotes : footerNoteL) {
				rowHeaderList.get(0).setImageName(String.valueOf(footerNotes.get("IMAGENAME")));
				rowHeaderList.get(0).setOptionalDesc(String.valueOf(footerNotes.get("OPTIONALTYPEDESCRIPTION")));
				if(String.valueOf(footerNotes.get("PULLDOWNTEXT"))!=null){
					rowHeaderList.get(0).setPulldownText(" - "+(String.valueOf(footerNotes.get("PULLDOWNTEXT"))));
				}
			}
		}


		finalList.add(rowHeaderList);
		finalList.add(contentList);
		finalList.add(columnHeaderList);
		return (ArrayList<Object>) finalList;

	}


	private ArrayList<Object> nonDomesticVehicles(String vehicleID2, int type, int lang, int pageNumber, int pulldownitemID) {

		
		finalList = new ArrayList<Object>();
		rowHeaderList= new ArrayList<SpecsAndDimensionBean>();
		contentList= new ArrayList<SpecsAndDimBeanContent>();
		columnHeaderList= new ArrayList<SpecsAndDimHelper>();
		
		String rowHeaderSql =	"select distinct ch.pulldownitemid"
				+", rh.rowheaderid , rh.rowcode, rh.rowheadersort "
				+" , rh.rowbolddescription"
				+", rh.rowDescription1"
				+" , rh.rowDescription2"
				+", ch.pagenumber"
				+" , rh.rowRestrictionText"
				+", ch.vehicleid ,conv.*, rh.rowcategoryid"
				+" from V_ColumnHeader ch"
				+" join V_Cell cell"
				+" on cell.COLUMNHEADERID=ch.columnheaderid and  Cell.localecode= "+lang 
				+" and (cell.CELLVALUENUMBER is not null or cell.CELLVALUESTRING is not null)"
				+" join V_RowHeader rh"
				+" on rh.ROWHEADERID=cell.rowheaderid and  rh.localecode = "+lang
				+" join V_RowCategory rc"
				+" on rc.ROWCATEGORYID=rh.ROWCATEGORYID and rc.localecode= "+lang
				+" left outer join V_Conversion conv"
				+" on conv.CONVERSIONID=rh.CONVERSIONID and conv.localecode= "+lang
				+" join V_Type t on rh.typeid = t.typeid and " 
				+" t.typeid= "+type+" and t.localecode= "+lang
				+" where ch.vehicleid= "+vehicleID+""
				+ " and ch.pagenumber=" +pageNumber +" and ch.pulldownitemid= "+pulldownitemID +" ORDER BY rh.rowHeaderSort";
		
		
		
		
		/*
		String rowHeaderSql = "SELECT distinct rh.RowHeaderID, rh.rowCode, rh.rowHeaderSort, rh.rowBoldDescription, rh.rowDescription1, rh.rowDescription2, rh.rowRestrictionText, ch.VehicleID, conv.*, t.*, rc.* " + 
				" FROM V_RowHeader rh, V_RowCategory rc, V_Cell Cell, " + 
				" V_ColumnHeader ch, V_Conversion conv, V_Type t WHERE " + 
				" rh.RowHeaderID = Cell.RowHeaderID AND t.localecode="+lang + 
				" AND rh.RowCategoryID = rc.RowCategoryID AND Cell.localecode="+lang + 
				" AND ch.ColumnHeaderID = Cell.ColumnHeaderID AND rh.localecode="+lang+
				"and rc.localecode="+lang+" and conv.localecode="+lang+" and ch.VehicleID = " + vehicleID + 
				" AND conv.ConversionID(+) = rh.ConversionID " + 
				" AND ch.pageNumber =  " + 1 +  
				" AND rh.typeID =  " + type +  
				" AND t.TypeID = rh.TypeID ORDER BY rc.rowCategorySort, rh.rowHeaderSort";*/


		List<Map<String, Object>> rowHeader = jdbcTemplate.queryForList(rowHeaderSql);


		for (Map row : rowHeader) {

			SpecsAndDimensionBean specsAndDimensionBean = new SpecsAndDimensionBean();
			specsAndDimensionBean.setRowBoldDesc((String.valueOf(row.get("ROWBOLDDESCRIPTION"))));
			specsAndDimensionBean.setRowHeaderID((BigDecimal)(row.get("ROWHEADERID")));
			specsAndDimensionBean.setRowCode((String.valueOf(row.get("ROWCODE"))));
			specsAndDimensionBean.setRowDesctiption1(String.valueOf(row.get("ROWDESCRIPTION1")));
			specsAndDimensionBean.setFromUnit((String.valueOf(row.get("FROMUNIT1"))));
			specsAndDimensionBean.setColumnHeaderID((BigDecimal)(row.get("ROWHEADERID")));
			specsAndDimensionBean.setToUnit((String.valueOf(row.get("TOUNIT2"))));
			specsAndDimensionBean.setRowCategoryID((BigDecimal)(row.get("ROWCATEGORYID")));
			specsAndDimensionBean.setMultiplier((BigDecimal)(row.get("MULTIPLIER")));
			specsAndDimensionBean.setFromUnitDecimals((BigDecimal)(row.get("UNIT1DECIMALPLACES")));
			specsAndDimensionBean.setToUnitDecimals((BigDecimal)(row.get("UNIT2DECIMALPLACES")));
			specsAndDimensionBean.setRestrictionText((String.valueOf(row.get("ROWRESTRICTIONTEXT"))));
			rowHeaderList.add(specsAndDimensionBean);

		}


		String cellSql = "SELECT Cell.ColumnHeaderID, Cell.RowHeaderID, Cell.cellValueNumber, " +
				" (Cell.cellValueNumber * conv.multiplier) AS cellValueNumberMetric,  " + 
				" Cell.cellValueString FROM V_Cell Cell, V_RowHeader rh, V_ColumnHeader ch, V_Conversion conv " +
				" WHERE rh.RowHeaderID = Cell.RowHeaderID AND rh.localecode="+lang+" and ch.localecode="+lang+" and " + 
				" ch.ColumnHeaderID = Cell.ColumnHeaderID AND conv.localecode="+lang + 
				" AND ch.VehicleID = " + vehicleID + 
				" AND Cell.LOCALECODE ="+lang+" AND ch.pageNumber =  " + pageNumber +  
				" AND rh.typeID =  " + type +  
				" AND conv.ConversionID(+) = rh.ConversionID ORDER BY rh.rowHeaderSort, ch.colHeaderSort";

		List<Map<String, Object>> cell = jdbcTemplate.queryForList(cellSql);



		for (Map row : cell) {
			SpecsAndDimBeanContent specsAndDimensionContent = new SpecsAndDimBeanContent();

			specsAndDimensionContent.setRowHeaderID((BigDecimal)(row.get("ROWHEADERID")));
			specsAndDimensionContent.setColumnHeaderID((BigDecimal)(row.get("COLUMNHEADERID")));
			specsAndDimensionContent.setCellValueNumber(String.valueOf(row.get("CELLVALUENUMBER")));
			specsAndDimensionContent.setCellValueNumberMetric(String.valueOf(row.get("CELLVALUENUMBERMETRIC")));
			specsAndDimensionContent.setCellvalueString(String.valueOf(row.get("CELLVALUESTRING")));

			contentList.add(specsAndDimensionContent);
		}



		String columnHeaderSql ="SELECT distinct ch.*, m.ModelID, m.ModelName, m.ModelDesc FROM " + 
				" V_ColumnHeader ch, V_Cell Cell, V_RowHeader rh, V_Model m WHERE " + 
				" rh.RowHeaderID = Cell.RowHeaderID AND ch.localecode="+lang+" and m.localecode="+lang+" and " + 
				" ch.ColumnHeaderID = Cell.ColumnHeaderID AND Cell.localecode = "+lang + 
				" AND ch.ModelID = m.ModelID (+) AND " +
				" ch.VehicleID = " + vehicleID + 
				" AND ch.pageNumber =  " + pageNumber +  
				" AND rh.typeID =  " + type +
				" ORDER BY ch.colHeaderSort";





		List<Map<String, Object>> columnHeader = jdbcTemplate.queryForList(columnHeaderSql);

		for (Map row : columnHeader) {

			SpecsAndDimHelper specsAndDimHelper = new SpecsAndDimHelper();

			specsAndDimHelper.setColumnHeaderID((BigDecimal)(row.get("COLUMNHEADERID")));
			specsAndDimHelper.setModelDesc(String.valueOf(row.get("MODELDESC")));
			specsAndDimHelper.setModelID((BigDecimal)(row.get("MODELID")));
			specsAndDimHelper.setModelName(String.valueOf(row.get("MODELNAME")));
			specsAndDimHelper.setColHeader1(String.valueOf(row.get("COLHEADER1")));

			columnHeaderList.add(specsAndDimHelper);

		}







		String footerNote = "SELECT distinct pdi.*, ch.pageNumber, t.* FROM V_PullDownItem pdi, " +
				" V_ColumnHeader ch, V_Type t, V_Cell Cell, V_RowHeader rh WHERE " + 
				" rh.RowHeaderID = Cell.RowHeaderID AND Cell.localecode ="+lang + 
				" AND ch.ColumnHeaderID = Cell.ColumnHeaderID AND pdi.localecode="+lang +
				" and ch.localecode="+lang+"and rh.localecode="+lang+" and t.localecode="+lang+"and " + 
				" ch.PullDownItemID = pdi.PullDownItemID AND ch.pageNumber = " +pageNumber+ 
				" and t.TypeID = pdi.TypeID AND ch.VehicleID = " + vehicleID +
				" AND rh.typeID =  " + type +  
				" ORDER BY ch.pageNumber";

		List<Map<String, Object>> footerNoteL = jdbcTemplate.queryForList(footerNote);

		getColumnsOption = "select * from columnstable where VehicleID = "+vehicleID+ " and PDFTYPE = "+VehicleConstant.SPECS;

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM V_division d, V_vehicle v, V_region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  v.localecode="+lang+" and r.localecode="+lang+" and d.localecode="+lang+" and" +
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);
		if(rowHeaderList.size()>0){
			for (Map vehicleDetails : vehicle) {
				rowHeaderList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				rowHeaderList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				rowHeaderList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				rowHeaderList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				rowHeaderList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				rowHeaderList.get(0).setRegionID((BigDecimal) ((vehicleDetails.get("REGIONID"))));
				rowHeaderList.get(0).setLocaleCode((BigDecimal) ((vehicleDetails.get("LOCALECODE"))));
			}
		}

		List<Map<String, Object>> columnsOption = jdbcTemplate.queryForList(getColumnsOption);
		if(rowHeaderList.size()>0){
			for (Map vehicleDetails : columnsOption) {
				rowHeaderList.get(0).setColumnBreak((BigDecimal)(vehicleDetails.get("COLUMNSTOSPLIT")));
				rowHeaderList.get(0).setIsLandscape((BigDecimal)(vehicleDetails.get("LANDSCAPE")));
			}
		}

		if(rowHeaderList.size()>0){
			for (Map footerNotes : footerNoteL) {
				rowHeaderList.get(0).setImageName(String.valueOf(footerNotes.get("IMAGENAME")));
				rowHeaderList.get(0).setOptionalDesc(String.valueOf(footerNotes.get("OPTIONALTYPEDESCRIPTION")));
				if(String.valueOf(footerNotes.get("PULLDOWNTEXT"))!=null){
					rowHeaderList.get(0).setPulldownText(" - "+(String.valueOf(footerNotes.get("PULLDOWNTEXT"))));
				}
			}
		}



		finalList.add(rowHeaderList);
		finalList.add(contentList);
		finalList.add(columnHeaderList);
		return (ArrayList<Object>) finalList;

	}


	public List<String> getAVehicles() {
		List<String> listVehicles = new ArrayList<String>();
		Query query = null;
		String sql = null;

		try{

			query = new Query();

			//sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 and VEHICLEID=17008";

			sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 AND REGIONID =14 and VEHICLEYEAR !=2016 and VehicleID=16365";	
			jdbcTemplate = new JdbcTemplate(dataSource);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
			for (Map row : rows) {
				listVehicles.add((String.valueOf(row.get("VehicleID"))));
			}

			return listVehicles;
		}

		catch(Exception e ){
			System.out.println("Exception" +e);
		}
		return listVehicles;

	}




}
