package com.dci.enterprise.dao.impl;
//package com.dci.enterprise.model.dao.impl;
//
//import java.math.BigDecimal;
//import java.math.BigInteger;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//
//import javax.management.Query;
//import javax.sql.DataSource;
//
//import org.springframework.jdbc.core.JdbcTemplate;
//
//import com.dci.enterprise.model.ColorAndTrimBean;
//import com.dci.enterprise.model.dao.ColorAndTrimDAO;
//
//public class CopyOfColorAndTrimImpl_BACKUP implements ColorAndTrimDAO{
//
//	private DataSource dataSource;
//	private JdbcTemplate jdbcTemplate;
//	List<ColorAndTrimBean> modelList = new ArrayList<ColorAndTrimBean>();
//
//	public void setDataSource(DataSource dataSource) {
//		this.dataSource = dataSource;
//	}
//	public List<ColorAndTrimBean> getVehicleItemsXML(int subCategoryID, String queryType,String vehicleID) {
//		Query query = null;
//		String Seatsql = null;
//		String Testsql = null;
//		String Interiorsql = null;
//		String Extsql = null;
//		int typeID = 4;
//		try{
//
//			query = new Query();
//			Seatsql = "SELECT s.*, st.* , im.* " +
//					" FROM seat s, seattrim st, Images im " +
//					" WHERE " +
//					" (s.VehicleID = " + vehicleID + ") AND " +
//					" (s.typeID = " + typeID + ") AND "+
//					" (s.seattrimid = st.seattrimid) AND " +
//					" (s.imageid(+) = im.imageid)";
//					
//					
//					Interiorsql = "SELECT DISTINCT i.*, si.*, ir.restrictionid " +
//					" FROM  seat s, seatinterior si, interior i, interiorRestriction ir " +
//					" WHERE " +
//					" (s.VehicleID = " + vehicleID + ") AND " +
//					" (s.typeID = " + typeID + ") AND " +
//					" (s.seatid = si.seatid) AND " +
//					" (si.interiorid = i.interiorid) AND " +
//					" (ir.VehicleID(+) = " + vehicleID + ") AND " +
//					" (ir.typeID(+) = " + typeID + ") AND " +
//					" (ir.interiorid(+) = i.interiorid) ";
//					
//					Testsql = "SELECT vhec.vehicleHasexteriorColorid, ec.* " +
//							" FROM  vehicleHasExteriorColor vhec, exteriorColor ec " +
//							" WHERE " +
//							" (vhec.VehicleID = " + vehicleID + ") AND " +
//							" (vhec.typeID = " + typeID + ") and  (vhec.upperExteriorColorID = ec.exteriorColorID) order by ExteriorColorSort";
//					
//					Extsql  = "SELECT vhec.vehicleHasexteriorColorid, ecai.*, i.*, ac.availableCodeName " +
//							" FROM  vehicleHasExteriorColor vhec, exteriorColorAvailableInterior ecai, interior i, AvailableCode ac " +
//							" WHERE " +
//							" (vhec.VehicleID = " + vehicleID + ") AND " +
//							" (vhec.typeID = " + typeID + ") AND " +
//							" (vhec.vehicleHasExteriorColorID = ecai.vehicleHasExteriorColorID) AND " +
//							" (ac.availableCodeID = ecai.availableCodeID) AND " +
//							" (ecai.interiorid = i.interiorid)";
//
//
//			jdbcTemplate = new JdbcTemplate(dataSource);
//			//List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
//		//	List<Map<String, Object>> newrows = jdbcTemplate.queryForList(Testsql);
//			List<Map<String, Object>> seatColor = jdbcTemplate.queryForList(Extsql);
//			List<Map<String, Object>>  interiorColor= jdbcTemplate.queryForList(Testsql);
//			int count=0;
//			for (Map row : seatColor) {
//				count++;
//				if(count%2==0){
//				ColorAndTrimBean colorAndTrimBean = new ColorAndTrimBean();
//				colorAndTrimBean.setRegionName("Canada");
//			//	colorAndTrimBean.setSeatID((BigDecimal) row.get("VEHICLEHASEXTERIORCOLORID"));
//				colorAndTrimBean.setSeatType((String.valueOf(row.get("EXTERIORCOLORNAME"))));
//		//		colorAndTrimBean.setColorName((String.valueOf(row.get("INTCOLORNAME")))+count);
//				colorAndTrimBean.setIntColorCode((String.valueOf(row.get("INTCOLORCODE"))));
//				colorAndTrimBean.setVehicleName("TestingVehicle");
//				modelList.add(colorAndTrimBean);}
//			}
//
//		for (Map row : interiorColor) {
//				for (int i = 0; i < modelList.size(); i++) {
//					//if((colorTrimSeatList.get(i).getSeatID()).equals(row.get("VEHICLEHASEXTERIORCOLORID")))
//						modelList.get(i).setSeatType((String.valueOf(row.get("EXTERIORCOLORNAME"))));
//					
//				}
//			}
//			return modelList;
//		}
//
//		catch(Exception e ){
//			System.out.println("Exception" +e);
//		}
//		return modelList;
//
//	}
//
//
//
//
//	public List<String> getAVehicles() {
//		List<String> listVehicles = new ArrayList<String>();
//		Query query = null;
//		String sql = null;
//
//		try{
//
//			query = new Query();
//
//			//sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 and VEHICLEID=17008";
//
//			sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 and VEHICLEID=16029";
//			jdbcTemplate = new JdbcTemplate(dataSource);
//			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
//			for (Map row : rows) {
//				listVehicles.add((String.valueOf(row.get("VehicleID"))));
//			}
//
//			return listVehicles;
//		}
//
//		catch(Exception e ){
//			System.out.println("Exception" +e);
//		}
//		return listVehicles;
//
//	}
//	public HashSet getNColor() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//
//}
