package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.management.Query;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.enterprise.dao.EngineAxleDAO;
import com.dci.enterprise.model.EOGCanadaPDFGenerator;
import com.dci.enterprise.model.EngineAxleBean;
import com.dci.enterprise.model.EngineAxleContentBean;
import com.dci.enterprise.model.EngineAxleTableHeaders;
import com.dci.enterprise.model.SpecsAndDimHelper;
import com.dci.general.utilities.VehicleConstant;

public class EngineAxleDAOImpl implements EngineAxleDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	String vehicleID=null;
	List<ArrayList<Object>> finaList_TypeID;
	List<Object> finalList;
	List<EngineAxleBean> rowHeaderList;
	List<EngineAxleContentBean> engineAxleContentList;
	List<EngineAxleTableHeaders> engineAxleHeaderList;
	static boolean isCanada=false;
	static boolean isVehicleActive=false;
	Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	String getVehicle = null;
	public List<ArrayList<Object>> getVehicleItemsXML( String vehicleID,int type, int lang) {

		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		query = new Query();
		this.vehicleID= vehicleID;
		finalList= new ArrayList<Object>();
		rowHeaderList= new ArrayList<EngineAxleBean>();
		engineAxleContentList= new ArrayList<EngineAxleContentBean>();
		engineAxleHeaderList= new ArrayList<EngineAxleTableHeaders>();


		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d,vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND v.vehicleActiveFlag = 1 AND " +
				" (v.divisionID = d.divisionID) and " +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);

		for (Map row : vehicle) {

			if(((BigDecimal)(row.get("REGIONID"))).intValueExact()==14){

				isCanada= true;
			}
			else{
				isCanada=false;
			}

			if(((BigDecimal)(row.get("VEHICLEACTIVEFLAG"))).intValueExact()==1){

				isVehicleActive= true;
			}
			else{
				isVehicleActive=false;
			}

		}
		if(isVehicleActive){
			finaList_TypeID	= new ArrayList<ArrayList<Object>>();
			if(isCanada)
			{
				log.info("VEHICLE is in Canadian Region");
				for (int pageNum = 1; pageNum <= 3; pageNum++) {
					finaList_TypeID.add(nonDomesticVehicles( vehicleID, type,  lang,pageNum));	
				}
			}
			else{

				log.info("VEHICLE is in non-Canadian Region");
				for (int pageNum = 1; pageNum <= 3; pageNum++) {
					finaList_TypeID.add(domesticVehicles( vehicleID, type,  lang,pageNum));	
				}
			}


		}
		else{
			log.error("VEHICLE NOT ACTIVE");
		}
		return finaList_TypeID;
	}



	private ArrayList<Object>  domesticVehicles(String vehicleID2, int type, int lang, int pageNum) {
		finalList= new ArrayList<Object>();
		rowHeaderList= new ArrayList<EngineAxleBean>();
		engineAxleContentList= new ArrayList<EngineAxleContentBean>();
		engineAxleHeaderList= new ArrayList<EngineAxleTableHeaders>();


		String rowHeaderSql = "SELECT  e.*, oc.grayTabTypeID, easc.*, eac.*, vhe.*, pdi.*, gt.gtActiveFlagEngAxle " +
				" FROM Vehicle v, Engine e, OptionCode oc, EngineAxleSubCat easc, EngineAxleCat eac, VehicleHasEngine vhe, pulldownitem pdi, graytabtype gt WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND" +
				" (vhe.EngineID = e.EngineID) AND "+
				" (vhe.VehicleID = v.VehicleID) AND" +
				" (easc.pageNumber = " + pageNum + ")   and " +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND " +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND   " +
				" (easc.PullDownItemID = pdi.PullDownItemID) AND " +
				" (e.RPOID = oc.RPOID(+)) and (oc.graytabtypeid = gt.graytabtypeid(+))  "+
				" order by eac.eaCatSort, easc.eaSubCatSort, vhe.vehiclehasengineSort";


		List<Map<String, Object>> rowHeader = jdbcTemplate.queryForList(rowHeaderSql);


		for (Map row : rowHeader) {

			EngineAxleBean engineAxleBean = new EngineAxleBean();

			engineAxleBean.setRpoID((BigDecimal)(row.get("RPOID")));
			engineAxleBean.setEngineID((BigDecimal)(row.get("ENGINEID")));
			engineAxleBean.setVehicleHasEngineID((BigDecimal)(row.get("VEHICLEHASENGINEID")));
			engineAxleBean.setEngineDesc((String.valueOf(row.get("ENGINEDESCRIPTION"))));
			engineAxleBean.setEngineRpo(String.valueOf(row.get("ENGINERPO")));
			engineAxleBean.setEaSubCatText(String.valueOf(row.get("EASUBCATTEXT")));
			engineAxleBean.setEaCatText(String.valueOf(row.get("EACATTEXT")));
			engineAxleBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			rowHeaderList.add(engineAxleBean);

		}




		String tableContent = "SELECT  vhe.vehiclehasengineid, c.componentid, ac.availablecodename, ehc.restrictionid, cs.componentsort " +
				" FROM Vehicle v, Engine e, EngineAxleSubCat easc, EngineAxleCat eac, VehicleHasEngine vhe, pulldownitem pdi, EngineHasComponents ehc, component c, componenttype ct, vehicleComponentHasRestriction vchr, availablecode ac, Componentsort cs WHERE " +
				" (v.VehicleID = " + vehicleID + ") and" +
				" (vhe.EngineID = e.EngineID) AND  " +
				" (vhe.VehicleID = v.VehicleID) and" +
				" (easc.pageNumber = " + pageNum + ") AND " +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND " +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND " +
				" (easc.PullDownItemID = pdi.PullDownItemID) and " +
				" (cs.ComponentID(+) = c.ComponentID) and " +
				" (cs.VehicleID(+) =" +  vehicleID +") and "  +
				" (ehc.VehicleHasEngineID = vhe.VehicleHasEngineID) and " +
				" (ehc.ComponentID = c.ComponentID) and (c.componenttypeID = ct.componenttypeID) and " +
				" (vchr.componentid(+) = c.componentid) and (" + vehicleID + " = vchr.vehicleid(+)) and " +
				" (ehc.availablecodeid = ac.availablecodeid) order by c.componentTypeID, cs.ComponentSort";


		List<Map<String, Object>> columnHeader = jdbcTemplate.queryForList(tableContent);

		for (Map row : columnHeader) {

			EngineAxleContentBean engineAxleContentBean = new EngineAxleContentBean();
			engineAxleContentBean.setVehicleHasEngineID((BigDecimal)(row.get("VEHICLEHASENGINEID")));
			engineAxleContentBean.setComponentID((BigDecimal)(row.get("COMPONENTID")));
			engineAxleContentBean.setAvailableCodeName(String.valueOf(row.get("AVAILABLECODENAME")));
			engineAxleContentBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			engineAxleContentBean.setComponentSort((BigDecimal)(row.get("COMPONENTSORT")));
			engineAxleContentList.add(engineAxleContentBean);

		}

		String tableHeadersql = "SELECT  DISTINCT c.*, oc.grayTabTypeID, ct.ComponenttypeName, vchr.restrictionID, v.vehicleid, cs.*, gt.gtActiveFlagEngAxle " +
				" FROM Vehicle v, Engine e, OptionCode oc, EngineAxleSubCat easc, EngineAxleCat eac, VehicleHasEngine vhe, pulldownitem pdi, EngineHasComponents ehc, component c, componenttype ct, vehicleComponentHasRestriction vchr, availablecode ac, componentSort cs, graytabtype gt WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND" +
				" (vhe.EngineID = e.EngineID) AND  " +
				" (vhe.VehicleID = v.VehicleID) AND" +
				" (easc.pageNumber = " + pageNum + ") AND" +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND " +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND " +
				" (easc.PullDownItemID = pdi.PullDownItemID) and " +
				" (ehc.VehicleHasEngineID = vhe.VehicleHasEngineID) and " +
				" (ehc.ComponentID = c.ComponentID) and (c.componenttypeID = ct.componenttypeID) and " +
				" (vchr.componentid(+) = c.componentid) and (" + vehicleID + " = vchr.vehicleid(+)) and " +
				" (ehc.availablecodeid = ac.availablecodeid) and " +
				" (cs.ComponentID(+) = c.ComponentID) and " +
				" (cs.VehicleID(+) =" +  vehicleID +") and " +
				" (c.RPOID = oc.RPOID(+)) and (oc.graytabtypeid = gt.graytabtypeid(+)) " +
				" order by c.componentTypeID, cs.ComponentSort";


		List<Map<String, Object>> tableHeaders = jdbcTemplate.queryForList(tableHeadersql);


		for (Map row : tableHeaders) {
			EngineAxleTableHeaders engineAxleTableHeaders = new EngineAxleTableHeaders();

			engineAxleTableHeaders.setComponentID((BigDecimal)(row.get("COMPONENTID")));
			engineAxleTableHeaders.setRpoID((BigDecimal)(row.get("RPOID")));
			engineAxleTableHeaders.setComponentRPO(String.valueOf(row.get("COMPONENTRPO")));
			engineAxleTableHeaders.setComponentDesc1(String.valueOf(row.get("COMPONENTDESC1")));
			engineAxleTableHeaders.setComponentDesc2(String.valueOf(row.get("COMPONENTDESC2")));
			engineAxleTableHeaders.setComponentDesc3(String.valueOf(row.get("COMPONENTDESC3")));
			engineAxleTableHeaders.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			engineAxleTableHeaders.setComponentTypeName(String.valueOf(row.get("COMPONENTTYPENAME")));
			engineAxleTableHeaders.setComponentSort((BigDecimal)(row.get("COMPONENTSORT")));

			engineAxleHeaderList.add(engineAxleTableHeaders);

		}


		String	restrictionSql = "SELECT  DISTINCT r.restrictionid, r.restrictionText, r.vehicleid " +
				"  FROM Vehicle v, Engine e, EngineAxleCat eac, EngineAxleSubCat easc, VehicleHasEngine vhe, pulldownitem pdi, Restriction r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (vhe.EngineID = e.EngineID)  and " +
				" (vhe.VehicleID = v.VehicleID) AND " +
				" (easc.pageNumber = " + pageNum + ") AND" +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND " +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND " +
				" (easc.PullDownItemID = r.PullDownItemID) and " +
				" (easc.PullDownItemID = pdi.PullDownItemID) " +
				" order by r.restrictionid";


		List<Map<String, Object>> restriction = jdbcTemplate.queryForList(restrictionSql);

		Map<BigDecimal,String> restrictionSet = new TreeMap<BigDecimal,String>();

		for (Map row : restriction) {

			if(row.get("RESTRICTIONID")!=null){
				restrictionSet.put((BigDecimal)(row.get("RESTRICTIONID")),String.valueOf(row.get("RESTRICTIONTEXT")));
			}
		}

		String getPulldownText =  "SELECT  DISTINCT pdi.*, easc.pageNumber " +
				" FROM Vehicle v, Engine e, EngineAxleSubCat easc, EngineAxleCat eac, VehicleHasEngine vhe, pulldownitem pdi WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND" +
				" (vhe.EngineID = e.EngineID) AND" +
				" (vhe.VehicleID = v.VehicleID) AND" +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND  easc.pagenumber="+pageNum+" and" +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND " +
				" (easc.PullDownItemID = pdi.PullDownItemID) " +
				" order by easc.pageNumber";

		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM division d, vehicle v, region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);

		if(rowHeaderList.size()>0){
			for (Map vehicleDetails : vehicle) {
				rowHeaderList.get(0).setRestrictionList(restrictionSet);
				rowHeaderList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				rowHeaderList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				rowHeaderList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				rowHeaderList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				rowHeaderList.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
				rowHeaderList.get(0).setDivisionID((BigDecimal)(vehicleDetails.get("DIVISIONID")));
				rowHeaderList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
			}
		}
		String	getColumnsOption = "select * from columnstable where VehicleID = "+vehicleID+" and PDFTYPE = "+VehicleConstant.ENGINE_AXLE;
		List<Map<String, Object>> columnsOption = jdbcTemplate.queryForList(getColumnsOption);
		if(rowHeaderList.size()>0){
			for (Map vehicleDetails : columnsOption) {
				rowHeaderList.get(0).setColumnBreak((BigDecimal)(vehicleDetails.get("COLUMNSTOSPLIT")));
				rowHeaderList.get(0).setIsLandscape((BigDecimal)(vehicleDetails.get("LANDSCAPE")));
			}
		}

		List<Map<String, Object>> pulldownText = jdbcTemplate.queryForList(getPulldownText);
		if(rowHeaderList.size()>0){
			for (Map pulldown : pulldownText) {
				if(String.valueOf(pulldown.get("PULLDOWNTEXT"))!=null)
				{
					rowHeaderList.get(0).setPageLabel(" - " +String.valueOf(pulldown.get("PULLDOWNTEXT")));
				}
			}
		}
		finalList.add(rowHeaderList);
		finalList.add(engineAxleHeaderList);
		finalList.add(engineAxleContentList);

		return (ArrayList<Object>) finalList;
	}





	private ArrayList<Object> nonDomesticVehicles(String vehicleID, int type, int lang,int pageNum) {
		finalList= new ArrayList<Object>();
		rowHeaderList= new ArrayList<EngineAxleBean>();
		engineAxleContentList= new ArrayList<EngineAxleContentBean>();
		engineAxleHeaderList= new ArrayList<EngineAxleTableHeaders>();


		String rowHeaderSql = "SELECT  e.*, oc.grayTabTypeID, easc.*, eac.*, vhe.*, pdi.*, gt.gtActiveFlagEngAxle " +
				" FROM v_Vehicle v, v_Engine e, v_OptionCode oc, v_EngineAxleSubCat easc, v_EngineAxleCat eac, VehicleHasEngine vhe, v_pulldownitem pdi, v_graytabtype gt WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND" +
				" (vhe.EngineID = e.EngineID) AND v.localecode="+lang+" and e.localecode="+lang+" And"+
				" (vhe.VehicleID = v.VehicleID) AND" +
				" (easc.pageNumber = " + pageNum + ") AND easc.localecode="+lang+" and " +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND " +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND eac.localecode(+)="+lang+" and gt.localecode="+lang+" and " +
				" (easc.PullDownItemID = pdi.PullDownItemID) AND pdi.localecode="+lang+" and" +
				" (e.RPOID = oc.RPOID(+)) and (oc.graytabtypeid = gt.graytabtypeid(+)) and oc.localecode(+)="+lang+
				" order by eac.eaCatSort, easc.eaSubCatSort, vhe.vehiclehasengineSort";


		List<Map<String, Object>> rowHeader = jdbcTemplate.queryForList(rowHeaderSql);


		for (Map row : rowHeader) {

			EngineAxleBean engineAxleBean = new EngineAxleBean();

			engineAxleBean.setRpoID((BigDecimal)(row.get("RPOID")));
			engineAxleBean.setEngineID((BigDecimal)(row.get("ENGINEID")));
			engineAxleBean.setVehicleHasEngineID((BigDecimal)(row.get("VEHICLEHASENGINEID")));
			engineAxleBean.setEngineDesc((String.valueOf(row.get("ENGINEDESCRIPTION"))));
			engineAxleBean.setEngineRpo(String.valueOf(row.get("ENGINERPO")));
			engineAxleBean.setEaSubCatText(String.valueOf(row.get("EASUBCATTEXT")));
			engineAxleBean.setEaCatText(String.valueOf(row.get("EACATTEXT")));
			engineAxleBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));

			rowHeaderList.add(engineAxleBean);

		}




		String tableContent = "SELECT  vhe.vehiclehasengineid, c.componentid, ac.availablecodename, ehc.restrictionid, cs.componentsort " +
				" FROM v_Vehicle v, v_Engine e, v_EngineAxleSubCat easc, v_EngineAxleCat eac, VehicleHasEngine vhe, v_pulldownitem pdi, EngineHasComponents ehc, v_component c, v_componenttype ct, vehicleComponentHasRestriction vchr, v_availablecode ac, Componentsort cs WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND e.localecode="+lang+" and easc.localecode="+lang+" and eac.localecode="+lang+" and pdi.localecode="+lang+" and" +
				" (vhe.EngineID = e.EngineID) AND  c.localecode="+lang+" and ct.localecode="+lang+" and ac.localecode="+lang+" and" +
				" (vhe.VehicleID = v.VehicleID) AND v.localecode="+lang+"and" +
				" (easc.pageNumber = " + pageNum + ") AND " +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND " +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND " +
				" (easc.PullDownItemID = pdi.PullDownItemID) and " +
				" (cs.ComponentID(+) = c.ComponentID) and " +
				" (cs.VehicleID(+) =" +  vehicleID +") and "  +
				" (ehc.VehicleHasEngineID = vhe.VehicleHasEngineID) and " +
				" (ehc.ComponentID = c.ComponentID) and (c.componenttypeID = ct.componenttypeID) and " +
				" (vchr.componentid(+) = c.componentid) and (" + vehicleID + " = vchr.vehicleid(+)) and " +
				" (ehc.availablecodeid = ac.availablecodeid) order by c.componentTypeID, cs.ComponentSort";


		List<Map<String, Object>> columnHeader = jdbcTemplate.queryForList(tableContent);

		for (Map row : columnHeader) {

			EngineAxleContentBean engineAxleContentBean = new EngineAxleContentBean();
			engineAxleContentBean.setVehicleHasEngineID((BigDecimal)(row.get("VEHICLEHASENGINEID")));
			engineAxleContentBean.setComponentID((BigDecimal)(row.get("COMPONENTID")));
			engineAxleContentBean.setAvailableCodeName(String.valueOf(row.get("AVAILABLECODENAME")));
			engineAxleContentBean.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			engineAxleContentBean.setComponentSort((BigDecimal)(row.get("COMPONENTSORT")));
			engineAxleContentList.add(engineAxleContentBean);

		}

		String tableHeadersql = "SELECT  DISTINCT c.*, oc.grayTabTypeID, ct.ComponenttypeName, vchr.restrictionID, v.vehicleid, cs.componentsort, gt.gtActiveFlagEngAxle " +
				" FROM v_Vehicle v, v_Engine e, v_OptionCode oc, v_EngineAxleSubCat easc, v_EngineAxleCat eac, VehicleHasEngine vhe, v_pulldownitem pdi, EngineHasComponents ehc, v_component c, v_componenttype ct, vehicleComponentHasRestriction vchr, v_availablecode ac, componentSort cs, v_graytabtype gt WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  c.localecode="+lang+" and ct.localecode="+lang+" and ac.localecode="+lang+" and gt.localecode="+lang+" and" +
				" (vhe.EngineID = e.EngineID) AND v.localecode="+lang+" and e.localecode="+lang+" and oc.localecode="+lang+" and eac.localecode="+lang+" and " +
				" (vhe.VehicleID = v.VehicleID) AND" +
				" (easc.pageNumber = " + pageNum + ") AND" +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND " +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND " +
				" (easc.PullDownItemID = pdi.PullDownItemID) and " +
				" (ehc.VehicleHasEngineID = vhe.VehicleHasEngineID) and " +
				" (ehc.ComponentID = c.ComponentID) and (c.componenttypeID = ct.componenttypeID) and " +
				" (vchr.componentid(+) = c.componentid) and (" + vehicleID + " = vchr.vehicleid(+)) and " +
				" (ehc.availablecodeid = ac.availablecodeid) and " +
				" (cs.ComponentID(+) = c.ComponentID) and " +
				" (cs.VehicleID(+) =" +  vehicleID +") and " +
				" (c.RPOID = oc.RPOID(+)) and (oc.graytabtypeid = gt.graytabtypeid(+)) " +
				" order by c.componentTypeID, cs.ComponentSort";


		List<Map<String, Object>> tableHeaders = jdbcTemplate.queryForList(tableHeadersql);


		for (Map row : tableHeaders) {
			EngineAxleTableHeaders engineAxleTableHeaders = new EngineAxleTableHeaders();

			engineAxleTableHeaders.setComponentID((BigDecimal)(row.get("COMPONENTID")));
			engineAxleTableHeaders.setRpoID((BigDecimal)(row.get("RPOID")));
			engineAxleTableHeaders.setComponentRPO(String.valueOf(row.get("COMPONENTRPO")));
			engineAxleTableHeaders.setComponentDesc1(String.valueOf(row.get("COMPONENTDESC1")));
			engineAxleTableHeaders.setComponentDesc2(String.valueOf(row.get("COMPONENTDESC2")));
			engineAxleTableHeaders.setComponentDesc3(String.valueOf(row.get("COMPONENTDESC3")));
			engineAxleTableHeaders.setRestrictionID((BigDecimal)(row.get("RESTRICTIONID")));
			engineAxleTableHeaders.setComponentTypeName(String.valueOf(row.get("COMPONENTTYPENAME")));
			engineAxleTableHeaders.setComponentSort((BigDecimal)(row.get("COMPONENTSORT")));

			engineAxleHeaderList.add(engineAxleTableHeaders);

		}


		String	restrictionSql = "SELECT  DISTINCT r.restrictionid, r.restrictionText, r.vehicleid " +
				"  FROM v_Vehicle v, v_Engine e, v_EngineAxleCat eac, v_EngineAxleSubCat easc, VehicleHasEngine vhe, v_pulldownitem pdi, v_Restriction r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND " +
				" (vhe.EngineID = e.EngineID) AND r.localecode="+lang+" and v.localecode="+lang+" and e.localecode="+lang+" and eac.localecode="+lang+" and easc.localecode="+lang+" and pdi.localecode="+lang+" and" +
				" (vhe.VehicleID = v.VehicleID) AND " +
				" (easc.pageNumber = " + pageNum + ") AND" +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND " +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND " +
				" (easc.PullDownItemID = r.PullDownItemID) and " +
				" (easc.PullDownItemID = pdi.PullDownItemID) " +
				" order by r.restrictionid";


		List<Map<String, Object>> restriction = jdbcTemplate.queryForList(restrictionSql);

		Map<BigDecimal,String> restrictionSet = new TreeMap<BigDecimal,String>();

		for (Map row : restriction) {

			if(row.get("RESTRICTIONID")!=null){
				restrictionSet.put((BigDecimal)(row.get("RESTRICTIONID")),String.valueOf(row.get("RESTRICTIONTEXT")));
			}
		}





		getVehicle = "SELECT v.*, d.divisionName, r.regionName FROM v_division d, v_vehicle v, v_region r WHERE " +
				" (v.VehicleID = " + vehicleID + ") AND  v.localecode="+lang+" and r.localecode="+lang+" and d.localecode="+lang+" and" +
				" (v.divisionID = d.divisionID) and v.vehicleActiveFlag = 1 and" +
				" (v.regionID = d.regionID) and " +
				" (d.regionID = r.regionID) ";

		List<Map<String, Object>> vehicle = jdbcTemplate.queryForList(getVehicle);

		if(rowHeaderList.size()>0){
			for (Map vehicleDetails : vehicle) {
				rowHeaderList.get(0).setRestrictionList(restrictionSet);
				rowHeaderList.get(0).setVehicleId((BigDecimal)vehicleDetails.get("VEHICLEID"));
				rowHeaderList.get(0).setVehicleName(String.valueOf(vehicleDetails.get("VEHICLENAME")));
				rowHeaderList.get(0).setRegionName(String.valueOf(vehicleDetails.get("REGIONNAME")));
				rowHeaderList.get(0).setVehicleYear((BigDecimal)(vehicleDetails.get("VEHICLEYEAR")));
				rowHeaderList.get(0).setDivisionName(String.valueOf(vehicleDetails.get("DIVISIONNAME")));
				rowHeaderList.get(0).setDivisionID((BigDecimal)(vehicleDetails.get("DIVISIONID")));
				rowHeaderList.get(0).setLocaleCode((BigDecimal)(vehicleDetails.get("LOCALECODE")));
			}
		}
		
		String getPulldownText =  "SELECT  DISTINCT pdi.*, easc.pageNumber " +
				" FROM v_Vehicle v, v_Engine e, v_EngineAxleSubCat easc, v_EngineAxleCat eac, VehicleHasEngine vhe, v_pulldownitem pdi WHERE " +
				" (v.VehicleID = " + vehicleID +") AND" +
				" (vhe.EngineID = e.EngineID) AND v.localecode="+lang+" and e.localecode="+lang+" and pdi.localecode="+lang+" and" +
				" (vhe.VehicleID = v.VehicleID) AND easc.localecode(+)="+lang+" and eac.localecode="+lang+" and " +
				" (vhe.EngineAxleSubCatID = easc.EngineAxleSubCatID) AND  easc.pagenumber="+pageNum+" and" +
				" (easc.EngineAxleCatID(+) = eac.EngineAxleCatID) AND " +
				" (easc.PullDownItemID = pdi.PullDownItemID) " +
				" order by easc.pageNumber";
		
		
		
		String	getColumnsOption = "select * from columnstable where VehicleID = "+vehicleID+" and PDFTYPE = "+VehicleConstant.ENGINE_AXLE;
		List<Map<String, Object>> columnsOption = jdbcTemplate.queryForList(getColumnsOption);
		if(rowHeaderList.size()>0){
			for (Map vehicleDetails : columnsOption) {
				rowHeaderList.get(0).setColumnBreak((BigDecimal)(vehicleDetails.get("COLUMNSTOSPLIT")));
				rowHeaderList.get(0).setIsLandscape((BigDecimal)(vehicleDetails.get("LANDSCAPE")));
			}
		}

		List<Map<String, Object>> pulldownText = jdbcTemplate.queryForList(getPulldownText);
		if(rowHeaderList.size()>0){
			for (Map pulldown : pulldownText) {
				if(String.valueOf(pulldown.get("PULLDOWNTEXT"))!=null)
				{
					rowHeaderList.get(0).setPageLabel(" - " +String.valueOf(pulldown.get("PULLDOWNTEXT")));
				}
			}
		}
		
		finalList.add(rowHeaderList);
		finalList.add(engineAxleHeaderList);
		finalList.add(engineAxleContentList);

		return (ArrayList<Object>) finalList;
	}


	public List<String> getAVehicles() {
		List<String> listVehicles = new ArrayList<String>();
		Query query = null;
		String sql = null;

		try{

			query = new Query();

			//sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 and VEHICLEID=17008";

			sql = "select * from VEHICLE where VEHICLEACTIVEFLAG =1 AND REGIONID =14 and VEHICLEYEAR !=2016 and VehicleID=16365";	
			jdbcTemplate = new JdbcTemplate(dataSource);
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
			for (Map row : rows) {
				listVehicles.add((String.valueOf(row.get("VehicleID"))));
			}

			return listVehicles;
		}

		catch(Exception e ){
			System.out.println("Exception" +e);
		}
		return listVehicles;

	}




}
