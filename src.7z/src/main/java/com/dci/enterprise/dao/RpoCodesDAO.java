package com.dci.enterprise.dao;

import java.util.List;

import com.dci.enterprise.model.RpoCodesBean;

public interface RpoCodesDAO {
	
	public List<RpoCodesBean> getVehicleItemsXML(String vehicleID,int lang);
	
	public List<String> getAVehicles();


}
