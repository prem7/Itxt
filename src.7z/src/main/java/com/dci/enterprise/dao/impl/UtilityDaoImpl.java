package com.dci.enterprise.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.management.Query;
import javax.sql.DataSource;


import org.springframework.jdbc.core.JdbcTemplate;

import com.dci.extrafunc.CFDWrapper;
import com.dci.extrafunc.CFDXML;
import com.dci.extrafunc.CategoryBuilder;
import com.dci.extrafunc.CategoryHelper;
import com.dci.extrafunc.DescHelper;
import com.dci.extrafunc.TitleHelper;
import com.dci.general.utilities.UtilityDAO;


public class UtilityDaoImpl implements UtilityDAO{
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private String[] modelList = null;


	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	public String[] getVehicleItemsXML(int lang) {

		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		query = new Query();


		String getModel ="SELECT DISTINCT v.*, "
				+ "(SELECT MAX(p.pageNumber) FROM v_package p, v_model m WHERE (v.vehicleid = m.vehicleid) AND (m.modelid = p.modelid) and p.localecode="+lang+" and m.localecode="+lang+") "
				+ "AS maxNumberPages, "
				+ "(SELECT MAX(subcat.pageNumber) FROM v_EngineAxleSubCat subcat WHERE (v.vehicleid = subcat.vehicleid) and subcat.localecode="+lang+") AS maxEngineAxle,"
				+ "(SELECT MAX(colH.pageNumber) FROM v_Type t, v_RowHeader rowH, v_Cell c, v_ColumnHeader colH WHERE "
				+ "(colH.vehicleid = v.vehicleid) and (colH.columnheaderid = c.columnheaderid) and "
				+ "(c.rowHeaderid = rowH.rowheaderid) and (rowH.typeid = t.typeid) and (t.type = 'Specs') and t.localecode="+lang+" "
				+ "and rowH.localecode="+lang+" and c.localecode="+lang+" and colH.localecode="+lang+") AS maxSpecsPages, "
				+ "(SELECT MAX(colH.pageNumber) FROM v_Type t, v_RowHeader rowH, v_Cell c, v_ColumnHeader colH "
				+ "WHERE (colH.vehicleid = v.vehicleid) and (colH.columnheaderid = c.columnheaderid) and (c.rowHeaderid = rowH.rowheaderid) "
				+ "and (rowH.typeid = t.typeid) and (t.type = 'Dimensions') and t.localecode="+lang+" and rowH.localecode="+lang+" and c.localecode="+lang+" "
				+ "and colH.localecode="+lang+") AS maxDimenPages, "
				+ "(SELECT MAX(th.pageNumber) "
				+ "FROM v_TraileringHeader th, v_TraileringCategoryHeader tch, v_TraileringCategory tc "
				+ "WHERE th.TraileringHeaderID = tch.TraileringHeaderID AND tch.TraileringCategoryID = tc.TraileringCategoryID "
				+ "AND tc.VehicleID = v.vehicleid and tch.localecode="+lang+" and tc.localecode="+lang+" and th.localecode="+lang+") AS maxTraileringPages "
				+ "FROM v_vehicle v, UserHistory uh, LastPDFRun lpr where v.localecode="+lang+" and v.vehicleactiveflag = 1 "
				+ "AND TO_DATE(uh.TIMESTAMP, 'mm/dd/yyyy hh:mi am') > lpr.RUNDATE"
				+ " AND uh.VEHICLEID = v.VEHICLEID AND lpr.PDFRUNID = 1  ORDER BY v.vehicleid";

		List<Map<String, Object>> modelIDList = jdbcTemplate.queryForList(getModel);

		modelList=	new String[modelIDList.size()];
		int count= 0;
		for (Map row : modelIDList) {

			if(row.get("VEHICLEID")!=null){

				BigDecimal temp = (BigDecimal) row.get("VEHICLEID");
				modelList[count]=  temp.toString();	
				count++;
			}
		} 


		return modelList;
	}


	public boolean isDomestic(String vehicleID) {

		Query query = null;
		jdbcTemplate = new JdbcTemplate(dataSource);
		query = new Query();


		String getVehicle ="select REGIONID from vehicle where VEHICLEID = "+vehicleID;

		List<Map<String, Object>> vehicleD = jdbcTemplate.queryForList(getVehicle);

		for (Map row : vehicleD) {
			BigDecimal regionID = (BigDecimal) row.get("REGIONID");
			if(regionID.intValueExact() == 14)
			{
				return false;
			}

		}

		return true;
	}

	public List<CategoryBuilder> startXMLRendering(String vehicleID){

		jdbcTemplate = new JdbcTemplate(dataSource);

		String tempQuery = "select unique * from vmds_chrome_export";
			//	+ "where vehicleid= "+vehicleID;//+" and rpoid in (4264,27028,27399)";




		//List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sqlQuery);
	List<Map<String, Object>> temp_resultList = jdbcTemplate.queryForList(tempQuery);
		CFDXML cfd = new CFDXML();
		List<CFDXML> finalList = new ArrayList<CFDXML>();
		String marketingDesc;
		String marketingTitle;
		String marketingDesc_trans;
		String marketingTitle_trans;
		String rpoName;
		CategoryHelper categoryHelper = new CategoryHelper();
		CategoryBuilder categoryBuilder =  new CategoryBuilder();
		List<CategoryBuilder> builders= new ArrayList<CategoryBuilder>();
		List <DescHelper> descHelpers = new ArrayList<DescHelper>();
		List<TitleHelper> title = new ArrayList<TitleHelper>();
		System.out.println(temp_resultList.size());
		int count = 0;
		for (Map row : temp_resultList) {
			count++;
			cfd = new CFDXML();
			TitleHelper titleHelper = new TitleHelper();
			CFDWrapper cfdWrapper = new CFDWrapper();
			DescHelper descHelper = new DescHelper();
			categoryBuilder =  new CategoryBuilder();
			marketingDesc = String.valueOf(row.get("DESCRIPTION"));
			marketingTitle = String.valueOf(row.get("DESCRIPTIONTITLE"));
			rpoName = String.valueOf(row.get("RPONAME"));
			marketingDesc_trans = getTranslationfromDictionary(marketingDesc);
			marketingTitle_trans = getTranslationfromDictionary(marketingTitle);
			//getRpoName(rpoId);

			descHelper.setOriginalText(marketingDesc);
		//	descHelper.setOriginalText((descHelper.getOriginalText()));
			titleHelper.setOriginalText((marketingTitle));
			descHelper.setTranslatedText((marketingDesc_trans));
			titleHelper.setTranslatedText((marketingTitle_trans));
			//descHelpers.add(descHelper);
		//	title.add(titleHelper);

			//	finalList.add(cfd);
			cfdWrapper.setDescHelpers(descHelper);
			cfdWrapper.setTitleHelpers(titleHelper);
		//	categoryBuilder.setTitleHelpers(titleHelper);
			categoryBuilder.setCfdWrapper(cfdWrapper);
			categoryBuilder.setRpoName(rpoName);
			categoryBuilder.setMmc(String.valueOf(row.get("MODELNAME")));
			categoryBuilder.setPackageCode(String.valueOf(row.get("PACKAGENAME")));
			categoryBuilder.setModelYear(String.valueOf(row.get("MODELYEAR")));
			categoryBuilder.setCategoryName(String.valueOf(row.get("CATEGORYNAME")));
			builders.add(categoryBuilder);
		//	System.out.println(count);
		}
		
		
		
		//categoryHelper.setTempList(finalList);

		return builders; 

	}
	public static String text2html(String html) {
		//html.replace("&lt;", "<").replace("\r", "");
		
		//return HtmlEscapers.htmlEscaper().escape(html);
		
	    //return Jsoup.parse(html).text();
		return "";
	}

	private String getRpoName(String rpoId) {
		// TODO Auto-generated method stub
		String temp = "" ;
		if(rpoId!="null"){

			String sqlQuery ="Select RPONAME from OptionCode where RPOID = "+rpoId;
			List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sqlQuery);
			for (Map row : resultList) {


				temp = String.valueOf(row.get("RPONAME"));
			}
		}
		return temp;
	}


	private String getTranslationfromDictionary(String tempMarketingDesc) {
		// TODO Auto-generated method stub
		String temp = "" ;
		String lb;
		//lb = tempMarketingDesc;
		if(tempMarketingDesc!="null"){
			lb= tempMarketingDesc.replace("\n", "").replace("\r", "");
			String sqlQuery ="SELECT * FROM vmds_cfd_trans_dictionary where "
					+ " original_text = '"+lb.replace("'", "''")+"'";
			List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sqlQuery);
			for (Map row : resultList) {


				temp = String.valueOf(row.get("TRANSLATED_TEXT"));
			}
		}
		return temp;
	}





}
