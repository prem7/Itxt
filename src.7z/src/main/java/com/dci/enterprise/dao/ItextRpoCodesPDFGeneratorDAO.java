package com.dci.enterprise.dao;

import java.util.List;

import com.dci.enterprise.model.RpoCodesBean;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

public interface ItextRpoCodesPDFGeneratorDAO {


	void onCloseDocument(PdfWriter writer, Document document);

	public void startRpoCodesPDFGeneration(List<RpoCodesBean> rpoCodes, Document document, PdfWriter writer, int vehiclePrint);

	void startRpoCodesPDFGeneration(List<RpoCodesBean> vehicleItemsXML);
}
