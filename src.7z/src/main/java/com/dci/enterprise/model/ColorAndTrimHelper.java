package com.dci.enterprise.model;

import java.math.BigDecimal;

public class ColorAndTrimHelper {

	private BigDecimal interiorID;
	private String intColorName;
	private String intColorCode;
	private BigDecimal seatID;
	private BigDecimal restrictionID;
	
	private String packageName;
	private String regionName;
	private BigDecimal localCode;
	private BigDecimal regionID;
	private String vehicleName;
	private BigDecimal modelID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private BigDecimal localeCode;
	private String divisionName;
	private BigDecimal isLandscape;
	private BigDecimal columnBreak;
	private BigDecimal divisionID;
	private long hashCodeGen;
	private String pageLabel;
	private String pulldownText;
	
	/**
	 * @return the interiorID
	 */
	public BigDecimal getInteriorID() {
		return interiorID;
	}
	/**
	 * @param interiorID the interiorID to set
	 */
	public void setInteriorID(BigDecimal interiorID) {
		this.interiorID = interiorID;
	}
	/**
	 * @return the intColorName
	 */
	public String getIntColorName() {
		return intColorName;
	}
	/**
	 * @param intColorName the intColorName to set
	 */
	public void setIntColorName(String intColorName) {
		this.intColorName = intColorName;
	}
	/**
	 * @return the intColorCode
	 */
	public String getIntColorCode() {
		return intColorCode;
	}
	/**
	 * @param intColorCode the intColorCode to set
	 */
	public void setIntColorCode(String intColorCode) {
		this.intColorCode = intColorCode;
	}
	/**
	 * @return the seatID
	 */
	public BigDecimal getSeatID() {
		return seatID;
	}
	/**
	 * @param seatID the seatID to set
	 */
	public void setSeatID(BigDecimal seatID) {
		this.seatID = seatID;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}
	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}
	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}
	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}
	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}
	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}
	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}
	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}
	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	/**
	 * @return the localCode
	 */
	public BigDecimal getLocalCode() {
		return localCode;
	}
	/**
	 * @param localCode the localCode to set
	 */
	public void setLocalCode(BigDecimal localCode) {
		this.localCode = localCode;
	}
	/**
	 * @return the regionID
	 */
	public BigDecimal getRegionID() {
		return regionID;
	}
	/**
	 * @param regionID the regionID to set
	 */
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
	}
	
	
	
	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}
	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}
	
	
	
	
	/**
	 * @return the isLandscape
	 */
	public BigDecimal getIsLandscape() {
		return isLandscape;
	}
	/**
	 * @param isLandscape the isLandscape to set
	 */
	public void setIsLandscape(BigDecimal isLandscape) {
		this.isLandscape = isLandscape;
	}
	/**
	 * @return the columnBreak
	 */
	public BigDecimal getColumnBreak() {
		return columnBreak;
	}
	/**
	 * @param columnBreak the columnBreak to set
	 */
	public void setColumnBreak(BigDecimal columnBreak) {
		this.columnBreak = columnBreak;
	}
	
	
	/**
	 * @return the divisionID
	 */
	public BigDecimal getDivisionID() {
		return divisionID;
	}
	/**
	 * @param divisionID the divisionID to set
	 */
	public void setDivisionID(BigDecimal divisionID) {
		this.divisionID = divisionID;
	}
	
	
	/**
	 * @return the hashCodeGen
	 */
	public long getHashCodeGen() {
		return hashCodeGen;
	}
	/**
	 * @param hashCodeGen the hashCodeGen to set
	 */
	public void setHashCodeGen(long hashCodeGen) {
		this.hashCodeGen = hashCodeGen;
	}
	
	
	/**
	 * @return the pageLabel
	 */
	public String getPageLabel() {
		return pageLabel;
	}
	/**
	 * @param pageLabel the pageLabel to set
	 */
	public void setPageLabel(String pageLabel) {
		this.pageLabel = pageLabel;
	}
	

	/**
	 * @return the pulldownText
	 */
	public String getPulldownText() {
		return pulldownText;
	}
	/**
	 * @param pulldownText the pulldownText to set
	 */
	public void setPulldownText(String pulldownText) {
		this.pulldownText = pulldownText;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColorAndTrimHelper [interiorID=" + interiorID
				+ ", intColorName=" + intColorName + ", intColorCode="
				+ intColorCode + ", seatID=" + seatID + ", restrictionID="
				+ restrictionID + ", packageName=" + packageName
				+ ", regionName=" + regionName + ", localCode=" + localCode
				+ ", regionID=" + regionID + ", vehicleName=" + vehicleName
				+ ", modelID=" + modelID + ", vehicleId=" + vehicleId
				+ ", vehicleYear=" + vehicleYear + ", localeCode=" + localeCode
				+ ", divisionName=" + divisionName + ", isLandscape="
				+ isLandscape + ", columnBreak=" + columnBreak
				+ ", divisionID=" + divisionID + ", hashCodeGen=" + hashCodeGen
				+ ", pageLabel=" + pageLabel + "]";
	}

	
	
}
