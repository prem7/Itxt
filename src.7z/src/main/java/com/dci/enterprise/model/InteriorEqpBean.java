package com.dci.enterprise.model;

import java.math.BigDecimal;
import java.util.HashMap;


public class InteriorEqpBean {

	//table Headers
	private String packageRestrtictionDesc;
	private String packageDescText;
	private String pageLabel;	
	private String packageName;
	private String regionName;
	private String vehicleName;
	private BigDecimal modelID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private String division;
	//table content
	private BigDecimal rpoId;
	private String rpoName;
	private String rpoDescBold;
	private String rpoDesc;
	private BigDecimal typeFlag;
	private String regylatoryFlag;
	private String extendedDesc;

	//availability Codes

	private String availableCode;
	private BigDecimal packageSort;
	private String rDescription;
	private BigDecimal availableCodeID;
	private HashMap< BigDecimal, String> packageNameMap;
	private HashMap< BigDecimal, String> packageDescMap;
	private int pageNumber;



	/**
	 * @return the rpoName
	 */
	public String getRpoName() {
		return rpoName;
	}
	/**
	 * @param rpoName the rpoName to set
	 */
	public void setRpoName(String rpoName) {
		this.rpoName = rpoName;
	}
	/**
	 * @return the rpoDescBold
	 */
	public String getRpoDescBold() {
		return rpoDescBold;
	}
	/**
	 * @param rpoDescBold the rpoDescBold to set
	 */
	public void setRpoDescBold(String rpoDescBold) {
		this.rpoDescBold = rpoDescBold;
	}
	/**
	 * @return the rpoDesc
	 */
	public String getRpoDesc() {
		return rpoDesc;
	}
	/**
	 * @param rpoDesc the rpoDesc to set
	 */
	public void setRpoDesc(String rpoDesc) {
		this.rpoDesc = rpoDesc;
	}

	/**
	 * @return the exteriorColorName
	 */

	/**
	 * @return the rpoId
	 */
	public BigDecimal getRpoId() {
		return rpoId;
	}
	/**
	 * @param rpoId the rpoId to set
	 */
	public void setRpoId(BigDecimal rpoId) {
		this.rpoId = rpoId;
	}

	/**
	 * @return the typeFlag
	 */
	public BigDecimal getTypeFlag() {
		return typeFlag;
	}
	/**
	 * @param typeFlag the typeFlag to set
	 */
	public void setTypeFlag(BigDecimal typeFlag) {
		this.typeFlag = typeFlag;
	}
	/**
	 * @return the regylatoryFlag
	 */
	public String getRegylatoryFlag() {
		return regylatoryFlag;
	}
	/**
	 * @param regylatoryFlag the regylatoryFlag to set
	 */
	public void setRegylatoryFlag(String regylatoryFlag) {
		this.regylatoryFlag = regylatoryFlag;
	}
	/**
	 * @return the extendedDesc
	 */
	public String getExtendedDesc() {
		return extendedDesc;
	}
	/**
	 * @param extendedDesc the extendedDesc to set
	 */
	public void setExtendedDesc(String extendedDesc) {
		this.extendedDesc = extendedDesc;
	}
	/**
	 * @return the packageRestrtictionDesc
	 */
	public String getPackageRestrtictionDesc() {
		return packageRestrtictionDesc;
	}
	/**
	 * @param packageRestrtictionDesc the packageRestrtictionDesc to set
	 */
	public void setPackageRestrtictionDesc(String packageRestrtictionDesc) {
		this.packageRestrtictionDesc = packageRestrtictionDesc;
	}
	/**
	 * @return the packageDescText
	 */
	public String getPacakgeDescText() {
		return packageDescText;
	}
	/**
	 * @param packageDescText the packageDescText to set
	 */
	public void setPacakgeDescText(String pacakgeDescText) {
		this.packageDescText = pacakgeDescText;
	}
	/**
	 * @return the pageLabel
	 */
	public String getPageLabel() {
		return pageLabel;
	}
	/**
	 * @param pageLabel the pageLabel to set
	 */
	public void setPageLabel(String pageLabel) {
		this.pageLabel = pageLabel;
	}
	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}
	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	/**
	 * @return the availableCode
	 */
	public String getAvailableCode() {
		return availableCode;
	}
	/**
	 * @param availableCode the availableCode to set
	 */
	public void setAvailableCode(String availableCode) {
		this.availableCode = availableCode;
	}



	/**
	 * @return the packageSort
	 */
	public BigDecimal getPackageSort() {
		return packageSort;
	}
	/**
	 * @param packageSort the packageSort to set
	 */
	public void setPackageSort(BigDecimal packageSort) {
		this.packageSort = packageSort;
	}
	/**
	 * @return the rDescription
	 */
	public String getrDescription() {
		return rDescription;
	}
	/**
	 * @param rDescription the rDescription to set
	 */
	public void setrDescription(String rDescription) {
		this.rDescription = rDescription;
	}
	/**
	 * @return the availableCodeID
	 */
	public BigDecimal getAvailableCodeID() {
		return availableCodeID;
	}
	/**
	 * @param availableCodeID the availableCodeID to set
	 */
	public void setAvailableCodeID(BigDecimal availableCodeID) {
		this.availableCodeID = availableCodeID;
	}



	/**
	 * @return the packageDescText
	 */
	public String getPackageDescText() {
		return packageDescText;
	}
	/**
	 * @param packageDescText the packageDescText to set
	 */
	public void setPackageDescText(String packageDescText) {
		this.packageDescText = packageDescText;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}
	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}
	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}



	/**
	 * @return the packageNameMap
	 */
	public HashMap<BigDecimal, String> getPackageNameMap() {
		return packageNameMap;
	}
	/**
	 * @param packageNameMap the packageNameMap to set
	 */
	public void setPackageNameMap(HashMap<BigDecimal, String> packageNameMap) {
		this.packageNameMap = packageNameMap;
	}
	/**
	 * @return the packageDescMap
	 */
	public HashMap<BigDecimal, String> getPackageDescMap() {
		return packageDescMap;
	}
	/**
	 * @param packageDescMap the packageDescMap to set
	 */
	public void setPackageDescMap(HashMap<BigDecimal, String> packageDescMap) {
		this.packageDescMap = packageDescMap;
	}

	
	
	
	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}
	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}
	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}
	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}
	/**
	 * @return the pageNumber
	 */
	public int getPageNumber() {
		return pageNumber;
	}
	/**
	 * @param pageNumber the pageNumber to set
	 */
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	
	
	/**
	 * @return the division
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division the division to set
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	@Override
	public String toString() {
		return "rpoId : " +rpoId + " RpoName: "+rpoName + " RPODesc: "+rpoDesc + "ExtendedDesc " +extendedDesc +" RDescription " +rDescription; 
	}
}
