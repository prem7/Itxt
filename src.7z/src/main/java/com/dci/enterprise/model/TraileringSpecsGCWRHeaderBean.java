package com.dci.enterprise.model;

import java.math.BigDecimal;

public class TraileringSpecsGCWRHeaderBean {

	private BigDecimal vehicleID;
	private BigDecimal GCWRValue;
	private BigDecimal GCWRValueMetric;
	
	
	/**
	 * @return the vehicleID
	 */
	public BigDecimal getVehicleID() {
		return vehicleID;
	}
	/**
	 * @param vehicleID the vehicleID to set
	 */
	public void setVehicleID(BigDecimal vehicleIDl) {
		this.vehicleID = vehicleIDl;
	}
	/**
	 * @return the gCWRValue
	 */
	public BigDecimal getGCWRValue() {
		return GCWRValue;
	}
	/**
	 * @param gCWRValue the gCWRValue to set
	 */
	public void setGCWRValue(BigDecimal gCWRValue) {
		GCWRValue = gCWRValue;
	}
	/**
	 * @return the gCWRValueMetric
	 */
	public BigDecimal getGCWRValueMetric() {
		return GCWRValueMetric;
	}
	/**
	 * @param gCWRValueMetric the gCWRValueMetric to set
	 */
	public void setGCWRValueMetric(BigDecimal gCWRValueMetric) {
		GCWRValueMetric = gCWRValueMetric;
	}
	
	
}
