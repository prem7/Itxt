package com.dci.enterprise.model;

import java.math.BigDecimal;

public class SpecsAndDimHelper {

	
	private String modelDesc;
	private String modelName;
	private BigDecimal modelID;
	private BigDecimal columnHeaderID;
	private String colHeader1;
	
	/**
	 * @return the modelDesc
	 */
	public String getModelDesc() {
		return modelDesc;
	}
	/**
	 * @param modelDesc the modelDesc to set
	 */
	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}
	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}
	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}
	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}
	/**
	 * @return the columnHeaderID
	 */
	public BigDecimal getColumnHeaderID() {
		return columnHeaderID;
	}
	/**
	 * @param columnHeaderID the columnHeaderID to set
	 */
	public void setColumnHeaderID(BigDecimal columnHeaderID) {
		this.columnHeaderID = columnHeaderID;
	}
	/**
	 * @return the colHeader1
	 */
	public String getColHeader1() {
		return colHeader1;
	}
	/**
	 * @param colHeader1 the colHeader1 to set
	 */
	public void setColHeader1(String colHeader1) {
		this.colHeader1 = colHeader1;
	}
	
	
}
