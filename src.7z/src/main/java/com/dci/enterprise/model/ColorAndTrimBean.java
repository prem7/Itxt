package com.dci.enterprise.model;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;

public class ColorAndTrimBean {


	//Query 1 
	private String modelName;
	private String modelDesc;
	private String regionName;	
	private BigDecimal vActiveflag;
	private String divisionName;

	//Query 2
	private String decorLevel;
	private String seatType;
	private String seatCode;
	private String seatTrim;
	private String seatTrimID;
	private BigDecimal seatID;
	private BigDecimal restrictionID;
	private String seatTrimCode;
	private String seatSort;
	private BigDecimal newoptionFlag;
	private BigDecimal seatTypeRestriction;
	private BigDecimal seatCodeRestrictionID;
	private BigDecimal seatDecorLevelRestrictionID;
	//Query 3

	private String intColorName;
	private String intColorCode;

	private int workItemID;
	private int modelSort;
	private String vehicleName;
	private String rpodescbold;
	private String rpodesc;
	private String rponame;	

	//
	private String exteriorColorName;
	private BigDecimal vehicleHasExteriorColorID;
	private String exteriorColorCode;
	private String extraText;
	private String exteriorColorWanNumber;
	private Collection<Map<String, String>> colorAvaialable;
	private BigDecimal exteriorColorID;


	//

	private String availableCodeName;


	private HashSet colorCodeList;
	private Map<Integer, String[]> colorList;

	private long hashCodeGen;


	/**
	 * @return the intColorCode
	 */
	public String getIntColorCode() {
		return intColorCode;
	}
	/**
	 * @param intColorCode the intColorCode to set
	 */
	public void setIntColorCode(String intColorCode) {
		this.intColorCode = intColorCode;
	}



	/**
	 * @return the decorLevel
	 */
	public String getDecorLevel() {
		return decorLevel;
	}
	/**
	 * @param decorLevel the decorLevel to set
	 */
	public void setDecorLevel(String decorLevel) {
		this.decorLevel = decorLevel;
	}


	/**
	 * @param workItemID the workItemID to set
	 */
	public void setWorkItemID(int workItemID) {
		this.workItemID = workItemID;
	}
	/**
	 * @param modelSort the modelSort to set
	 */
	public void setModelSort(int modelSort) {
		this.modelSort = modelSort;
	}

	/**
	 * @return the intColorName
	 */
	public String getIntColorName() {
		return intColorName;
	}
	/**
	 * @param intColorName the intColorName to set
	 */
	public void setIntColorName(String intColorName) {
		this.intColorName = intColorName;
	}
	/**
	 * @return the seatType
	 */
	public String getSeatType() {
		return seatType;
	}


	/**
	 * @param seatType the seatType to set
	 */
	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}
	public ColorAndTrimBean() {
	}

	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getModelDesc() {
		return modelDesc;
	}
	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}



	public Integer getWorkItemID() {
		return workItemID;
	}
	public void setWorkItemID(Integer workItemID) {
		this.workItemID = workItemID;
	}
	public Integer getModelSort() {
		return modelSort;
	}
	public void setModelSort(Integer modelSort) {
		this.modelSort = modelSort;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColorAndTrimBean [modelName=" + modelName + ", modelDesc="
				+ modelDesc + ", regionName=" + regionName + ", vActiveflag="
				+ vActiveflag + ", divisionName=" + divisionName
				+ ", decorLevel=" + decorLevel + ", seatType=" + seatType
				+ ", seatCode=" + seatCode + ", seatTrim=" + seatTrim
				+ ", seatTrimID=" + seatTrimID + ", seatID=" + seatID
				+ ", restrictionID=" + restrictionID + ", seatTrimCode="
				+ seatTrimCode + ", intColorName=" + intColorName
				+ ", intColorCode=" + intColorCode + ", workItemID="
				+ workItemID + ", modelSort=" + modelSort + ", vehicleName="
				+ vehicleName + ", rpodescbold=" + rpodescbold + ", rpodesc="
				+ rpodesc + ", rponame=" + rponame + ", exteriorColorName="
				+ exteriorColorName + ", vehicleHasExteriorColorID="
				+ vehicleHasExteriorColorID + ", exteriorColorCode="
				+ exteriorColorCode + ", exteriorColorWanNumber="
				+ exteriorColorWanNumber + ", colorAvaialable="
				+ colorAvaialable + ", availableCodeName=" + availableCodeName
				+ ", colorCodeList=" + colorCodeList + ", colorList="
				+ colorList + ", hashCodeGen=" + hashCodeGen + "]";
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}
	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	/**
	 * @return the rpodescbold
	 */
	public String getRpodescbold() {
		return rpodescbold;
	}
	/**
	 * @param rpodescbold the rpodescbold to set
	 */
	public void setRpodescbold(String rpodescbold) {
		this.rpodescbold = rpodescbold;
	}
	/**
	 * @return the rpodesc
	 */
	public String getRpodesc() {
		return rpodesc;
	}
	/**
	 * @param rpodesc the rpodesc to set
	 */
	public void setRpodesc(String rpodesc) {
		this.rpodesc = rpodesc;
	}
	/**
	 * @return the rponame
	 */
	public String getRponame() {
		return rponame;
	}
	/**
	 * @param rponame the rponame to set
	 */
	public void setRponame(String rponame) {
		this.rponame = rponame;
	}
	/**
	 * @return the seatCode
	 */
	public String getSeatCode() {
		return seatCode;
	}
	/**
	 * @param seatCode the seatCode to set
	 */
	public void setSeatCode(String seatCode) {
		this.seatCode = seatCode;
	}
	/**
	 * @return the seatTrim
	 */
	public String getSeatTrim() {
		return seatTrim;
	}
	/**
	 * @param seatTrim the seatTrim to set
	 */
	public void setSeatTrim(String seatTrim) {
		this.seatTrim = seatTrim;
	}
	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	/**
	 * @return the seatTrimID
	 */
	public String getSeatTrimID() {
		return seatTrimID;
	}
	/**
	 * @param seatTrimID the seatTrimID to set
	 */
	public void setSeatTrimID(String seatTrimID) {
		this.seatTrimID = seatTrimID;
	}
	/**
	 * @return the seatID
	 */
	public BigDecimal getSeatID() {
		return seatID;
	}
	/**
	 * @param seatID the seatID to set
	 */
	public void setSeatID(BigDecimal seatID) {
		this.seatID = seatID;
	}
	/**
	 * @return the vActiveflag
	 */
	public BigDecimal getvActiveflag() {
		return vActiveflag;
	}
	/**
	 * @param bigDecimal the vActiveflag to set
	 */
	public void setvActiveflag(BigDecimal bigDecimal) {
		this.vActiveflag = bigDecimal;
	}
	/**
	 * @return the hashCodeGen
	 */

	/**
	 * @return the seatTrimCode
	 */
	public String getSeatTrimCode() {
		return seatTrimCode;
	}
	/**
	 * @return the hashCodeGen
	 */
	public Long getHashCodeGen() {
		return hashCodeGen;
	}
	/**
	 * @param hashCodeGen the hashCodeGen to set
	 */
	public void setHashCodeGen(long hashCodeGen) {
		this.hashCodeGen = hashCodeGen;
	}
	/**
	 * @param seatTrimCode the seatTrimCode to set
	 */
	public void setSeatTrimCode(String seatTrimCode) {
		this.seatTrimCode = seatTrimCode;
	}
	/**
	 * @return the colorCodeList
	 */
	public HashSet getColorCodeList() {
		return colorCodeList;
	}
	/**
	 * @param colorCodeList the colorCodeList to set
	 */
	public void setColorCodeList(HashSet colorCodeList) {
		this.colorCodeList = colorCodeList;
	}
	/**
	 * @return the colorList
	 */
	public Map<Integer, String[]> getColorList() {
		return colorList;
	}
	/**
	 * @param colorDictionary the colorList to set
	 */
	public void setColorList(Map<Integer, String[]> colorDictionary) {
		this.colorList = colorDictionary;
	}
	/**
	 * @return the exteriorColorName
	 */
	public String getExteriorColorName() {
		return exteriorColorName;
	}
	/**
	 * @param exteriorColorName the exteriorColorName to set
	 */
	public void setExteriorColorName(String exteriorColorName) {
		this.exteriorColorName = exteriorColorName;
	}
	/**
	 * @return the vehicleHasExteriorColorID
	 */
	public BigDecimal getVehicleHasExteriorColorID() {
		return vehicleHasExteriorColorID;
	}
	/**
	 * @param vehicleHasExteriorColorID the vehicleHasExteriorColorID to set
	 */
	public void setVehicleHasExteriorColorID(BigDecimal vehicleHasExteriorColorID) {
		this.vehicleHasExteriorColorID = vehicleHasExteriorColorID;
	}
	/**
	 * @return the exteriorColorCode
	 */
	public String getExteriorColorCode() {
		return exteriorColorCode;
	}
	/**
	 * @param exteriorColorCode the exteriorColorCode to set
	 */
	public void setExteriorColorCode(String exteriorColorCode) {
		this.exteriorColorCode = exteriorColorCode;
	}
	/**
	 * @return the exteriorColorWanNumber
	 */
	public String getExteriorColorWanNumber() {
		return exteriorColorWanNumber;
	}
	/**
	 * @param exteriorColorWanNumber the exteriorColorWanNumber to set
	 */
	public void setExteriorColorWanNumber(String exteriorColorWanNumber) {
		this.exteriorColorWanNumber = exteriorColorWanNumber;
	}
	/**
	 * @return the availableCodeName
	 */
	public String getAvailableCodeName() {
		return availableCodeName;
	}
	/**
	 * @param availableCodeName the availableCodeName to set
	 */
	public void setAvailableCodeName(String availableCodeName) {
		this.availableCodeName = availableCodeName;
	}
	/**
	 * @return the colorAvaialable
	 */
	public Collection<Map<String, String>> getColorAvaialable() {
		return colorAvaialable;
	}
	/**
	 * @param collection the colorAvaialable to set
	 */
	public void setColorAvaialable(Collection<Map<String, String>> collection) {
		this.colorAvaialable = collection;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the seatSort
	 */
	public String getSeatSort() {
		return seatSort;
	}
	/**
	 * @param seatSort the seatSort to set
	 */
	public void setSeatSort(String seatSort) {
		this.seatSort = seatSort;
	}
	/**
	 * @return the newoptionFlag
	 */
	public BigDecimal getNewoptionFlag() {
		return newoptionFlag;
	}
	/**
	 * @param newoptionFlag the newoptionFlag to set
	 */
	public void setNewoptionFlag(BigDecimal newoptionFlag) {
		this.newoptionFlag = newoptionFlag;
	}
	/**
	 * @return the seatTypeRestriction
	 */
	public BigDecimal getSeatTypeRestriction() {
		return seatTypeRestriction;
	}
	/**
	 * @param seatTypeRestriction the seatTypeRestriction to set
	 */
	public void setSeatTypeRestriction(BigDecimal seatTypeRestriction) {
		this.seatTypeRestriction = seatTypeRestriction;
	}
	/**
	 * @return the seatCodeRestrictionID
	 */
	public BigDecimal getSeatCodeRestrictionID() {
		return seatCodeRestrictionID;
	}
	/**
	 * @param seatCodeRestrictionID the seatCodeRestrictionID to set
	 */
	public void setSeatCodeRestrictionID(BigDecimal seatCodeRestrictionID) {
		this.seatCodeRestrictionID = seatCodeRestrictionID;
	}
	/**
	 * @return the exteriorColorID
	 */
	public BigDecimal getExteriorColorID() {
		return exteriorColorID;
	}
	/**
	 * @param exteriorColorID the exteriorColorID to set
	 */
	public void setExteriorColorID(BigDecimal exteriorColorID) {
		this.exteriorColorID = exteriorColorID;
	}
	public String getExtraText() {
		return extraText;
	}
	public void setExtraText(String extraText) {
		this.extraText = extraText;
	}
	public BigDecimal getSeatDecorLevelRestrictionID() {
		return seatDecorLevelRestrictionID;
	}
	public void setSeatDecorLevelRestrictionID(BigDecimal seatDecorLevelRestrictionID) {
		this.seatDecorLevelRestrictionID = seatDecorLevelRestrictionID;
	}




}
