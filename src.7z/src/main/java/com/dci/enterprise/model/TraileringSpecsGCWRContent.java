package com.dci.enterprise.model;

import java.math.BigDecimal;

public class TraileringSpecsGCWRContent {

	private BigDecimal traileringCategoryHeaderID;
	private BigDecimal maxTraileringWeight;
	private BigDecimal axleRatio;
	private BigDecimal traileringCateogoryID;
	private BigDecimal traileringHeaderID;
	private String AxleRatioText;
	private BigDecimal axleRatioRestrictionID;
	private BigDecimal maxTraileringWeightRestricionID;
	private BigDecimal maxTraileringWeightMetric;
	private BigDecimal engineSort;
	
	
	
	/**
	 * @return the traileringCategoryHeaderID
	 */
	public BigDecimal getTraileringCategoryHeaderID() {
		return traileringCategoryHeaderID;
	}
	/**
	 * @param traileringCategoryHeaderID the traileringCategoryHeaderID to set
	 */
	public void setTraileringCategoryHeaderID(BigDecimal traileringCategoryHeaderID) {
		this.traileringCategoryHeaderID = traileringCategoryHeaderID;
	}
	/**
	 * @return the maxTraileringWeight
	 */
	public BigDecimal getMaxTraileringWeight() {
		return maxTraileringWeight;
	}
	/**
	 * @param maxTraileringWeight the maxTraileringWeight to set
	 */
	public void setMaxTraileringWeight(BigDecimal maxTraileringWeight) {
		this.maxTraileringWeight = maxTraileringWeight;
	}
	/**
	 * @return the axleRatio
	 */
	public BigDecimal getAxleRatio() {
		return axleRatio;
	}
	/**
	 * @param axleRatio the axleRatio to set
	 */
	public void setAxleRatio(BigDecimal axleRatio) {
		this.axleRatio = axleRatio;
	}
	/**
	 * @return the traileringCateogoryID
	 */
	public BigDecimal getTraileringCateogoryID() {
		return traileringCateogoryID;
	}
	/**
	 * @param traileringCateogoryID the traileringCateogoryID to set
	 */
	public void setTraileringCateogoryID(BigDecimal traileringCateogoryID) {
		this.traileringCateogoryID = traileringCateogoryID;
	}
	/**
	 * @return the traileringHeaderID
	 */
	public BigDecimal getTraileringHeaderID() {
		return traileringHeaderID;
	}
	/**
	 * @param traileringHeaderID the traileringHeaderID to set
	 */
	public void setTraileringHeaderID(BigDecimal traileringHeaderID) {
		this.traileringHeaderID = traileringHeaderID;
	}
	/**
	 * @return the axleRatioText
	 */
	public String getAxleRatioText() {
		return AxleRatioText;
	}
	/**
	 * @param axleRatioText the axleRatioText to set
	 */
	public void setAxleRatioText(String axleRatioText) {
		AxleRatioText = axleRatioText;
	}
	/**
	 * @return the axleRatioRestrictionID
	 */
	public BigDecimal getAxleRatioRestrictionID() {
		return axleRatioRestrictionID;
	}
	/**
	 * @param axleRatioRestrictionID the axleRatioRestrictionID to set
	 */
	public void setAxleRatioRestrictionID(BigDecimal axleRatioRestrictionID) {
		this.axleRatioRestrictionID = axleRatioRestrictionID;
	}
	/**
	 * @return the maxTraileringWeightRestricionID
	 */
	public BigDecimal getMaxTraileringWeightRestricionID() {
		return maxTraileringWeightRestricionID;
	}
	/**
	 * @param maxTraileringWeightRestricionID the maxTraileringWeightRestricionID to set
	 */
	public void setMaxTraileringWeightRestricionID(
			BigDecimal maxTraileringWeightRestricionID) {
		this.maxTraileringWeightRestricionID = maxTraileringWeightRestricionID;
	}
	/**
	 * @return the maxTraileringWeightMetric
	 */
	public BigDecimal getMaxTraileringWeightMetric() {
		return maxTraileringWeightMetric;
	}
	/**
	 * @param maxTraileringWeightMetric the maxTraileringWeightMetric to set
	 */
	public void setMaxTraileringWeightMetric(BigDecimal maxTraileringWeightMetric) {
		this.maxTraileringWeightMetric = maxTraileringWeightMetric;
	}
	/**
	 * @return the engineSort
	 */
	public BigDecimal getEngineSort() {
		return engineSort;
	}
	/**
	 * @param engineSort the engineSort to set
	 */
	public void setEngineSort(BigDecimal engineSort) {
		this.engineSort = engineSort;
	}

	
	
	
}
