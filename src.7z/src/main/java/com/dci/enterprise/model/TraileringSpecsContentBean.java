package com.dci.enterprise.model;

import java.math.BigDecimal;

public class TraileringSpecsContentBean {
	
	private BigDecimal traileringCategoryID;
	private String TCName;
	private BigDecimal TCSort;
	private BigDecimal vehicleID;
	private BigDecimal modelID;
	private BigDecimal restrictionID;
	private String modelName;
	private String modeldesc;
	private BigDecimal maxRows;
	
	
	/**
	 * @return the traileringCategoryID
	 */
	public BigDecimal getTraileringCategoryID() {
		return traileringCategoryID;
	}
	/**
	 * @param traileringCategoryID the traileringCategoryID to set
	 */
	public void setTraileringCategoryID(BigDecimal traileringCategoryID) {
		this.traileringCategoryID = traileringCategoryID;
	}
	/**
	 * @return the tCName
	 */
	public String getTCName() {
		return TCName;
	}
	/**
	 * @param tCName the tCName to set
	 */
	public void setTCName(String tCName) {
		TCName = tCName;
	}
	/**
	 * @return the tCSort
	 */
	public BigDecimal getTCSort() {
		return TCSort;
	}
	/**
	 * @param tCSort the tCSort to set
	 */
	public void setTCSort(BigDecimal tCSort) {
		TCSort = tCSort;
	}
	/**
	 * @return the vehicleID
	 */
	public BigDecimal getVehicleID() {
		return vehicleID;
	}
	/**
	 * @param vehicleID the vehicleID to set
	 */
	public void setVehicleID(BigDecimal vehicleID) {
		this.vehicleID = vehicleID;
	}
	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}
	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}
	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	/**
	 * @return the modeldesc
	 */
	public String getModeldesc() {
		return modeldesc;
	}
	/**
	 * @param modeldesc the modeldesc to set
	 */
	public void setModeldesc(String modeldesc) {
		this.modeldesc = modeldesc;
	}
	/**
	 * @return the maxRows
	 */
	public BigDecimal getMaxRows() {
		return maxRows;
	}
	/**
	 * @param maxRows the maxRows to set
	 */
	public void setMaxRows(BigDecimal maxRows) {
		this.maxRows = maxRows;
	}

}
