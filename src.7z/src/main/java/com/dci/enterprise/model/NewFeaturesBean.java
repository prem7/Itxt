package com.dci.enterprise.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

public class NewFeaturesBean {
	
	public BigDecimal typeID;
	public String NFtext;
	public BigDecimal getTypeID() {
		return typeID;
	}
	public void setTypeID(BigDecimal typeID) {
		this.typeID = typeID;
	}
	public String getNFtext() {
		return NFtext;
	}
	public void setNFtext(String nFtext) {
		NFtext = nFtext;
	}
	

}
