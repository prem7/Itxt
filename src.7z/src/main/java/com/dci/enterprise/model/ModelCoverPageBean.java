package com.dci.enterprise.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

public class ModelCoverPageBean {
	
	
	private String vehicleName;
	private String divisionName;
	private BigDecimal divisionID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private String division;

	private BigDecimal regionID;
	private BigDecimal localeCode;
	private ArrayList<NewFeaturesBean> newFeaturesList;

	
	
	public ArrayList<NewFeaturesBean> getNewFeaturesList() {
		return newFeaturesList;
	}
	public void setNewFeaturesList(ArrayList<NewFeaturesBean> newFeaturesList) {
		this.newFeaturesList = newFeaturesList;
	}
	public BigDecimal getDivisionID() {
		return divisionID;
	}
	public void setDivisionID(BigDecimal divisionID) {
		this.divisionID = divisionID;
	}
	public BigDecimal getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public BigDecimal getRegionID() {
		return regionID;
	}
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
	}
	public BigDecimal getLocaleCode() {
		return localeCode;
	}
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}
	private Map<BigDecimal, String> modelNames;
	
	
	
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public String getDivisionName() {
		return divisionName;
	}
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	
	public Map<BigDecimal, String> getModelNames() {
		return modelNames;
	}
	public void setModelNames(Map<BigDecimal, String> modelNames) {
		this.modelNames = modelNames;
	}
	

	

}
