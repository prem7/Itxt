package com.dci.enterprise.model;

import java.math.BigDecimal;

public class ColorRestrictionBean {


	private BigDecimal restrictionID;
	
	private String restriction;

	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the restriction
	 */
	public String getRestriction() {
		return restriction;
	}
	/**
	 * @param restriction the restriction to set
	 */
	public void setRestriction(String restriction) {
		this.restriction = restriction;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColorRestrictionBean [restrictionID=" + restrictionID
				+ ", restriction=" + restriction + "]";
	}
	
	

}
