package com.dci.enterprise.model;

import java.math.BigDecimal;

public class TraileringSpecsBeanRestriction {

	private  BigDecimal pulldownItemID;
	private String pullDownText;
	private BigDecimal typeID;
	private BigDecimal vehicleId;
	private BigDecimal engineSort;

	private BigDecimal restrictionID;
	private String restrictionText;
	private String optionalFooterNote1;
	private String optionalFooterNote2;
	private String optionalFooterNote3;
	private String optionalFooterNote4;
	private String optionalFooterNote5;
	private String optionalFooterNote6;
	private String optionalFooterNote7;
	private String optionalFooterNote8;
	private String optionalFooterNote9;
	private String optionalFooterNote10;
	private String optionalFooterNote11;
	private String optionalFooterNote12;
	private String optionalFooterNote13;
	private String optionalFooterNote14;

	private String type;
	private String type2;
	private String optionalTypeDescription;
	private String upperColorExt;
	private String lowerColorExt;



	/**
	 * @return the pulldownItemID
	 */
	public BigDecimal getPulldownItemID() {
		return pulldownItemID;
	}
	/**
	 * @param pulldownItemID the pulldownItemID to set
	 */
	public void setPulldownItemID(BigDecimal pulldownItemID) {
		this.pulldownItemID = pulldownItemID;
	}
	/**
	 * @return the pullDownText
	 */
	public String getPullDownText() {
		return pullDownText;
	}
	/**
	 * @param pullDownText the pullDownText to set
	 */
	public void setPullDownText(String pullDownText) {
		this.pullDownText = pullDownText;
	}
	/**
	 * @return the typeID
	 */
	public BigDecimal getTypeID() {
		return typeID;
	}
	/**
	 * @param typeID the typeID to set
	 */
	public void setTypeID(BigDecimal typeID) {
		this.typeID = typeID;
	}
	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}
	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}
	/**
	 * @return the engineSort
	 */
	public BigDecimal getEngineSort() {
		return engineSort;
	}
	/**
	 * @param engineSort the engineSort to set
	 */
	public void setEngineSort(BigDecimal engineSort) {
		this.engineSort = engineSort;
	}
	/**
	 * @return the optionalFooterNote2
	 */
	public String getOptionalFooterNote2() {
		return optionalFooterNote2;
	}
	/**
	 * @param optionalFooterNote2 the optionalFooterNote2 to set
	 */
	public void setOptionalFooterNote2(String optionalFooterNote2) {
		this.optionalFooterNote2 = optionalFooterNote2;
	}
	/**
	 * @return the optionalFooterNote1
	 */
	public String getOptionalFooterNote1() {
		return optionalFooterNote1;
	}
	/**
	 * @param optionalFooterNote1 the optionalFooterNote1 to set
	 */
	public void setOptionalFooterNote1(String optionalFooterNote1) {
		this.optionalFooterNote1 = optionalFooterNote1;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the type2
	 */
	public String getType2() {
		return type2;
	}
	/**
	 * @param type2 the type2 to set
	 */
	public void setType2(String type2) {
		this.type2 = type2;
	}
	/**
	 * @return the optionalTypeDescription
	 */
	public String getOptionalTypeDescription() {
		return optionalTypeDescription;
	}
	/**
	 * @param optionalTypeDescription the optionalTypeDescription to set
	 */
	public void setOptionalTypeDescription(String optionalTypeDescription) {
		this.optionalTypeDescription = optionalTypeDescription;
	}
	/**
	 * @return the optionalFooterNote3
	 */
	public String getOptionalFooterNote3() {
		return optionalFooterNote3;
	}
	/**
	 * @param optionalFooterNote3 the optionalFooterNote3 to set
	 */
	public void setOptionalFooterNote3(String optionalFooterNote3) {
		this.optionalFooterNote3 = optionalFooterNote3;
	}
	/**
	 * @return the optionalFooterNote4
	 */
	public String getOptionalFooterNote4() {
		return optionalFooterNote4;
	}
	/**
	 * @param optionalFooterNote4 the optionalFooterNote4 to set
	 */
	public void setOptionalFooterNote4(String optionalFooterNote4) {
		this.optionalFooterNote4 = optionalFooterNote4;
	}
	/**
	 * @return the optionalFooterNote5
	 */
	public String getOptionalFooterNote5() {
		return optionalFooterNote5;
	}
	/**
	 * @param optionalFooterNote5 the optionalFooterNote5 to set
	 */
	public void setOptionalFooterNote5(String optionalFooterNote5) {
		this.optionalFooterNote5 = optionalFooterNote5;
	}
	/**
	 * @return the optionalFooterNote6
	 */
	public String getOptionalFooterNote6() {
		return optionalFooterNote6;
	}
	/**
	 * @param optionalFooterNote6 the optionalFooterNote6 to set
	 */
	public void setOptionalFooterNote6(String optionalFooterNote6) {
		this.optionalFooterNote6 = optionalFooterNote6;
	}
	/**
	 * @return the optionalFooterNote7
	 */
	public String getOptionalFooterNote7() {
		return optionalFooterNote7;
	}
	/**
	 * @param optionalFooterNote7 the optionalFooterNote7 to set
	 */
	public void setOptionalFooterNote7(String optionalFooterNote7) {
		this.optionalFooterNote7 = optionalFooterNote7;
	}
	/**
	 * @return the optionalFooterNote8
	 */
	public String getOptionalFooterNote8() {
		return optionalFooterNote8;
	}
	/**
	 * @param optionalFooterNote8 the optionalFooterNote8 to set
	 */
	public void setOptionalFooterNote8(String optionalFooterNote8) {
		this.optionalFooterNote8 = optionalFooterNote8;
	}
	/**
	 * @return the optionalFooterNote9
	 */
	public String getOptionalFooterNote9() {
		return optionalFooterNote9;
	}
	/**
	 * @param optionalFooterNote9 the optionalFooterNote9 to set
	 */
	public void setOptionalFooterNote9(String optionalFooterNote9) {
		this.optionalFooterNote9 = optionalFooterNote9;
	}
	/**
	 * @return the optionalFooterNote10
	 */
	public String getOptionalFooterNote10() {
		return optionalFooterNote10;
	}
	/**
	 * @param optionalFooterNote10 the optionalFooterNote10 to set
	 */
	public void setOptionalFooterNote10(String optionalFooterNote10) {
		this.optionalFooterNote10 = optionalFooterNote10;
	}
	/**
	 * @return the optionalFooterNote11
	 */
	public String getOptionalFooterNote11() {
		return optionalFooterNote11;
	}
	/**
	 * @param optionalFooterNote11 the optionalFooterNote11 to set
	 */
	public void setOptionalFooterNote11(String optionalFooterNote11) {
		this.optionalFooterNote11 = optionalFooterNote11;
	}
	/**
	 * @return the optionalFooterNote12
	 */
	public String getOptionalFooterNote12() {
		return optionalFooterNote12;
	}
	/**
	 * @param optionalFooterNote12 the optionalFooterNote12 to set
	 */
	public void setOptionalFooterNote12(String optionalFooterNote12) {
		this.optionalFooterNote12 = optionalFooterNote12;
	}
	/**
	 * @return the optionalFooterNote13
	 */
	public String getOptionalFooterNote13() {
		return optionalFooterNote13;
	}
	/**
	 * @param optionalFooterNote13 the optionalFooterNote13 to set
	 */
	public void setOptionalFooterNote13(String optionalFooterNote13) {
		this.optionalFooterNote13 = optionalFooterNote13;
	}
	/**
	 * @return the optionalFooterNote14
	 */
	public String getOptionalFooterNote14() {
		return optionalFooterNote14;
	}
	/**
	 * @param optionalFooterNote14 the optionalFooterNote14 to set
	 */
	public void setOptionalFooterNote14(String optionalFooterNote14) {
		this.optionalFooterNote14 = optionalFooterNote14;
	}
	/**
	 * @return the upperColorExt
	 */
	public String getUpperColorExt() {
		return upperColorExt;
	}
	/**
	 * @param upperColorExt the upperColorExt to set
	 */
	public void setUpperColorExt(String upperColorExt) {
		this.upperColorExt = upperColorExt;
	}
	/**
	 * @return the lowerColorExt
	 */
	public String getLowerColorExt() {
		return lowerColorExt;
	}
	/**
	 * @param lowerColorExt the lowerColorExt to set
	 */
	public void setLowerColorExt(String lowerColorExt) {
		this.lowerColorExt = lowerColorExt;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the restrictionText
	 */
	public String getRestrictionText() {
		return restrictionText;
	}
	/**
	 * @param restrictionText the restrictionText to set
	 */
	public void setRestrictionText(String restrictionText) {
		this.restrictionText = restrictionText;
	}



}
