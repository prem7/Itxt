package com.dci.enterprise.model;

import java.math.BigDecimal;

public class ExtraColumnsHeaderBean {

	private BigDecimal vehicleHasExteriorColorID;
	private BigDecimal restrictionID;
	private BigDecimal extraColumnHeaderID;
	private String extraColumnText;
	private String extraHeaderText;
	
	/**
	 * @return the vehicleHasExteriorColorID
	 */
	public BigDecimal getVehicleHasExteriorColorID() {
		return vehicleHasExteriorColorID;
	}
	/**
	 * @param vehicleHasExteriorColorID the vehicleHasExteriorColorID to set
	 */
	public void setVehicleHasExteriorColorID(BigDecimal vehicleHasExteriorColorID) {
		this.vehicleHasExteriorColorID = vehicleHasExteriorColorID;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the extraColumnHeaderID
	 */
	
	/**
	 * @return the extraColumnText
	 */
	public String getExtraColumnText() {
		return extraColumnText;
	}
	/**
	 * @param extraColumnText the extraColumnText to set
	 */
	public void setExtraColumnText(String extraColumnText) {
		this.extraColumnText = extraColumnText;
	}
	/**
	 * @return the extraHeaderText
	 */
	public String getExtraHeaderText() {
		return extraHeaderText;
	}
	/**
	 * @param extraHeaderText the extraHeaderText to set
	 */
	public void setExtraHeaderText(String extraHeaderText) {
		this.extraHeaderText = extraHeaderText;
	}
	/**
	 * @return the extraColumnHeaderID
	 */
	public BigDecimal getExtraColumnHeaderID() {
		return extraColumnHeaderID;
	}
	/**
	 * @param extraColumnHeaderID the extraColumnHeaderID to set
	 */
	public void setExtraColumnHeaderID(BigDecimal extraColumnHeaderID) {
		this.extraColumnHeaderID = extraColumnHeaderID;
	}
	
	
	
}
