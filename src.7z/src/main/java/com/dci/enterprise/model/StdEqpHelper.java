package com.dci.enterprise.model;

import java.math.BigDecimal;

public class StdEqpHelper {


	private String trimName;
	private String modelName;
	private BigDecimal modelID;
	private String modelDesc;
	private String packageName;
	private BigDecimal packageID;
	private BigDecimal packageDescID;
	private BigDecimal packageSort;
	private String restriction;
	private String packageDesc1;
	private String pageLabel;
	private String packageRestrictionDesc;
	private BigDecimal packageRestrictionID;
	private BigDecimal pageNumber;
	private BigDecimal restrictionID;
	private String packageDesc2;
	
	
	private BigDecimal isLandscape;
	private String regionName;
	private String vehicleName;
	private String divisionName;
	private BigDecimal divisionID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private String division;
	private BigDecimal regionID;
	private BigDecimal localeCode;
	
	
	/**
	 * @return the trimName
	 */
	public String getTrimName() {
		return trimName;
	}
	/**
	 * @param trimName the trimName to set
	 */
	public void setTrimName(String trimName) {
		this.trimName = trimName;
	}
	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}
	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	/**
	 * @return the restriction
	 */
	public String getRestriction() {
		return restriction;
	}
	/**
	 * @param restriction the restriction to set
	 */
	public void setRestriction(String restriction) {
		this.restriction = restriction;
	}
	
	/**
	 * @return the pageNumber
	 */
	public BigDecimal getPageNumber() {
		return pageNumber;
	}
	/**
	 * @param pageNumber the pageNumber to set
	 */
	public void setPageNumber(BigDecimal pageNumber) {
		this.pageNumber = pageNumber;
	}
	/**
	 * @return the packageRestrictionDesc
	 */
	public String getPackageRestrictionDesc() {
		return packageRestrictionDesc;
	}
	/**
	 * @param packageRestrictionDesc the packageRestrictionDesc to set
	 */
	public void setPackageRestrictionDesc(String packageRestrictionDesc) {
		this.packageRestrictionDesc = packageRestrictionDesc;
	}
	/**
	 * @return the packageDesc2
	 */
	public String getPackageDesc2() {
		return packageDesc2;
	}
	/**
	 * @param packageDesc2 the packageDesc2 to set
	 */
	public void setPackageDesc2(String packageDesc2) {
		this.packageDesc2 = packageDesc2;
	}
	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}
	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	/**
	 * @return the packageDesc1
	 */
	public String getPackageDesc1() {
		return packageDesc1;
	}
	/**
	 * @param packageDesc1 the packageDesc1 to set
	 */
	public void setPackageDesc1(String packageDesc1) {
		this.packageDesc1 = packageDesc1;
	}
	/**
	 * @return the pageLabel
	 */
	public String getPageLabel() {
		return pageLabel;
	}
	/**
	 * @param pageLabel the pageLabel to set
	 */
	public void setPageLabel(String pageLabel) {
		this.pageLabel = pageLabel;
	}
	/**
	 * @return the packageSort
	 */
	public BigDecimal getPackageSort() {
		return packageSort;
	}
	/**
	 * @param packageSort the packageSort to set
	 */
	public void setPackageSort(BigDecimal packageSort) {
		this.packageSort = packageSort;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the packageRestrictionID
	 */
	public BigDecimal getPackageRestrictionID() {
		return packageRestrictionID;
	}
	/**
	 * @param packageRestrictionID the packageRestrictionID to set
	 */
	public void setPackageRestrictionID(BigDecimal packageRestrictionID) {
		this.packageRestrictionID = packageRestrictionID;
	}
	/**
	 * @return the packageID
	 */
	public BigDecimal getPackageID() {
		return packageID;
	}
	/**
	 * @param packageID the packageID to set
	 */
	public void setPackageID(BigDecimal packageID) {
		this.packageID = packageID;
	}
	/**
	 * @return the packageDescID
	 */
	public BigDecimal getPackageDescID() {
		return packageDescID;
	}
	/**
	 * @param packageDescID the packageDescID to set
	 */
	public void setPackageDescID(BigDecimal packageDescID) {
		this.packageDescID = packageDescID;
	}
	
	
	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}
	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}
	
	
	
	/**
	 * @return the modelDesc
	 */
	public String getModelDesc() {
		return modelDesc;
	}
	/**
	 * @param modelDesc the modelDesc to set
	 */
	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}
	
	
	
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}
	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	/**
	 * @return the divisionID
	 */
	public BigDecimal getDivisionID() {
		return divisionID;
	}
	/**
	 * @param divisionID the divisionID to set
	 */
	public void setDivisionID(BigDecimal divisionID) {
		this.divisionID = divisionID;
	}
	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}
	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}
	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}
	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}
	/**
	 * @return the division
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division the division to set
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return the regionID
	 */
	public BigDecimal getRegionID() {
		return regionID;
	}
	/**
	 * @param regionID the regionID to set
	 */
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	
	@Override
	public String toString() {
		return "StdEqpHelper [trimName=" + trimName + ", modelName="
				+ modelName + ", packageName=" + packageName + ", packageID="
				+ packageID + ", packageDescID=" + packageDescID
				+ ", packageSort=" + packageSort + ", restriction="
				+ restriction + ", packageDesc1=" + packageDesc1
				+ ", pageLabel=" + pageLabel + ", packageRestrictionDesc="
				+ packageRestrictionDesc + ", packageRestrictionID="
				+ packageRestrictionID + ", pageNumber=" + pageNumber
				+ ", restrictionID=" + restrictionID + ", packageDesc2="
				+ packageDesc2 + "]";
	}
	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}
	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}
	/**
	 * @return the isLandscape
	 */
	public BigDecimal getIsLandscape() {
		return isLandscape;
	}
	/**
	 * @param isLandscape the isLandscape to set
	 */
	public void setIsLandscape(BigDecimal isLandscape) {
		this.isLandscape = isLandscape;
	}



}
