package com.dci.enterprise.model;

import java.math.BigDecimal;


public class SpecsAndDimensionBean {

	//table Headers
	
	private String packageName;
	private String regionName;
	private String vehicleName;
	private BigDecimal modelID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private String divisionName;
	private String imageName;
	private String optionalDesc;
	private BigDecimal regionID;
	private BigDecimal localeCode;
	private BigDecimal isLandscape;
	private BigDecimal ColumnBreak;
	
	//table content
	private String rowBoldDesc;
	private String rowDesctiption1;
	private String fromUnit;
	private String toUnit;
	private BigDecimal rowHeaderID;
	private BigDecimal columnHeaderID;
	private BigDecimal multiplier;
	private String rowCode;
	private BigDecimal fromUnitDecimals;
	private BigDecimal toUnitDecimals;
	private BigDecimal rowCategoryID;
	private String restrictionText;
	private String pulldownText;
	
	
	//availability Codes

	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}




	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}




	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}




	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}




	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}




	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}




	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}




	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}




	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}




	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}




	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}




	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}




	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}




	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String division) {
		this.divisionName = division;
	}




	/**
	 * @return the rowDesctiption1
	 */
	public String getRowDesctiption1() {
		return rowDesctiption1;
	}




	/**
	 * @param rowDesctiption1 the rowDesctiption1 to set
	 */
	public void setRowDesctiption1(String rowDesctiption1) {
		this.rowDesctiption1 = rowDesctiption1;
	}




	/**
	 * @return the fromUnit
	 */
	public String getFromUnit() {
		return fromUnit;
	}




	/**
	 * @param fromUnit the fromUnit to set
	 */
	public void setFromUnit(String fromUnit) {
		this.fromUnit = fromUnit;
	}




	/**
	 * @return the toUnit
	 */
	public String getToUnit() {
		return toUnit;
	}




	/**
	 * @param toUnit the toUnit to set
	 */
	public void setToUnit(String toUnit) {
		this.toUnit = toUnit;
	}




	/**
	 * @return the rowHeaderID
	 */
	public BigDecimal getRowHeaderID() {
		return rowHeaderID;
	}




	/**
	 * @param rowHeaderID the rowHeaderID to set
	 */
	public void setRowHeaderID(BigDecimal rowHeaderID) {
		this.rowHeaderID = rowHeaderID;
	}




	/**
	 * @return the columnHeaderID
	 */
	public BigDecimal getColumnHeaderID() {
		return columnHeaderID;
	}




	/**
	 * @param columnHeaderID the columnHeaderID to set
	 */
	public void setColumnHeaderID(BigDecimal columnHeaderID) {
		this.columnHeaderID = columnHeaderID;
	}




	/**
	 * @return the multiplier
	 */
	public BigDecimal getMultiplier() {
		return multiplier;
	}




	/**
	 * @param multiplier the multiplier to set
	 */
	public void setMultiplier(BigDecimal multiplier) {
		this.multiplier = multiplier;
	}




	/**
	 * @return the rowBoldDesc
	 */
	public String getRowBoldDesc() {
		return rowBoldDesc;
	}




	/**
	 * @param rowBoldDesc the rowBoldDesc to set
	 */
	public void setRowBoldDesc(String rowBoldDesc) {
		this.rowBoldDesc = rowBoldDesc;
	}




	/**
	 * @return the imageName
	 */
	public String getImageName() {
		return imageName;
	}




	/**
	 * @param imageName the imageName to set
	 */
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}




	/**
	 * @return the optionalDesc
	 */
	public String getOptionalDesc() {
		return optionalDesc;
	}




	/**
	 * @param optionalDesc the optionalDesc to set
	 */
	public void setOptionalDesc(String optionalDesc) {
		this.optionalDesc = optionalDesc;
	}




	/**
	 * @return the rowCode
	 */
	public String getRowCode() {
		return rowCode;
	}




	/**
	 * @param rowCode the rowCode to set
	 */
	public void setRowCode(String rowCode) {
		this.rowCode = rowCode;
	}




	/**
	 * @return the regionID
	 */
	public BigDecimal getRegionID() {
		return regionID;
	}




	/**
	 * @param regionID the regionID to set
	 */
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
	}



	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}




	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}




	/**
	 * @return the isLandscape
	 */
	public BigDecimal getIsLandscape() {
		return isLandscape;
	}




	/**
	 * @param isLandscape the isLandscape to set
	 */
	public void setIsLandscape(BigDecimal isLandscape) {
		this.isLandscape = isLandscape;
	}




	/**
	 * @return the columnBreak
	 */
	public BigDecimal getColumnBreak() {
		return ColumnBreak;
	}




	/**
	 * @param columnBreak the columnBreak to set
	 */
	public void setColumnBreak(BigDecimal columnBreak) {
		ColumnBreak = columnBreak;
	}







	/**
	 * @return the rowCategoryID
	 */
	public BigDecimal getRowCategoryID() {
		return rowCategoryID;
	}




	/**
	 * @param rowCategoryID the rowCategoryID to set
	 */
	public void setRowCategoryID(BigDecimal rowCategoryID) {
		this.rowCategoryID = rowCategoryID;
	}




	/**
	 * @return the restrictionText
	 */
	public String getRestrictionText() {
		return restrictionText;
	}




	/**
	 * @param restrictionText the restrictionText to set
	 */
	public void setRestrictionText(String restrictionText) {
		this.restrictionText = restrictionText;
	}



	/**
	 * @return the fromUnitDecimals
	 */
	public BigDecimal getFromUnitDecimals() {
		return fromUnitDecimals;
	}




	/**
	 * @param fromUnitDecimals the fromUnitDecimals to set
	 */
	public void setFromUnitDecimals(BigDecimal fromUnitDecimals) {
		this.fromUnitDecimals = fromUnitDecimals;
	}




	/**
	 * @return the toUnitDecimals
	 */
	public BigDecimal getToUnitDecimals() {
		return toUnitDecimals;
	}




	/**
	 * @param toUnitDecimals the toUnitDecimals to set
	 */
	public void setToUnitDecimals(BigDecimal toUnitDecimals) {
		this.toUnitDecimals = toUnitDecimals;
	}




	/**
	 * @return the pulldownText
	 */
	public String getPulldownText() {
		return pulldownText;
	}




	/**
	 * @param pulldownText the pulldownText to set
	 */
	public void setPulldownText(String pulldownText) {
		this.pulldownText = pulldownText;
	}




	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SpecsAndDimensionBean [packageName=" + packageName
				+ ", regionName=" + regionName + ", vehicleName=" + vehicleName
				+ ", modelID=" + modelID + ", vehicleId=" + vehicleId
				+ ", vehicleYear=" + vehicleYear + ", divisionName="
				+ divisionName + ", imageName=" + imageName + ", optionalDesc="
				+ optionalDesc + ", regionID=" + regionID + ", localeCode="
				+ localeCode + ", isLandscape=" + isLandscape
				+ ", ColumnBreak=" + ColumnBreak + ", rowBoldDesc="
				+ rowBoldDesc + ", rowDesctiption1=" + rowDesctiption1
				+ ", fromUnit=" + fromUnit + ", toUnit=" + toUnit
				+ ", rowHeaderID=" + rowHeaderID + ", columnHeaderID="
				+ columnHeaderID + ", multiplier=" + multiplier + ", rowCode="
				+ rowCode + ", fromUnitDecimals=" + fromUnitDecimals
				+ ", toUnitDecimals=" + toUnitDecimals + ", rowCategoryID="
				+ rowCategoryID + ", restrictionText=" + restrictionText + "]";
	}




}
