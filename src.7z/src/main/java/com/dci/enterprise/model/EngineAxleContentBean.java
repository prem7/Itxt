package com.dci.enterprise.model;

import java.math.BigDecimal;

public class EngineAxleContentBean {
	
	
	
	private BigDecimal VehicleHasEngineID;
	private BigDecimal componentID;
	private String availableCodeName;
	private BigDecimal restrictionID;
	private BigDecimal componentSort;
	
	
	
	/**
	 * @return the vehicleHasEngineID
	 */
	public BigDecimal getVehicleHasEngineID() {
		return VehicleHasEngineID;
	}
	/**
	 * @param vehicleHasEngineID the vehicleHasEngineID to set
	 */
	public void setVehicleHasEngineID(BigDecimal vehicleHasEngineID) {
		VehicleHasEngineID = vehicleHasEngineID;
	}
	/**
	 * @return the componentID
	 */
	public BigDecimal getComponentID() {
		return componentID;
	}
	/**
	 * @param componentID the componentID to set
	 */
	public void setComponentID(BigDecimal componentID) {
		this.componentID = componentID;
	}
	/**
	 * @return the availableCodeName
	 */
	public String getAvailableCodeName() {
		return availableCodeName;
	}
	/**
	 * @param availableCodeName the availableCodeName to set
	 */
	public void setAvailableCodeName(String availableCodeName) {
		this.availableCodeName = availableCodeName;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the componentSort
	 */
	public BigDecimal getComponentSort() {
		return componentSort;
	}
	/**
	 * @param componentSort the componentSort to set
	 */
	public void setComponentSort(BigDecimal componentSort) {
		this.componentSort = componentSort;
	}


	
}
