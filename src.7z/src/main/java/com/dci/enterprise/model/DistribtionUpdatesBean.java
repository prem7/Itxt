package com.dci.enterprise.model;

import java.math.BigDecimal;
import java.util.HashMap;


public class DistribtionUpdatesBean {

	//table Headers
	private String packageName;
	private String regionName;
	private String vehicleName;
	private BigDecimal modelID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private String division;
	private String divisionName;
	private BigDecimal regionID;
	private BigDecimal localeCode;
	//table content
	private BigDecimal duDay;
	private BigDecimal duMonth;
	private BigDecimal duYear;
	private String duText;
	private BigDecimal distID;

	//availability Codes




	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}

	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}

	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}

	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}

	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}

	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}

	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}

	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}

	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}

	/**
	 * @return the division
	 */
	public String getDivision() {
		return division;
	}

	/**
	 * @param division the division to set
	 */
	public void setDivision(String division) {
		this.division = division;
	}

	/**
	 * @return the duDay
	 */
	public BigDecimal getDuDay() {
		return duDay;
	}

	/**
	 * @param duDay the duDay to set
	 */
	public void setDuDay(BigDecimal duDay) {
		this.duDay = duDay;
	}

	/**
	 * @return the duMonth
	 */
	public BigDecimal getDuMonth() {
		return duMonth;
	}

	/**
	 * @param duMonth the duMonth to set
	 */
	public void setDuMonth(BigDecimal duMonth) {
		this.duMonth = duMonth;
	}

	/**
	 * @return the duYear
	 */
	public BigDecimal getDuYear() {
		return duYear;
	}

	/**
	 * @param duYear the duYear to set
	 */
	public void setDuYear(BigDecimal duYear) {
		this.duYear = duYear;
	}

	/**
	 * @return the duText
	 */
	public String getDuText() {
		return duText;
	}

	/**
	 * @param duText the duText to set
	 */
	public void setDuText(String duText) {
		this.duText = duText;
	}

	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}

	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}

	/**
	 * @return the regionID
	 */
	public BigDecimal getRegionID() {
		return regionID;
	}

	/**
	 * @param regionID the regionID to set
	 */
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
	}

	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}

	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {

		this.localeCode = localeCode;
	}

	
	
	/**
	 * @return the distID
	 */
	public BigDecimal getDistID() {
		return distID;
	}

	/**
	 * @param distID the distID to set
	 */
	public void setDistID(BigDecimal distID) {
		this.distID = distID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DistribtionUpdatesBean [packageName=" + packageName
				+ ", regionName=" + regionName + ", vehicleName=" + vehicleName
				+ ", modelID=" + modelID + ", vehicleId=" + vehicleId
				+ ", vehicleYear=" + vehicleYear + ", division=" + division
				+ ", divisionName=" + divisionName + ", regionID=" + regionID
				+ ", localeCode=" + localeCode + ", duDay=" + duDay
				+ ", duMonth=" + duMonth + ", duYear=" + duYear + ", duText="
				+ duText + "]";
	}
	
	
	
	
}
