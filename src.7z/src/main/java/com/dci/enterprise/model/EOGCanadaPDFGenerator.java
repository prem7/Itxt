package com.dci.enterprise.model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dci.enterprise.dao.ColorAndTrimDAO;
import com.dci.enterprise.dao.DistributionUpdatesDAO;
import com.dci.enterprise.dao.EngineAxleDAO;
import com.dci.enterprise.dao.EqpGrpDAO;
import com.dci.enterprise.dao.InteriorEqpDAO;
import com.dci.enterprise.dao.ItextDistributionUpdatesPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextEngineAxlePDFGeneratorDAO;
import com.dci.enterprise.dao.ItextEquipGrpPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextExteriorPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextInteriorPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextRpoCodesPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextSpecsAndDimensionPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextStdEquipPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextTraileringSpecsPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextWheelsPDFGeneratorDAO;
import com.dci.enterprise.dao.ModelCoverPageDAO;
import com.dci.enterprise.dao.NewFeaturesCoverPageDAO;
import com.dci.enterprise.dao.RpoCodesDAO;
import com.dci.enterprise.dao.SpecsAndDimensionDAO;
import com.dci.enterprise.dao.StandardEqpDAO;
import com.dci.enterprise.dao.TraileringSpecsDAO;
import com.dci.enterprise.dao.WheelsAndRadiosDao;
import com.dci.general.utilities.UtilityDAO;
import com.dci.general.utilities.VehicleConstant;
import com.dci.jasper.reporter.ItextPDFGenerator_ModelCoverPage;
import com.dci.jasper.reporter.ItextPDFGenerator_NewFeatures;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;

public class EOGCanadaPDFGenerator {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static  void main(String[] args) {

		long startSystemTime = System.currentTimeMillis();
		List<String> list = new ArrayList<String>();
		Logger log = Logger.getLogger(EOGCanadaPDFGenerator.class.getName());
		//public List<ColorAndTrimBean> mainMethod(){
		//long Start = System.currentTimeMillis();
		log.info("Starting program");


		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");


		int lang = 1;
		if(getProperty("languageEnglish").equalsIgnoreCase("true")){
			generatePDFs(context, list,lang);
		}
		//Generate French PDFs

		if(getProperty("languageFrench").equalsIgnoreCase("true")){
			lang = 2;
			generatePDFs(context, list,lang);
		}
		//	System.out.println(" FindAll :"+ );
		context.close();
		
		long timeTakeninSeconds = ((System.currentTimeMillis()-startSystemTime))/1000;
		BigDecimal timeTakeninMinutes = new BigDecimal( (((System.currentTimeMillis()-startSystemTime))/1000)/60);
		

		System.err.print(" TIME TAKEN TO GENERATE PDFs -  "+timeTakeninMinutes +" Minutes");
		System.err.print(" OR "+timeTakeninSeconds +" Seconds");
		//return ;
		log.info("Exiting the program");

	}

	public static String getProperty(String property){

		String temp = null;
		Properties eProperties = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream("./EOG.properties");
			eProperties.load(input);
			temp = eProperties.getProperty(property);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return temp ;


	}
	public static void generatePDFs(ApplicationContext context, List<String> list,int lang) {			
		boolean isDomestic =false; 
		Properties eProperties = new Properties();
		InputStream input = null;
		UtilityDAO utilityDAO = (UtilityDAO)context.getBean("UtilityDAO");

		try {
			input = new FileInputStream("./EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String[] vehicleList = null;

		if(eProperties.getProperty("singlevehicleId")!=null && !eProperties.getProperty("singlevehicleId").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			vehicleList= new String[1];
			vehicleList[0] = eProperties.getProperty("singlevehicleId");
			System.out.println(eProperties.getProperty("singlevehicleId")+"  "+eProperties.getProperty("listVehicleIds")+"/testing");	

		}

		else
		{
			int test =	eProperties.getProperty("listVehicleIds").split(",").length;
			vehicleList = eProperties.getProperty("listVehicleIds").split(",");

			List<String> myList = new ArrayList<String>(Arrays.asList(vehicleList));

			System.out.println("Total vehicle List : " +myList);

		}


		if(eProperties.getProperty("generateChangedVehiclesOnly").equals("true")){


			vehicleList = utilityDAO.getVehicleItemsXML(1);
			List<String> myList = new ArrayList<String>(Arrays.asList(vehicleList));
			System.out.println("Generating Changed Vehicles only" );
			System.out.println("Total vehicle List : " +myList);
		}



		ColorAndTrimDAO colorAndTrimDAO = (ColorAndTrimDAO)context.getBean("ColorAndTrimDAO");
		StandardEqpDAO standardEqpDAO = (StandardEqpDAO)context.getBean("StandardEqpBeanDao");
		EqpGrpDAO eqpGrpDAO = (EqpGrpDAO)context.getBean("EqpGrpBeanDao");
		InteriorEqpDAO interiorEqpDAO = (InteriorEqpDAO) context.getBean("InteriorBeanDao");
		InteriorEqpDAO exteriorEqpDAO = (InteriorEqpDAO) context.getBean("ExteriorBeanDao");
		RpoCodesDAO rpoCodesDAO = (RpoCodesDAO) context.getBean("RpoCodesBeanDao");
		EngineAxleDAO engineAxleDAO = (EngineAxleDAO) context.getBean("EngineAxleDAO");
		TraileringSpecsDAO traileringSpecsDAO = (TraileringSpecsDAO) context.getBean("TraileringSpecsDAO");
		DistributionUpdatesDAO distributionUpdatesDAO = (DistributionUpdatesDAO) context.getBean("distributionUpdatesDAO");
		SpecsAndDimensionDAO specsAndDimensionDAO = (SpecsAndDimensionDAO) context.getBean("SpecsAndDimensionDAO");
		WheelsAndRadiosDao wheelsAndRadiosDao = (WheelsAndRadiosDao)context.getBean("WheelsAndRadiosDao");
		ModelCoverPageDAO modelCoverPageDAO = (ModelCoverPageDAO)context.getBean("CoverPageDao");
		NewFeaturesCoverPageDAO NewFeaturesDAO = (NewFeaturesCoverPageDAO)context.getBean("NewForYearDao");

		ItextTraileringSpecsPDFGeneratorDAO itextTraileringSpecsPDFGeneratorDAO =(ItextTraileringSpecsPDFGeneratorDAO)context.getBean("ItextPDFGenerator_TraileringSpecs");

		ItextPDFGeneratorDAO itextPDFGeneratorDAO = (ItextPDFGeneratorDAO)context.getBean("ItextGenerator");

		ItextStdEquipPDFGeneratorDAO itextStdEquipPDFGeneratorDAO = (ItextStdEquipPDFGeneratorDAO)context.getBean("ItextPDFGenerator_StdEqp");

		//	ItextStdEquipPDFGeneratorDAO itextEquipGroupPDFGeneratorDAO = (ItextStdEquipPDFGeneratorDAO)context.getBean("ItextPDFGenerator_EqpGroup");

		ItextEquipGrpPDFGeneratorDAO itextEquipGrpPDFGeneratorDAO = (ItextEquipGrpPDFGeneratorDAO)context.getBean("ItextPDFGenerator_EqpGroup");

		//	ItextStdEquipPDFGeneratorDAO itextEquipGroupAddlPDFGeneratorDAO = (ItextStdEquipPDFGeneratorDAO)context.getBean("ItextPDFGenerator_EqpGroupAddOptions");

		ItextEquipGrpPDFGeneratorDAO itextEquipAddPDFGeneratorDAO = (ItextEquipGrpPDFGeneratorDAO)context.getBean("ItextPDFGenerator_EqpGroupAddOptions");

		ItextStdEquipPDFGeneratorDAO itextPegStairStepDAO = (ItextStdEquipPDFGeneratorDAO)context.getBean("ItextPDFGenerator_PegStair");

		ItextInteriorPDFGeneratorDAO interiorPDFGeneratorDAO = (ItextInteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_Interior");

		ItextExteriorPDFGeneratorDAO exteriorPDFGeneratorDAO = (ItextExteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_Exterior");

		ItextInteriorPDFGeneratorDAO mechanicalPDFGeneratorDAO = (ItextInteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_Mech");

		ItextInteriorPDFGeneratorDAO seoShipPDFGeneratorDAO = (ItextInteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_SeoShip");

		ItextInteriorPDFGeneratorDAO onStarPDFGeneratorDAO = (ItextInteriorPDFGeneratorDAO)context.getBean("ItextPDFGenerator_OnStar");

		ItextRpoCodesPDFGeneratorDAO rpoCodesPDFGeneratorDAO = (ItextRpoCodesPDFGeneratorDAO)context.getBean("ItextPDFGenerator_RpoCodes");

		ItextDistributionUpdatesPDFGeneratorDAO distributionUpdatesPDFGeneratorDAO = (ItextDistributionUpdatesPDFGeneratorDAO)context.getBean("ItextPDFGenerator_DistUpdates");

		ItextSpecsAndDimensionPDFGeneratorDAO specsAndDimensionPDFGeneratorDAO =(ItextSpecsAndDimensionPDFGeneratorDAO)context.getBean("ItextPDFGenerator_SpecsAndDimension");

		ItextSpecsAndDimensionPDFGeneratorDAO dimensionPDFGeneratorDAO =(ItextSpecsAndDimensionPDFGeneratorDAO)context.getBean("ItextPDFGenerator_Dimension");

		ItextWheelsPDFGeneratorDAO itextWheelsPDFGeneratorDAO = (ItextWheelsPDFGeneratorDAO)context.getBean("ItextGenerator_wheels");

		itextWheelsPDFGeneratorDAO = (ItextWheelsPDFGeneratorDAO)context.getBean("ItextGenerator_wheels");

		ItextPDFGenerator_ModelCoverPage itextPDFGenerator_ModelCoverPageDAO = 
				(ItextPDFGenerator_ModelCoverPage)context.getBean("ItextGenerator_coverPage");
		
		ItextPDFGenerator_NewFeatures itextPDFGenerator_NewFeatures = (ItextPDFGenerator_NewFeatures)context.getBean("ItextPDFGenerator_NewFeatures");
		ItextEngineAxlePDFGeneratorDAO itextEngineAxlePDFGeneratorDAO = (ItextEngineAxlePDFGeneratorDAO)context.getBean("ItextPDFGenerator_EngineAxle");

		itextEngineAxlePDFGeneratorDAO = (ItextEngineAxlePDFGeneratorDAO)context.getBean("ItextPDFGenerator_EngineAxle");


		//		list = (specsAndDimensionDAO.getAVehicles());

		/*colorAndTrimDAO.setLangFrench(false);
				colorAndTrimDAO.setLangEnglish(true);
				colorAndTrimDAO.setPageType(OrderingInfoConstants.EXTERIOR);*/

		for (String vehicle : vehicleList) {
			
			try{
			if(lang ==1 || !(lang ==2 && utilityDAO.isDomestic(vehicle))){
				System.out.println("Current Vehicle - "+vehicle+" with lang = "+lang +" vehicle "+ (Arrays.asList(vehicleList).indexOf(vehicle)+1)+ " of "+vehicleList.length);
				//itextPDFGeneratorDAO.startRadioPDFGeneration(colorAndTrimDAO.getVehicleItemsXML(1, "1",vehicle));
				//	List<List<StandardEqpBean>>temp=	standardEqpDAO.getVehicleItemsXML(1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1);

				//--StandardEquipment 
				if (eProperties.getProperty("genStdEquip","").equals("true")){
					itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, lang), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText());
					
				}

				if (eProperties.getProperty("genColorTrim","").equals("true")){
					itextPDFGeneratorDAO.startColorAndTrimPDFGeneration(colorAndTrimDAO.getVehicleItemsXML(4, vehicle, lang),VehicleConstant.PRINTBOOKS);
				}

				//-- Equipment Groups -- 
				if (eProperties.getProperty("genEqGroups","").equals("true")){
					//TEMP	itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),standardEqpDAO.getRegOption());
					startEqpGroupWithAdd(standardEqpDAO, eqpGrpDAO, itextEquipGrpPDFGeneratorDAO, 
							itextEquipAddPDFGeneratorDAO, null, null, vehicle, true, false,lang,VehicleConstant.PRINTBOOKS);
				}

				// Additional Option XML -- 
				if (eProperties.getProperty("genEqGroupsWithAddlOptions","").equals("true")){
					startEqpGroupWithAdd(standardEqpDAO,eqpGrpDAO,
							itextEquipGrpPDFGeneratorDAO,itextEquipAddPDFGeneratorDAO, 
							null, null, vehicle, true, true,lang,VehicleConstant.PRINTBOOKS);
				}

				//NON USED REGULTORY OPTION	itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, "((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.regulatoryFlag = 1)", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText());

				//Radios
				if(standardEqpDAO.isRequired(VehicleConstant.RADIOS,vehicle)){
				if (eProperties.getProperty("genRadios","").equals("true")){
					itextWheelsPDFGeneratorDAO.startRadioPDFGeneration(VehicleConstant.RADIOS,wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,lang));
				}
				}
				//wheels
				if (eProperties.getProperty("genWheels","").equals("true")){
					itextWheelsPDFGeneratorDAO.startRadioPDFGeneration(VehicleConstant.WHEELS,wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.WHEELS,vehicle,lang));
				}

				//interiors
				if (eProperties.getProperty("genInterior","").equals("true")){
					interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle,lang), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
				}

				//Mechanical
				if (eProperties.getProperty("genMechanical","").equals("true")){
					mechanicalPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,3, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
				}

				//Seo Ship
				if (eProperties.getProperty("genSEOShipThru","").equals("true")){
					if(standardEqpDAO.isRequired(VehicleConstant.SEO_SHIP_PDF,vehicle)){
					seoShipPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,4, "sc.subcategorysorter ,oced.optionCodeSort ", " sc.subcategorysorter ,oced.optionCodeSort ", vehicle, lang), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
					}
				}

				//genOnStar
				if (eProperties.getProperty("genOnStar","").equals("true")){
					if(standardEqpDAO.isRequired(VehicleConstant.ONSTAR,vehicle)){
						onStarPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,5, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
					}

				}


				//Exteriors
				if (eProperties.getProperty("genExterior","").equals("true")){
					//itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText());

					exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang), exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),exteriorEqpDAO.getPackageDescText(),VehicleConstant.PRINTBOOKS);
				}

				//---- RPO CODES ---//
				if (eProperties.getProperty("genRPOCodes","").equals("true") && (standardEqpDAO.isRequired(VehicleConstant.RPO_CODES_PDF,vehicle))) {
					
					rpoCodesPDFGeneratorDAO.startRpoCodesPDFGeneration(rpoCodesDAO.getVehicleItemsXML(vehicle, lang));
				}

				//-- DISTUPDATES
				if (eProperties.getProperty("genDistUpdates","").equals("true")) {
					distributionUpdatesPDFGeneratorDAO.startDistUpdatePDFGeneration(distributionUpdatesDAO.getVehicleItemsXML(vehicle, lang));
				}

				//SpecsAndDimension
				//Specs
				if (eProperties.getProperty("genSpecs","").equals("true")) {
					if(standardEqpDAO.isRequired(VehicleConstant.SPECS_PDF,vehicle)){
					specsAndDimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 2,lang));
					}
					}

				//Dimension
				if (eProperties.getProperty("genDimen","").equals("true")) {
					if(standardEqpDAO.isRequired(VehicleConstant.DIM_PDF,vehicle))
					dimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 1,lang));
				}

				//EngineAxle
				if (eProperties.getProperty("genEngineAxle","").equals("true") ) {
					if(standardEqpDAO.isRequired(VehicleConstant.ENGINE_AXLE_PDF,vehicle))
					itextEngineAxlePDFGeneratorDAO.startSpecsAndDimPDFGeneration(engineAxleDAO.getVehicleItemsXML(vehicle, 1, lang));
				}

				//Trailering
				if (eProperties.getProperty("genTrailering","").equals("true")) {
					if(traileringSpecsDAO.isRequired(VehicleConstant.TRAILERING,vehicle)){
					itextTraileringSpecsPDFGeneratorDAO.startRadioPDFGeneration(traileringSpecsDAO.getVehicleItemsXML(1, vehicle, lang),null,null,0);
					}
					}


				if (eProperties.getProperty("genEqGroupsStair","").equals("true")) {
					//itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.POG,null);
					if(standardEqpDAO.isRequired(VehicleConstant.PEGSTAIRSTEP,vehicle)){

						itextPegStairStepDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, lang), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),standardEqpDAO.getRegOption());
					}

				}
				if(eProperties.getProperty("genNewFeatures","").equals("true"))
				{
					PdfWriter writer = null;
					Document document=null;
					document = new Document(PageSize.LETTER, 25, 20, 50, 100);
					document.setMargins(72,72, 75, 115);
					document.setMarginMirroringTopBottom(true);

					String location = null;
					String fileName =vehicle+"-"+"NewFeatures";
					if(lang==2){
						fileName+="_fr";
					}

					if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
					{
						location = eProperties.getProperty("pdfDefaultLocation");
					}
					try {
						writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));

					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (DocumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					document.open();
					//interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),document,writer);
					//exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),exteriorEqpDAO.getPackageDescText(),document,writer);
					//standard equip
					//	writer.setPageEvent(null);
					//	document.newPage();
					itextPDFGenerator_ModelCoverPageDAO.startRadioPDFGeneration(VehicleConstant.RADIOS,
							modelCoverPageDAO.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					
					document.newPage();
					writer.setPageEvent(null);
					if(standardEqpDAO.isRequired(VehicleConstant.NEWFEATURES_2018,vehicle)||standardEqpDAO.isRequired(VehicleConstant.NEWFEATURES_2019,vehicle)){
					itextPDFGenerator_NewFeatures.startRadioPDFGeneration(VehicleConstant.RADIOS,
							NewFeaturesDAO.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					}
					document.newPage();
					writer.setPageEvent(null);
					/*//Equipment Groups 
					startEqpGroupWithAdd(standardEqpDAO, 
							eqpGrpDAO, itextEquipGrpPDFGeneratorDAO,
							itextEquipAddPDFGeneratorDAO, document, writer, vehicle, false, false,lang,VehicleConstant.VEHICLE_PRINT);
					
					document.newPage();
					writer.setPageEvent(null);
					//interior
					interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang),
							interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
							interiorEqpDAO.getPackageDescText(),document, writer,VehicleConstant.VEHICLE_PRINT);
					writer.setPageEvent(null);
					//exterior
					document.newPage();
					exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang), 
							exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),
							exteriorEqpDAO.getPackageDescText(),document, writer,VehicleConstant.VEHICLE_PRINT);
					writer.setPageEvent(null);
					//mechanical
					document.newPage();
					mechanicalPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,3, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang), 
							interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
							interiorEqpDAO.getPackageDescText(),document, writer,VehicleConstant.VEHICLE_PRINT);
				//	writer.setPageEvent(null);
					//engine axle
//					writer.setPageEvent(null);
					if(standardEqpDAO.isRequired(VehicleConstant.SEO_SHIP_PDF,vehicle)){
						document.newPage();
						writer.setPageEvent(null);
						seoShipPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,4, "sc.subcategorysorter ,oced.optionCodeSort ", " sc.subcategorysorter ,oced.optionCodeSort ", vehicle,lang), 
								interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
								interiorEqpDAO.getPackageDescText(),  document, writer,VehicleConstant.VEHICLE_PRINT);
						writer.setPageEvent(null);
						}
					document.newPage();
				
					writer.setPageEvent(null);
					
					if(standardEqpDAO.isRequired(VehicleConstant.ONSTAR,vehicle)){
						document.newPage();
						onStarPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,5, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang),
								interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
								interiorEqpDAO.getPackageDescText(),VehicleConstant.VEHICLE_PRINT);
						onStarPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,5, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang),
								interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
								interiorEqpDAO.getPackageDescText(), document, writer, VehicleConstant.VEHICLE_PRINT);
					}
					
					document.newPage();
					writer.setPageEvent(null);
					//color and Trim
					//color and Trim
					itextPDFGeneratorDAO.startColorAndTrimPDFGeneration(colorAndTrimDAO.getVehicleItemsXML(4, vehicle, lang),
							document,writer,VehicleConstant.VEHICLE_PRINT);
				
					document.newPage();
					writer.setPageEvent(null);
					
					//engine axle
					if(standardEqpDAO.isRequired(VehicleConstant.ENGINE_AXLE_PDF,vehicle)){
					
					itextEngineAxlePDFGeneratorDAO.startSpecsAndDimPDFGeneration(engineAxleDAO.getVehicleItemsXML(vehicle, 1, lang),
							document,writer,VehicleConstant.VEHICLE_PRINT);
					}
					document.newPage();
					document.setPageSize(PageSize.LETTER);
					writer.setPageEvent(null);
					
						//dimensions
					if(standardEqpDAO.isRequired(VehicleConstant.DIM_PDF,vehicle)){
						document.newPage();
						writer.setPageEvent(null);
					dimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 1,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					document.newPage();
					writer.setPageEvent(null);
					}
					document.newPage();
					writer.setPageEvent(null);
					//specs
					if(standardEqpDAO.isRequired(VehicleConstant.SPECS_PDF,vehicle)){
					specsAndDimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 2,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					//writer.setPageEvent(null);
					document.newPage();
					//writer.setPageEvent(null);
					//	writer.setPageEvent(null);
					//trailering 
					if(standardEqpDAO.isRequired(VehicleConstant.TRAILERING_SPECS_PDF,vehicle)){
					itextTraileringSpecsPDFGeneratorDAO.startRadioPDFGeneration(traileringSpecsDAO.getVehicleItemsXML(1, vehicle, lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					//writer.setPageEvent(null);
					//rpo codes
					}
					}
					document.newPage();*/
					writer.setPageEvent(null);
					
					document.close();
				
				
				}
				
				}
				if(eProperties.getProperty("isPog","").equals("true"))
				{
					/*PdfWriter writer = null;
					Document document=null;
					document = new Document(PageSize.LETTER, 25, 20, 50, 100);
					document.setMargins(72,72, 75, 115);
					document.setMarginMirroringTopBottom(true);

					String location = null;
					String fileName =vehicle+"-"+"CoverPage";
					if(lang==2){
						fileName+="_fr";
					}

					if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
					{
						location = eProperties.getProperty("pdfDefaultLocation");
					}
					try {
						writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));

					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (DocumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					document.open();
					//interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),document,writer);
					//exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),exteriorEqpDAO.getPackageDescText(),document,writer);
					//standard equip
					//	writer.setPageEvent(null);
					//	document.newPage();
					
					document.newPage();
					writer.setPageEvent(null);
					itextPDFGenerator_ModelCoverPageDAO.startRadioPDFGeneration(VehicleConstant.RADIOS,
							modelCoverPageDAO.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					document.newPage();
					writer.setPageEvent(null);
					

					document.close();
				*/
					
					
						PdfWriter writer = null;
						Document document=null;
						document = new Document(PageSize.LETTER, 25, 20, 50, 100);
						document.setMargins(72,72, 75, 115);
						document.setMarginMirroringTopBottom(true);

						String location = null;
						String fileName =vehicle+"-"+"POG_fo";
						if(lang==2){
							fileName+="_fr";
						}

						if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
						{
							location = eProperties.getProperty("pdfDefaultLocation");
						}
						try {
							writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));

						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (DocumentException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						document.open();
						//interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),document,writer);
						//exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),exteriorEqpDAO.getPackageDescText(),document,writer);
						//standard equip
						//	writer.setPageEvent(null);
						//	document.newPage();
						
						document.newPage();
						writer.setPageEvent(null);
						///itextPDFGenerator_ModelCoverPageDAO.startRadioPDFGeneration(VehicleConstant.RADIOS,
							//	modelCoverPageDAO.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
						//document.newPage();
					//	writer.setPageEvent(null);
						itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, lang),
								standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),
								standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.VEHICLE_PRINT,null);
						//eq groups
						document.newPage();
							writer.setPageEvent(null);
							document.newPage();
					//	System.out.println(""+writer.getPageNumber());
						//	writer.setPageCount(100);
						startEqpGroupWithAdd(standardEqpDAO, 
								eqpGrpDAO, itextEquipGrpPDFGeneratorDAO,
								itextEquipAddPDFGeneratorDAO, document, writer, vehicle, false, true,lang,VehicleConstant.VEHICLE_PRINT);
						/*itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(
							standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1),
							standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),
							standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.VEHICLE_PRINT,null);*/
					//additional options
					writer.setPageEvent(null);
					document.newPage();
					/*itextEquipGroupAddlPDFGeneratorDAO.startStdEquipPDFGeneration(
							standardEqpDAO.getVehicleItemsXML(1, "((poc.availableCodeID = 2) OR (poc.availableCodeID = 10)) AND (oc.categoryid != 4) AND (oc.categoryid != 5)", " oced.optionCodeSort ", vehicle, 1), 
							standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),
							standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.VEHICLE_PRINT,null);*/
						 
						//engine axle
						writer.setPageEvent(null);
						document.newPage();
						//if(standardEqpDAO.isRequired(VehicleConstant.TRAILERING,vehicle)){
						itextEngineAxlePDFGeneratorDAO.startSpecsAndDimPDFGeneration(engineAxleDAO.getVehicleItemsXML(vehicle, 1, lang),
								document,writer,VehicleConstant.VEHICLE_PRINT);

						document.newPage();
						//}
						document.setPageSize(PageSize.LETTER);
						document.newPage();
						//color and Trim
						writer.setPageEvent(null);
						itextPDFGeneratorDAO.startColorAndTrimPDFGeneration(colorAndTrimDAO.getVehicleItemsXML(4, vehicle,lang),
								document,writer,VehicleConstant.VEHICLE_PRINT);

						document.setPageSize(PageSize.LETTER);
						document.newPage();
						
						writer.setPageEvent(null);
						
						
						//seo option
					/*	if(standardEqpDAO.isRequired(VehicleConstant.SEO_SHIP_PDF,vehicle)){
							seoShipPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,4, "sc.subcategorysorter ,oced.optionCodeSort ", " sc.subcategorysorter ,oced.optionCodeSort ", vehicle,lang), 
									interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
									interiorEqpDAO.getPackageDescText(),  document, writer,VehicleConstant.VEHICLE_PRINT);
							writer.setPageEvent(null);
							}
						
						
					
						//dimension
						document.setPageSize(PageSize.LETTER);
						document.newPage();					
						writer.setPageEvent(null);*/
					//	if(standardEqpDAO.isRequired(VehicleConstant.DIM_PDF,vehicle)){
						dimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 1,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
						document.newPage();
					//	}
						//specs
					//	if(standardEqpDAO.isRequired(VehicleConstant.SPECS_PDF,vehicle)){
						writer.setPageEvent(null);
						specsAndDimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 2,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					//	}
						//trailering
					/*	document.setPageSize(PageSize.LETTER);
						document.setMargins( 72,72, 75, 115);
						document.newPage();
						writer.setPageEvent(null);
					//	if(standardEqpDAO.isRequired(VehicleConstant.TRAILERING,vehicle)){
							writer.setPageEvent(null);
							itextTraileringSpecsPDFGeneratorDAO.startRadioPDFGeneration(traileringSpecsDAO.getVehicleItemsXML(1, vehicle,lang),
									document,writer,VehicleConstant.PRODUCTPORTFOLIO);
						//}
*/						
						document.close();
					
				
				}

				if(eProperties.getProperty("isPP","").equals("true"))
				{
					PdfWriter writer = null;
					Document document=null;
					document = new Document(PageSize.LETTER, 25, 20, 50, 100);
					document.setMargins(72,72, 75, 115);
					document.setMarginMirroringTopBottom(true);

					String location = null;
					String fileName =vehicle+"-"+"P_ProdFolio_fo";
					if(lang==2){
						fileName+="_fr";
					}

					if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
					{
						location = eProperties.getProperty("pdfDefaultLocation");
					}
					try {
						writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));

					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (DocumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					document.open();
					//interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),document,writer);
					//exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),exteriorEqpDAO.getPackageDescText(),document,writer);
					//standard equip
					itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, 
							" (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, lang), 
							standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),
							document,writer,VehicleConstant.PRODUCTPORTFOLIO,null);
					//eq groups
					//eq groups
					document.newPage();
					writer.setPageEvent(null);
					//TEMP		itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.PRODUCTPORTFOLIO,null);
					//additional options
					startEqpGroupWithAdd(standardEqpDAO,eqpGrpDAO,
							itextEquipGrpPDFGeneratorDAO,itextEquipAddPDFGeneratorDAO, 
							document, writer, vehicle, false, true,lang,VehicleConstant.PRODUCTPORTFOLIO);
					//TEMP		itextEquipGroupAddlPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, "((poc.availableCodeID = 2) OR (poc.availableCodeID = 10)) AND (oc.categoryid != 4) AND (oc.categoryid != 5)", " oced.optionCodeSort ", vehicle, 1), standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.PRODUCTPORTFOLIO,null);
					//eq groups
					if(standardEqpDAO.isRequired(VehicleConstant.ENGINE_AXLE_PDF,vehicle)){
					document.newPage();
					//engine axle
					writer.setPageEvent(null);
					itextEngineAxlePDFGeneratorDAO.startSpecsAndDimPDFGeneration(engineAxleDAO.getVehicleItemsXML(vehicle, 1, lang),
							document,writer,VehicleConstant.PRODUCTPORTFOLIO);
					//eq groups
					}
					document.setPageSize(PageSize.LETTER);
					document.setMargins( 72,72, 75, 115);
					document.newPage();
					writer.setPageEvent(null);
					//dimensions
					dimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 1,lang),
							document,writer,VehicleConstant.PRODUCTPORTFOLIO);
					//eq groups

					document.newPage();
					//specs
					writer.setPageEvent(null);
					specsAndDimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 2,lang),
							document,writer,VehicleConstant.PRODUCTPORTFOLIO);
					//eq groups
					document.setPageSize(PageSize.LETTER);
					document.setMargins( 72,72, 75, 115);
					document.newPage();
					writer.setPageEvent(null);
					if(standardEqpDAO.isRequired(VehicleConstant.TRAILERING,vehicle)){
						//trailering
						writer.setPageEvent(null);
						itextTraileringSpecsPDFGeneratorDAO.startRadioPDFGeneration(traileringSpecsDAO.getVehicleItemsXML(1, vehicle,lang),
								document,writer,VehicleConstant.PRODUCTPORTFOLIO);
					}
					document.close();
				}
				if(eProperties.getProperty("genModelCover","").equals("true"))
				{
				PdfWriter writer = null;
				Document document=null;
				document = new Document(PageSize.LETTER, 25, 20, 50, 100);
				document.setMargins(72,72, 75, 115);
				document.setMarginMirroringTopBottom(true);

				String location = null;
				String fileName =vehicle+"-"+"CoverPage";
				if(lang==2){
					fileName+="_fr";
				}

				if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
				{
					location = eProperties.getProperty("pdfDefaultLocation");
				}
				try {
					writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));

				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				document.open();
				//interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),document,writer);
				//exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),exteriorEqpDAO.getPackageDescText(),document,writer);
				//standard equip
				//	writer.setPageEvent(null);
				//	document.newPage();
				
				document.newPage();
				writer.setPageEvent(null);
				itextPDFGenerator_ModelCoverPageDAO.startRadioPDFGeneration(VehicleConstant.RADIOS,
						modelCoverPageDAO.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
				document.newPage();
				writer.setPageEvent(null);
				

				document.close();
			
			}

				if(eProperties.getProperty("genVehiclePrint","").equals("true"))
				{
					PdfWriter writer = null;
					Document document=null;
					document = new Document(PageSize.LETTER, 25, 20, 50, 100);
					document.setMargins(72,72, 75, 115);
					document.setMarginMirroringTopBottom(true);

					String location = null;
					String fileName =vehicle+"-"+"vehiclePrint_fo";
					if(lang==2){
						fileName+="_fr";
					}
				
					if(!standardEqpDAO.isDomesticORIPC(Integer.parseInt(vehicle))&&lang==2 || standardEqpDAO.isDomesticORIPC(Integer.parseInt(vehicle))&&lang==1 || !standardEqpDAO.isDomesticORIPC(Integer.parseInt(vehicle))){

					if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
					{
						location = eProperties.getProperty("pdfDefaultLocation");
					}
					try {
						writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));

					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (DocumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					document.open();
					//interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),interiorEqpDAO.getPackageDescText(),document,writer);
					//exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, 1), exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),exteriorEqpDAO.getPackageDescText(),document,writer);
					//standard equip
					itextStdEquipPDFGeneratorDAO.startStdEquipPDFGeneration(standardEqpDAO.getVehicleItemsXML(1, " (poc.availableCodeID = 1) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, lang),
							standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),
							standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.VEHICLE_PRINT,null);
					//eq groups
					document.newPage();
					writer.setPageEvent(null);
					
					/*TEMP		itextEquipGroupPDFGeneratorDAO.startStdEquipPDFGeneration(
						standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, 1),
						standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),
						standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.VEHICLE_PRINT,null);
				//additional options
				document.newPage();
				itextEquipGroupAddlPDFGeneratorDAO.startStdEquipPDFGeneration(
						standardEqpDAO.getVehicleItemsXML(1, "((poc.availableCodeID = 2) OR (poc.availableCodeID = 10)) AND (oc.categoryid != 4) AND (oc.categoryid != 5)", " oced.optionCodeSort ", vehicle, 1), 
						standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),
						standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.VEHICLE_PRINT,null);
					 */
					//additional option 
					if(standardEqpDAO.isRequired(VehicleConstant.EQP_GROUPS_PDF,vehicle)){
					startEqpGroupWithAdd(standardEqpDAO,eqpGrpDAO,
							itextEquipGrpPDFGeneratorDAO,itextEquipAddPDFGeneratorDAO, 
							document, writer, vehicle, false, true,lang,VehicleConstant.VEHICLE_PRINT);
					//writer.setPageEvent(null);
					//peg Stair
					//writer.setPageEvent(null);
					//interior
					}
					document.newPage();
					writer.setPageEvent(null);
					if(standardEqpDAO.isRequired(VehicleConstant.PEGSTAIRSTEP,vehicle)){
						document.newPage();
						itextPegStairStepDAO.startStdEquipPDFGeneration(
								//fix to match individual pdf
								//standardEqpDAO.getVehicleItemsXML(1, " ((((poc.availableCodeID = 5) ) AND ((oc.categoryid = 3) or (oc.categoryid = 2)  or (oc.categoryid = 1) ))  or (poc.availablecodeid=6 and oc.categoryid=2))", " oced.optionCodeSort ", vehicle, lang),
								standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, lang),
								standardEqpDAO.getAvaialableCode(),standardEqpDAO.getPackageList(),standardEqpDAO.getModelList(),
								standardEqpDAO.getPackageDescText(),document,writer,VehicleConstant.VEHICLE_PRINT,standardEqpDAO.getRegOption());
					}
					document.newPage();
					writer.setPageEvent(null);
					//interior
					document.newPage();
					interiorPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,2, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang),
							interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
							interiorEqpDAO.getPackageDescText(),document, writer,VehicleConstant.VEHICLE_PRINT);
					writer.setPageEvent(null);
					//exterior
					document.newPage();
					exteriorPDFGeneratorDAO.startExteriorPDFGeneration(exteriorEqpDAO.getVehicleItemsXML(5,1, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang), 
							exteriorEqpDAO.getAvaialableCode(),exteriorEqpDAO.getPackageList(),exteriorEqpDAO.getModelList(),
							exteriorEqpDAO.getPackageDescText(),document, writer,VehicleConstant.VEHICLE_PRINT);

					writer.setPageEvent(null);
					//mechanical
					document.newPage();
					mechanicalPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,3, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang), 
							interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
							interiorEqpDAO.getPackageDescText(),document, writer,VehicleConstant.VEHICLE_PRINT);
				//	writer.setPageEvent(null);
					//engine axle
					if(standardEqpDAO.isRequired(VehicleConstant.ENGINE_AXLE_PDF,vehicle)){
					document.newPage();
					itextEngineAxlePDFGeneratorDAO.startSpecsAndDimPDFGeneration(engineAxleDAO.getVehicleItemsXML(vehicle, 1, lang),
							document,writer,VehicleConstant.VEHICLE_PRINT);
					}
					document.newPage();
					document.setPageSize(PageSize.LETTER);
					writer.setPageEvent(null);
					//color and Trim
					itextPDFGeneratorDAO.startColorAndTrimPDFGeneration(colorAndTrimDAO.getVehicleItemsXML(4, vehicle, lang),
							document,writer,VehicleConstant.VEHICLE_PRINT);
					document.newPage();
					writer.setPageEvent(null);
					//seo 
					if(standardEqpDAO.isRequired(VehicleConstant.SEO_SHIP_PDF,vehicle)){
					seoShipPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,4, "sc.subcategorysorter ,oced.optionCodeSort ", " sc.subcategorysorter ,oced.optionCodeSort ", vehicle,lang), 
							interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
							interiorEqpDAO.getPackageDescText(),  document, writer,VehicleConstant.VEHICLE_PRINT);
					writer.setPageEvent(null);
					}
					//onstar
					if(standardEqpDAO.isRequired(VehicleConstant.ONSTAR,vehicle)){
						document.newPage();
						/*onStarPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,5, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang),
								interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
								interiorEqpDAO.getPackageDescText(),VehicleConstant.VEHICLE_PRINT);*/
						onStarPDFGeneratorDAO.startInteriorPDFGeneration(interiorEqpDAO.getVehicleItemsXML(5,5, "oced.optionCodeSort ", " oced.optionCodeSort ", vehicle, lang),
								interiorEqpDAO.getAvaialableCode(),interiorEqpDAO.getPackageList(),interiorEqpDAO.getModelList(),
								interiorEqpDAO.getPackageDescText(), document, writer, VehicleConstant.VEHICLE_PRINT);
					}
					writer.setPageEvent(null);
					//dimensions
					if(standardEqpDAO.isRequired(VehicleConstant.DIM_PDF,vehicle)){
					dimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 1,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					document.newPage();
					writer.setPageEvent(null);
					}
					
					//specs
					if(standardEqpDAO.isRequired(VehicleConstant.SPECS_PDF,vehicle)){
					specsAndDimensionPDFGeneratorDAO.startSpecsAndDimPDFGeneration(specsAndDimensionDAO.getVehicleItemsXML(vehicle, 2,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					//writer.setPageEvent(null);
					//wheels
					}
					document.newPage();
					document.setPageSize(PageSize.LETTER);
					if(standardEqpDAO.isRequired(VehicleConstant.WHEELS,vehicle)){
					itextWheelsPDFGeneratorDAO.startRadioPDFGeneration(VehicleConstant.WHEELS,
							wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.WHEELS,vehicle,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					
					}//	writer.setPageEvent(null);
					//radios
					document.newPage();
					if(standardEqpDAO.isRequired(VehicleConstant.RADIOS,vehicle)){
					itextWheelsPDFGeneratorDAO.startRadioPDFGeneration(VehicleConstant.RADIOS,
							wheelsAndRadiosDao.getVehicleItemsXML(VehicleConstant.RADIOS,vehicle,lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					}
					document.newPage();
						writer.setPageEvent(null);
					//trailering 
					if(standardEqpDAO.isRequired(VehicleConstant.TRAILERING_SPECS_PDF,vehicle)){
					itextTraileringSpecsPDFGeneratorDAO.startRadioPDFGeneration(traileringSpecsDAO.getVehicleItemsXML(1, vehicle, lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					//writer.setPageEvent(null);
					//rpo codes
					}
					document.newPage();
					if(standardEqpDAO.isRequired(VehicleConstant.RPO_CODES_PDF,vehicle)){
					rpoCodesPDFGeneratorDAO.startRpoCodesPDFGeneration(rpoCodesDAO.getVehicleItemsXML(vehicle, lang),document,writer,VehicleConstant.VEHICLE_PRINT);
					}
					//	writer.setPageEvent(null);
					document.newPage();
					//distupdate
					distributionUpdatesPDFGeneratorDAO.startDistUpdatePDFGeneration(distributionUpdatesDAO.getVehicleItemsXML(vehicle, lang),document,writer,VehicleConstant.VEHICLE_PRINT);

					document.close();
				}

			}
			}
		
			catch(Exception e){
				System.out.println(e);
				
			}
			
		}
		

	}




	public static void startEqpGroupWithAdd(StandardEqpDAO standardEqpDAO,
			EqpGrpDAO eqpGrpDAO, ItextEquipGrpPDFGeneratorDAO itextEquipGrpPDFGeneratorDAO,
			ItextEquipGrpPDFGeneratorDAO itextEquipAddPDFGeneratorDAO,Document document,
			PdfWriter writer, String vehicle,boolean isSingleRun, boolean isEqpGrpAdd, int lang,int type){
		Document doc = null;
		PdfWriter	wrt = null;
		if(isSingleRun){

			wrt = null;
			doc=null;
			doc = new Document(PageSize.LETTER, 25, 20, 50, 100);
			doc.setMargins(72,72, 75, 115);
			doc.setMarginMirroringTopBottom(true);
			doc.open();
			String pdfType = "";
			pdfType = "-oi_egrps_fo";
			if(isEqpGrpAdd)
			{
				type = VehicleConstant.VEHICLE_PRINT;
				pdfType = "-oi_egrps_addloptions_fo";
			}

			if(lang==2){
				pdfType+="_fr";
			}

			pdfType+=".pdf";
			try {
				wrt = PdfWriter.getInstance(doc, new FileOutputStream(getProperty("pdfDefaultLocation")+vehicle+pdfType));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			doc = document;
			wrt = writer;
		}
		Object[][] availablecode_EQP = standardEqpDAO.getVehicleItemsXML(1, " ((poc.availableCodeID = 5) OR (poc.availableCodeID = 6)) AND (oc.categoryid != 4) AND (oc.categoryid != 5) ", " oced.optionCodeSort ", vehicle, lang); 
		Object[][] eqp_obj=	 standardEqpDAO.getAvaialableCode();
		List<StdEqpHelper> temppacakgeDes= standardEqpDAO.getPackageDescText();
		Object[][] tempObj =  new Object[2][2];
		Object[][] availablecode_Add = null;
		Object[][] add_obj = null;
		List<Object> tempReg = null;
		List<StdEqpHelper> temppacakgeDesAdd = null;
		tempReg = standardEqpDAO.getRegOption();
		if(isEqpGrpAdd){

			availablecode_Add = standardEqpDAO.getVehicleItemsXML(1, "((poc.availableCodeID = 2) OR (poc.availableCodeID = 10)) AND (oc.categoryid != 4) AND (oc.categoryid != 5)", " oced.optionCodeSort ", vehicle, lang);
			add_obj=	 standardEqpDAO.getAvaialableCode();
			temppacakgeDesAdd= standardEqpDAO.getPackageDescText();
			tempReg = standardEqpDAO.getRegOption();

		}
		List<ArrayList<BigDecimal>> tempModelList = standardEqpDAO.getModelList();
		int pageCount = getpageCount(tempModelList);
		List<HashMap<BigDecimal,ArrayList<String>>> tempPackageList = standardEqpDAO.getPackageList();
		int currentPage = 1;
		for(int i=0;i<pageCount;i++){

			if((i<availablecode_EQP.length && availablecode_EQP[i][0]!=null && availablecode_EQP[i][1]!=null)){
				wrt.setPageEvent(null);
			//	doc.newPage();
				//doc.newPage();
				tempObj[0][0] = availablecode_EQP[i][0];
				tempObj[0][1] = availablecode_EQP[i][1];
				itextEquipGrpPDFGeneratorDAO.startStdEquipPDFGeneration(tempObj, eqp_obj,tempPackageList.get(i),tempModelList.get(i),temppacakgeDes,(i+1),currentPage,doc,wrt,type,tempReg,lang);
				doc.newPage();

				if(isEqpGrpAdd){
					wrt.setPageEvent(null);
				//	
					tempObj[0][0] = availablecode_Add[i][0];
					tempObj[0][1] = availablecode_Add[i][1];
					//additional options
					itextEquipAddPDFGeneratorDAO.startStdEquipPDFGeneration(tempObj, add_obj,tempPackageList.get(i),tempModelList.get(i),temppacakgeDesAdd,(i+1),currentPage,doc,wrt,type,tempReg,lang);
					doc.newPage();
				}
			}

		}
if(pageCount!=0){
		if(isSingleRun){
			doc.close();
		}
}
	}

	private static int getpageCount(List<ArrayList<BigDecimal>> tempModelList) {
		int count=0;
	for (ArrayList<BigDecimal> arrayList : tempModelList) {
		if(!arrayList.isEmpty())
			count ++;
	}
		return count;
	}
}




