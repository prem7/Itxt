package com.dci.enterprise.model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class EngineAxleBean {

	private BigDecimal rpoID;
	private BigDecimal EngineID;
	private String engineDesc;
	private BigDecimal restrictionID;
	private String engineRpo;
	private String EaSubCatText;
	private BigDecimal vehicleHasEngineID;
	private String eaCatText;
	
	
	
	
	private String regionName;
	private String vehicleName;
	private BigDecimal modelID;
	private BigDecimal vehicleId;
	private BigDecimal localeCode;
	private BigDecimal divisionID;
	private BigDecimal vehicleYear;
	private String divisionName;
	private String pageLabel;
	private BigDecimal columnBreak;
	private BigDecimal isLandscape;
	private Map<BigDecimal, String> restrictionList;
	
	
	
	/**
	 * @return the rpoID
	 */
	public BigDecimal getRpoID() {
		return rpoID;
	}
	/**
	 * @param rpoID the rpoID to set
	 */
	public void setRpoID(BigDecimal rpoID) {
		this.rpoID = rpoID;
	}
	/**
	 * @return the engineID
	 */
	public BigDecimal getEngineID() {
		return EngineID;
	}
	/**
	 * @param engineID the engineID to set
	 */
	public void setEngineID(BigDecimal engineID) {
		EngineID = engineID;
	}
	/**
	 * @return the engineDesc
	 */
	public String getEngineDesc() {
		return engineDesc;
	}
	/**
	 * @param engineDesc the engineDesc to set
	 */
	public void setEngineDesc(String engineDesc) {
		this.engineDesc = engineDesc;
	}
	/**
	 * @return the engineRpo
	 */
	public String getEngineRpo() {
		return engineRpo;
	}
	/**
	 * @param engineRpo the engineRpo to set
	 */
	public void setEngineRpo(String engineRpo) {
		this.engineRpo = engineRpo;
	}
	/**
	 * @return the eaSubCatText
	 */
	public String getEaSubCatText() {
		return EaSubCatText;
	}
	/**
	 * @param eaSubCatText the eaSubCatText to set
	 */
	public void setEaSubCatText(String eaSubCatText) {
		EaSubCatText = eaSubCatText;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}
	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}
	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}
	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}
	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}
	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}
	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}
	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	/**
	 * @return the restrictionList
	 */
	/**
	 * @return the restrictionList
	 */
	public Map<BigDecimal, String> getRestrictionList() {
		return restrictionList;
	}
	/**
	 * @param restrictionList the restrictionList to set
	 */
	public void setRestrictionList(Map<BigDecimal, String> restrictionList) {
		this.restrictionList = restrictionList;
	}
	/**
	 * @return the vehicleHasEngineID
	 */
	public BigDecimal getVehicleHasEngineID() {
		return vehicleHasEngineID;
	}
	/**
	 * @param vehicleHasEngineID the vehicleHasEngineID to set
	 */
	public void setVehicleHasEngineID(BigDecimal vehicleHasEngineID) {
		this.vehicleHasEngineID = vehicleHasEngineID;
	}
	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}
	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}
	/**
	 * @return the divisionID
	 */
	public BigDecimal getDivisionID() {
		return divisionID;
	}
	/**
	 * @param divisionID the divisionID to set
	 */
	public void setDivisionID(BigDecimal divisionID) {
		this.divisionID = divisionID;
	}
	/**
	 * @return the pageLabel
	 */
	public String getPageLabel() {
		return pageLabel;
	}
	/**
	 * @param pageLabel the pageLabel to set
	 */
	public void setPageLabel(String label) {
		this.pageLabel = label;
	}
	/**
	 * @return the columnBreak
	 */
	public BigDecimal getColumnBreak() {
		return columnBreak;
	}
	/**
	 * @param columnBreak the columnBreak to set
	 */
	public void setColumnBreak(BigDecimal columnBreak) {
		this.columnBreak = columnBreak;
	}
	/**
	 * @return the isLandscape
	 */
	public BigDecimal getIsLandscape() {
		return isLandscape;
	}
	/**
	 * @param isLandscape the isLandscape to set
	 */
	public void setIsLandscape(BigDecimal isLandscape) {
		this.isLandscape = isLandscape;
	}
	/**
	 * @return the eaCatText
	 */
	public String getEaCatText() {
		return eaCatText;
	}
	/**
	 * @param eaCatText the eaCatText to set
	 */
	public void setEaCatText(String eaCatText) {
		this.eaCatText = eaCatText;
	}
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}



}
