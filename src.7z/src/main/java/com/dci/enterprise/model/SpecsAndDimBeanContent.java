package com.dci.enterprise.model;

import java.math.BigDecimal;

public class SpecsAndDimBeanContent {

	private BigDecimal columnHeaderID;
	private BigDecimal rowHeaderID;
	private String cellValueNumber;
	private String cellValueNumberMetric;
	private String cellvalueString;



	/**
	 * @return the columnHeaderID
	 */
	public BigDecimal getColumnHeaderID() {
		return columnHeaderID;
	}
	/**
	 * @param columnHeaderID the columnHeaderID to set
	 */
	public void setColumnHeaderID(BigDecimal columnHeaderID) {
		this.columnHeaderID = columnHeaderID;
	}
	/**
	 * @return the rowHeaderID
	 */
	public BigDecimal getRowHeaderID() {
		return rowHeaderID;
	}
	/**
	 * @param rowHeaderID the rowHeaderID to set
	 */
	public void setRowHeaderID(BigDecimal rowHeaderID) {
		this.rowHeaderID = rowHeaderID;
	}
	/**
	 * @return the cellValueNumber
	 */
	public String getCellValueNumber() {
		return cellValueNumber;
	}
	/**
	 * @param cellValueNumber the cellValueNumber to set
	 */
	public void setCellValueNumber(String cellValueNumber) {
		this.cellValueNumber = cellValueNumber;
	}
	/**
	 * @return the cellValueNumberMetric
	 */
	public String getCellValueNumberMetric() {
		return cellValueNumberMetric;
	}
	/**
	 * @param cellValueNumberMetric the cellValueNumberMetric to set
	 */
	public void setCellValueNumberMetric(String cellValueNumberMetric) {
		this.cellValueNumberMetric = cellValueNumberMetric;
	}
	
	/**
	 * @return the cellvalueString
	 */
	public String getCellvalueString() {
		return cellvalueString;
	}
	/**
	 * @param cellvalueString the cellvalueString to set
	 */
	public void setCellvalueString(String cellvalueString) {
		this.cellvalueString = cellvalueString;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SpecsAndDimBeanContent [columnHeaderID=" + columnHeaderID
				+ ", rowHeaderID=" + rowHeaderID + ", cellValueNumber="
				+ cellValueNumber + ", cellValueNumberMetric="
				+ cellValueNumberMetric + "]";
	}
	

}
