package com.dci.enterprise.model;

import java.math.BigDecimal;

public class EngineAxleTableHeaders {



	private BigDecimal componentID;
	private BigDecimal rpoID;
	private String componentRPO;
	private String componentDesc1;
	private String componentDesc2;
	private String componentDesc3;
	private BigDecimal componentTypeID;
	private String componentTypeName;
	private BigDecimal restrictionID;
	private BigDecimal componentSort;



	/**
	 * 
	 * @return the componentID
	 */
	public BigDecimal getComponentID() {
		return componentID;
	}
	/**
	 * @param componentID the componentID to set
	 */
	public void setComponentID(BigDecimal componentID) {
		this.componentID = componentID;
	}
	/**
	 * @return the rpoID
	 */
	public BigDecimal getRpoID() {
		return rpoID;
	}
	/**
	 * @param rpoID the rpoID to set
	 */
	public void setRpoID(BigDecimal rpoID) {
		this.rpoID = rpoID;
	}
	/**
	 * @return the componentRPO
	 */
	public String getComponentRPO() {
		return componentRPO;
	}
	/**
	 * @param componentRPO the componentRPO to set
	 */
	public void setComponentRPO(String componentRPO) {
		this.componentRPO = componentRPO;
	}
	/**
	 * @return the componentDesc1
	 */
	public String getComponentDesc1() {
		return componentDesc1;
	}
	/**
	 * @param componentDesc1 the componentDesc1 to set
	 */
	public void setComponentDesc1(String componentDesc1) {
		this.componentDesc1 = componentDesc1;
	}
	/**
	 * @return the componentDesc2
	 */
	public String getComponentDesc2() {
		return componentDesc2;
	}
	/**
	 * @param componentDesc2 the componentDesc2 to set
	 */
	public void setComponentDesc2(String componentDesc2) {
		this.componentDesc2 = componentDesc2;
	}
	/**
	 * @return the componentDesc3
	 */
	public String getComponentDesc3() {
		return componentDesc3;
	}
	/**
	 * @param componentDesc3 the componentDesc3 to set
	 */
	public void setComponentDesc3(String componentDesc3) {
		this.componentDesc3 = componentDesc3;
	}
	/**
	 * @return the componentTypeID
	 */
	public BigDecimal getComponentTypeID() {
		return componentTypeID;
	}
	/**
	 * @param componentTypeID the componentTypeID to set
	 */
	public void setComponentTypeID(BigDecimal componentTypeID) {
		this.componentTypeID = componentTypeID;
	}
	/**
	 * @return the componentTypeName
	 */
	public String getComponentTypeName() {
		return componentTypeName;
	}
	/**
	 * @param componentTypeName the componentTypeName to set
	 */
	public void setComponentTypeName(String componentTypeName) {
		this.componentTypeName = componentTypeName;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the componentSort
	 */
	public BigDecimal getComponentSort() {
		return componentSort;
	}
	/**
	 * @param componentSort the componentSort to set
	 */
	public void setComponentSort(BigDecimal componentSort) {
		this.componentSort = componentSort;
	}





}
