package com.dci.enterprise.model;

import java.math.BigDecimal;

public class ColorTrimAvailabliltiy {
	
	
	private BigDecimal vehicleHasExteriorColorID;
	private BigDecimal availableCodeID;
	private String intColorName;
	private String availableCodeName;//extra coulmnsText
	private BigDecimal interiorID;	//ALIAS extracoulmnHeaderID
	private BigDecimal vehicleID;
	private BigDecimal intColorID;
	private String intColorCode;
	private String intSort;
	private BigDecimal restrictionID;
	private String avExtraText;
	private BigDecimal typeId;
	private boolean isExtraColumn;
	
	/**
	 * @return the vehicleHasExteriorColorID
	 */
	public BigDecimal getVehicleHasExteriorColorID() {
		return vehicleHasExteriorColorID;
	}
	/**
	 * @param vehicleHasExteriorColorID the vehicleHasExteriorColorID to set
	 */
	public void setVehicleHasExteriorColorID(BigDecimal vehicleHasExteriorColorID) {
		this.vehicleHasExteriorColorID = vehicleHasExteriorColorID;
	}
	/**
	 * @return the availableCodeID
	 */
	public BigDecimal getAvailableCodeID() {
		return availableCodeID;
	}
	/**
	 * @param availableCodeID the availableCodeID to set
	 */
	public void setAvailableCodeID(BigDecimal availableCodeID) {
		this.availableCodeID = availableCodeID;
	}
	/**
	 * @return the intColorName
	 */
	
	/**
	 * @return the availableCodeName
	 */
	public String getAvailableCodeName() {
		return availableCodeName;
	}
	/**
	 * @return the intColorName
	 */
	public String getIntColorName() {
		return intColorName;
	}
	/**
	 * @param intColorName the intColorName to set
	 */
	public void setIntColorName(String intColorName) {
		this.intColorName = intColorName;
	}
	/**
	 * @param availableCodeName the availableCodeName to set
	 */
	public void setAvailableCodeName(String availableCodeName) {
		this.availableCodeName = availableCodeName;
	}
	/**
	 * @return the interiorID
	 */
	public BigDecimal getInteriorID() {
		return interiorID;
	}
	/**
	 * @param interiorID the interiorID to set
	 */
	public void setInteriorID(BigDecimal interiorID) {
		this.interiorID = interiorID;
	}
	/**
	 * @return the vehicleID
	 */
	public BigDecimal getVehicleID() {
		return vehicleID;
	}
	/**
	 * @param vehicleID the vehicleID to set
	 */
	public void setVehicleID(BigDecimal vehicleID) {
		this.vehicleID = vehicleID;
	}
	/**
	 * @return the intColorID
	 */
	public BigDecimal getIntColorID() {
		return intColorID;
	}
	/**
	 * @param intColorID the intColorID to set
	 */
	public void setIntColorID(BigDecimal intColorID) {
		this.intColorID = intColorID;
	}
	/**
	 * @return the intColorCode
	 */
	public String getIntColorCode() {
		return intColorCode;
	}
	/**
	 * @param intColorCode the intColorCode to set
	 */
	public void setIntColorCode(String intColorCode) {
		this.intColorCode = intColorCode;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the intSort
	 */
	public String getIntSort() {
		return intSort;
	}
	/**
	 * @param intSort the intSort to set
	 */
	public void setIntSort(String intSort) {
		this.intSort = intSort;
	}
	/**
	 * @return the avExtraText
	 */
	public String getAvExtraText() {
		return avExtraText;
	}
	/**
	 * @param avExtraText the avExtraText to set
	 */
	public void setAvExtraText(String avExtraText) {
		this.avExtraText = avExtraText;
	}
	/**
	 * @return the typeId
	 */
	public BigDecimal getTypeId() {
		return typeId;
	}
	/**
	 * @param typeId the typeId to set
	 */
	public void setTypeId(BigDecimal typeId) {
		this.typeId = typeId;
	}
	/**
	 * @return the isExtraColumn
	 */
	public boolean isExtraColumn() {
		return isExtraColumn;
	}
	/**
	 * @param isExtraColumn the isExtraColumn to set
	 */
	public void setExtraColumn(boolean isExtraColumn) {
		this.isExtraColumn = isExtraColumn;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColorTrimAvailabliltiy [vehicleHasExteriorColorID="
				+ vehicleHasExteriorColorID + ", availableCodeID="
				+ availableCodeID + ", intColorName=" + intColorName
				+ ", availableCodeName=" + availableCodeName + ", interiorID="
				+ interiorID + ", vehicleID=" + vehicleID + ", intColorID="
				+ intColorID + ", intColorCode=" + intColorCode + ", intSort="
				+ intSort + ", restrictionID=" + restrictionID
				+ ", avExtraText=" + avExtraText + ", typeId=" + typeId
				+ ", isExtraColumn=" + isExtraColumn + "]";
	}

	
	

}
