package com.dci.enterprise.model;

import java.math.BigDecimal;

public class WheelsAndRadiosBean  {

	//header
	private String modelName;
	private String modelDesc;
	private String regionName;	
	private BigDecimal vActiveflag;
	private String divisionName;
	private String vehicleName;
	private BigDecimal divisionID;
	private BigDecimal vehicleYear;
	private BigDecimal vehicleID;
	private BigDecimal regionID;
	private BigDecimal localeCode;
	//content
	private BigDecimal imageID;
	private String imageName;
	private String imageCategoryDesc;
	private BigDecimal rpoID;
	private String rpoName;
	private String rpoDescBold;
	private String rpoDesc;
	private String extendedDesc;
	
	
	
	/**
	 * @return the imageID
	 */
	public BigDecimal getImageID() {
		return imageID;
	}
	/**
	 * @param imageID the imageID to set
	 */
	public void setImageID(BigDecimal imageID) {
		this.imageID = imageID;
	}
	/**
	 * @return the imageName
	 */
	public String getImageName() {
		return imageName;
	}
	/**
	 * @param imageName the imageName to set
	 */
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	/**
	 * @return the imageCategoryDesc
	 */
	public String getImageCategoryDesc() {
		return imageCategoryDesc;
	}
	/**
	 * @param imageCategoryDesc the imageCategoryDesc to set
	 */
	public void setImageCategoryDesc(String imageCategoryDesc) {
		this.imageCategoryDesc = imageCategoryDesc;
	}
	/**
	 * @return the rpoID
	 */
	public BigDecimal getRpoID() {
		return rpoID;
	}
	/**
	 * @param rpoID the rpoID to set
	 */
	public void setRpoID(BigDecimal rpoID) {
		this.rpoID = rpoID;
	}
	/**
	 * @return the rpoName
	 */
	public String getRpoName() {
		return rpoName;
	}
	/**
	 * @param rpoName the rpoName to set
	 */
	public void setRpoName(String rpoName) {
		this.rpoName = rpoName;
	}
	/**
	 * @return the rpoDescBold
	 */
	public String getRpoDescBold() {
		return rpoDescBold;
	}
	/**
	 * @param rpoDescBold the rpoDescBold to set
	 */
	public void setRpoDescBold(String rpoDescBold) {
		this.rpoDescBold = rpoDescBold;
	}
	/**
	 * @return the rpoDesc
	 */
	public String getRpoDesc() {
		return rpoDesc;
	}
	/**
	 * @param rpoDesc the rpoDesc to set
	 */
	public void setRpoDesc(String rpoDesc) {
		this.rpoDesc = rpoDesc;
	}
	/**
	 * @return the extendedDesc
	 */
	public String getExtendedDesc() {
		return extendedDesc;
	}
	/**
	 * @param extendedDesc the extendedDesc to set
	 */
	public void setExtendedDesc(String extendedDesc) {
		this.extendedDesc = extendedDesc;
	}
	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}
	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	/**
	 * @return the modelDesc
	 */
	public String getModelDesc() {
		return modelDesc;
	}
	/**
	 * @param modelDesc the modelDesc to set
	 */
	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the vActiveflag
	 */
	public BigDecimal getvActiveflag() {
		return vActiveflag;
	}
	/**
	 * @param vActiveflag the vActiveflag to set
	 */
	public void setvActiveflag(BigDecimal vActiveflag) {
		this.vActiveflag = vActiveflag;
	}
	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}
	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	/**
	 * @return the vehicleID
	 */
	public BigDecimal getVehicleID() {
		return vehicleID;
	}
	/**
	 * @param vehicleID the vehicleID to set
	 */
	public void setVehicleID(BigDecimal vehicleID) {
		this.vehicleID = vehicleID;
	}
	
	
	
	
	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}
	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}
	
	
	/**
	 * @return the divisionID
	 */
	public BigDecimal getDivisionID() {
		return divisionID;
	}
	/**
	 * @param divisionID the divisionID to set
	 */
	public void setDivisionID(BigDecimal divisionID) {
		this.divisionID = divisionID;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	
	/**
	 * @return the regionID
	 */
	public BigDecimal getRegionID() {
		return regionID;
	}
	/**
	 * @param regionID the regionID to set
	 */
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
		
	}
	
	
	
	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}
	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WheelsAndRadiosBean [modelName=" + modelName + ", modelDesc="
				+ modelDesc + ", regionName=" + regionName + ", vActiveflag="
				+ vActiveflag + ", divisionName=" + divisionName
				+ ", vehicleName=" + vehicleName + ", divisionID=" + divisionID
				+ ", vehicleYear=" + vehicleYear + ", vehicleID=" + vehicleID
				+ ", regionID=" + regionID + ", imageID=" + imageID
				+ ", imageName=" + imageName + ", imageCategoryDesc="
				+ imageCategoryDesc + ", rpoID=" + rpoID + ", rpoName="
				+ rpoName + ", rpoDescBold=" + rpoDescBold + ", rpoDesc="
				+ rpoDesc + ", extendedDesc=" + extendedDesc + "]";
	}

	
	

}
