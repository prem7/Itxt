package com.dci.enterprise.model;

import java.math.BigDecimal;

public class TraileringSpecsGCWRBean {

	
	private BigDecimal traileringHeaderID;
	private BigDecimal traileringGGCWRRatingsID;
	private BigDecimal rearAxleRatio;
	private String raRatioText;
	private BigDecimal restricionID;
	private BigDecimal workItemID;
	private BigDecimal GCWRValue;
	private BigDecimal engineSort;
	/**
	 * @return the traileringHeaderID
	 */
	public BigDecimal getTraileringHeaderID() {
		return traileringHeaderID;
	}
	/**
	 * @param traileringHeaderID the traileringHeaderID to set
	 */
	public void setTraileringHeaderID(BigDecimal traileringHeaderID) {
		this.traileringHeaderID = traileringHeaderID;
	}
	/**
	 * @return the traileringGGCWRRatingsID
	 */
	public BigDecimal getTraileringGGCWRRatingsID() {
		return traileringGGCWRRatingsID;
	}
	/**
	 * @param traileringGGCWRRatingsID the traileringGGCWRRatingsID to set
	 */
	public void setTraileringGGCWRRatingsID(BigDecimal traileringGGCWRRatingsID) {
		this.traileringGGCWRRatingsID = traileringGGCWRRatingsID;
	}
	/**
	 * @return the rearAxleRatio
	 */
	public BigDecimal getRearAxleRatio() {
		return rearAxleRatio;
	}
	/**
	 * @param rearAxleRatio the rearAxleRatio to set
	 */
	public void setRearAxleRatio(BigDecimal rearAxleRatio) {
		this.rearAxleRatio = rearAxleRatio;
	}
	/**
	 * @return the raRatioText
	 */
	public String getRaRatioText() {
		return raRatioText;
	}
	/**
	 * @param raRatioText the raRatioText to set
	 */
	public void setRaRatioText(String raRatioText) {
		this.raRatioText = raRatioText;
	}
	/**
	 * @return the restricionID
	 */
	public BigDecimal getRestricionID() {
		return restricionID;
	}
	/**
	 * @param restricionID the restricionID to set
	 */
	public void setRestricionID(BigDecimal restricionID) {
		this.restricionID = restricionID;
	}
	/**
	 * @return the workItemID
	 */
	public BigDecimal getWorkItemID() {
		return workItemID;
	}
	/**
	 * @param workItemID the workItemID to set
	 */
	public void setWorkItemID(BigDecimal workItemID) {
		this.workItemID = workItemID;
	}
	/**
	 * @return the gCWRValue
	 */
	public BigDecimal getGCWRValue() {
		return GCWRValue;
	}
	/**
	 * @param gCWRValue the gCWRValue to set
	 */
	public void setGCWRValue(BigDecimal gCWRValue) {
		GCWRValue = gCWRValue;
	}
	/**
	 * @return the engineSort
	 */
	public BigDecimal getEngineSort() {
		return engineSort;
	}
	/**
	 * @param engineSort the engineSort to set
	 */
	public void setEngineSort(BigDecimal engineSort) {
		this.engineSort = engineSort;
	}
	
	
}
