package com.dci.enterprise.model;

import java.util.List;

import java.math.BigDecimal;

public class ColorAndTrimAvailability_Combined {

	private String colorName;
	private BigDecimal colorID;
	private List<String> combinedAvailabilty;
	private BigDecimal vehicleHasExteriorColorID;
	
	
	
	
	public BigDecimal getColorID() {
		return colorID;
	}
	public void setColorID(BigDecimal colorID) {
		this.colorID = colorID;
	}
	
	public String getColorName() {
		return colorName;
	}
	public void setColorName(String colorName) {
		this.colorName = colorName;
	}
	
	public List<String> getCombinedAvailabilty() {
		return combinedAvailabilty;
	}
	public void setCombinedAvailabilty(List<String> combinedAvailabilty) {
		this.combinedAvailabilty = combinedAvailabilty;
	}
	public BigDecimal getVehicleHasExteriorColorID() {
		return vehicleHasExteriorColorID;
	}
	public void setVehicleHasExteriorColorID(BigDecimal vehicleHasExteriorColorID) {
		this.vehicleHasExteriorColorID = vehicleHasExteriorColorID;
	}
	
	
	
	
	
}
