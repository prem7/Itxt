package com.dci.enterprise.model;

import java.math.BigDecimal;
import java.util.HashMap;


public class RpoCodesBean {

	//table Headers
	private String packageName;
	private String regionName;
	private String vehicleName;
	private BigDecimal modelID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private String division;
	private String divisionName;
	private BigDecimal localeCode;
	private BigDecimal regionID;
	//table content
	private BigDecimal rpoId;
	private String rpoName;
	private String rpoDescBold;
	private String rpoDesc;
	

	//availability Codes


	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}

	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}

	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}

	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}

	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}

	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}

	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}

	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}

	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}

	/**
	 * @return the division
	 */
	public String getDivision() {
		return division;
	}

	/**
	 * @param division the division to set
	 */
	public void setDivision(String division) {
		this.division = division;
	}

	/**
	 * @return the rpoId
	 */
	public BigDecimal getRpoId() {
		return rpoId;
	}

	/**
	 * @param rpoId the rpoId to set
	 */
	public void setRpoId(BigDecimal rpoId) {
		this.rpoId = rpoId;
	}

	/**
	 * @return the rpoName
	 */
	public String getRpoName() {
		return rpoName;
	}

	/**
	 * @param rpoName the rpoName to set
	 */
	public void setRpoName(String rpoName) {
		this.rpoName = rpoName;
	}

	/**
	 * @return the rpoDescBold
	 */
	public String getRpoDescBold() {
		return rpoDescBold;
	}

	/**
	 * @param rpoDescBold the rpoDescBold to set
	 */
	public void setRpoDescBold(String rpoDescBold) {
		this.rpoDescBold = rpoDescBold;
	}

	/**
	 * @return the rpoDesc
	 */
	public String getRpoDesc() {
		return rpoDesc;
	}

	/**
	 * @param rpoDesc the rpoDesc to set
	 */
	public void setRpoDesc(String rpoDesc) {
		this.rpoDesc = rpoDesc;
	}



	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}

	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}

	
	
	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}

	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}

	
	
	/**
	 * @return the regionID
	 */
	public BigDecimal getRegionID() {
		return regionID;
	}

	/**
	 * @param regionID the regionID to set
	 */
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RpoCodesBean [packageName=" + packageName + ", regionName="
				+ regionName + ", vehicleName=" + vehicleName + ", modelID="
				+ modelID + ", vehicleId=" + vehicleId + ", vehicleYear="
				+ vehicleYear + ", division=" + division + ", divisionName="
				+ divisionName + ", localeCode=" + localeCode + ", regionID="
				+ regionID + ", rpoId=" + rpoId + ", rpoName=" + rpoName
				+ ", rpoDescBold=" + rpoDescBold + ", rpoDesc=" + rpoDesc + "]";
	}

	



}
