package com.dci.enterprise.model;

import java.math.BigDecimal;

public class ColorAndTrim_ExteriorBean {

	private String exteriorColorName;
	private BigDecimal vehicleHasExteriorColorID;
	private String exteriorColorCode;
	private String exteriorColorWanNumber;
	

	///Holder for Availability Code;

	/**
	 * @return the exteriorColorName
	 */
	public String getExteriorColorName() {
		return exteriorColorName;
	}
	/**
	 * @param exteriorColorName the exteriorColorName to set
	 */
	public void setExteriorColorName(String exteriorColorName) {
		this.exteriorColorName = exteriorColorName;
	}
	/**
	 * @return the vehicleHasExteriorColorID
	 */
	public BigDecimal getVehicleHasExteriorColorID() {
		return vehicleHasExteriorColorID;
	}
	/**
	 * @param bigDecimal the vehicleHasExteriorColorID to set
	 */
	public void setVehicleHasExteriorColorID(BigDecimal bigDecimal) {
		this.vehicleHasExteriorColorID = bigDecimal;
	}
	/**
	 * @return the exteriorColorCode
	 */
	public String getExteriorColorCode() {
		return exteriorColorCode;
	}
	/**
	 * @param exteriorColorCode the exteriorColorCode to set
	 */
	public void setExteriorColorCode(String exteriorColorCode) {
		this.exteriorColorCode = exteriorColorCode;
	}
	/**
	 * @return the exteriorColorWanNumber
	 */
	public String getExteriorColorWanNumber() {
		return exteriorColorWanNumber;
	}
	/**
	 * @param exteriorColorWanNumber the exteriorColorWanNumber to set
	 */
	public void setExteriorColorWanNumber(String exteriorColorWanNumber) {
		this.exteriorColorWanNumber = exteriorColorWanNumber;
	}






}
