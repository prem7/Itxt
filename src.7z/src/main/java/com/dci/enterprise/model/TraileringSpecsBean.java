package com.dci.enterprise.model;

import java.math.BigDecimal;

public class TraileringSpecsBean {

	private BigDecimal traileringHeaderID;
	private  BigDecimal pulldownItemID;
	private BigDecimal pageNumber;
	private String engineDescription;
	private BigDecimal engineID;
	private BigDecimal engineSort;
	private BigDecimal restrictionID;
	private String rpoName;
	
	private String packageName;
	private String regionName;
	private String vehicleName;
	private BigDecimal modelID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private String divisionName;
	private BigDecimal localeCode;
	private BigDecimal regionID;
	private BigDecimal divisionID;
	private String pulldownText;
	
	/**
	 * @return the traileringHeaderID
	 */
	public BigDecimal getTraileringHeaderID() {
		return traileringHeaderID;
	}
	/**
	 * @param traileringHeaderID the traileringHeaderID to set
	 */
	public void setTraileringHeaderID(BigDecimal traileringHeaderID) {
		this.traileringHeaderID = traileringHeaderID;
	}
	/**
	 * @return the pulldownItemID
	 */
	public BigDecimal getPulldownItemID() {
		return pulldownItemID;
	}
	/**
	 * @param pulldownItemID the pulldownItemID to set
	 */
	public void setPulldownItemID(BigDecimal pulldownItemID) {
		this.pulldownItemID = pulldownItemID;
	}
	/**
	 * @return the pageNumber
	 */

	/**
	 * @return the engineDescription
	 */
	public String getEngineDescription() {
		return engineDescription;
	}
	/**
	 * @return the pageNumber
	 */
	public BigDecimal getPageNumber() {
		return pageNumber;
	}
	/**
	 * @param pageNumber the pageNumber to set
	 */
	public void setPageNumber(BigDecimal pageNumber) {
		this.pageNumber = pageNumber;
	}
	/**
	 * @param engineDescription the engineDescription to set
	 */
	public void setEngineDescription(String engineDescription) {
		this.engineDescription = engineDescription;
	}
	/**
	 * @return the engineID
	 */
	public BigDecimal getEngineID() {
		return engineID;
	}
	/**
	 * @param engineID the engineID to set
	 */
	public void setEngineID(BigDecimal engineID) {
		this.engineID = engineID;
	}
	/**
	 * @return the engineSort
	 */
	public BigDecimal getEngineSort() {
		return engineSort;
	}
	/**
	 * @param engineSort the engineSort to set
	 */
	public void setEngineSort(BigDecimal engineSort) {
		this.engineSort = engineSort;
	}
	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}
	/**
	 * @return the rpoName
	 */
	public String getRpoName() {
		return rpoName;
	}
	/**
	 * @param rpoName the rpoName to set
	 */
	public void setRpoName(String rpoName) {
		this.rpoName = rpoName;
	}
	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}
	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}
	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}
	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}
	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}
	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}
	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}
	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}
	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}
	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}
	/**
	 * @return the regionID
	 */
	public BigDecimal getRegionID() {
		return regionID;
	}
	/**
	 * @param regionID the regionID to set
	 */
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
	}
	
	
	/**
	 * @return the divisionID
	 */
	public BigDecimal getDivisionID() {
		return divisionID;
	}
	/**
	 * @param divisionID the divisionID to set
	 */
	public void setDivisionID(BigDecimal divisionID) {
		this.divisionID = divisionID;
	}
	
	
	
	/**
	 * @return the pulldownText
	 */
	public String getPulldownText() {
		return pulldownText;
	}
	/**
	 * @param pulldownText the pulldownText to set
	 */
	public void setPulldownText(String pulldownText) {
		this.pulldownText = pulldownText;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TraileringSpecsBean [traileringHeaderID=" + traileringHeaderID
				+ ", pulldownItemID=" + pulldownItemID + ", pageNumber="
				+ pageNumber + ", engineDescription=" + engineDescription
				+ ", engineID=" + engineID + ", engineSort=" + engineSort
				+ ", restrictionID=" + restrictionID + ", rpoName=" + rpoName
				+ ", packageName=" + packageName + ", regionName=" + regionName
				+ ", vehicleName=" + vehicleName + ", modelID=" + modelID
				+ ", vehicleId=" + vehicleId + ", vehicleYear=" + vehicleYear
				+ ", divisionName=" + divisionName + ", localeCode="
				+ localeCode + ", regionID=" + regionID + "]";
	}

	
	
}
