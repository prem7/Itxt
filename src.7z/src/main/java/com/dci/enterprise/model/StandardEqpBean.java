package com.dci.enterprise.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class StandardEqpBean {

	//table Headers
	private String packageRestrtictionDesc;
	private String packageDescText;
	private String pageLabel;	
	private String packageName;
	private String regionName;
	private String vehicleName;
	private BigDecimal packageID;
	private BigDecimal modelID;
	private String divisionName;
	private BigDecimal divisionID;
	private BigDecimal vehicleId;
	private BigDecimal vehicleYear;
	private String division;
	private BigDecimal regionID;
	private BigDecimal localeCode;
	private BigDecimal columnBreak;
	private BigDecimal isLandscape;
	//table content
	private BigDecimal rpoId;
	private String rpoName;
	private String rpoDescBold;
	private String rpoDesc;
	private BigDecimal typeFlag;
	private String regylatoryFlag;
	private String extendedDesc;
	private BigDecimal packageDescID;
	private BigDecimal newOptionFLag;
	private String subCategoryName;
	private BigDecimal optionSort;
	//availability Codes
	private BigDecimal restrictionID;
	private String availableCode;
	private BigDecimal packageSort;
	private String rDescription;
	private BigDecimal availableCodeID;
	private HashMap< BigDecimal, String> packageNameMap;
	private HashMap< BigDecimal, String> packageDescMap;
	private BigDecimal pageNumber;
	private List<ArrayList<BigDecimal>> packageList;
	private int customSort;
	private ArrayList<BigDecimal> tempPackageList;
	



	/**
	 * @return the rpoName
	 */
	public String getRpoName() {
		return rpoName;
	}
	/**
	 * @param rpoName the rpoName to set
	 */
	public void setRpoName(String rpoName) {
		this.rpoName = rpoName;
	}
	/**
	 * @return the rpoDescBold
	 */
	public String getRpoDescBold() {
		return rpoDescBold;
	}
	/**
	 * @param rpoDescBold the rpoDescBold to set
	 */
	public void setRpoDescBold(String rpoDescBold) {
		this.rpoDescBold = rpoDescBold;
	}
	/**
	 * @return the rpoDesc
	 */
	public String getRpoDesc() {
		return rpoDesc;
	}
	/**
	 * @param rpoDesc the rpoDesc to set
	 */
	public void setRpoDesc(String rpoDesc) {
		this.rpoDesc = rpoDesc;
	}

	/**
	 * @return the exteriorColorName
	 */

	/**
	 * @return the rpoId
	 */
	public BigDecimal getRpoId() {
		return rpoId;
	}
	/**
	 * @param rpoId the rpoId to set
	 */
	public void setRpoId(BigDecimal rpoId) {
		this.rpoId = rpoId;
	}

	/**
	 * @return the typeFlag
	 */
	public BigDecimal getTypeFlag() {
		return typeFlag;
	}
	/**
	 * @param typeFlag the typeFlag to set
	 */
	public void setTypeFlag(BigDecimal typeFlag) {
		this.typeFlag = typeFlag;
	}
	/**
	 * @return the regylatoryFlag
	 */
	public String getRegylatoryFlag() {
		return regylatoryFlag;
	}
	/**
	 * @param regylatoryFlag the regylatoryFlag to set
	 */
	public void setRegylatoryFlag(String regylatoryFlag) {
		this.regylatoryFlag = regylatoryFlag;
	}
	/**
	 * @return the extendedDesc
	 */
	public String getExtendedDesc() {
		return extendedDesc;
	}
	/**
	 * @param extendedDesc the extendedDesc to set
	 */
	public void setExtendedDesc(String extendedDesc) {
		this.extendedDesc = extendedDesc;
	}
	/**
	 * @return the packageRestrtictionDesc
	 */
	public String getPackageRestrtictionDesc() {
		return packageRestrtictionDesc;
	}
	/**
	 * @param packageRestrtictionDesc the packageRestrtictionDesc to set
	 */
	public void setPackageRestrtictionDesc(String packageRestrtictionDesc) {
		this.packageRestrtictionDesc = packageRestrtictionDesc;
	}
	/**
	 * @return the packageDescText
	 */
	public String getPacakgeDescText() {
		return packageDescText;
	}
	/**
	 * @param packageDescText the packageDescText to set
	 */
	public void setPacakgeDescText(String pacakgeDescText) {
		this.packageDescText = pacakgeDescText;
	}
	/**
	 * @return the pageLabel
	 */
	public String getPageLabel() {
		return pageLabel;
	}
	/**
	 * @param pageLabel the pageLabel to set
	 */
	public void setPageLabel(String pageLabel) {
		this.pageLabel = pageLabel;
	}
	/**
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}
	/**
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	/**
	 * @return the availableCode
	 */
	public String getAvailableCode() {
		return availableCode;
	}
	/**
	 * @param availableCode the availableCode to set
	 */
	public void setAvailableCode(String availableCode) {
		this.availableCode = availableCode;
	}



	/**
	 * @return the packageSort
	 */
	public BigDecimal getPackageSort() {
		return packageSort;
	}
	/**
	 * @param packageSort the packageSort to set
	 */
	public void setPackageSort(BigDecimal packageSort) {
		this.packageSort = packageSort;
	}
	/**
	 * @return the rDescription
	 */
	public String getrDescription() {
		return rDescription;
	}
	/**
	 * @param rDescription the rDescription to set
	 */
	public void setrDescription(String rDescription) {
		this.rDescription = rDescription;
	}
	/**
	 * @return the availableCodeID
	 */
	public BigDecimal getAvailableCodeID() {
		return availableCodeID;
	}
	/**
	 * @param availableCodeID the availableCodeID to set
	 */
	public void setAvailableCodeID(BigDecimal availableCodeID) {
		this.availableCodeID = availableCodeID;
	}



	/**
	 * @return the packageDescText
	 */
	public String getPackageDescText() {
		return packageDescText;
	}
	/**
	 * @param packageDescText the packageDescText to set
	 */
	public void setPackageDescText(String packageDescText) {
		this.packageDescText = packageDescText;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the vehicleName
	 */
	public String getVehicleName() {
		return vehicleName;
	}
	/**
	 * @param vehicleName the vehicleName to set
	 */
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	/**
	 * @return the modelID
	 */
	public BigDecimal getModelID() {
		return modelID;
	}
	/**
	 * @param modelID the modelID to set
	 */
	public void setModelID(BigDecimal modelID) {
		this.modelID = modelID;
	}



	/**
	 * @return the packageNameMap
	 */
	public HashMap<BigDecimal, String> getPackageNameMap() {
		return packageNameMap;
	}
	/**
	 * @param packageNameMap the packageNameMap to set
	 */
	public void setPackageNameMap(HashMap<BigDecimal, String> packageNameMap) {
		this.packageNameMap = packageNameMap;
	}
	/**
	 * @return the packageDescMap
	 */
	public HashMap<BigDecimal, String> getPackageDescMap() {
		return packageDescMap;
	}
	/**
	 * @param packageDescMap the packageDescMap to set
	 */
	public void setPackageDescMap(HashMap<BigDecimal, String> packageDescMap) {
		this.packageDescMap = packageDescMap;
	}




	/**
	 * @return the vehicleYear
	 */
	public BigDecimal getVehicleYear() {
		return vehicleYear;
	}
	/**
	 * @param vehicleYear the vehicleYear to set
	 */
	public void setVehicleYear(BigDecimal vehicleYear) {
		this.vehicleYear = vehicleYear;
	}
	/**
	 * @return the vehicleId
	 */
	public BigDecimal getVehicleId() {
		return vehicleId;
	}
	/**
	 * @param vehicleId the vehicleId to set
	 */
	public void setVehicleId(BigDecimal vehicleId) {
		this.vehicleId = vehicleId;
	}
	/**
	 * @return the pageNumber
	 */
	public BigDecimal getPageNumber() {
		return pageNumber;
	}
	/**
	 * @param pageNumber the pageNumber to set
	 */
	public void setPageNumber(BigDecimal pageNumber) {
		this.pageNumber = pageNumber;
	}



	/**
	 * @return the division
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division the division to set
	 */
	public void setDivision(String division) {
		this.division = division;
	}

	/**
	 * @return the divisionName
	 */
	public String getDivisionName() {
		return divisionName;
	}
	/**
	 * @param divisionName the divisionName to set
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}



	/**
	 * @return the restrictionID
	 */
	public BigDecimal getRestrictionID() {
		return restrictionID;
	}
	/**
	 * @param restrictionID the restrictionID to set
	 */
	public void setRestrictionID(BigDecimal restrictionID) {
		this.restrictionID = restrictionID;
	}


	/**
	 * @return the divisionID
	 */
	public BigDecimal getDivisionID() {
		return divisionID;
	}
	/**
	 * @param divisionID the divisionID to set
	 */
	public void setDivisionID(BigDecimal divisionID) {
		this.divisionID = divisionID;
	}




	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */

	/**
	 * @return the regionID
	 */
	public BigDecimal getRegionID() {
		return regionID;
	}
	/**
	 * @param regionID the regionID to set
	 */
	public void setRegionID(BigDecimal regionID) {
		this.regionID = regionID;
	}
	/**
	 * @return the localeCode
	 */
	public BigDecimal getLocaleCode() {
		return localeCode;
	}
	/**
	 * @param localeCode the localeCode to set
	 */
	public void setLocaleCode(BigDecimal localeCode) {
		this.localeCode = localeCode;
	}

	/**
	 * @return the packageID
	 */
	public BigDecimal getPackageID() {
		return packageID;
	}
	/**
	 * @param packageID the packageID to set
	 */
	public void setPackageID(BigDecimal packageID) {
		this.packageID = packageID;
	}




	/**
	 * @return the packageDescID
	 */
	public BigDecimal getPackageDescID() {
		return packageDescID;
	}
	/**
	 * @param packageDescID the packageDescID to set
	 */
	public void setPackageDescID(BigDecimal packageDescID) {
		this.packageDescID = packageDescID;
	}



	/**
	 * @return the columnBreak
	 */
	public BigDecimal getColumnBreak() {
		return columnBreak;
	}
	/**
	 * @param columnBreak the columnBreak to set
	 */
	public void setColumnBreak(BigDecimal columnBreak) {
		this.columnBreak = columnBreak;
	}


	/**
	 * @return the isLandscape
	 */
	public BigDecimal getIsLandscape() {
		return isLandscape;
	}
	/**
	 * @param isLandscape the isLandscape to set
	 */
	public void setIsLandscape(BigDecimal isLandscape) {
		this.isLandscape = isLandscape;
	}





	/**
	 * @return the packageList
	 */
	public List<ArrayList<BigDecimal>> getPackageList() {
		return packageList;
	}
	/**
	 * @param packageList the packageList to set
	 */
	public void setPackageList(List<ArrayList<BigDecimal>> packageList) {
		this.packageList = packageList;
	}
	
	
	/**
	 * @return the subCategoryName
	 */
	public String getSubCategoryName() {
		return subCategoryName;
	}
	/**
	 * @param subCategoryName the subCategoryName to set
	 */
	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
	/**
	 * @return the newOptionFLag
	 */
	public BigDecimal getNewOptionFLag() {
		return newOptionFLag;
	}
	
	
	/**
	 * @return the customSort
	 */
	public int getCustomSort() {
		return customSort;
	}
	/**
	 * @param customSort the customSort to set
	 */
	public void setCustomSort(int customSort) {
		this.customSort = customSort;
	}
	
	
	/**
	 * @return the tempPackageList
	 */
	public ArrayList<BigDecimal> getTempPackageList() {
		return tempPackageList;
	}
	/**
	 * @param tempPackageList the tempPackageList to set
	 */
	public void setTempPackageList(ArrayList<BigDecimal> tempPackageList) {
		this.tempPackageList = tempPackageList;
	}
	/**
	 * @param newOptionFLag the newOptionFLag to set
	 */
	public void setNewOptionFLag(BigDecimal newOptionFLag) {
		this.newOptionFLag = newOptionFLag;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "StandardEqpBean [rpoId=" + rpoId + ", rpoName=" + rpoName+ ",packageRestrtictionDesc="+customSort +" packageRestrtictionDesc="
				+ packageRestrtictionDesc + ", packageDescText="
				+ packageDescText + ", pageLabel=" + pageLabel
				+ ", packageName=" + packageName + ", regionName=" + regionName
				+ ", vehicleName=" + vehicleName + ", packageID=" + packageID
				+ ", modelID=" + modelID + ", divisionName=" + divisionName
				+ ", divisionID=" + divisionID + ", vehicleId=" + vehicleId
				+ ", vehicleYear=" + vehicleYear + ", division=" + division
				+ ", regionID=" + regionID + ", localeCode=" + localeCode
				+ ", rpoId=" + rpoId + ", rpoName=" + rpoName
				+ ", rpoDescBold=" + rpoDescBold + ", rpoDesc=" + rpoDesc
				+ ", typeFlag=" + typeFlag + ", regylatoryFlag="
				+ regylatoryFlag + ", extendedDesc=" + extendedDesc
				+ ", restrictionID=" + restrictionID + ", availableCode="
				+ availableCode + ", packageSort=" + packageSort
				+ ", rDescription=" + rDescription + ", availableCodeID="
				+ availableCodeID + ", packageNameMap=" + packageNameMap
				+ ", packageDescMap=" + packageDescMap + ", pageNumber="
				+ pageNumber + "]";
	}
	public BigDecimal getOptionSort() {
		return optionSort;
	}
	public void setOptionSort(BigDecimal optionSort) {
		this.optionSort = optionSort;
	}




}
