package com.dci.jasper.reporter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import com.dci.enterprise.dao.ItextWheelsPDFGeneratorDAO;
import com.dci.enterprise.model.WheelsAndRadiosBean;
import com.dci.extrafunc.PropertyHelper;
import com.dci.general.utilities.VehicleConstant;
import com.dci.jasper.reporter.ItextPDFGenerator_EqpGrp.HeaderAndFooter;
import com.google.common.base.CaseFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class ItextPDFGenerator_WheelsAndRadios extends PdfPageEventHelper implements ItextWheelsPDFGeneratorDAO {
	private static List<WheelsAndRadiosBean> vehicleItemsXML = null;
	private static int subCategoryID;

	public static int pdfType;

	public void createPdf(int subCategoryID, List<WheelsAndRadiosBean> vehicleItemsXML, Document document, PdfWriter writer, int pdfType)
			throws IOException, DocumentException {
		this.subCategoryID = subCategoryID;
		this.pdfType = pdfType;
		this.vehicleItemsXML = (List<WheelsAndRadiosBean>)vehicleItemsXML;
		
		
		if(vehicleItemsXML!=null && !vehicleItemsXML.isEmpty()){
		if(pdfType==0){
		 document = new Document();
		document = new Document(PageSize.LETTER, 25, 20, 100, 150);
		document.setMargins(72,72, 75, 115);
		document.setMarginMirroringTopBottom(true);
			String fileName = vehicleItemsXML.get(0).getVehicleID()+"-"+"wheels_fo";
			
			if(subCategoryID==VehicleConstant.RADIOS){
				fileName = vehicleItemsXML.get(0).getVehicleID()+"-"+"radios_fo";
			}
			
			if(vehicleItemsXML.get(0).getRegionID().intValueExact()==14 && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
				fileName+="_fr";
			}
			PropertyHelper propertyHelper = new PropertyHelper();
			String location = propertyHelper.getProperty("pdfDefaultLocation");
		 writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));
		}
		
		writer.setPageEmpty(false);
		writer.setPageEvent(null);
		writer.setPageEvent(new HeaderAndFooter(""));
		// step 1
		document.open();
		// step 4
		//	PdfPTable headerTable = createHeader(vehicleItemsXML);
		PdfPTable table = createTable(subCategoryID,vehicleItemsXML);
		//PdfPTable footer = createFooter(writer);

		//	document.add(headerTable);
		document.add(table);
		//document.add(footer);

		if(pdfType==0)
		{

			onCloseDocument(writer, document);
			// step 5
			document.close();
		}
		
		}
	}


	public static PdfPTable createTable(int subCategoryID,List<WheelsAndRadiosBean> vehicleItemsXML) throws DocumentException {
		vehicleItemsXML = (List<WheelsAndRadiosBean>)vehicleItemsXML;
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);
		PdfPTable table1 = null;
		PdfPTable table3;
		PdfPTable table2;
		table.setTotalWidth(475);
		table.setLockedWidth(true);
		table.setSplitLate(false);
		PdfPCell cell;
		com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldFont =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD,BaseColor.WHITE);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.NORMAL,BaseColor.BLACK);

		table1 = new PdfPTable(2);
		table1.setTotalWidth(475);
		table1.setWidths(new int[]{199, 276});
		String frExten = "";
		if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
			frExten="_fr";
		}

		for (Iterator iterator = vehicleItemsXML.iterator(); iterator.hasNext();) {
			WheelsAndRadiosBean wheelsAndRadiosBean = (WheelsAndRadiosBean) iterator.next();
			
			Image image = null;
			PropertyHelper propertyHelper = new PropertyHelper();
			String imageloc = propertyHelper.getProperty("ImagesLocation");
			try {
				if(subCategoryID==VehicleConstant.RADIOS){
					image = Image.getInstance(new String(imageloc+"//radios//00-noradioimage"+frExten+".jpg"));

					if(!wheelsAndRadiosBean.getImageName().equals("null"))
					{
						image = Image.getInstance(new String(imageloc+"//radios//"+wheelsAndRadiosBean.getImageName()));
						image.scalePercent(80f);
						image.setAlignment(Element.ALIGN_CENTER);
					}
					else
					{
						image = Image.getInstance(new String(imageloc+"//radios//radios"+frExten+".jpg"));
						image.scalePercent(90f);
						image.setAlignment(Element.ALIGN_CENTER);
					}

				}
				else{
					image = Image.getInstance(new String(imageloc+"//wheels//01-nowheelavailable"+frExten+".jpg"));

					if(!wheelsAndRadiosBean.getImageName().equals("null"))
					{
						image = Image.getInstance(new String(imageloc+"//wheels//"+wheelsAndRadiosBean.getImageName()));
						image.scalePercent(100f);
						image.setAlignment(Element.ALIGN_CENTER);
					}
					else
					{
						image = Image.getInstance(new String(imageloc+"//wheels//wheels"+frExten+".jpg"));
						image.scalePercent(100f);
						image.setAlignment(Element.ALIGN_CENTER);
					}
				}} catch (MalformedURLException e) {
					e.printStackTrace();
				} catch (IOException e) {
					//image.scalePercent(100f);
					//image.setAlignment(Element.ALIGN_CENTER);

				}

			cell = new PdfPCell();

			cell.addElement(image);
			insertImage(table1,cell, Element.ALIGN_CENTER, 1, tableHeader1);

			insertCell(table1, wheelsAndRadiosBean.getRpoName()+"\n",wheelsAndRadiosBean.getRpoDescBold(),wheelsAndRadiosBean.getRpoDesc()+wheelsAndRadiosBean.getExtendedDesc(), Element.ALIGN_LEFT, 0, tableHeader1,BaseColor.WHITE);		

		}

		table2 = new PdfPTable(1);
		table2.setTotalWidth(475);

		cell = new PdfPCell();
		cell.setPaddingBottom(15);
		cell.setBorder(Rectangle.NO_BORDER);
		table2.addCell(cell);
		table.addCell(table1);

		return table;
	}
	public String getLocation()
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String location = null;
		if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			location = eProperties.getProperty("pdfDefaultLocation");
		}
		return location;
	}
	
	
	

	private static void insertImage(PdfPTable table, PdfPCell cell,
			int align, int i, Font tableHeader1) {
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setBorderWidth(0.75f);
		//add the call to the table
		table.addCell(cell);
	}


	public void startRadioPDFGeneration(int subCategoryID, List<WheelsAndRadiosBean> list) {

		try {
			new ItextPDFGenerator_WheelsAndRadios().createPdf(subCategoryID,list,null,null,0 );
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}


	}

	public static void insertCell(PdfPTable table,String text1, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		if(text1!=null){
			para.add(new Phrase(text1, font));
		}
		para.add(new Phrase(text, boldContentFont));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, font));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3f);
		cell.setPaddingTop(30f);
		cell.setPaddingLeft(8f);
		cell.setLeading(2f, 1f);
		cell.setBorderWidth(0.75f);
		cell.setBackgroundColor(color);
		//add the call to the table
		table.addCell(cell);

	}

	public void onCloseDocument(PdfWriter writer, Document document) {
		Paragraph p1 = new Paragraph("Testing************");
		PdfPCell cell = new PdfPCell();
		cell.addElement(p1);

		try {
			document.add(cell);
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	public class HeaderAndFooter extends PdfPageEventHelper {

		private String name = "";
		PdfTemplate total;

		protected Phrase footer;
		protected Phrase header;

		/*
		 * Font for header and footer part.
		 */
		com.itextpdf.text.Font headerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);

		/*
		 * constructor
		 */
		public HeaderAndFooter(String name) {
			super();
			this.name = name;
			header = new Phrase("***** Header *****");
			footer = new Phrase("**** Footer ****");
		}

		@Override
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
			super.onOpenDocument(writer, document);
		}
		@Override
		public void onEndPage(PdfWriter writer, Document document) {

			PdfContentByte cb = writer.getDirectContent();

			//header content
			String headerContent = "Name: " +name;

			//header content
			String footerContent = headerContent;
			/*
			 * Header
			 */
			/*	ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(headerContent,headerFont), 
	                document.leftMargin(), document.top() -30, 0);*/

			/*
			 * Foooter
			 */
			DateFormat defDate=null;
			PropertyHelper propertyHelper = new PropertyHelper();
			if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
				defDate  = DateFormat.getDateInstance(DateFormat.LONG,Locale.FRANCE);
				
				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				if(propertyHelper.getProperty("ForcedateOnPDF_FR")!=null && propertyHelper.getProperty("ForcedateOnPDF_FR").trim()!="") {
					currDate = propertyHelper.getProperty("ForcedateOnPDF_FR");
				}
				com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
						writer.getCurrentPageNumber()),boldContentFont), 
						document.left()+250 , document.bottom()-45, 0);
					
			}
			else{
			defDate  = DateFormat.getDateInstance(DateFormat.LONG);
			String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
			if(propertyHelper.getProperty("ForcedateOnPDF_EN")!=null && propertyHelper.getProperty("ForcedateOnPDF_EN").trim()!="") {
				currDate = propertyHelper.getProperty("ForcedateOnPDF_EN");
			}
			com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
			ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
					writer.getCurrentPageNumber()),boldContentFont), 
					document.left()+250 , document.bottom()-45, 0);
			}

			PdfPTable table = new PdfPTable(3);
			table.getDefaultCell().setBorder(0);
			table.getDefaultCell().setPaddingBottom(25);

			PdfPTable table1 = null;

			table.setTotalWidth(475);
			table.setLockedWidth(true);
			PdfPCell cell;

			com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.WHITE);
			com.itextpdf.text.Font regionFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.WHITE);
			cell = new PdfPCell(new Phrase(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader));
			cell.setMinimumHeight(15f);
			cell.setBackgroundColor(BaseColor.BLACK);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);

			table.addCell(cell);

			cell = new PdfPCell(new Phrase("WHEELS",tableHeader));
			if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
				cell = new PdfPCell(new Phrase("ROUES ",tableHeader));
			}

			if(subCategoryID==VehicleConstant.RADIOS){
				cell = new PdfPCell(new Phrase("RADIOS",tableHeader));
			}
			cell.setFixedHeight(15f);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(BaseColor.BLACK);

			table.addCell(cell);


			cell = new PdfPCell(new Phrase(vehicleItemsXML.get(0).getRegionName(),regionFont));
			cell.setFixedHeight(15f);
			cell.setBackgroundColor(BaseColor.BLACK);

			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);


			table.addCell(cell);


			PdfPTable table2;
			table2 = new PdfPTable(1);
			table2.setTotalWidth(475);
			cell = new PdfPCell();
			cell.setPaddingBottom(25);
			cell.setBorder(Rectangle.NO_BORDER);

			PdfPTable table4 = new PdfPTable(2);
			table4 = new PdfPTable(2);
			table4.getDefaultCell().setBorder(0);
			table4.getDefaultCell().setPadding(0);
			table4.setTotalWidth(475);
			cell.setBackgroundColor(new BaseColor(153,153,153));

			try {
				table4.setWidths(new int[] {75,400});
			} catch (DocumentException e) {
				e.printStackTrace();
			}



			table.addCell(table4);

			table.writeSelectedRows(0, -1, 70, 750, writer.getDirectContent());
		}

	}

	public void startRadioPDFGeneration(int subCategoryID,
			List<WheelsAndRadiosBean> vehicleItemsXML, Document document,
			PdfWriter writer, int pdfType) {
		
		try {
			new ItextPDFGenerator_WheelsAndRadios().createPdf(subCategoryID,vehicleItemsXML,document,writer,pdfType );
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}

		
	}


}
