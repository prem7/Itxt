package com.dci.jasper.reporter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.swing.text.TabExpander;

import com.dci.enterprise.dao.ItextSpecsAndDimensionPDFGeneratorDAO;
import com.dci.enterprise.model.SpecsAndDimBeanContent;
import com.dci.enterprise.model.SpecsAndDimHelper;
import com.dci.enterprise.model.SpecsAndDimensionBean;
import com.dci.extrafunc.PropertyHelper;
import com.dci.general.utilities.VehicleConstant;
import com.google.common.base.CaseFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class ItextPDFGenerator_SpecsAndDimension extends PdfPageEventHelper implements ItextSpecsAndDimensionPDFGeneratorDAO{
	//public static final String RESULT = "c:\\reports\\TestingStandardEq.pdf";
	private static List<SpecsAndDimensionBean> vehicleItemsXML = null;
	private  List<SpecsAndDimensionBean>  rowHeaderList=null;
	private  List<SpecsAndDimBeanContent>  contentList=null;
	private  List<SpecsAndDimHelper>  columnHeaderList=null;
	List<SpecsAndDimHelper> OriginalcolumnHeaderList = new ArrayList<SpecsAndDimHelper>();
	static int tempC;
	public static boolean isPOG = false;
	public static int pdfType;
	public static int tableWidth = 475;
	public static	Document document=null;
	public static String pageLabel;
	private int pageNum=0;
	public ArrayList<String> packageRestrictionList = new ArrayList<String>();
	public static Properties unicodeProperties;
	InputStream inputStream = null;
	public void createPdf(List<ArrayList<Object>>  finalList, Document document, PdfWriter writer, int pdfType)
			throws IOException, DocumentException {
		tableWidth = 475;
		tempC=0;
		vehicleItemsXML =null;	
		vehicleItemsXML = (List<SpecsAndDimensionBean>)finalList.get(0).get(0);

		if(vehicleItemsXML!=null && !vehicleItemsXML.isEmpty() ){
			//	vehicleItemsXML = (List<SpecsAndDimensionBean>)finalList.get(0);
			PdfPTable headerTable = null;
			PdfPTable table = null;
			PropertyHelper propertyHelper = new PropertyHelper();
			String location = propertyHelper.getProperty("pdfDefaultLocation");
			int defaultColSize =0;
			PdfPTable table2 = null;
			if(vehicleItemsXML.get(0).getColumnBreak()!=null){
				defaultColSize = vehicleItemsXML.get(0).getColumnBreak().intValueExact();
			}
			// step 1
			if(pdfType==VehicleConstant.SINGLERUN){
				if( vehicleItemsXML.get(0).getIsLandscape()!=null && vehicleItemsXML.get(0).getIsLandscape().intValueExact()==1){

					document = new Document(PageSize.LETTER.rotate(), 100, 50, 20, 25);
					document.setMargins(72,72,85, 72);
					tableWidth = 575;
				}
				else{
					document = new Document(PageSize.LETTER, 25, 20, 50, 100);
					document.setMargins(72,72, 75, 115);
				}
				document.setMarginMirroringTopBottom(true);

				String fileName = vehicleItemsXML.get(0).getVehicleId()+"-"+"specs_fo";
				// step 2
				if(vehicleItemsXML.get(0).getRegionID().intValueExact()==14 && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
					fileName+="_fr";
				}
				writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));
				writer.setPageEvent(new HeaderAndFooter(""));
				// step 3
				document.open();
				// step 4
			}
			writer.setPageEvent(new HeaderAndFooter(""));
			writer.setPageEmpty(false);
			if(pdfType!=0){

				if( vehicleItemsXML.get(0).getIsLandscape()!=null && vehicleItemsXML.get(0).getIsLandscape().intValueExact()==1){
					document.setPageSize(PageSize.LETTER.rotate());
					document.setMargins(72,72,85, 72);
					//document.newPage();
					tableWidth = 575;

				}
				else
					tableWidth=475;
			}
			// step 3
			document.open();
			pageNum =0;

			for (int k = 0; k < finalList.size(); k++) {

				rowHeaderList = (List<SpecsAndDimensionBean>)finalList.get(k).get(0);
				columnHeaderList = (List<SpecsAndDimHelper>)finalList.get(k).get(2);
				if(!(columnHeaderList.isEmpty() || rowHeaderList.isEmpty())){
					pageNum++;
				}
			}

			for (int k = 0; k < finalList.size(); k++) {

				rowHeaderList = (List<SpecsAndDimensionBean>)finalList.get(k).get(0);
				columnHeaderList = (List<SpecsAndDimHelper>)finalList.get(k).get(2);
				if(!(columnHeaderList.isEmpty() || rowHeaderList.isEmpty())){
					if(k>0){
						document.newPage();
					}
					for (int j = 0; j < columnHeaderList.size(); j++) {
						OriginalcolumnHeaderList.add(columnHeaderList.get(j));
					}

					for(int i =0;i<defaultColSize; i ++){
						columnHeaderList.remove(columnHeaderList.get(columnHeaderList.size()-1));
					}
					if(!rowHeaderList.isEmpty()){
						if( rowHeaderList.get(0).getPulldownText()==null ){
							rowHeaderList.get(0).setPulldownText("");
						}
						if(rowHeaderList.get(0).getPulldownText().trim().equalsIgnoreCase("- SPECS"))
						{
							rowHeaderList.get(0).setPulldownText("");
						}

					}

					rowHeaderList =(List<SpecsAndDimensionBean>)finalList.get(k).get(0);
					pageLabel = rowHeaderList.get(0).getPulldownText();

					table = createTable(finalList.get(k));
					columnHeaderList = OriginalcolumnHeaderList;
					int temp = OriginalcolumnHeaderList.size();
					tempC =temp;
					if(defaultColSize>0){
						for(int i =0;i<temp-defaultColSize; i ++){
							columnHeaderList.remove(0);
						}

						//createpdfRun(availablecode, stdEqpHelperList);
						table2 = createTable(finalList.get(k));
						table2.setSplitLate(false);
						table2.setSplitRows(true);
					}


					//System.out.println(table.getRows(0, 1).toString());
					//document.add(headerTable);
					if(table!=null){
						document.add(table);
						if(table2!=null)
							document.add(table2);
					}

				}
			}
			//	PdfPTable footer = createFooter(writer);

			/*	document.add(headerTable);
			document.add(table);*/
			//	document.add(footer);

			if(pdfType==0){
				onCloseDocument(writer, document);
				// step 5
				document.close();
			}
		}
	}

	class TableHeader extends PdfPageEventHelper {
		/** The header text. */
		String header;
		/** The template with the total number of pages. */
		PdfTemplate total;

		/**
		 * Allows us to change the content of the header.
		 * @param header The new header String
		 */
		public void setHeader(String header) {
			this.header = header;
		}

		/**
		 * Creates the PdfTemplate that will hold the total number of pages.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onOpenDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
		}

		/**
		 * Adds a header to every page
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onEndPage(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			try {
				table.setWidths(new int[]{24, 24, 2});
				table.setTotalWidth(tableWidth);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(550);
				table.getDefaultCell().setBorder(Rectangle.BOTTOM);
				table.addCell(header);
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Page %d of", writer.getCurrentPageNumber()));
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.BOTTOM);
				table.addCell(cell);
				table.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
			}
			catch(DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		/**
		 * Fills out the total number of pages before the document is closed.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onCloseDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT,
					new Phrase(String.valueOf(writer.getCurrentPageNumber() - 1)),
					2, 2, 0);
		}
	}


	public String getLocation()
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String location = null;
		if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			location = eProperties.getProperty("pdfDefaultLocation");
		}
		return location;
	}

	public  PdfPTable createTable(List<Object> finalList) throws DocumentException {
		loadRestriction();
		rowHeaderList = (List<SpecsAndDimensionBean>)finalList.get(0);
		contentList = (List<SpecsAndDimBeanContent>)finalList.get(1);
		columnHeaderList = (List<SpecsAndDimHelper>)finalList.get(2);

		PdfPTable table1 = null;

		PdfPTable table2 = null;
		PdfPTable tableSpec = null;
		PdfPTable tableCap = null;
		PdfPTable tableMain = null;
		PdfPTable tableColumn = null;
		PdfPTable tableCapContent = null;
		com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.WHITE);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);




	//	System.out.println(columnHeaderList.size());
		table1 = new PdfPTable(columnHeaderList.size()+1);
		tableColumn = new PdfPTable(columnHeaderList.size()+1);
		tableCapContent = new PdfPTable(columnHeaderList.size()+1);
		table2 = new PdfPTable(1);
		tableMain = new PdfPTable(1);
		tableSpec = new PdfPTable(1);
		tableCap = new PdfPTable(1);
		table1.setLockedWidth(true);
		table1.setTotalWidth(tableWidth);
		tableCapContent.setLockedWidth(true);
		tableCapContent.setTotalWidth(tableWidth);
		tableColumn.setLockedWidth(true);
		tableColumn.setTotalWidth(tableWidth);

		table2.setLockedWidth(true);
		table2.setTotalWidth(tableWidth);
		tableMain.setLockedWidth(true);
		tableMain.setSplitLate(false);
		tableMain.setSplitRows(true);
		tableMain.setTotalWidth(tableWidth);
		tableSpec.setLockedWidth(true);
		tableSpec.setTotalWidth(tableWidth);
		tableCap.setLockedWidth(true);
		tableCap.setTotalWidth(tableWidth);
		float[] width = new float[columnHeaderList.size()+1];
		width[0]= 164;
		int tabSize=311;
		if(tableWidth==575){
			tabSize=411;
		}
		for (int i = 1; i <= columnHeaderList.size(); i++) {
			width[i]=(tabSize/columnHeaderList.size());
		}
		table1.setWidths(width);
		tableCapContent.setWidths(width);
		tableColumn.setWidths(width);
		int specsCount =0;
		int capsCount = 0;
		for (SpecsAndDimensionBean specs_restrictionText : rowHeaderList) {

			if(specs_restrictionText.getRestrictionText()!=null && !(specs_restrictionText.getRestrictionText().equalsIgnoreCase("null"))  ){

				if(!packageRestrictionList.contains(specs_restrictionText.getRestrictionText()))
				{
					packageRestrictionList.add(specs_restrictionText.getRestrictionText());
				}
			}
		}

		//insertCell(table1,"",null, null, Element.ALIGN_LEFT, 1, tableHeader1,new BaseColor(204,204,204));
		insertCell(tableColumn,"",null, null, Element.ALIGN_LEFT, 1, tableHeader1,new BaseColor(204,204,204));

		for (SpecsAndDimHelper specsAndDimHelper : columnHeaderList) {
			if(specsAndDimHelper.getColHeader1()==null || specsAndDimHelper.getColHeader1()=="null" ) {

				specsAndDimHelper.setColHeader1("");
			}

			if(specsAndDimHelper.getModelName()!=null && specsAndDimHelper.getModelName()!="null"){

				insertCell(tableColumn,specsAndDimHelper.getModelName()+" \n "+ specsAndDimHelper.getModelDesc()+"\n"+specsAndDimHelper.getColHeader1(),null, null, Element.ALIGN_CENTER, 1, tableHeader1,new BaseColor(204,204,204));

			}
			else {

				insertCell(tableColumn,specsAndDimHelper.getColHeader1(),null, null, Element.ALIGN_CENTER, 1, tableHeader1,new BaseColor(204,204,204));
			}
		}
		if(!rowHeaderList.isEmpty() ){
			String header1 = "Specifications";
			if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2)
			{
				header1 = "Fiche technique ";

			}
			
			insertCell(tableSpec, header1, null, null, Element.ALIGN_LEFT, 1, tableHeader1, BaseColor.WHITE);
			for (SpecsAndDimensionBean foreachRow : rowHeaderList) {
				boolean foundMatch = false;

				if(foreachRow.getRowCategoryID()!=null && foreachRow.getRowCategoryID().intValueExact()==1){
					specsCount++;	
					if(foreachRow.getToUnit().equalsIgnoreCase("null")||foreachRow.getFromUnit().equalsIgnoreCase("null"))			
					{
						insertCell(table1,null,foreachRow.getRowDesctiption1()+restrictionFlag_package(foreachRow.getRestrictionText()), null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
					}
					else{	
						insertCell(table1,null,foreachRow.getRowDesctiption1()+restrictionFlag_package(foreachRow.getRestrictionText())+", "+ foreachRow.getFromUnit()+" ("+foreachRow.getToUnit()+")", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
					}
					for (SpecsAndDimHelper foreachColumn : columnHeaderList){
						foundMatch = false;

						for (SpecsAndDimBeanContent foreachCell : contentList){
							if(foreachRow.getRowHeaderID().equals(foreachCell.getRowHeaderID())&& foreachCell.getColumnHeaderID().equals(foreachColumn.getColumnHeaderID()))
							{
								String cell;
								if(foreachCell.getCellValueNumberMetric()==null) {

									foundMatch = true;
									insertCell(table1,"--",null, null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);

								}
								else {
									if(!foreachCell.getCellValueNumberMetric().equalsIgnoreCase("null")){
										insertCell_WNumber(table1,null, foreachCell.getCellValueNumber()+" ("+ decimalPlaces(foreachCell.getCellValueNumberMetric(),foreachRow.getToUnitDecimals().intValueExact())+")", null, Element.ALIGN_CENTER, 1, tableHeader,BaseColor.WHITE);
										foundMatch = true;
									}
									else if(foreachCell.getCellvalueString()!=null && foreachCell.getCellvalueString()!="null")
									{
										insertCell_WNumber(table1,"",foreachCell.getCellvalueString(), "", Element.ALIGN_CENTER, 1, tableHeader,BaseColor.WHITE);
										foundMatch = true;
									}

									else {
										insertCell(table1,"","--", "", Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
										foundMatch = true;
									}
									//insertCell(table1,null, tableContent.getCellValueNumber()+"("+ cell+")", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
								}

							}
						}

						if(!foundMatch){
							insertCell(table1,"","--", "", Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
						}
					}
				}

			}
		}
		
		String header2 = "Capacities";
		if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2)
		{
			header2 = "Capacit�s ";

		}
		insertCell(tableCap, header2, null, null, Element.ALIGN_LEFT, 1, tableHeader1, BaseColor.WHITE);


		for (SpecsAndDimensionBean foreachRow : rowHeaderList) {
			boolean foundMatch = false;
			if(foreachRow.getRowCategoryID()!=null && foreachRow.getRowCategoryID().intValueExact()==2){
				capsCount++;
				if(foreachRow.getToUnit().equalsIgnoreCase("null")||foreachRow.getFromUnit().equalsIgnoreCase("null"))			
				{
					insertCell(tableCapContent,null,foreachRow.getRowDesctiption1()+restrictionFlag_package(foreachRow.getRestrictionText()), null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
				}
				else{	
					insertCell(tableCapContent,null,foreachRow.getRowDesctiption1()+restrictionFlag_package(foreachRow.getRestrictionText())+", "+ foreachRow.getFromUnit()+" ("+foreachRow.getToUnit()+")", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
				}
				for (SpecsAndDimHelper foreachColumn : columnHeaderList){
					foundMatch = false;

					for (SpecsAndDimBeanContent foreachCell : contentList){
						if(foreachRow.getRowHeaderID().equals(foreachCell.getRowHeaderID())&& foreachCell.getColumnHeaderID().equals(foreachColumn.getColumnHeaderID()))
						{
							String cell;
							if(foreachCell.getCellValueNumberMetric()==null)
							{
								foundMatch = true;
								insertCell(tableCapContent,"--",null, null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);

							}
							else{
								if(foreachCell.getCellValueNumber()!=null && foreachCell.getCellValueNumber()!="null"){

									insertCell_WNumber(tableCapContent,null, decimalPlaces(foreachCell.getCellValueNumber(),foreachRow.getToUnitDecimals().intValueExact())+" ("+ decimalPlaces(foreachCell.getCellValueNumberMetric(),foreachRow.getToUnitDecimals().intValueExact())+")", null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
									foundMatch = true;
								}
								else if(foreachCell.getCellvalueString()!=null && foreachCell.getCellvalueString()!="null")
								{
									insertCell(tableCapContent,"",foreachCell.getCellvalueString(), "", Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
									foundMatch = true;
								}
								//insertCell(table1,null, tableContent.getCellValueNumber()+"("+ cell+")", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
							}

						}
					}

					if(!foundMatch){
						insertCell(tableCapContent,"","--", "", Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
					}
				}
			}

		}

		int count = 0;
		String tempRestriction = "";
		for (String restrictionList : packageRestrictionList) {
			count++;
			tempRestriction += count+". "+restrictionList+"\n";
		}
		if(count >0){
			insertCell(table2,null,tempRestriction, null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
		}
		//table.addCell(table1);
		tableMain.getDefaultCell().setBorder(0);
		tableMain.getDefaultCell().setPadding(0);
		tableMain.addCell(tableColumn);
		if(specsCount!=0){
			tableMain.addCell(tableSpec);
		}
		tableMain.addCell(table1);
		//}
		//	if(capsCount!=0){
		tableMain.addCell(tableCap);
		tableMain.setHeaderRows(1);
		tableMain.addCell(tableCapContent);
		//	}
		tableMain.addCell(table2);

		return tableMain;

	}


	public String decimalPlaces(String cellvalue, int decimalPlaces){
		String cell;
		float cellval =Float.parseFloat(cellvalue);
		DecimalFormat df = null;      


		if(decimalPlaces==0)
		{
			df = new DecimalFormat("0");
		}

		if(decimalPlaces==1)
		{
			df =	 new DecimalFormat("0.0");
		}
		if(decimalPlaces==2)
		{
			df = new DecimalFormat("0.00");
		}
		if(decimalPlaces==3)
		{
			df =  new DecimalFormat("0.000");
		}

		cell =	df.format(cellval);

		/*	if(decimalPlaces!=0 && Float.parseFloat(cell) == Math.round(cellval))
		{
			df = new DecimalFormat("#.0");
			cell =	df.format(Float.parseFloat(cell));

		}*/

		return cell;

	}



	public String restrictionFlag_package(String currentRestriction){
		String unicodeFlag="";
		boolean isRestrictionExist = false;
		if(currentRestriction!=null && !currentRestriction. equalsIgnoreCase("null") &&  !currentRestriction.equalsIgnoreCase("")){
			int restrictionPosition=1;

			for (Iterator iterator = packageRestrictionList.iterator(); iterator
					.hasNext();) {

				String restiction = (String) iterator.next();
				if(currentRestriction.equalsIgnoreCase(restiction)){
					isRestrictionExist=true;
					break;
				}
				restrictionPosition++;

			}

			if(unicodeProperties.getProperty(String.valueOf(restrictionPosition))!=null && !unicodeProperties.getProperty(String.valueOf(restrictionPosition)).isEmpty())
			{
				unicodeFlag = unicodeProperties.getProperty(String.valueOf(restrictionPosition));
			}

		}
		if(!isRestrictionExist) {
			unicodeFlag="";
		}
		return unicodeFlag;
		}
	
	public void loadRestriction(){

		unicodeProperties = new Properties();
		inputStream = null;

		try {
			inputStream = new FileInputStream("./Unicode.properties");
			unicodeProperties.load(inputStream);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void insertImage(PdfPTable table, PdfPCell cell,
			int align, int i, Font tableHeader1) {
		cell.setHorizontalAlignment(align);
		cell.setVerticalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setBorderWidth(0.5f);
		//add the call to the table
		table.addCell(cell);

	}


	public void startSpecsAndDimPDFGeneration(List<ArrayList<Object>> specsAndDimesionsList) {
		// TODO Auto-generated method stub

		try {

			new ItextPDFGenerator_SpecsAndDimension().createPdf(specsAndDimesionsList,null,null,0 );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	public static void insertCell(PdfPTable table,String boldText, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		/*if(text!=null && text.length()>8)
		{
			text = text.replace("(", "\n(");
		}*/
		para.add(new Phrase(text, font));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingRight(1f);
		cell.setPaddingLeft(1f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row
		//if(text.trim().equalsIgnoreCase("")){
		cell.setMinimumHeight(10f);
		//	}
		//	//add the call to the table
		table.addCell(cell);

	}
	
	public static void insertCell_WNumber(PdfPTable table,String boldText, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		if(text!=null && text.length()>8 && tempC>5)
		{
			text = text.replace("(", "\n(");
		}
		para.add(new Phrase(text, font));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingRight(1f);
		cell.setPaddingLeft(1f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row
		//if(text.trim().equalsIgnoreCase("")){
		cell.setMinimumHeight(10f);
		//	}
		//	//add the call to the table
		table.addCell(cell);

	}

	public static void insertCustomCell(PdfPTable table,String boldText, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){




		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		para.add(new Phrase(text, font));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		cell.setNoWrap(true);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		cell.setBorder(Rectangle.LEFT);
		//in case there is no text and you wan to create an empty row
		//if(text.trim().equalsIgnoreCase("")){
		cell.setMinimumHeight(10f);
		//	}
		//	//add the call to the table

		table.addCell(cell);
		cell = new PdfPCell();
		cell.setBorderColor(BaseColor.WHITE);
		cell.setBorder(Rectangle.LEFT);
		table.addCell(cell);
		cell = new PdfPCell();
		cell.setBorder(Rectangle.RIGHT );

		table.addCell(cell);
	}

	public void onCloseDocument(PdfWriter writer, Document document) {
		Paragraph p1 = new Paragraph("Testing************");
		PdfPCell cell = new PdfPCell();
		cell.addElement(p1);

		try {
			document.add(cell);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private PdfPTable createFooter(PdfWriter writer) {
		DateFormat defDate=null;
		defDate  = DateFormat.getDateInstance(DateFormat.LONG);

		String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, defDate.format(new Date())); 
		com.itextpdf.text.Font footerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		PdfPTable table = new PdfPTable(1);
		table.setTotalWidth(tableWidth);
		Paragraph p1 = new Paragraph("Published " + currDate +" Page "+writer.getCurrentPageNumber(),footerFont);
		PdfPCell cell = new PdfPCell();

		p1.setAlignment(Element.ALIGN_CENTER);
		cell.addElement(p1);
		cell.setPaddingTop(40);
		cell.setPaddingBottom(40);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		return table;
	}


	public class HeaderAndFooter extends PdfPageEventHelper {

		private String name = "";
		PdfTemplate total;

		protected Phrase footer;
		protected Phrase header;

		/*
		 * Font for header and footer part.
		 */
		com.itextpdf.text.Font headerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		/*private static Font headerFont = new Font(Font.COURIER, 9,
	            Font.NORMAL,Color.blue);

	    private static Font footerFont = new Font(Font.TIMES_ROMAN, 9,
	            Font.BOLD,Color.blue);*/


		/*
		 * constructor
		 */
		public HeaderAndFooter(String name) {
			super();
			this.name = name;
			header = new Phrase("***** Header *****");
			footer = new Phrase("**** Footer ****");
		}

		@Override
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
			// TODO Auto-generated method stub
			super.onOpenDocument(writer, document);
		}
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			if(!vehicleItemsXML.isEmpty()){
				PdfContentByte cb = writer.getDirectContent();

				//header content
				String headerContent = "Name: " +name;

				//header content
				String footerContent = headerContent;
				/*
				 * Header
				 */
				/*	ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(headerContent,headerFont), 
	                document.leftMargin(), document.top() -30, 0);*/

				/*
				 * Foooter
				 */
				DateFormat defDate=null;
				PropertyHelper propertyHelper = new PropertyHelper();
				if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
					defDate  = DateFormat.getDateInstance(DateFormat.LONG,Locale.FRANCE);

					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_FR")!=null && propertyHelper.getProperty("ForcedateOnPDF_FR").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_FR");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
					if(vehicleItemsXML.get(0).getIsLandscape()!=null && vehicleItemsXML.get(0).getIsLandscape().intValueExact()==1){
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+350 , document.bottom()-45, 0);
					}
					else{
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+250 , document.bottom()-45, 0);
					}

				}
				else{
					defDate  = DateFormat.getDateInstance(DateFormat.LONG);
					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_EN")!=null && propertyHelper.getProperty("ForcedateOnPDF_EN").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_EN");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);

					if(vehicleItemsXML.get(0).getIsLandscape()!=null && vehicleItemsXML.get(0).getIsLandscape().intValueExact()==1){
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.bottom() , document.left()+250,-90);
					}
					else{
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+250 , document.bottom()-45, 0);
					}

				}


				PdfPTable table = new PdfPTable(3);
				table.getDefaultCell().setBorder(0);
				//table.getDefaultCell().setPaddingBottom(25);

				PdfPTable table1 = null;

				table.setTotalWidth(tableWidth);
				try {
					table.setWidths(new int[] {150,195,135});
				} catch (DocumentException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setLockedWidth(true);
				PdfPCell cell;

				com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.WHITE);

				//Paragraph p1 = new Paragraph(vehicleItemsXML2.get(0).getVehicleName(),tableHeader);
				//Paragraph p1 = new Paragraph(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader);
				//p1.setAlignment(Element.ALIGN_LEFT);
				cell = new PdfPCell(new Phrase(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);

				//	cell.addElement(p1);
				table.addCell(cell);

				//Paragraph p2 = new Paragraph("RPO CODES",tableHeader);
				/*if(pageLabelCount.size()>1){
					cell = new PdfPCell(new Phrase("SPECS" + " - " +pageLabel,tableHeader));
				}
				else
				{*/
				String tempHead = "SPECS";
				if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2)
				{
					tempHead = "FICHE TECHNIQUE ";

				}
				/*if((!rowHeaderList.isEmpty()) &&	rowHeaderList!=null  ){
					if( rowHeaderList.get(0).getPulldownText()==null && rowHeaderList.get(0).getPulldownText().trim().equalsIgnoreCase("- SPECS")){
						rowHeaderList.get(0).setPulldownText("");
					}
					if( rowHeaderList.get(0).getPulldownText().trim().equalsIgnoreCase("- SPECS")){
						rowHeaderList.get(0).setPulldownText("");
					}
					cell = new PdfPCell(new Phrase(tempHead+rowHeaderList.get(0).getPulldownText(),tableHeader));
				}
				else{
					cell = new PdfPCell(new Phrase(tempHead,tableHeader));
				}*/
				if(pageNum<2)
				{
					pageLabel="";
				}
				cell = new PdfPCell(new Phrase("SPECS "+pageLabel,tableHeader));
				if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2)
				{
					cell = new PdfPCell(new Phrase("FICHE TECHNIQUE  "+pageLabel,tableHeader));

				}
				//}
				cell.setMinimumHeight(15f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p2.setAlignment(Element.ALIGN_CENTER);

				//cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				//cell.addElement(p2);

				table.addCell(cell);

				//	Paragraph p3 = new Paragraph(vehicleItemsXML.get(0).getRegionName(),tableHeader);
				cell = new PdfPCell(new Phrase(vehicleItemsXML.get(0).getRegionName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p3.setAlignment(Element.ALIGN_RIGHT);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				//cell.addElement(p3);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				cell.setPaddingLeft(2f);

				table.addCell(cell);
				//	table.addCell(table2);
				if(vehicleItemsXML.get(0).getIsLandscape()!=null && vehicleItemsXML.get(0).getIsLandscape().intValueExact()==1){
					table.writeSelectedRows(0, -1,110, 550, writer.getDirectContent());
				}
				else{
					table.writeSelectedRows(0, -1, 70, 750, writer.getDirectContent());
				}
			}
			else {
				PdfContentByte cb = writer.getDirectContent();
				DateFormat defDate=null;
				defDate  = DateFormat.getDateInstance(DateFormat.LONG);

				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
						writer.getCurrentPageNumber()),headerFont), 
						document.left()+250 , document.bottom()-45, 0);

			}

		}




	}


	public void startSpecsAndDimPDFGeneration(List<ArrayList<Object>> specsAndDimesionsList,
			Document document, PdfWriter writer, int pdfType) {
		isPOG =true;
		try {

			new ItextPDFGenerator_SpecsAndDimension().createPdf(specsAndDimesionsList,document,writer,pdfType );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}









}
