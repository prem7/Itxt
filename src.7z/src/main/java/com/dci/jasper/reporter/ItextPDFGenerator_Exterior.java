package com.dci.jasper.reporter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import com.dci.enterprise.dao.ItextExteriorPDFGeneratorDAO;
import com.dci.enterprise.dao.ItextInteriorPDFGeneratorDAO;
import com.dci.enterprise.model.SpecsAndDimBeanContent;
import com.dci.enterprise.model.SpecsAndDimHelper;
import com.dci.enterprise.model.StandardEqpBean;
import com.dci.enterprise.model.StdEqpHelper;
import com.dci.extrafunc.PropertyHelper;
import com.dci.general.utilities.VehicleConstant;
import com.google.common.base.CaseFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.HyphenationAuto;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;

public class ItextPDFGenerator_Exterior extends PdfPageEventHelper implements ItextExteriorPDFGeneratorDAO {
	//public static final String RESULT = "c:\\reports\\TestingStandardEq.pdf";
	private static List<StandardEqpBean> vehicleItemsXML = null;
	private static List<StandardEqpBean> headerHelper=null;
	private static List<StandardEqpBean> availableCodeList=null;
	private static HashMap<BigDecimal,ArrayList<String>>  packageNameList=null;
	public  List<BigDecimal>   modelList=null;
	private  List<BigDecimal>   MasterModelList=new ArrayList<BigDecimal>();
	private  List<StdEqpHelper>  stdEqpHelperList=null;
	public static	Document document=null;
	public static String pageLabel;
	public static PdfPTable headerTable;
	public static PdfPCell headerText;
	Set<String> pageLabelCount = new HashSet<String>();
	public ArrayList<Integer> restrictionIDList = new ArrayList<Integer>();
	public ArrayList<Integer> packageRestrictionIDList = new ArrayList<Integer>();
	static int coulumnCount=0;
	public PdfPTable tableContent = null;
	public static boolean isPOG = false;
	public PdfPTable tableDesc = null;
	public static int pdfType;
	private ArrayList<BigDecimal> packageIDList;
	public List<ArrayList<BigDecimal>> modelList_final;
	public static Properties unicodeProperties;
	InputStream inputStream = null;
	public void createPdf( List<List<StandardEqpBean>> vehicleItemsXML,Object[][] availablecode,
			List<HashMap<BigDecimal, ArrayList<String>>>  packageNameMap,List<ArrayList<BigDecimal>> modellistFromMethod,
			List<StdEqpHelper>  stdEqpHelperList, Document document,PdfWriter writer, int pdfType)
					throws IOException, DocumentException {


		//this.modelList = modellistFromMethod;
		//this.MasterModelList = modellistFromMethod;
		int defaultColSize = 0;
		this.pdfType = pdfType;
		PropertyHelper propertyHelper = new PropertyHelper();
		String location = propertyHelper.getProperty("pdfDefaultLocation");
		PdfPTable headerTable = null;
		// step 1
		headerHelper = (List<StandardEqpBean>)availablecode[0][0];	
		if(headerHelper!=null && !headerHelper.isEmpty()){
		if(headerHelper.get(0).getColumnBreak()!=null){
			defaultColSize = headerHelper.get(0).getColumnBreak().intValueExact();
		}
		//	this.packageIDList = headerHelper.get(0).getPackageList();
		if(pdfType!=VehicleConstant.VEHICLE_PRINT){

			if( headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){

				document = new Document(PageSize.LETTER.rotate(), 100, 50, 20, 25);
				document.setMargins(72,72,72, 72);
			}
			else{
				document = new Document(PageSize.LETTER, 25, 20, 50, 100);
				document.setMargins(72,72, 75, 115);
			}

			//document.setMargins(72,72, 75, 115);
			document.setMarginMirroringTopBottom(true);

			String fileName = headerHelper.get(0).getVehicleId()+"-"+"oi_ext_fo";

			if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getRegionID().intValueExact()==14 && headerHelper.get(0).getLocaleCode().intValueExact()==2){
				fileName+="_fr";
			}

			// step 2
			writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));
			writer.setPageEmpty(false);
			writer.setPageEvent(new HeaderAndFooter(""));
			// step 3
			document.open();
			// step 4
		}
		modelList_final = new ArrayList<ArrayList<BigDecimal>>();
		writer.setPageEvent(new HeaderAndFooter(""));
		this.document = document;



		for(int k = 0 ; k< 4 ; k++){

			modelList= modellistFromMethod.get(k);

			for (int j = 0; j < modelList.size(); j++) {
				MasterModelList.add(modelList.get(j));
			}


			for(int i =0;i<defaultColSize; i ++){
				modelList.remove(modelList.get(modelList.size()-1));
			}

			modelList_final.add((ArrayList<BigDecimal>) modelList);
		}
		createpdfRun(availablecode, stdEqpHelperList, packageNameMap);
		for(int k = 0 ; k< 4 ; k++){
			modelList = MasterModelList;
			int temp = MasterModelList.size();
			if(defaultColSize>0){
				for(int i =0;i<temp-defaultColSize; i ++){
					modelList.remove(0);
				}
				modelList_final.add((ArrayList<BigDecimal>) modelList);
				createpdfRun(availablecode, stdEqpHelperList,packageNameMap);
			}
		}
		if(pdfType!=VehicleConstant.VEHICLE_PRINT){

			onCloseDocument(writer, document);
			
			
			// step 5
			document.close();
		}
		}
	}

	public void getModelList(int i){

	}
	private PdfPTable createpdfRun(Object[][] availablecode,List<StdEqpHelper>  stdEqpHelperList, List<HashMap<BigDecimal, ArrayList<String>>> packageNameMap) throws DocumentException {
		tableDesc = new PdfPTable(1);
		tableDesc = createTableHeaders();
		loadRestriction();
		for(int i=0;i<modelList_final.size();i++){
			if((i<availablecode.length && availablecode[i][0]!=null && availablecode[i][1]!=null)){
				packageIDList = headerHelper.get(0).getPackageList().get(i);
				this.packageNameList = packageNameMap.get(i);
				modelList = modelList_final.get(i);
				
				try {
					tableDesc = new PdfPTable(1);
					tableDesc = createTableHeaders();
					tableDesc.setSplitLate(false);
					tableDesc.setSplitRows(true);
					document.newPage();
					tableContent = createTable(availablecode[i][0],availablecode[i][1],stdEqpHelperList,(i+1),packageNameMap);
					
					tableDesc.addCell(tableContent);
				} catch (Exception e) {
					e.printStackTrace();
				}
				if(tableContent!=null){
					try {
						
						document.add(tableDesc);
					} catch (DocumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if((i+1)!=availablecode.length){
						document.newPage();
					}
				}
			}
		}
		
		return tableDesc;

	}
	public String getLocation()
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String location = null;
		if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			location = eProperties.getProperty("pdfDefaultLocation");
		}
		return location;
	}

	class TableHeader extends PdfPageEventHelper {
		/** The header text. */
		String header;
		/** The template with the total number of pages. */
		PdfTemplate total;

		/**
		 * Allows us to change the content of the header.
		 * @param header The new header String
		 */
		public void setHeader(String header) {
			this.header = header;
		}

		/**
		 * Creates the PdfTemplate that will hold the total number of pages.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onOpenDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
		}

		/**
		 * Adds a header to every page
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onEndPage(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			try {
				table.setWidths(new int[]{24, 24, 2});
				table.setTotalWidth(527);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(475);
				table.getDefaultCell().setBorder(Rectangle.BOTTOM);
				table.addCell(header);
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Page %d of", writer.getCurrentPageNumber()));
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.BOTTOM);
				table.addCell(cell);
				table.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
			}
			catch(DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		/**
		 * Fills out the total number of pages before the document is closed.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onCloseDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT,
					new Phrase(String.valueOf(writer.getCurrentPageNumber() - 1)),
					2, 2, 0);
		}
	}




	public  PdfPTable createTableHeaders() throws DocumentException  {
		BaseFont base = null;
		try {
			base = BaseFont.createFont("c:/windows/fonts/ARIALUNI.ttf", BaseFont.IDENTITY_H, false);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Font Wfont = new Font(base, 12, Font.NORMAL);
		PdfPTable table = new PdfPTable(1);
		table.setTotalWidth(475);
		table.setLockedWidth(true);
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);
		// we add a cell with colspan 3
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD,BaseColor.BLACK);
		Image blackBoxImg = null;
		Image whiteBoxImg = null;
		try {
			blackBoxImg = Image.getInstance("blackbox.gif");
			whiteBoxImg = Image.getInstance("whitebox.gif");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		String stringHeader = " S = Standard Equipment"+"\t \t \t"+" A = Available"+"\t \t \t"+" --(dashes) = Not Available \t \t \t D = ADI Available \n";
		String stringBlack =  " = Included in Equipment Group"+"";
		String stringWhite =  " = Included in Equipment Group but upgradeable\n";
		if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
			stringHeader = " S = �quipement de s�rie "+"\t\t"+" A = Livrables "+"\t\t"+" --(Tirets) = Non Disponible\n";
			stringBlack =  " = Compris dans le groupe d'�quipements  "+"";
			stringWhite =  " = Compris dans le groupe d'�quipements, mais peut �tre mis � niveau.\n";
		}

		String ending="";
		String truckDesc="";
		if(headerHelper.get(0).getDivisionID()!=null){
			if(headerHelper.get(0).getDivisionID().intValueExact()==1 || headerHelper.get(0).getDivisionID().intValueExact()==2){

				truckDesc = "\n* Indicates availability of feature on multiple models. For example, it indicates feature availability on 2WD and 4WD Models or Rear wheel drive and"+
						" All-wheel drive Models. ";
				if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
					truckDesc = "\n* Indique disponibilit� de ce type sur plusieurs mod�les. Par exemple, il indique la disponibilit� des fonctions sur les mod�les 2RM et 4RM ou propulsion arri�re et toutes roues motrices mod�les.";
				}

			}
		}
		else{
			truckDesc="";
		}
		ending ="Codes listed in the shaded column titled Ref. Only RPO Code are for internal use only and should not be ordered. ";

		if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
			ending = "Les codes �num�r�s dans la colonne ombrag�e intitul�e Code �FC de r�f. sont pour usage interne seulement et ne doivent pas �tre command�s. ";
		}	
		Paragraph paragraph_black = new Paragraph();
		paragraph_black.setAlignment(Element.ALIGN_CENTER);
		paragraph_black.add(new Phrase(stringHeader, tableHeader1));
		if (blackBoxImg != null) {
			whiteBoxImg.scalePercent(60f);
			blackBoxImg.scalePercent(60f);
			paragraph_black.add(new Phrase("\u25A0", Wfont));
		}
		paragraph_black.add(new Phrase(stringBlack, tableHeader1));
		paragraph_black.add(new Phrase("  ", tableHeader1));
		paragraph_black.add(new Phrase("\u25A1", Wfont));
		paragraph_black.add(new Phrase(stringWhite, tableHeader1));
		Paragraph temp;
		PdfPCell cell1 = new PdfPCell(paragraph_black);
		temp = new Paragraph();
		temp.add(truckDesc);
		temp.setLeading(1f, 1f);
		temp.setFont(tableHeader1);
		temp.setAlignment(Element.ALIGN_LEFT);
		//paragraph_black.add(temp);
		cell1.addElement(paragraph_black);
		cell1.addElement(temp);
		
		temp = new Paragraph();
		temp.add(ending);
		temp.setFont(boldContentFont);
		temp.setAlignment(Element.ALIGN_LEFT);
		//paragraph_black.add(new Phrase(ending, boldContentFont));
		
		//cell1.addElement(paragraph_black);
		cell1.addElement(temp);
		cell1.setPaddingBottom(6f);
		cell1.setPaddingLeft(8f);
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell1.setVerticalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell1);
		return table;
	}

	public  PdfPTable createTable(Object tableContent,Object availabilityCodes, 
			List<StdEqpHelper>  stdEqpHelperList, int currentPage,List<HashMap<BigDecimal, ArrayList<String>>> packageNameMap) throws DocumentException {
		this.stdEqpHelperList = stdEqpHelperList;
		vehicleItemsXML = (List<StandardEqpBean>)tableContent;
		availableCodeList = (List<StandardEqpBean>)availabilityCodes;
		if(!availableCodeList.isEmpty()){
			PdfPTable table = new PdfPTable(1);
			table.getDefaultCell().setBorder(0);
			table.getDefaultCell().setPadding(0);
			PdfPTable table1 = null;
			PdfPTable table3;
			PdfPTable table2;
			table.setExtendLastRow(false);
	
			table.setTotalWidth(475);
			table.setLockedWidth(true);

			int columnSizeNewTable =0;
			for (BigDecimal modelListIteratorCol_count : modelList) {
				for (StdEqpHelper stdEqpHelper : stdEqpHelperList) {
					if(stdEqpHelper.getPackageDescID().equals(modelListIteratorCol_count) && stdEqpHelper.getPageNumber().intValueExact()==currentPage)
					{

						columnSizeNewTable++;
					}
				}

			}




			table.getDefaultCell().setBorder(0);
			PdfPCell cell;
			com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
			com.itextpdf.text.Font boldFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.WHITE);
			com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
			com.itextpdf.text.Font imageFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL,BaseColor.BLACK);
			com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD,BaseColor.BLACK);
			com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA, 6, Font.BOLD,BaseColor.BLACK);

			//String	fontpath="c://reports//wingding.ttf";
			/*FontFactory.register("c://reports//wingding.ttf");
			BaseFont wingdingsFont;
			com.itextpdf.text.Font  textFont = FontFactory.getFont("wingding", BaseFont.IDENTITY_H, 
				    BaseFont.EMBEDDED, 5);*/
			BaseFont base = null;
			try {
				base = BaseFont.createFont("c:/windows/fonts/ARIALUNI.ttf", BaseFont.IDENTITY_H, false);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Font Wfont = new Font(base, 12, Font.NORMAL);
			Font superBoldScriptfont = new Font(base, 11, Font.NORMAL);
			Font superScriptfont = new Font(base, 10, Font.NORMAL);
			Font superScriptfont_white = new Font(base, 12, Font.NORMAL);
			superScriptfont_white.setColor(BaseColor.WHITE);
			table.setTotalWidth(475);
			table.setLockedWidth(true);
			table.setSplitLate(false);
			//table.set
			table.setHeaderRows(1);
			//table.setFooterRows(1);

			//	table.setTableEvent(new RepeatSplitEvent());
			cell = new PdfPCell(new Phrase("Cell with rowspan 2"));
			Phrase phrase = new  Phrase("S = Standard Equipment A = Available --(dashes) = Not Available \n",tableHeader1);
			Image blackBoxImg = null;
			Image whiteBoxImg = null;
			try {
				blackBoxImg = Image.getInstance("blackbox.gif");
				whiteBoxImg = Image.getInstance("whitebox.gif");
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			String stringHeader = " S = Standard Equipment"+"\t\t"+" A = Available"+"\t\t"+" --(dashes) = Not Available \n \n";
			String stringBlack =  " = Included in Equipment Group"+"";
			String stringWhite =  " = Included in Equipment Group but upgradeable \n \n\n";
			String ending = /*"*Indicates availability of feature on multiple models. For example, it indicates feature availability on 2WD and 4WD Models or Rear wheel drive and"+
				"All-wheel drive Model. \n*/
					"Codes listed in the shaded column titled Ref. Only RPO Code are for internal use only and should not be ordered. ";

			Paragraph paragraph_black = new Paragraph();
			paragraph_black.setAlignment(Element.ALIGN_RIGHT);
			paragraph_black.add(new Phrase(stringHeader, tableHeader1));
			if (blackBoxImg != null) {
				whiteBoxImg.scalePercent(90f);
				paragraph_black.add(new Chunk( blackBoxImg, 1f, 1f));
			}
			paragraph_black.add(new Phrase(stringBlack, tableHeader1));
		//	paragraph_black.add(new Phrase(" ", tableHeader1));
		//	paragraph_black.add(new Chunk( whiteBoxImg, 1f, 1f));
			paragraph_black.add(new Phrase(stringWhite, tableHeader1));

			paragraph_black.add(new Phrase(ending, boldContentFont));
			PdfPCell cell1 = new PdfPCell(paragraph_black);
			cell1.setPaddingBottom(4f);
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setVerticalAlignment(Element.ALIGN_CENTER);
			//headerText = cell1;
			PdfPCell cell2 = new PdfPCell();
			//	table.addCell(cell2);

			//phrase.add(chunk);
			/*	cell = new PdfPCell(new Phrase("S = Standard Equipment A = Available -- (dashes) = Not Available \n"
				+ " = Included in Equipment Group = Included in Equipment Group but upgradeable \n"
				+" *Indicates availability of feature on multiple models. For example, it indicates feature availability on 2WD and 4WD Models or Rear wheel drive and \n"+
				"All-wheel drive Models.",tableHeader1));*/
			cell = new PdfPCell(phrase);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			//	table.addCell(cell);
			cell.setBorder(0);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setBorder(Rectangle.NO_BORDER);

			//	cell.setBackgroundColor(BaseColor.BLACK);
			Set<String> mySet = new HashSet<String>();

			int colulmns=0;


			Map<Integer,String> packageNameSet = new TreeMap<Integer,String>();
			restrictionIDList.clear();
			packageRestrictionIDList.clear();
			for (StdEqpHelper stdHelper : stdEqpHelperList) {
				pageLabelCount.add(stdHelper.getPageLabel());
				if(stdHelper.getPageNumber().intValueExact()==currentPage ){
					colulmns++;
					String packageDesc1= stdHelper.getPackageDesc1();
					if(stdHelper.getPackageDesc2()!="null"){
						packageDesc1 += " \n"+ stdHelper.getPackageDesc2();
					}
					packageNameSet.put(stdHelper.getPackageSort().intValueExact(),packageDesc1);
					pageLabel = stdHelper.getPageLabel();
					if(stdHelper.getRestrictionID()!=null)
					{
						if(!restrictionIDList.contains(stdHelper.getRestrictionID().intValueExact())){
							restrictionIDList.add(stdHelper.getRestrictionID().intValueExact());
						}
					}

					if(stdHelper.getPackageRestrictionID()!=null)
					{
						if(!packageRestrictionIDList.contains(stdHelper.getPackageRestrictionID().intValueExact())){

							packageRestrictionIDList.add(stdHelper.getPackageRestrictionID().intValueExact());

						}
					}
				}
			}

			Collections.sort(restrictionIDList);
			//	Collections.sort(packageRestrictionIDList);

			for (Iterator itr = packageNameSet.entrySet().iterator(); itr.hasNext();)
			{
				Map.Entry<Integer, String> entrySet = (Map.Entry) itr.next();

				String value = entrySet.getValue();

				if (!mySet.add(value))
				{
					itr.remove();               
				}
			} 

			cell.setBackgroundColor(new BaseColor(204,204,204));
			float sizeColumns=0;
			float[] columnsArray = new float[3+packageNameSet.size()] ;
			columnsArray[0]=35.2f;
			columnsArray[1]=35.2f;


			if(colulmns==1 || packageNameSet.size()==0){
				columnsArray[2]=366f;
				sizeColumns=38.60f;
			}


			else if(colulmns==2){
				columnsArray[2]=313f;
				sizeColumns = 91.6f/colulmns;
			}
			else if(colulmns==3){
				columnsArray[2]=265f;
				sizeColumns = 139.6f/colulmns;
			}
			else if(colulmns==4){
				columnsArray[2]=217.7f;
				sizeColumns = 187f/colulmns;
			}

			else if(colulmns==5){
				columnsArray[2]=151.1f;
				sizeColumns = 253.5f/colulmns;
			}
			else if(colulmns==6){
				columnsArray[2]=205.7f;
				sizeColumns = 198.9f/colulmns;
			}
			else if(colulmns==7){
				columnsArray[2]=170f;
				sizeColumns = 234.6f/columnSizeNewTable;
			}

			else {
				columnsArray[2]=150.8f;
				sizeColumns = 253.80f/colulmns;
			}

			for (int i = 3; i < packageNameSet.size()+3; i++) {
				columnsArray[i]=sizeColumns;
			}


			PdfPTable	table4 = new PdfPTable(4);
			table4 = new PdfPTable(4);
			table4.getDefaultCell().setBorder(0);
			table4.getDefaultCell().setPadding(0);
			table4.setTotalWidth(475);
			cell.setBackgroundColor(new BaseColor(204,204,204));
			table4.setWidths(new float[] {columnsArray[0],columnsArray[1],columnsArray[2],(475-(70.4f+columnsArray[2]))});
			table4.setLockedWidth(true);
			cell.setBackgroundColor(new BaseColor(204,204,204));
			//table4.setWidths(new int[]{30,30,200,(int) 33.3,33,33,33});
			//table4.setLockedWidth(true);

			if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
				cell = new PdfPCell(new Phrase("Code \n �FC ind�pendant",boldContentFont));
			}
			else{
				cell = new PdfPCell(new Phrase("Free \n Flow \n RPO \n Code",boldContentFont));
			}
			cell.setNoWrap(false);
			cell.setMinimumHeight(55f);
			cell.setPaddingTop(8f);
			cell.setPaddingTop(3f);
			cell.setLeading(1, 1.5f);
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			//cell.setBorder(Rectangle.NO_BORDER);
			table4.addCell(cell);

			if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
				cell = new PdfPCell(new Phrase("Code.\n �FC \n de r�f. seulement",boldContentFont));
			}

			else
			{
				cell = new PdfPCell(new Phrase("Ref.\n Only \n RPO\n Code",boldContentFont));
			}

			cell.setNoWrap(false);
			cell.setPaddingTop(8f);
			cell.setLeading(1, 1.5f);
			cell.setPaddingTop(3f);
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table4.addCell(cell);


			String restriction = "";
			int countRest=1;
			List<String>restrictionList = new ArrayList<String>();
			for (StdEqpHelper stdHelper : stdEqpHelperList) {
				if(stdHelper.getPageNumber().intValueExact()==currentPage && !(stdHelper.getPackageRestrictionDesc().equalsIgnoreCase("null"))){

					if (!restrictionList.contains(stdHelper.getPackageRestrictionDesc().trim())) {
						restrictionList.add(stdHelper.getPackageRestrictionDesc().trim());
						restriction+=countRest+" - "+stdHelper.getPackageRestrictionDesc().trim()+"\n";
						countRest++;
					}

				}
			}
			LineSeparator ls = new LineSeparator();
				
			Paragraph ph = new Paragraph();
			ph.setFont(boldContentFont);
			ph.add(" Description"+"\n");
			ph.setAlignment(Element.ALIGN_CENTER);
			ph.add(restriction.trim()+"\n");
			ls.setLineWidth(0.5f);
			ls.setPercentage(102f);
			
			if(headerHelper.get(0).getRegionID()!=null && headerHelper.get(0).getRegionID().intValueExact()!=14 && headerHelper.get(0).getRegionID().intValueExact()!=1){
				ph.add(new Chunk(ls));
				ph.add("\n\n PREFERRED EQUIPMENT GROUP");
				ph.setFont(boldContentFont);
			}
			
			cell = new PdfPCell(ph);
			cell.setLeading(1f, 1.2f);
			cell.setNoWrap(false);
			cell.setPaddingTop(5);
			cell.setPaddingBottom(5);
			cell.setPaddingLeft(4);
	//		cell.setLeading(1f, 1f);
			cell.setBackgroundColor(new BaseColor(204,204,204));
			//cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			//cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table4.addCell(cell);

			PdfPTable packageNameTable=null;
			if(modelList.size()==0){

				packageNameTable = new PdfPTable(4);
			}
			else{
				packageNameTable = new PdfPTable(columnSizeNewTable);
			}

			columnsArray = null;
			columnsArray = new float[columnSizeNewTable];
			for (int i = 0; i <columnSizeNewTable; i++) {
				columnsArray[i]=257/columnSizeNewTable;
			}
			packageNameTable.setWidths(columnsArray);
			cell.setFixedHeight(22f);
			packageNameTable.getDefaultCell().setBorder(0);
			packageNameTable.getDefaultCell().setPadding(0);
			//	packageNameTable.getDefaultCell().setColspan(packageCount);
			PdfPCell packageDescCell;
			int packageCount = 0;
			Set<Integer> keys = packageNameSet.keySet();
			ArrayList<BigDecimal> tempModelList = new ArrayList<BigDecimal>(modelList.size());
			for (BigDecimal modelListIterator : modelList) {
				for (StdEqpHelper stdEqpHelper : stdEqpHelperList) {
					if(stdEqpHelper.getPackageDescID().equals(modelListIterator) &&stdEqpHelper.getPageNumber().intValueExact()==currentPage )
					{
						if(stdEqpHelper.getPackageDesc2()=="null")
						{
							stdEqpHelper.setPackageDesc2("");
						}
						if (headerHelper.get(0).getDivisionID().intValueExact()!=4 && headerHelper.get(0).getDivisionID().intValueExact()!=5)
						{
							if(stdEqpHelper.getModelName()!=null && headerHelper.get(0).getDivisionID().intValueExact()!=1 && headerHelper.get(0).getDivisionID().intValueExact()!=2){

								packageDescCell = new PdfPCell(new Phrase(stdEqpHelper.getPackageDesc1()+"\n"+stdEqpHelper.getModelName(),boldContentFont1));
							}
							else if (headerHelper.get(0).getDivisionID().intValueExact()==1 
									&& headerHelper.get(0).getRegionID().intValueExact()!=1
									&& headerHelper.get(0).getRegionID().intValueExact()!=14){
								
								packageDescCell = new PdfPCell(new Phrase(stdEqpHelper.getPackageDesc1()+"\n"+stdEqpHelper.getPackageDesc2(),boldContentFont1));		
							}
							else {
								packageDescCell = new PdfPCell(new Phrase(stdEqpHelper.getPackageDesc1()+"\n"+stdEqpHelper.getPackageDesc2(),boldContentFont1));		
							}

						}
						else{
							if(headerHelper.get(0).getDivisionID().intValueExact()!=1 && headerHelper.get(0).getDivisionID().intValueExact()==5)
							{
								
								packageDescCell = new PdfPCell(new Phrase(stdEqpHelper.getPackageDesc1()+"\n"+stdEqpHelper.getPackageDesc2(),boldContentFont1));
							}
							else if(stdEqpHelper.getModelDesc()!=null && headerHelper.get(0).getDivisionID().intValueExact()==4){
								if(stdEqpHelper.getPackageDesc2()=="null"){
									stdEqpHelper.setPackageDesc2("");
								}
								packageDescCell = new PdfPCell(new Phrase(stdEqpHelper.getPackageDesc1()+"\n"+stdEqpHelper.getPackageDesc2(),boldContentFont1));
							}
							else if(stdEqpHelper.getModelDesc()!=null && headerHelper.get(0).getDivisionID().intValueExact()!=1){
								packageDescCell = new PdfPCell(new Phrase(stdEqpHelper.getModelName()+"\n"+stdEqpHelper.getModelDesc(),boldContentFont1));
							}
							else{
								packageDescCell = new PdfPCell(new Phrase(stdEqpHelper.getModelName(),boldContentFont1));		
							}


						}

						packageDescCell.setBackgroundColor(new BaseColor(204,204,204));
						packageDescCell.setNoWrap(false);
						//packageDescCell.setColspan(packageCount);
						packageDescCell.setPaddingBottom(5);
						packageDescCell.setLeading(1, 1.5f);
						packageDescCell.setPaddingTop(5);
						packageDescCell.setVerticalAlignment(Element.ALIGN_CENTER);
						packageDescCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						packageDescCell.setColspan(packageNameList.get(modelListIterator).size());
						packageDescCell.setColspan(packageNameMap.get(currentPage-1).get(modelListIterator).size());
						if(!tempModelList.contains(modelListIterator)){
							packageNameTable.addCell(packageDescCell);
						}
						tempModelList.add(modelListIterator);
					}
				}

			}
			for (BigDecimal modelListIterator : modelList) {
				for (StdEqpHelper stdEqpHelper : stdEqpHelperList) {
					if(stdEqpHelper.getPackageDescID().equals(modelListIterator) && stdEqpHelper.getPageNumber().intValueExact()==currentPage)
					{
						if(stdEqpHelper.getPackageRestrictionID()== null){
							stdEqpHelper.setPackageRestrictionID(new BigDecimal(10));
						}
						if(headerHelper.get(0).getDivisionID().intValueExact()!=3 && 
								headerHelper.get(0).getDivisionID().intValueExact()!=4 &&
								headerHelper.get(0).getDivisionID().intValueExact()!=2
								&& headerHelper.get(0).getDivisionID().intValueExact()!=5){
							if(stdEqpHelper.getTrimName()!=null && !stdEqpHelper.getTrimName().equals("null") && (headerHelper.get(0).getRegionID().intValueExact()==14 || headerHelper.get(0).getRegionID().intValueExact()==1)){
								Phrase ph1 = new Phrase(stdEqpHelper.getPackageName()+"\n"+stdEqpHelper.getTrimName(),boldContentFont1);
								Phrase ph2 = new Phrase(restrictionFlag_package(stdEqpHelper.getPackageRestrictionID().intValueExact()),superBoldScriptfont);
								ph1.add(ph2);
								packageDescCell = new PdfPCell(ph1);	
							}
							else
							{
								Phrase ph1 = new Phrase(stdEqpHelper.getPackageName(),boldContentFont1);
								Phrase ph2 = new Phrase(restrictionFlag_package(stdEqpHelper.getPackageRestrictionID().intValueExact()),superBoldScriptfont);
								ph1.add(ph2);
								packageDescCell = new PdfPCell(ph1);
							}						
						}
						else 
						{
							if(stdEqpHelper.getTrimName()!=null && !stdEqpHelper.getTrimName().equals("null") && (headerHelper.get(0).getRegionID().intValueExact()==14 ||headerHelper.get(0).getRegionID().intValueExact()==1) ){
								Chunk chunk;
								if(stdEqpHelper.getTrimName().equalsIgnoreCase(stdEqpHelper.getPackageName()))
								{
									 chunk = new Chunk(stdEqpHelper.getTrimName(),boldContentFont1);
								}
								else{
									 chunk = new Chunk(stdEqpHelper.getTrimName()+"\n"+stdEqpHelper.getPackageName(),boldContentFont1);
								}
									chunk.setHyphenation(new HyphenationAuto("de", "DE", 0,6));
								Phrase ph1 = new Phrase(chunk);
								Phrase ph2 = new Phrase(restrictionFlag_package(stdEqpHelper.getPackageRestrictionID().intValueExact()),superBoldScriptfont);
								ph1.setFont(boldContentFont1);
								ph1.add(ph2);
								packageDescCell = new PdfPCell(ph1);	
							}
							else
							{
								Phrase ph1 = new Phrase(stdEqpHelper.getPackageName(),boldContentFont1);
								Phrase ph2 = new Phrase(restrictionFlag_package(stdEqpHelper.getPackageRestrictionID().intValueExact()),superBoldScriptfont);
								ph1.add(ph2);
								packageDescCell = new PdfPCell(ph1);
							}

						}
						packageDescCell.setBackgroundColor(new BaseColor(204,204,204));
						packageDescCell.setNoWrap(false);
						packageDescCell.setColspan(packageCount);
								packageDescCell.setPaddingBottom(2);
						packageDescCell.setLeading(1, 1.5f);
						//	packageDescCell.setPaddingTop(5);
						//	packageDescCell.setMinimumHeight(3f);
						packageDescCell.setVerticalAlignment(Element.ALIGN_CENTER);
						packageDescCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						packageNameTable.addCell(packageDescCell);
					}
				}

			}


			table4.addCell(packageNameTable);
			//headerTable.addCell(headerText);
			//	headerTable.addCell(table4);

			//headerTable = table4;

			table1 = new PdfPTable(3+columnSizeNewTable);
			table1.setTotalWidth(475);
			float[] columnsArrayTable = new float[3+columnSizeNewTable] ;
			columnsArrayTable[0]=35.2f;
			columnsArrayTable[1]=35.2f;
			float sizeColumns1=0;

			if(colulmns==1){
				columnsArrayTable[2]=366f;
				sizeColumns1=38.60f;
			}


			else if(colulmns==2){
				columnsArrayTable[2]=313;
				sizeColumns1 = 91.6f/columnSizeNewTable;
			}
			else if(colulmns==3){
				columnsArrayTable[2]=265;
				sizeColumns1 = 139.6f/columnSizeNewTable;
			}
			else if(colulmns==4){
				columnsArrayTable[2]=217.7f;
				sizeColumns1 = 187f/columnSizeNewTable;
			}
			else if(colulmns==5){
				columnsArrayTable[2]=151.1f;
				sizeColumns1 = 253.5f/columnSizeNewTable;
			}
			else if(colulmns==6){
				columnsArrayTable[2]=205.7f;
				sizeColumns1 = 198.9f/columnSizeNewTable;
			}

			else if(colulmns==7){
				columnsArrayTable[2]=170f;
				sizeColumns1 = 234.6f/columnSizeNewTable;
			}

			else {
				columnsArrayTable[2]=150.8f;
				sizeColumns1 = 253.80f/columnSizeNewTable;
			}

			for (int i = 3; i < columnsArrayTable.length; i++) {
				columnsArrayTable[i]=sizeColumns1;
			}

			table1.setWidths(columnsArrayTable);


			for (StandardEqpBean foreachRow : vehicleItemsXML){
				restrictionIDList.clear();
				boolean foundMatch = false;
				Image image = null;

				cell = new PdfPCell();
				cell.addElement(image);
				/*if(table1.getTotalHeight()>200){
				document.newPage();
			}*/

				//availableCodeList
				String tempStr = "";
				String extDesc ="";


				List <String> tempResList = new ArrayList<String>();
				int count=1;
				boolean isFreeRpo= false;
				for (StandardEqpBean loop1 : availableCodeList){


					if(foreachRow.getRpoId().equals(loop1.getRpoId()))
					{
						if(loop1.getAvailableCodeID().intValueExact()==2 || loop1.getAvailableCodeID().intValueExact()==10 ){
							isFreeRpo= true;
						}
						if(loop1.getrDescription()!="null" && !tempResList.contains(loop1.getrDescription())){
							restrictionIDList.add(loop1.getRestrictionID().intValueExact());
							tempStr += "\t \t"+count+" - "+loop1.getrDescription().trim()+"\n";
							tempResList.add(loop1.getrDescription());
							count++;
						}
					}
				}
				//				Collections.sort(restrictionIDList);

				if(foreachRow.getExtendedDesc()!="null")
				{
					if(foreachRow.getrDescription()!="null"){
						extDesc = foreachRow.getExtendedDesc();
					}
					else{
						extDesc = "";
					}
				}
				String rpoDesc = "";
				if(foreachRow.getRpoDesc()!="null")
				{
					if(foreachRow.getRpoDesc()!="null"){
						rpoDesc = foreachRow.getRpoDesc();
					}
					else{
						rpoDesc = "";
					}
				}
				String isNew="";

				if(foreachRow.getTypeFlag().intValueExact()==0){
					foreachRow.setRpoName("");
				}
				if(foreachRow.getNewOptionFLag()!=null && foreachRow.getNewOptionFLag().intValueExact()==1)
				{
					if(headerHelper.get(0).getLocaleCode()!= null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
						isNew ="Nouveau! ";
					}
					else
						isNew = "NEW! ";
				}
				if(isFreeRpo){
					insertCell(table1,"","",foreachRow.getRpoName(),null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
					insertCell(table1,"",null,"",null, Element.ALIGN_CENTER, 1, tableHeader1,new BaseColor(204,204,204));
				}
				else
				{
					insertImage(table1,cell, Element.ALIGN_CENTER, 1, tableHeader1);
					//insertCell(table1,image, Element.ALIGN_LEFT, 1, tableHeader1);	
					insertCell(table1,"",null,foreachRow.getRpoName(),null, Element.ALIGN_CENTER, 1, tableHeader1,new BaseColor(204,204,204));	

				}

				insertCell(table1,isNew , foreachRow.getRpoDescBold(),rpoDesc+extDesc+"\n",tempStr, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);	
				/*	insertCell(table1,"Test3", Element.ALIGN_LEFT, 1, tableHeader1);	
				insertCell(table1,"Test4", Element.ALIGN_LEFT, 1, tableHeader1);	
				insertCell(table1,"Test5", Element.ALIGN_LEFT, 1, tableHeader1);*/

				for (BigDecimal foreachColumn : packageIDList){
					foundMatch = false;

					for (StandardEqpBean foreachCell : availableCodeList){
						if(foreachCell.getRestrictionID()==null){
							foreachCell.setRestrictionID(new BigDecimal(10));
						}
						if((foreachCell.getRpoId().equals(foreachRow.getRpoId())&&foreachCell.getPackageID().equals(foreachColumn) && modelList.contains(foreachCell.getPackageDescID()))){
							foundMatch = true;
							if(foreachCell.getAvailableCode().equalsIgnoreCase("I")){
								foreachCell.setAvailableCode("A");
							}
							if(foreachCell.getAvailableCode().equalsIgnoreCase("I/D")){
								foreachCell.setAvailableCode("A/D");
							}

							if((!foreachCell.getrDescription().equalsIgnoreCase("null")) && (foreachCell.getrDescription()!=null)){

								if(foreachCell.getAvailableCodeID().intValue()==5)
								{

									PdfPCell imgCell = new PdfPCell();
									//	blackBoxImg.scaleAbsolute(4, 4);
									//	imgCell.addElement(blackBoxImg);
									imgCell.setPaddingTop(-2f);
									imgCell.setPaddingLeft(15f);

									if(foreachCell.getRestrictionID()!=null){
										Phrase p = new Phrase("\u25A0" + restrictionFlag(foreachCell.getRestrictionID().intValueExact()),Wfont);
										if(foreachCell.getRestrictionID().intValueExact()==10) {
											p = new Phrase("\u25A0",Wfont);
											Phrase	ph2 = new Phrase(restrictionFlag(foreachCell.getRestrictionID().intValueExact()),superScriptfont_white);
											p.add(ph2);
										}
										imgCell.addElement(p);
										//imgCell.setPaddingTop(4f);
										//imgCell.setPaddingLeft(4f);
										imgCell.setPaddingTop(-2f);
										imgCell.setPaddingLeft(15f);
										insertCustomCell(table1,null,p,null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
									}
									//insertImage(table1, imgCell, Element.ALIGN_CENTER, 1, imageFont);

								}

								else	if(foreachCell.getAvailableCodeID().intValue()==6)
								{

									PdfPCell imgCell = new PdfPCell();
									Phrase p = new Phrase("\u25A1" + restrictionFlag(foreachCell.getRestrictionID().intValueExact()),Wfont);
									if(foreachCell.getRestrictionID().intValueExact()==10) {
										p = new Phrase("\u25A1",Wfont);
										Phrase	ph2 = new Phrase(restrictionFlag(foreachCell.getRestrictionID().intValueExact()),superScriptfont_white);
										p.add(ph2);
									}
									imgCell.addElement(p);
									imgCell.setPaddingTop(-2f);
									imgCell.setPaddingLeft(15f);
									//	insertImage(table1, imgCell, Element.ALIGN_CENTER, 1, imageFont);
									insertCustomCell(table1,null,p,null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
								}

								else

								{
									if(foreachCell.getRestrictionID()!=null){Phrase ph1 = new Phrase(foreachCell.getAvailableCode(),tableHeader1);
									Phrase ph2 = new Phrase(restrictionFlag(foreachCell.getRestrictionID().intValueExact()),Wfont);
									if(foreachCell.getRestrictionID().intValueExact()==10){
										
										ph1 = new Phrase(foreachCell.getAvailableCode(),tableHeader1);
										ph2 = new Phrase(restrictionFlag(foreachCell.getRestrictionID().intValueExact()),superScriptfont_white);
										
									}
									ph1.add(ph2);
									insertCustomCell(table1,null,ph1,null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
									}
								}


							}


							else{
								//		

								if(foreachCell.getAvailableCodeID().intValue()==5)
								{

									PdfPCell imgCell = new PdfPCell();
									//	blackBoxImg.scaleAbsolute(4, 4);
									//	imgCell.addElement(blackBoxImg);
									Phrase p = new Phrase("\u25A0",Wfont);
									imgCell.addElement(p);
									imgCell.setPaddingTop(-2f);
									imgCell.setPaddingLeft(12f);

									if(foreachCell.getRestrictionID()!=null){
										p = new Phrase("\u25A0" + restrictionFlag(foreachCell.getRestrictionID().intValueExact()),Wfont);
										
										if(foreachCell.getRestrictionID().intValueExact()==10) {
											p = new Phrase("\u25A0",Wfont);
											Phrase	ph2 = new Phrase(restrictionFlag(foreachCell.getRestrictionID().intValueExact()),superScriptfont_white);
											p.add(ph2);
										}
										imgCell.addElement(p);
										imgCell.setPaddingTop(-2f);
										imgCell.setPaddingLeft(15f);
									}
									//	insertImage(table1, imgCell, Element.ALIGN_CENTER, 1, imageFont);
									insertCustomCell(table1,null,p,null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
								}

								else	if(foreachCell.getAvailableCodeID().intValue()==6)
								{

									PdfPCell imgCell = new PdfPCell();
									Phrase p = new Phrase("\u25A1" + restrictionFlag(foreachCell.getRestrictionID().intValueExact()),Wfont);
									if(foreachCell.getRestrictionID().intValueExact()==10) {
										p = new Phrase("\u25A1",Wfont);
										Phrase	ph2 = new Phrase(restrictionFlag(foreachCell.getRestrictionID().intValueExact()),superScriptfont_white);
										p.add(ph2);
									}
									imgCell.addElement(p);
									imgCell.setPaddingTop(-2f);
									imgCell.setPaddingLeft(15f);
									//insertImage(table1, imgCell, Element.ALIGN_CENTER, 1, imageFont);
									insertCustomCell(table1,null,p,null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
								}
								else {
									Phrase p = new Phrase(foreachCell.getAvailableCode() + restrictionFlag(foreachCell.getRestrictionID().intValueExact()),tableHeader1);
									if(foreachCell.getRestrictionID().intValueExact()==10) {									
										Phrase	ph2 = new Phrase(restrictionFlag(foreachCell.getRestrictionID().intValueExact()),superScriptfont_white);
										p.add(ph2);
									}
									
									insertCustomCell(table1,null,p,null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
									//insertCell(table1,"",null,foreachCell.getAvailableCode(),null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
								}
							}
							/*	insertCell(table1,"Test4", Element.ALIGN_LEFT, 1, tableHeader1);	
					insertCell(table1,"Test5", Element.ALIGN_LEFT, 1, tableHeader1);*/


						}


					}
					if(!foundMatch){
						insertCell(table1,"","","--", "", Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);

					}

				}

			}

			table2 = new PdfPTable(1);
			table2.setTotalWidth(475);

			cell = new PdfPCell();
			cell.setPaddingBottom(15);
			cell.setBorder(Rectangle.NO_BORDER);

			table2.addCell(cell);

			//table.addCell(table2);
			//table.addCell(table3);
			//table.addCell(table1);

			//table.addCell(table3);
			//table.addCell(table3);
			//table.addCell(table3);
			table.addCell(table4);
		//	table1.setExtendLastRow(false);
			table.addCell(table1);
			
			
			
			return table;
		}
		return null;
	}


	private static void insertImage(PdfPTable table, PdfPCell cell,
			int align, int i, Font tableHeader1) {
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);

		//add the call to the table
		table.addCell(cell);

	}


	public void startExteriorPDFGeneration(Object[][] objects, Object[][] availableCodeList,
			List<HashMap<BigDecimal, ArrayList<String>>> packageNameMap,
			List<ArrayList<BigDecimal>> modelList, List<StdEqpHelper> stdHelper,int pdfType) {
		// TODO Auto-generated method stub

		try {

			new ItextPDFGenerator_Exterior().createPdf(null,objects, packageNameMap ,modelList,stdHelper,null,null,pdfType );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	public static void insertCell(PdfPTable table,String isNew,String boldText, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font contentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font redFont1 =  FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.BLACK);

		Paragraph para = new Paragraph();
		if(pdfType==VehicleConstant.PRINTBOOKS || pdfType==VehicleConstant.VEHICLE_PRINT ){

			redFont1 = FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.RED);
		}

		if(isNew!=null){
			para.add(new Phrase(isNew, redFont1));
		}

		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		para.add(new Phrase(text, font));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, contentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row
		if(text.trim().equalsIgnoreCase("")){
			cell.setMinimumHeight(10f);
		}
		//add the call to the table
		table.addCell(cell);

	}

	public static void insertCustomCell(PdfPTable table,String boldText, Phrase p1,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		para.add(p1);
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(1f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row

		//add the call to the table
		table.addCell(cell);

	}




	public String restrictionFlag(int currentRestrictionID){
		String unicodeFlag="";
		boolean isRestrictionExist = false;
		if(currentRestrictionID!=10){
			int restrictionPosition=1;		
			for (Iterator iterator = restrictionIDList.iterator(); iterator
					.hasNext();) {

				Integer restictionId = (Integer) iterator.next();
				if(currentRestrictionID==restictionId){
					isRestrictionExist = true;
					break;
				}
				restrictionPosition++;

			}

			if(unicodeProperties.getProperty(String.valueOf(restrictionPosition))!=null && !unicodeProperties.getProperty(String.valueOf(restrictionPosition)).isEmpty())
			{
				unicodeFlag = unicodeProperties.getProperty(String.valueOf(restrictionPosition));
			}

		}
		if(!isRestrictionExist) {
			unicodeFlag="99";
			if(!unicodeProperties.getProperty(String.valueOf(99)).isEmpty())
			{
				unicodeFlag = unicodeProperties.getProperty(String.valueOf(99));
			}
		}
		return unicodeFlag;


	}


	public String restrictionFlag_package(int currentRestrictionID){
		String unicodeFlag="";
		boolean isRestrictionExist = false;
		if(currentRestrictionID!=10){
			int restrictionPosition=1;

			for (Iterator iterator = packageRestrictionIDList.iterator(); iterator
					.hasNext();) {

				Integer restictionId = (Integer) iterator.next();
				if(currentRestrictionID==restictionId){
					isRestrictionExist = true;
					break;
				}
				restrictionPosition++;

			}

			if(unicodeProperties.getProperty(String.valueOf(restrictionPosition))!=null && !unicodeProperties.getProperty(String.valueOf(restrictionPosition)).isEmpty())
			{
				unicodeFlag = unicodeProperties.getProperty(String.valueOf(restrictionPosition));
			}

		}
		if(!isRestrictionExist) {
			unicodeFlag="";
		}
		return unicodeFlag;
		}
	
	
	public void loadRestriction(){

		unicodeProperties = new Properties();
		inputStream = null;

		try {
			inputStream = new FileInputStream("./Unicode.properties");
			unicodeProperties.load(inputStream);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public class HeaderAndFooter extends PdfPageEventHelper {

		private String name = "";
		PdfTemplate total;

		protected Phrase footer;
		protected Phrase header;

		/*
		 * Font for header and footer part.
		 */
		com.itextpdf.text.Font headerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		/*private static Font headerFont = new Font(Font.COURIER, 9,
	            Font.NORMAL,Color.blue);

	    private static Font footerFont = new Font(Font.TIMES_ROMAN, 9,
	            Font.BOLD,Color.blue);*/


		/*
		 * constructor
		 */
		public HeaderAndFooter(String name) {
			super();
			this.name = name;
			header = new Phrase("***** Header *****");
			footer = new Phrase("**** Footer ****");
		}

		@Override
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
			// TODO Auto-generated method stub
			super.onOpenDocument(writer, document);
		}
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			if(!headerHelper.isEmpty()){
				PdfContentByte cb = writer.getDirectContent();

				//header content
				String headerContent = "Name: " +name;

				//header content
				String footerContent = headerContent;
				/*
				 * Header
				 */
				/*	ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(headerContent,headerFont), 
	                document.leftMargin(), document.top() -30, 0);*/

				/*
				 * Footer
				 */
				DateFormat defDate=null;
				PropertyHelper propertyHelper = new PropertyHelper();
				if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
					defDate  = DateFormat.getDateInstance(DateFormat.LONG,Locale.FRANCE);

					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_FR")!=null && propertyHelper.getProperty("ForcedateOnPDF_FR").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_FR");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
					if(headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+350 , document.bottom()-45, 0);
					}
					else{
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+250 , document.bottom()-45, 0);
					}

				}
				else{
					defDate  = DateFormat.getDateInstance(DateFormat.LONG);
					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_EN")!=null && propertyHelper.getProperty("ForcedateOnPDF_EN").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_EN");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);

					if(headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+350 , document.bottom()-45, 0);
					}
					else{
						
						
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+250 , document.bottom()-45, 0);
					}

				}


				PdfPTable table = new PdfPTable(3);
				table.getDefaultCell().setBorder(0);
				//table.getDefaultCell().setPaddingBottom(25);

				PdfPTable table1 = null;

				table.setTotalWidth(475);
				try {
					table.setWidths(new int[] {150,195,135});
				} catch (DocumentException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setLockedWidth(true);
				PdfPCell cell;

				com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.WHITE);

				//Paragraph p1 = new Paragraph(vehicleItemsXML2.get(0).getVehicleName(),tableHeader);
				//Paragraph p1 = new Paragraph(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader);
				//p1.setAlignment(Element.ALIGN_LEFT);
				cell = new PdfPCell(new Phrase(headerHelper.get(0).getVehicleYear() +" "+ headerHelper.get(0).getDivisionName() +" "+ headerHelper.get(0).getVehicleName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);

				//	cell.addElement(p1);
				table.addCell(cell);

				//Paragraph p2 = new Paragraph("RPO CODES",tableHeader);
				String pageTitle ="EXTERIOR";
				if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
					pageTitle ="EXT�RIEUR";
				}
				if(pageLabelCount.size()>1){
					cell = new PdfPCell(new Phrase(pageTitle + " - " +pageLabel,tableHeader));
				}
				else
				{
					cell = new PdfPCell(new Phrase(pageTitle,tableHeader));
				}
				cell.setMinimumHeight(15f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p2.setAlignment(Element.ALIGN_CENTER);

				//cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				//cell.addElement(p2);

				table.addCell(cell);

				//	Paragraph p3 = new Paragraph(vehicleItemsXML.get(0).getRegionName(),tableHeader);
				cell = new PdfPCell(new Phrase(headerHelper.get(0).getRegionName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p3.setAlignment(Element.ALIGN_RIGHT);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				//cell.addElement(p3);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				cell.setPaddingLeft(2f);

				table.addCell(cell);

				//	table.addCell(table2);
				if(headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){
					table.writeSelectedRows(0, -1, 157, 570, writer.getDirectContent());
				}
				else{
					
					
					table.writeSelectedRows(0, -1, 70, 750, writer.getDirectContent());
				}
			}
			else {
				PdfContentByte cb = writer.getDirectContent();
				DateFormat defDate=null;
				defDate  = DateFormat.getDateInstance(DateFormat.LONG);

				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
						writer.getCurrentPageNumber()),headerFont), 
						document.left()+250 , document.bottom()-45, 0);

			}

		}




	}




	public void startExteriorPDFGeneration(Object[][] objects, Object[][] availableCodeList,
			List<HashMap<BigDecimal, ArrayList<String>>> packageNameMap,
			List<ArrayList<BigDecimal>> modelList, List<StdEqpHelper> stdHelper,
			Document document, PdfWriter writer,int pdfType) {
		try {
			isPOG= true;
			//set boolean here and use it in the main class 
			new ItextPDFGenerator_Exterior().createPdf(null,objects, packageNameMap ,modelList,stdHelper,document, writer,pdfType);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}









}
