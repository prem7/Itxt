package com.dci.jasper.reporter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.dci.enterprise.dao.ItextEngineAxlePDFGeneratorDAO;
import com.dci.enterprise.model.EngineAxleBean;
import com.dci.enterprise.model.EngineAxleContentBean;
import com.dci.enterprise.model.EngineAxleTableHeaders;
import com.dci.enterprise.model.StdEqpHelper;
import com.dci.extrafunc.PropertyHelper;
import com.dci.general.utilities.VehicleConstant;
import com.google.common.base.CaseFormat;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfNumber;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPage;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class ItextPDFGenerator_EngineAxle extends PdfPageEventHelper implements ItextEngineAxlePDFGeneratorDAO {
	//public static final String RESULT = "c:\\reports\\TestingStandardEq.pdf";
	private static List<EngineAxleBean> headerHelper=null;
	private static HashMap<BigDecimal,ArrayList<String>>  packageNameList=null;
	private  List<StdEqpHelper>  stdEqpHelperList=null;
	public static	Document document=null;
	public static String pageLabel;
	public static int tableWidth = 475;
	public static PdfPTable headerTable;
	public static PdfPCell headerText;
	Set<String> pageLabelCount = new HashSet<String>();
	public ArrayList<Integer> restrictionIDList = new ArrayList<Integer>();
	public ArrayList<Integer> packageRestrictionIDList = new ArrayList<Integer>();
	static int coulumnCount=0;
	public static boolean isPOG = false;
	public static int pdfType=0;
	private	List<EngineAxleBean> rowHeaderList;
	public static Properties unicodeProperties;
	InputStream inputStream = null;
	private	List<EngineAxleContentBean> engineAxleContentList;
	private	List<EngineAxleTableHeaders> engineAxleHeaderList;
	private	List<EngineAxleTableHeaders> temp_engineAxleHeaderList;
	public static int pageNumber = 0;
	private	List<List<EngineAxleTableHeaders>> master_engineAxleHeaderList = new ArrayList<List<EngineAxleTableHeaders>>();
	public void createPdf( List<ArrayList<Object>> engineAxleList, Document document, PdfWriter writer)
			throws IOException, DocumentException {

		//this.packageNameList = packageNameMap;
		PdfPTable headerTable = null;
		PdfPTable tableDesc = null;
		PdfPTable tableContent = null;
		headerHelper = null;
		PropertyHelper propertyHelper = new PropertyHelper();
		String location = propertyHelper.getProperty("pdfDefaultLocation");
		headerHelper = (List<EngineAxleBean>)engineAxleList.get(0).get(0);
		loadRestriction();
		if(headerHelper!=null && !headerHelper.isEmpty()  ){
			if(pdfType==0){
				// step 1
				if( headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){

					document = new Document(PageSize.LETTER.rotate(), 100, 50, 20, 25);
					document.setPageSize(PageSize.LETTER.rotate());
					document.setMargins(72,72,85, 72);
					document.newPage();
					tableWidth = 575;
				}
				else{
					document = new Document(PageSize.LETTER, 25, 20, 50, 100);
					document.setMargins(72,72, 75, 115);
					tableWidth=475;
				}



				String fileName = headerHelper.get(0).getVehicleId()+"-"+"engineAxle_fo";
				if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
					fileName+="_fr";
				}
				// step 2
				writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));

				// step 3
				document.open();

			}
			if(pdfType!=0){

				if( headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){
					document.setPageSize(PageSize.LETTER.rotate());
					document.setMargins(72,72,85, 72);
					document.newPage();
					tableWidth = 575;

				}
				else
					tableWidth=475;
			}

			/*document.setPageSize(PageSize.LETTER.rotate());
			document.setMargins( 100, 50, 20, 25);*/
			/*	Rotate rotation = new Rotate();
			writer.setPageEvent(rotation);*/
			writer.setPageEvent(new HeaderAndFooter(""));
			// step 4
			int defaultColSize =2;
			if(headerHelper.get(0).getColumnBreak()!=null){
				defaultColSize = headerHelper.get(0).getColumnBreak().intValueExact();
			}
			
			/*for(int k = 0 ; k< 3 ; k++){
				temp_engineAxleHeaderList = new ArrayList<EngineAxleTableHeaders>();
				engineAxleHeaderList = (List<EngineAxleTableHeaders>)engineAxleList.get(k).get(1);
				
				for (int j = 0; j < engineAxleHeaderList.size(); j++) {
					temp_engineAxleHeaderList.add(engineAxleHeaderList.get(j));
				}
					master_engineAxleHeaderList.add(k,(List<EngineAxleTableHeaders>) temp_engineAxleHeaderList);
				}


			engineAxleHeaderList = (List<EngineAxleTableHeaders>)engineAxleList.get(1).get(1);	
			engineAxleHeaderList.remove(0);*/
			
			
			 pageNumber = 0;
			 
				for (int pageNum = 0; pageNum<engineAxleList.size(); pageNum++) {

					//	rowHeaderList = (List<EngineAxleBean>)engineAxleList.get(pageNum).get(0);
				

					if(!((List<Object>) engineAxleList.get(pageNum).get(0)).isEmpty()){
					pageNumber++;
					
					}
					
				}
				
				
			for (int pageNum = 0; pageNum<engineAxleList.size(); pageNum++) {

				//	rowHeaderList = (List<EngineAxleBean>)engineAxleList.get(pageNum).get(0);
			

				if(!((List<Object>) engineAxleList.get(pageNum).get(0)).isEmpty()){
			
					if(pageNum>0){
						document.newPage();
					}



						tableDesc = new PdfPTable(1);
					tableDesc = createTableHeaders();
					tableDesc.setSplitLate(false);
					tableDesc.setSplitRows(true);

					tableContent = createTable(engineAxleList.get(pageNum));
					tableDesc.addCell(tableContent);
					if(tableContent!=null){
						document.add(tableDesc);

					}
				}


				if(headerHelper.get(0).getColumnBreak()!=null)
				{
					tableContent = createTable(engineAxleList.get(pageNum));
				}
			}
			//	PdfPTable footer = createFooter(writer);

			/*	document.add(headerTable);
					document.add(table);*/
			//	document.add(footer);

			if(pdfType==0){
				onCloseDocument(writer, document);
				// step 5
				document.close();
			}

		}
	}

	public String getLocation()
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String location = null;
		if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			location = eProperties.getProperty("pdfDefaultLocation");
		}
		return location;
	}

	class TableHeader extends PdfPageEventHelper {
		/** The header text. */
		String header;
		/** The template with the total number of pages. */
		PdfTemplate total;

		/**
		 * Allows us to change the content of the header.
		 * @param header The new header String
		 */
		public void setHeader(String header) {
			this.header = header;
		}

		/**
		 * Creates the PdfTemplate that will hold the total number of pages.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onOpenDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
		}

		/**
		 * Adds a header to every page
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onEndPage(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			try {
				table.setWidths(new int[]{24, 24, 2});
				table.setTotalWidth(527);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(tableWidth);
				table.getDefaultCell().setBorder(Rectangle.BOTTOM);
				table.addCell(header);
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Page %d of", writer.getCurrentPageNumber()));
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.BOTTOM);
				table.addCell(cell);
				table.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
			}
			catch(DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		/**
		 * Fills out the total number of pages before the document is closed.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onCloseDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT,
					new Phrase(String.valueOf(writer.getCurrentPageNumber() - 1)),
					2, 2, 0);
		}
	}





	public  PdfPTable createTableHeaders() throws DocumentException  {

		PdfPTable table = new PdfPTable(1);
		table.setTotalWidth(tableWidth);
		table.setLockedWidth(true);
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);
		// we add a cell with colspan 3
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD,BaseColor.BLACK);
		Image blackBoxImg = null;
		Image whiteBoxImg = null;
		try {
			blackBoxImg = Image.getInstance("blackbox.gif");
			whiteBoxImg = Image.getInstance("whitebox.gif");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		String stringHeader = " S = Standard Equipment"+"\t \t \t"+" A = Available"+"\t \t \t"+" --(dashes) = Not Available \n";
		String stringBlack =  " = Included in Equipment Group"+"";
		String stringWhite =  " = Included in Equipment Group but upgradeable\n";
		if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
			stringHeader = " S = �quipement de s�rie "+"\t\t"+" A = Livrables "+"\t\t"+" --(Tirets) = Non Disponible\n";
			stringBlack =  " = Compris dans le groupe d'�quipements  "+"";
			stringWhite =  " = Compris dans le groupe d'�quipements, mais peut �tre mis � niveau.\n";
		}


		String ending="";
		String truckDesc="";
		if(headerHelper.get(0).getDivisionID()!=null){
			if(headerHelper.get(0).getDivisionID().intValueExact()==1 || headerHelper.get(0).getDivisionID().intValueExact()==2){

				truckDesc = "\n* Indicates availability of feature on multiple models. For example, it indicates feature availability on 2WD and 4WD Models or Rear wheel drive and"+
						" All-wheel drive Models. ";
				if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
					truckDesc = "\n* Indique disponibilit� de ce type sur plusieurs mod�les. Par exemple, il indique la disponibilit� des fonctions sur les mod�les 2RM et 4RM ou propulsion arri�re et toutes roues motrices mod�les.";
				}

			}
		}
		else{
			truckDesc="";
		}
		ending ="";

		if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
			ending = "";
		}	
		Paragraph paragraph_black = new Paragraph();
		paragraph_black.setAlignment(Element.ALIGN_CENTER);
		paragraph_black.add(new Phrase(stringHeader, tableHeader1));
		if (blackBoxImg != null) {
			whiteBoxImg.scalePercent(60f);
			blackBoxImg.scalePercent(60f);
			paragraph_black.add(new Chunk( blackBoxImg, 1f, 1f));
		}
		paragraph_black.add(new Phrase(stringBlack, tableHeader1));
		paragraph_black.add(new Phrase("  ", tableHeader1));
		paragraph_black.add(new Chunk( whiteBoxImg, 1f, 1f));
		paragraph_black.add(new Phrase(stringWhite, tableHeader1));
		Paragraph temp;
		PdfPCell cell1 = new PdfPCell(paragraph_black);
		temp = new Paragraph();
		temp.add(truckDesc);
		temp.setLeading(1f, 1f);
		temp.setFont(tableHeader1);
		temp.setAlignment(Element.ALIGN_LEFT);
		//paragraph_black.add(temp);
		cell1.addElement(paragraph_black);
		cell1.addElement(temp);

		temp = new Paragraph();
		temp.add(ending);
		temp.setFont(boldContentFont);
		temp.setAlignment(Element.ALIGN_LEFT);
		//paragraph_black.add(new Phrase(ending, boldContentFont));

		//cell1.addElement(paragraph_black);
		cell1.addElement(temp);
		cell1.setPaddingBottom(6f);
		cell1.setPaddingLeft(8f);
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell1.setVerticalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell1);

		return table;
	}






	public  PdfPTable createTable(List<Object> engineAxleList) throws DocumentException {

		Multimap<String, BigDecimal> componentTypeName = ArrayListMultimap.create();
		rowHeaderList = null;
		engineAxleHeaderList = null;
		engineAxleContentList = null;
		restrictionIDList = new ArrayList<Integer>();
		rowHeaderList = (List<EngineAxleBean>)engineAxleList.get(0);
		engineAxleHeaderList = (List<EngineAxleTableHeaders>)engineAxleList.get(1);
		engineAxleContentList =  (List<EngineAxleContentBean>)engineAxleList.get(2);

		ArrayList<BigDecimal> 	componentIDList= getComponentIdList(engineAxleContentList);
		com.itextpdf.text.Font boldFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font restFont =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA, 6, Font.BOLD,BaseColor.BLACK);
		BaseFont base = null;

		try {
			base = BaseFont.createFont("c:/windows/fonts/ARIALUNI.ttf", BaseFont.IDENTITY_H, false);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Font Wfont = new Font(base, 12, Font.NORMAL);
		Font superBoldScriptfont = new Font(base, 12, Font.NORMAL);
		Font superScriptfont = new Font(base, 10, Font.NORMAL);

		PdfPTable table = new PdfPTable(1);
		table.setTotalWidth(tableWidth);
		table.setWidths(new int[] {tableWidth});
		table.setLockedWidth(true);
		table.getDefaultCell().setBorder(1);
		table.getDefaultCell().setPadding(0);
		//	table.setSplitRows(true);
		table.setSplitLate(false);

		table.setHeaderRows(1);

		PdfPTable restrictionTable = new PdfPTable(1);
		restrictionTable.setTotalWidth(tableWidth);

		restrictionTable.setWidths(new int[] {tableWidth});
		restrictionTable.getDefaultCell().setBorder(0);
		restrictionTable.getDefaultCell().setPadding(0);
		Map<BigDecimal,String> tempset = rowHeaderList.get(0).getRestrictionList();
		int count_temp =0;
		String tempres = "";
		for (BigDecimal key : tempset.keySet()) {
			if(!restrictionIDList.contains(key.intValueExact())){
				restrictionIDList.add(key.intValueExact());
			}
		}
		List <String> tempResList = new ArrayList<String>();

		for (String key : tempset.values()) {
			if(!tempResList.contains(key)){
				count_temp++;
				tempres+= count_temp+"- " + key+"\n";
				tempResList.add(key);

			}
		}
		if(tempResList.size()>0){
			insertCell(restrictionTable,"", tempres, "", Element.ALIGN_LEFT, 0, restFont, BaseColor.WHITE);
		}
		int tmpTransCount=0;
		int tempOtherCount=0;
		for (EngineAxleTableHeaders engineAxletempHeaders :engineAxleHeaderList) {
			if(engineAxletempHeaders.getComponentTypeName().equalsIgnoreCase(VehicleConstant.TRANSMISSION)||engineAxletempHeaders.getComponentTypeName().equalsIgnoreCase(VehicleConstant.TRANSMISSION_fr))
			{
				tmpTransCount++;
			}
			else
			{
				tempOtherCount++;
			}
		}

		Collections.sort(restrictionIDList);
		PdfPTable staticHeaders = new PdfPTable(2);
		int[] temp = new int[componentIDList.size()+2] ;
		int[] temp_1 = new int[componentIDList.size()];
		if(componentIDList.size()==11){
			temp[0] = 43;
			temp[1] = 76;
			temp[2] = 51;
			temp[3] = 51;

			temp_1[0] = 51;
			temp_1[1] = 51;
			for (int i = 4; i < temp.length; i++) {
				temp[i] = 254/(temp.length-4);
			}

			for (int i = 2; i < temp_1.length; i++) {
				temp_1[i] = 254/(temp.length-4);
			}
		}

		/*else	if(componentIDList.size()==7){
			temp[0] = 43;
			temp[1] = 212;
			temp[2] = 51;

			temp_1[0] = 51;
			for (int i = 3; i < temp.length; i++) {
				temp[i] = 169/(temp.length-3);
			}

			for (int i = 1; i < temp_1.length; i++) {
				temp_1[i] = 169/(temp.length-3);
			}
		}


		else		if(componentIDList.size()==6){
			temp[0] = 43;
			temp[1] = 241;
			temp[2] = 51;

			temp_1[0] = 51;
			for (int i = 3; i < temp.length; i++) {
				temp[i] = 140/(temp.length-3);
			}

			for (int i = 1; i < temp_1.length; i++) {
				temp_1[i] = 140/(temp.length-3);
			}
		}


		else	if(componentIDList.size()==4){
			temp[0] = 43;
			temp[1] = 297;
			temp[2] = 51;

			temp_1[0] = 51;
			for (int i = 3; i < temp.length; i++) {
				temp[i] = 86/(temp.length-3);
			}

			for (int i = 1; i < temp_1.length; i++) {
				temp_1[i] = 86/(temp.length-3);
			}
		}

		else	if(componentIDList.size()==14){
			temp[0] = 42;
			temp[1] = 42;
			temp[2] = 51;
			temp[3] = 51;
			temp_1[0] = 51;

			for (int i = 4; i < temp.length; i++) {
				temp[i] = 340/(temp.length-3);
			}

			for (int i = 1; i < temp_1.length; i++) {
				temp_1[i] = 340/(temp.length-3);
			}

		}
		else	if(componentIDList.size()==12){
			temp[0] = 42;
			temp[1] = 42;
			temp[2] = 51;
			temp[3] = 51;
			temp_1[0] = 51;

			for (int i = 4; i < temp.length; i++) {
				temp[i] = 340/(temp.length-3);
			}

			for (int i = 1; i < temp_1.length; i++) {
				temp_1[i] = 340/(temp.length-3);
			}

		}
		else	if(componentIDList.size()==10){
			temp[0] = 42;
			temp[1] = 104;
			temp[2] = 51;
			temp[3] = 51;
			temp_1[0] = 51;

			for (int i = 4; i < temp.length; i++) {
				temp[i] = 226/(temp.length-4);
			}

			for (int i = 1; i < temp_1.length; i++) {
				temp_1[i] = 226/(temp.length-3);
			}

		}*/

		else
		{
			int tempAvailw = tableWidth;
			int tmpNumb=2;

			temp[0] = 42;
			temp[1] = (tableWidth-(temp[0]+tmpTransCount*51+tempOtherCount*28));

			for(tmpNumb =2; tmpNumb<(tmpTransCount+2);tmpNumb++){
				temp[tmpNumb] = 51;
			}

			tempAvailw = (tempOtherCount*28);
			for (int i = tmpNumb; i < temp.length; i++) {
				temp[i] = 28;
			}

			tempAvailw = tempOtherCount*28;

			for(tmpNumb =0; tmpNumb<(tmpTransCount);tmpNumb++){
				temp_1[tmpNumb] = 51;
			}

			for (int i = tmpNumb; i < (temp_1.length); i++) {
				temp_1[i] = 28;
			}
			/*for (int j = tmpNumb-1; j < temp.length; j++) {
				temp[i] = tempAvailw/(temp.length-3);
			}*/
			/*temp_1[0] = 51;
			for (int i = 1; i < temp_1.length; i++) {
				temp_1[i] = tempAvailw/tempOtherCount;
			}*/
		}
		int temp_Width =tmpTransCount*51+tempOtherCount*28;
		/*for (int f : temp_1) {
			temp_Width+=f;
		}
		int temp_Width_H =0;
		for (int f : temp) {
			temp_Width_H+=f;
		}*/

		PdfPTable tableMain = new PdfPTable(2);
		tableMain.setTotalWidth(tableWidth);
		tableMain.setWidths(new int[] {temp[0]+temp[1],temp_Width});
		tableMain.setLockedWidth(true);
		tableMain.getDefaultCell().setBorder(0);
		tableMain.getDefaultCell().setPadding(0);
		//	tableMain.setSplitRows(true);
		//tableMain.setSplitLate(true);


		staticHeaders.setTotalWidth(temp[0]+temp[1]);
		staticHeaders.getDefaultCell().setBorder(0);
		staticHeaders.getDefaultCell().setPadding(0);
		//staticHeaders.setLockedWidth(true);
		staticHeaders.setWidths(new int[] {temp[0],temp[1]});
		staticHeaders.setLockedWidth(true);
		//staticHeaders.setSplitLate(true);
		//staticHeaders.setSplitRows(true);
		//staticHeaders.setWidthPercentage(100);



		PdfPCell blankCell = new PdfPCell(new Phrase(" "));
		blankCell.setColspan(2);
		blankCell.setFixedHeight(16f);
		blankCell.setBackgroundColor(new BaseColor(204,204,204));
		staticHeaders.addCell(blankCell);
		blankCell.setColspan(2);

		insertCell(staticHeaders,"Model",null, null, Element.ALIGN_LEFT, 1, tableHeader1,new BaseColor(204,204,204));
		insertCell(staticHeaders,"Engine",null, null, Element.ALIGN_CENTER, 1, tableHeader1,new BaseColor(204,204,204));




		for (EngineAxleTableHeaders engineAxleTableHeaders : engineAxleHeaderList) {

			componentTypeName.put(engineAxleTableHeaders.getComponentTypeName(),engineAxleTableHeaders.getComponentID());

		}

		float[] columnsArray = new float[componentTypeName.size()] ;
		//componentTypeName.size();
		//componentTypeName.get("Axles").size();
		int columnPos=0;
		String trans="Transmissions";
		String axles="Axles";
		String kg ="GVWR lbs. (kg)";

		if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
			trans = "Bo�tes de vitesses";
			axles = "Ponts";
			kg = "PNBV, kg (lb)";

		}




		for (int i = 0; i < componentTypeName.get(trans).size(); i++) {

			columnsArray[columnPos]=51;
			columnPos++;
		}

		for (int i = 0; i < componentTypeName.get(axles).size(); i++) {

			columnsArray[columnPos]=28;
			columnPos++;
		}

		for (int i = 0; i < componentTypeName.get(kg).size(); i++) {

			columnsArray[columnPos]=23;
			columnPos++;
		}


		float[] columnsArray_1 = new float[2+componentTypeName.size()] ;
		//componentTypeName.size();
		//componentTypeName.get("Axles").size();
		columnsArray_1[0]=44;
		columnsArray_1[1]=260;
		int columnPos_1=2;
		for (int i = 0; i < componentTypeName.get(trans).size(); i++) {

			columnsArray_1[columnPos_1]=51;
			columnPos_1++;
		}

		for (int i = 0; i < componentTypeName.get(axles).size(); i++) {

			columnsArray_1[columnPos_1]=23;
			columnPos_1++;
		}

		for (int i = 0; i < componentTypeName.get(kg).size(); i++) {

			columnsArray_1[columnPos_1]=23;
			columnPos_1++;
		}

		PdfPTable componentType = new PdfPTable(componentTypeName.size());
		componentType.setTotalWidth(temp_Width);
		/*		temp = ArrayUtils.removeElement(temp, 0);
		temp = ArrayUtils.removeElement(temp, 0);*/

		//	temp.
		componentType.setWidths(temp_1);
		//componentType.setLockedWidth(true);
		componentType.getDefaultCell().setBorder(0);
		componentType.getDefaultCell().setPadding(0);
		//componentType.setSplitRows(true);
		//	componentType.setSplitLate(false);

		PdfPCell cell1 = new PdfPCell() ;

		for (EngineAxleTableHeaders engineAxleTableHeaders : engineAxleHeaderList) {

			if(engineAxleTableHeaders.getComponentTypeName() != null && componentTypeName.get(engineAxleTableHeaders.getComponentTypeName()).size()>0)
			{	
				Paragraph para = new Paragraph();
				para.add(new Phrase(engineAxleTableHeaders.getComponentTypeName(), boldContentFont1));
				cell1 = new PdfPCell(para);
				cell1.setBackgroundColor(new BaseColor(204,204,204));
				cell1.setColspan(componentTypeName.get(engineAxleTableHeaders.getComponentTypeName()).size());
				cell1.setVerticalAlignment(Element.ALIGN_CENTER);
				cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell1.setPaddingTop(5);
				cell1.setPaddingLeft(2);
				cell1.setPaddingRight(2);
				cell1.setPaddingBottom(5);
				//cell1.setLeading(1, 1.5f);

				componentType.addCell(cell1);

				componentTypeName.removeAll(engineAxleTableHeaders.getComponentTypeName());
			}


		}


		int columnSize =0;
		for (EngineAxleTableHeaders engineAxleTableHeaders : engineAxleHeaderList) {

			if(	engineAxleTableHeaders.getComponentDesc1()=="null"){
				engineAxleTableHeaders.setComponentDesc1("");
			}

			if(	engineAxleTableHeaders.getComponentDesc2()=="null"){
				engineAxleTableHeaders.setComponentDesc2("");
			}

			if(	engineAxleTableHeaders.getComponentDesc3()=="null"){
				engineAxleTableHeaders.setComponentDesc3("");
			}
			
			if(	engineAxleTableHeaders.getComponentRPO()=="null"){
				engineAxleTableHeaders.setComponentRPO("");
			}


			if(engineAxleTableHeaders.getComponentTypeName() != null )
			{	

				Paragraph para = new Paragraph();
				para.add(new Phrase(engineAxleTableHeaders.getComponentRPO()+"\n"+engineAxleTableHeaders.getComponentDesc1()+"\n"
						+engineAxleTableHeaders.getComponentDesc2()+"\n"
						+engineAxleTableHeaders.getComponentDesc3(), boldFont));

				cell1 = new PdfPCell(para);
				cell1.setBackgroundColor(new BaseColor(204,204,204));
				cell1.setVerticalAlignment(Element.ALIGN_CENTER);
				cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell1.setPaddingTop(5);
				cell1.setPaddingLeft(1);
				cell1.setPaddingRight(1);
				cell1.setPaddingBottom(5);
				//cell1.setLeading(1, 1.5f);

				componentType.addCell(cell1);
				columnSize++;
			}
		}






		PdfPTable tableRowContent = new PdfPTable(2);
		tableRowContent.setWidths(new int[] {44,260});
		//tableRowContent.setLockedWidth(true);
		tableRowContent.getDefaultCell().setBorder(0);
		tableRowContent.getDefaultCell().setPadding(0);	

		PdfPTable tableContent = new PdfPTable(2+columnSize);
		tableContent.setWidths(temp);
		//	tableContent.setTotalWidth(tableWidth);
		//	tableContent.setLockedWidth(true);
		//tableContent.setLockedWidth(true);
		tableContent.getDefaultCell().setBorder(0);
		tableContent.getDefaultCell().setPadding(0);	
		/*tableContent.setSplitRows(true);
		tableContent.setSplitLate(true);*/
		//	tableContent.setLockedWidth(true);
		List<BigDecimal> engineList = new ArrayList<BigDecimal>();

		for (EngineAxleBean engineAxleBean : rowHeaderList){
			engineList.add(engineAxleBean.getVehicleHasEngineID());
		}
		int count=0;
		//	for (BigDecimal engineNum : engineList) {
		String tempSubCat="";
		String tempSubCat2="";
		List<String> tempeaCatTextList = new ArrayList<String>();
		for (EngineAxleBean foreachRow : rowHeaderList) { 
			boolean foundMatch = false;

			if(!tempeaCatTextList.contains(foreachRow.getEaCatText()) && foreachRow.getEaCatText()!="null")
			{
				
				insertCell(tableContent, foreachRow.getEaCatText(), "", "", Element.ALIGN_LEFT, 2 +columnSize , tableHeader1, BaseColor.WHITE);
			}
			else if (!tempeaCatTextList.contains(foreachRow.getEaCatText()) && foreachRow.getEaCatText().equalsIgnoreCase("null")){
				insertCell(tableContent, " ", "", "", Element.ALIGN_LEFT, 2 +columnSize , tableHeader1, BaseColor.WHITE);
			}
			
			
			tempeaCatTextList.add(foreachRow.getEaCatText());
			if(foreachRow.getEaSubCatText().equalsIgnoreCase(tempSubCat)){
				//insertCell(tableContent,"--",null, null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
				insertTraileringSpace(tableContent);
			}
			else{
				insertCell_1(tableContent,foreachRow.getEaSubCatText(),null, null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
			}
			tempSubCat = foreachRow.getEaSubCatText();
			if(foreachRow.getRestrictionID()==null){
				foreachRow.setRestrictionID(new BigDecimal(10));
			}
			insertCustomCell(tableContent,foreachRow.getEngineRpo().trim()+" "+
					foreachRow.getEngineDesc(),new Phrase(restrictionFlag(foreachRow.getRestrictionID().intValueExact()),Wfont),"", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);

			for (BigDecimal foreachColumn : componentIDList){
				foundMatch = false;
				for (EngineAxleContentBean foreachCell : engineAxleContentList) { 

					if(foreachCell.getVehicleHasEngineID().equals(foreachRow.getVehicleHasEngineID()) && foreachCell.getComponentID().equals(foreachColumn) ){
						if(foreachCell.getRestrictionID()==null){
							foreachCell.setRestrictionID(new BigDecimal(10));
						}
						insertCustomCell(tableContent,foreachCell.getAvailableCodeName()+restrictionFlag(foreachCell.getRestrictionID().intValueExact()),new Phrase("",Wfont), "", null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
						foundMatch = true;
					}

				}

				if(!foundMatch){
					insertCell(tableContent,"--",null, null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);

				}
			}
		}
		/*if(count<columnSize){
				for(int i= 0; i <=columnSize-count; i++){

					//insertCell(tableContent,"--",null, null, Element.ALIGN_CENTER, 1, tableHeader1,new BaseColor(204,204,204));

				}*/
		//	}
		//}

		cell1 = new PdfPCell(new Phrase(" "));
		cell1.setColspan(2);
		cell1.setFixedHeight(5f);
		tableMain.addCell(staticHeaders);
		tableMain.addCell(componentType);
		//tableMain.addCell(cell1);
		/*tableMain.addCell(tableRowContent);
		tableMain.addCell(tableContent);*/
		if(!rowHeaderList.isEmpty()){
			//tableMain.addCell(restrictionTable);
			if(rowHeaderList.get(0).getPageLabel()!=null && rowHeaderList.get(0).getPageLabel().trim().equalsIgnoreCase("- Engine/Axle"))
			{
				rowHeaderList.get(0).setPageLabel("");
			}
			

			if(pageNumber<=1)
			{
				rowHeaderList.get(0).setPageLabel("");
			}
			

			if(rowHeaderList.get(0).getPageLabel()!=null && !rowHeaderList.get(0).getPageLabel().replace("-", "").trim().equals("")){
				Paragraph para = new Paragraph();
				para.add(new Phrase(""+rowHeaderList.get(0).getPageLabel().replace("-", "").trim(),boldFont));
				cell1 = new PdfPCell(para);
				cell1.setColspan(2);
				cell1.setFixedHeight(15f);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			}
		}
	//	tableMain.addCell(cell1);
		table.addCell(tableMain);
		table.addCell(tableContent);
		table.addCell(restrictionTable);
		table.getDefaultCell().setBorder(1);
		return table;
	}


	private ArrayList<BigDecimal> getComponentIdList(List<EngineAxleContentBean> engineAxleContentList) {
		
		ArrayList<BigDecimal> temp = new ArrayList<BigDecimal>() ;
		for (EngineAxleContentBean engineAxleContentBean : engineAxleContentList) {
			if(!temp.contains(engineAxleContentBean.getComponentID())){

				temp.add(engineAxleContentBean.getComponentID());
			}
		}

		return temp;
	}

	private static void insertImage(PdfPTable table, PdfPCell cell,
			int align, int i, Font tableHeader1) {
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);

		//add the call to the table
		table.addCell(cell);

	}


	public void startSpecsAndDimPDFGeneration(List<ArrayList<Object>> specsAndDimensionBeans) {
		// TODO Auto-generated method stub

		try {
			pdfType =0;
			new ItextPDFGenerator_EngineAxle().createPdf(specsAndDimensionBeans,null,null);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	public static void insertCell(PdfPTable table,String boldText, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		para.add(new Phrase(text, font));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(colspan);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		//	cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row
		//if(text.trim().equalsIgnoreCase("")){
		//cell.setMinimumHeight(25f);
		//}
		//add the call to the table
		table.addCell(cell);

	}


	public static void insertCell_1(PdfPTable table,String boldText, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		para.add(new Phrase(text, font));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		//	cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBorder(Rectangle.LEFT|Rectangle.TOP);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row
		//if(text.trim().equalsIgnoreCase("")){
		//cell.setMinimumHeight(25f);
		//}
		//add the call to the table
		table.addCell(cell);

	}
	public void insertTraileringSpace(PdfPTable table){
		PdfPCell cell = new PdfPCell();
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setBorder(Rectangle.LEFT);
		cell.setBorderWidth(0.5f);
		table.addCell(cell);
	}



	public static void insertCustomCell(PdfPTable table,String text, Phrase p1,String boldText,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font contentFont =  FontFactory.getFont(FontFactory.HELVETICA,9, Font.NORMAL,BaseColor.BLACK);
		Paragraph para = new Paragraph();
	
		if(text!=null){
			para.add(new Phrase(text, contentFont));
		}
		
		para.add(p1);
		//para.setAlignment(Element.ALIGN_LEFT);
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//cell.setVerticalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(8f);
		//cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row
		//if(text.trim().equalsIgnoreCase("")){
		cell.setMinimumHeight(10f);
		//}
		//in case there is no text and you wan to create an empty row

		//add the call to the table
		table.addCell(cell);

	}


	public String restrictionFlag(int currentRestrictionID){
		
		String unicodeFlag="";
		boolean isRestrictionExist = false;
		if(currentRestrictionID!=20){
			int restrictionPosition=1;

			for (int restriction : restrictionIDList) {


				if(currentRestrictionID==restriction){
					isRestrictionExist = true;
					break;
					
				}
				restrictionPosition++;
			}


			if(unicodeProperties.getProperty(String.valueOf(restrictionPosition))!=null && !unicodeProperties.getProperty(String.valueOf(restrictionPosition)).isEmpty())
			{
				unicodeFlag = unicodeProperties.getProperty(String.valueOf(restrictionPosition));
			}

		}
		if(!isRestrictionExist) {
			unicodeFlag="";
		}
		return unicodeFlag;
	}

	
	public void loadRestriction(){

		unicodeProperties = new Properties();
		inputStream = null;

		try {
			inputStream = new FileInputStream("./Unicode.properties");
			unicodeProperties.load(inputStream);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public class Rotate extends PdfPageEventHelper {
		protected PdfNumber rotation = PdfPage.LANDSCAPE;
		public void setRotation(PdfNumber rotation) {
			this.rotation = rotation;
		}
		public void onEndPage(PdfWriter writer, Document document) {
			writer.addPageDictEntry(PdfName.ROTATE, rotation);
		}
	}

	public class HeaderAndFooter extends PdfPageEventHelper {

		private String name = "";
		PdfTemplate total;

		protected Phrase footer;
		protected Phrase header;

		protected PdfNumber rotation = PdfPage.LANDSCAPE;
		public void setRotation(PdfNumber rotation) {
			this.rotation = rotation;
		}

		/*
		 * Font for header and footer part.
		 */
		com.itextpdf.text.Font headerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		/*private static Font headerFont = new Font(Font.COURIER, 9,
	            Font.NORMAL,Color.blue);

	    private static Font footerFont = new Font(Font.TIMES_ROMAN, 9,
	            Font.BOLD,Color.blue);*/


		/*
		 * constructor
		 */
		public HeaderAndFooter(String name) {
			super();
			this.name = name;
			header = new Phrase("***** Header *****");
			footer = new Phrase("**** Footer ****");
		}

		@Override
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
			// TODO Auto-generated method stub
			super.onOpenDocument(writer, document);
		}
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			//headerHelper.get(0).setIsLandscape(new BigDecimal(1));
			if(!headerHelper.isEmpty()){
				PdfContentByte cb = writer.getDirectContent();

				//header content
				String headerContent = "Name: " +name;

				//header content
				String footerContent = headerContent;
				/*
				 * Header
				 */
				/*	ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(headerContent,headerFont), 
	                document.leftMargin(), document.top() -30, 0);*/

				/*
				 * Footer
				 */
				DateFormat defDate=null;
				PropertyHelper propertyHelper = new PropertyHelper();
				if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
					defDate  = DateFormat.getDateInstance(DateFormat.LONG,Locale.FRANCE);

					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_FR")!=null && propertyHelper.getProperty("ForcedateOnPDF_FR").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_FR");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);

					if(headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+350 , document.bottom()-45, 0);
					}
					else{
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+250 , document.bottom()-45, 0);
					}


				}
				else{
					defDate  = DateFormat.getDateInstance(DateFormat.LONG);
					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_EN")!=null && propertyHelper.getProperty("ForcedateOnPDF_EN").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_EN");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
					if(headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.bottom() , document.left()+250,-90);
					}
					else{
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+250 , document.bottom()-45, 0);
					}
				}


				PdfPTable table = new PdfPTable(3);
				table.getDefaultCell().setBorder(0);
				//table.getDefaultCell().setPaddingBottom(25);

				PdfPTable table1 = null;

				table.setTotalWidth(tableWidth);
				try {
					table.setWidths(new int[] {150,195,135});
				} catch (DocumentException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setLockedWidth(true);
				PdfPCell cell;

				com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.WHITE);

				//Paragraph p1 = new Paragraph(vehicleItemsXML2.get(0).getVehicleName(),tableHeader);
				//Paragraph p1 = new Paragraph(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader);
				//p1.setAlignment(Element.ALIGN_LEFT);
				cell = new PdfPCell(new Phrase(headerHelper.get(0).getVehicleYear() +" "+ headerHelper.get(0).getDivisionName() +" "+ headerHelper.get(0).getVehicleName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);

				//	cell.addElement(p1);
				table.addCell(cell);

				//Paragraph p2 = new Paragraph("RPO CODES",tableHeader);
				if( headerHelper.get(0).getPageLabel()==null ){
					headerHelper.get(0).setPageLabel("");
				}
				if(headerHelper.get(0).getPageLabel().trim().equalsIgnoreCase("- Engine/Axle"))
				{
					headerHelper.get(0).setPageLabel("");
				}
				
				
				if(pageNumber<=1)
				{
					headerHelper.get(0).setPageLabel("");
				}
				
				
				
				cell = new PdfPCell(new Phrase("ENGINE/AXLE " +rowHeaderList.get(0).getPageLabel(),tableHeader));
				if(headerHelper.get(0).getLocaleCode()!=null && headerHelper.get(0).getLocaleCode().intValueExact()==2){
					cell = new PdfPCell(new Phrase("MOTEUR / PONT " +rowHeaderList.get(0).getPageLabel(),tableHeader));

				}
				cell.setMinimumHeight(15f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p2.setAlignment(Element.ALIGN_CENTER);

				//cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				//cell.addElement(p2);

				table.addCell(cell);

				//	Paragraph p3 = new Paragraph(vehicleItemsXML.get(0).getRegionName(),tableHeader);
				cell = new PdfPCell(new Phrase(headerHelper.get(0).getRegionName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p3.setAlignment(Element.ALIGN_RIGHT);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				//cell.addElement(p3);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				cell.setPaddingLeft(2f);

				table.addCell(cell);

				//	table.addCell(table2);
				if(headerHelper.get(0).getIsLandscape()!=null && headerHelper.get(0).getIsLandscape().intValueExact()==1){
					table.writeSelectedRows(0, -1,110, 550, writer.getDirectContent());
				}
				else{
					table.writeSelectedRows(0, -1, 70, 750, writer.getDirectContent());
				}
			}
			else {
				PdfContentByte cb = writer.getDirectContent();
				DateFormat defDate=null;
				defDate  = DateFormat.getDateInstance(DateFormat.LONG);

				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
						writer.getCurrentPageNumber()),headerFont), 
						document.left()+250 , document.bottom()-45, 0);

			}

		}




	}





	public void startSpecsAndDimPDFGeneration(List<ArrayList<Object>> specsAndDimensionBeans,
			Document document, PdfWriter writer,int pdfType) {
		try {
			isPOG = true;
			this.pdfType = pdfType;
			new ItextPDFGenerator_EngineAxle().createPdf(specsAndDimensionBeans,document,writer);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}











}
