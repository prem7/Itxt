package com.dci.jasper.reporter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import com.dci.enterprise.dao.ItextRpoCodesPDFGeneratorDAO;
import com.dci.enterprise.model.RpoCodesBean;
import com.dci.extrafunc.PropertyHelper;
import com.google.common.base.CaseFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class ItextPDFGenerator_RpoCodes extends PdfPageEventHelper implements ItextRpoCodesPDFGeneratorDAO{
	//public static final String RESULT = "c:\\reports\\TestingStandardEq.pdf";
	private static List<RpoCodesBean> vehicleItemsXML = null;
	private  List<RpoCodesBean>  stdEqpHelperList=null;
	public static	Document document=null;
	public static int pdfType;

	public void createPdf( List<RpoCodesBean>  RpoCodesBeanList, Document document, PdfWriter writer, int pdfType)
			throws IOException, DocumentException {

		PdfPTable headerTable = null;
		PdfPTable table = null;
		this.pdfType = pdfType;
		if(RpoCodesBeanList!=null && !RpoCodesBeanList.isEmpty()){
			if(pdfType==0){
				document = new Document();
				document = new Document(PageSize.LETTER, 25, 20, 100, 150);
				document.setMargins(72,72, 75, 115);
				document.setMarginMirroringTopBottom(true);
				if(!RpoCodesBeanList.isEmpty()&& RpoCodesBeanList.get(0)!=null){
					String fileName = RpoCodesBeanList.get(0).getVehicleId()+"-"+"rpo_codes_fo";


					if(RpoCodesBeanList.get(0).getRegionID()!=null && RpoCodesBeanList.get(0).getLocaleCode()!=null
							&& RpoCodesBeanList.get(0).getRegionID().intValueExact()==14 && RpoCodesBeanList.get(0).getLocaleCode().intValueExact()==2){
						fileName+="_fr";
					}
					PropertyHelper propertyHelper = new PropertyHelper();
					String location = propertyHelper.getProperty("pdfDefaultLocation");
					writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));

				}
			}
			writer.setPageEvent(null);
			writer.setPageEvent(new HeaderAndFooter(""));
			writer.setPageEmpty(false);
			// step 3
			document.open();
			// step 4

			//	headerTable = createHeader(vehicleItemsXML.get(0),i);
			table = createTable(RpoCodesBeanList);
			//document.add(headerTable);
			if(table!=null){
				document.add(table);
			}

			if(pdfType==0)
			{
				onCloseDocument(writer, document);
				// step 5
				document.close();
			}

		}
	}



	public String getLocation()
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String location = null;
		if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			location = eProperties.getProperty("pdfDefaultLocation");
		}
		return location;
	}

	class TableHeader extends PdfPageEventHelper {
		/** The header text. */
		String header;
		/** The template with the total number of pages. */
		PdfTemplate total;

		/**
		 * Allows us to change the content of the header.
		 * @param header The new header String
		 */
		public void setHeader(String header) {
			this.header = header;
		}

		/**
		 * Creates the PdfTemplate that will hold the total number of pages.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onOpenDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
		}

		/**
		 * Adds a header to every page
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onEndPage(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			try {
				table.setWidths(new int[]{24, 24, 2});
				table.setTotalWidth(475);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(550);
				table.getDefaultCell().setBorder(Rectangle.BOTTOM);
				table.addCell(header);
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Page %d of", writer.getCurrentPageNumber()));
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.BOTTOM);
				table.addCell(cell);
				table.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
			}
			catch(DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		/**
		 * Fills out the total number of pages before the document is closed.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onCloseDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT,
					new Phrase(String.valueOf(writer.getCurrentPageNumber() - 1)),
					2, 2, 0);
		}
	}


	public  PdfPTable createTable(List<RpoCodesBean> tableContent) throws DocumentException {
		vehicleItemsXML = (List<RpoCodesBean>)tableContent;
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);
		PdfPTable table1 = null;
		PdfPTable table3;
		PdfPTable table2;

		table.setTotalWidth(475);
		table.setLockedWidth(true);

		table.getDefaultCell().setBorder(0);
		PdfPCell cell = new PdfPCell();
		com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.WHITE);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);

		table.setTotalWidth(475);
		table.setLockedWidth(true);
		table.setSplitLate(false);

		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setBorder(0);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setBorder(Rectangle.NO_BORDER);

		cell.setBackgroundColor(new BaseColor(153,153,153));

		PdfPTable table4 = new PdfPTable(2);
		table4 = new PdfPTable(2);
		table4.getDefaultCell().setBorder(0);
		table4.getDefaultCell().setPadding(0);
		table4.setTotalWidth(475);
		cell.setBackgroundColor(new BaseColor(153,153,153));
		table4.setWidths(new int[] {75,400});
		table4.setLockedWidth(true);
		cell.setBackgroundColor(new BaseColor(153,153,153));
		cell = new PdfPCell(new Phrase("Option Code",boldContentFont));
		if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("le code d'option",boldContentFont));
		}
		cell.setNoWrap(false);
		cell.setMinimumHeight(15f);
		cell.setBackgroundColor(new BaseColor(153,153,153));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		table4.addCell(cell);


		cell = new PdfPCell(new Phrase("Description",boldContentFont));
		cell.setNoWrap(false);
		cell.setMinimumHeight(15f);
		cell.setBackgroundColor(new BaseColor(153,153,153));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		table4.addCell(cell);


		PdfPTable packageNameTable=null;
		packageNameTable = new PdfPTable(2);
		packageNameTable.setWidths(new int[] {75,400});
		cell.setFixedHeight(22f);
		packageNameTable.getDefaultCell().setBorder(0);
		packageNameTable.getDefaultCell().setPadding(0);
		packageNameTable.getDefaultCell().setColspan(2);

		table1 = new PdfPTable(2);
		table1.setWidths(new int[] {75,400});



		for (Iterator iterator = vehicleItemsXML.iterator(); iterator.hasNext();) {

			RpoCodesBean rpoCodesBean = (RpoCodesBean) iterator.next();

			//insertImage(table1,cell, Element.ALIGN_CENTER, 1, tableHeader1);
			insertCell(table1,rpoCodesBean.getRpoName(),null,null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
			if(rpoCodesBean.getRpoDesc()=="null"){
				rpoCodesBean.setRpoDesc("");
			}
			insertCell(table1,rpoCodesBean.getRpoDescBold()+rpoCodesBean.getRpoDesc(),null, null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);


		}

		table2 = new PdfPTable(1);
		table2.setTotalWidth(475);
		cell = new PdfPCell();
		cell.setPaddingBottom(0);
		cell.setBorder(Rectangle.NO_BORDER);

		table2.addCell(cell);
		table.addCell(table2);
		table.addCell(table4);
		table.addCell(table1);
		table.setHeaderRows(2);
		return table;

	}


	private static void insertImage(PdfPTable table, PdfPCell cell,
									int align, int i, Font tableHeader1) {
		cell.setHorizontalAlignment(align);
		cell.setVerticalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setBorderWidth(0.5f);
		//add the call to the table
		table.addCell(cell);

	}


	public void startRpoCodesPDFGeneration(List<RpoCodesBean> rpoCodesBeanList) {
		// TODO Auto-generated method stub

		try {

			new ItextPDFGenerator_RpoCodes().createPdf(rpoCodesBeanList,null,null,0 );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	public static void insertCell(PdfPTable table,String boldText, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		para.add(new Phrase(text, font));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		cell.setVerticalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3f);
		cell.setPaddingTop(0.1f);
		cell.setPaddingLeft(8f);
		//	cell.setLeading(1f, 1f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row

		//add the call to the table
		table.addCell(cell);

	}

	public void onCloseDocument(PdfWriter writer, Document document) {
		Paragraph p1 = new Paragraph("Testing************");
		PdfPCell cell = new PdfPCell();
		cell.addElement(p1);

		try {
			document.add(cell);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private PdfPTable createFooter(PdfWriter writer) {
		DateFormat defDate=null;
		defDate  = DateFormat.getDateInstance(DateFormat.LONG);

		String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, defDate.format(new Date()));
		com.itextpdf.text.Font footerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		PdfPTable table = new PdfPTable(1);
		table.setTotalWidth(475);
		Paragraph p1 = new Paragraph("Published " + currDate +" Page "+writer.getCurrentPageNumber(),footerFont);
		PdfPCell cell = new PdfPCell();

		p1.setAlignment(Element.ALIGN_CENTER);
		cell.addElement(p1);
		cell.setPaddingTop(40);
		cell.setPaddingBottom(40);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		return table;
	}


	public class HeaderAndFooter extends PdfPageEventHelper {

		private String name = "";
		PdfTemplate total;

		protected Phrase footer;
		protected Phrase header;

		/*
		 * Font for header and footer part.
		 */
		com.itextpdf.text.Font headerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		/*private static Font headerFont = new Font(Font.COURIER, 9,
	            Font.NORMAL,Color.blue);

	    private static Font footerFont = new Font(Font.TIMES_ROMAN, 9,
	            Font.BOLD,Color.blue);*/


		/*
		 * constructor
		 */
		public HeaderAndFooter(String name) {
			super();
			this.name = name;
			header = new Phrase("***** Header *****");
			footer = new Phrase("**** Footer ****");
		}

		@Override
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
			// TODO Auto-generated method stub
			super.onOpenDocument(writer, document);
		}
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);

			PdfContentByte cb = writer.getDirectContent();

			//header content
			String headerContent = "Name: " +name;

			//header content
			String footerContent = headerContent;
			/*
			 * Header
			 */
			/*	ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(headerContent,headerFont),
	                document.leftMargin(), document.top() -30, 0);*/

			/*
			 * Foooter
			 */
			DateFormat defDate=null;
			PropertyHelper propertyHelper = new PropertyHelper();
			if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
				defDate  = DateFormat.getDateInstance(DateFormat.LONG,Locale.FRANCE);

				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				if(propertyHelper.getProperty("ForcedateOnPDF_FR")!=null && propertyHelper.getProperty("ForcedateOnPDF_FR").trim()!="") {
					currDate = propertyHelper.getProperty("ForcedateOnPDF_FR");
				}

				//	com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ",
						writer.getCurrentPageNumber()),boldContentFont),
						document.left()+250 , document.bottom()-45, 0);

			}
			else{
				defDate  = DateFormat.getDateInstance(DateFormat.LONG);
				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				if(propertyHelper.getProperty("ForcedateOnPDF_EN")!=null && propertyHelper.getProperty("ForcedateOnPDF_EN").trim()!="") {
					currDate = propertyHelper.getProperty("ForcedateOnPDF_EN");
				}
				//	com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ",
						writer.getCurrentPageNumber()),boldContentFont),
						document.left()+250 , document.bottom()-45, 0);
			}


			PdfPTable table = new PdfPTable(3);
			table.getDefaultCell().setBorder(0);
			table.getDefaultCell().setPaddingBottom(25);

			PdfPTable table1 = null;

			table.setTotalWidth(475);
			table.setLockedWidth(true);
			PdfPCell cell;

			com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.WHITE);

			//Paragraph p1 = new Paragraph(vehicleItemsXML2.get(0).getVehicleName(),tableHeader);
			//Paragraph p1 = new Paragraph(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader);
			//p1.setAlignment(Element.ALIGN_LEFT);
			cell = new PdfPCell(new Phrase(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader));
			cell.setMinimumHeight(15f);
			cell.setBackgroundColor(BaseColor.BLACK);
			//	cell.setPaddingBottom(0.3f);
			//	cell.setPaddingTop(0.3f);
			//cell.setPaddingLeft(2f);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);

			//	cell.addElement(p1);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("RPO CODES",tableHeader));
			if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
				cell = new PdfPCell(new Phrase("Codes �FC",tableHeader));
			}

			cell.setFixedHeight(15f);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(BaseColor.BLACK);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(vehicleItemsXML.get(0).getRegionName(),tableHeader));
			cell.setFixedHeight(15f);
			cell.setBackgroundColor(BaseColor.BLACK);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell.setPaddingLeft(2f);

			table.addCell(cell);
			PdfPTable table2;
			table2 = new PdfPTable(1);
			table2.setTotalWidth(475);
			cell = new PdfPCell();
			cell.setPaddingBottom(25);
			cell.setBorder(Rectangle.NO_BORDER);

			PdfPTable table4 = new PdfPTable(2);
			table4 = new PdfPTable(2);
			table4.getDefaultCell().setBorder(0);
			table4.getDefaultCell().setPadding(0);
			table4.setTotalWidth(475);
			cell.setBackgroundColor(new BaseColor(153,153,153));

			try {
				table4.setWidths(new int[] {75,400});
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			table4.setLockedWidth(true);
			cell.setBackgroundColor(new BaseColor(153,153,153));
			cell = new PdfPCell(new Phrase("Option Code",boldContentFont));
			if(vehicleItemsXML.get(0).getLocaleCode()!=null && vehicleItemsXML.get(0).getLocaleCode().intValueExact()==2){
				cell = new PdfPCell(new Phrase("le code d'option",boldContentFont));
			}

			cell.setNoWrap(false);
			cell.setMinimumHeight(15f);
			cell.setBackgroundColor(new BaseColor(153,153,153));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table4.addCell(cell);


			cell = new PdfPCell(new Phrase("Description",boldContentFont));
			cell.setNoWrap(false);
			cell.setMinimumHeight(15f);
			cell.setBackgroundColor(new BaseColor(153,153,153));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table4.addCell(cell);


			table.addCell(table4);
			//	table.addCell(table2);

			table.writeSelectedRows(0, -1, 70, 750, writer.getDirectContent());
		}

	}


	public void startRpoCodesPDFGeneration(List<RpoCodesBean> rpoCodesBeanList,
										   Document document, PdfWriter writer, int pdfType) {
		try {

			new ItextPDFGenerator_RpoCodes().createPdf(rpoCodesBeanList,document,writer,pdfType );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


}
