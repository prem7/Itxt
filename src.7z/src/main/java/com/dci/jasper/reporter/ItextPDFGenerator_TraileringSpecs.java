package com.dci.jasper.reporter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import com.dci.enterprise.dao.ItextTraileringSpecsPDFGeneratorDAO;
import com.dci.enterprise.model.TraileringSpecsBean;
import com.dci.enterprise.model.TraileringSpecsBeanRestriction;
import com.dci.enterprise.model.TraileringSpecsContentBean;
import com.dci.enterprise.model.TraileringSpecsGCWRBean;
import com.dci.enterprise.model.TraileringSpecsGCWRContent;
import com.dci.enterprise.model.TraileringSpecsGCWRHeaderBean;
import com.dci.extrafunc.PropertyHelper;
import com.dci.general.utilities.VehicleConstant;
import com.google.common.base.CaseFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class ItextPDFGenerator_TraileringSpecs extends PdfPageEventHelper implements ItextTraileringSpecsPDFGeneratorDAO{
	//public static final String RESULT = "c:\\reports\\TestingStandardEq.pdf";




	private static List<TraileringSpecsBean> traileringSpecsHeaderList = null;
	private  List<TraileringSpecsContentBean>  traileringSpecsContentBeansList=null;
	private  List<TraileringSpecsGCWRBean>  traileringSpecsGCWRBeanList=null;
	private  List<TraileringSpecsGCWRContent>  traileringSpecsGCWRContentList=null;
	private  List<TraileringSpecsGCWRHeaderBean>  traileringSpecsGCWRHeaderBeansList=null;
	private  List<TraileringSpecsBeanRestriction>  traileringSpecsBeanRestrictionList=null;
	private  List<TraileringSpecsBeanRestriction>  traileringSpecsBeanRestrictionList2=null;
	private static int[] restrictionID; 
	public static ArrayList<Integer> restrictionIDList = new ArrayList<Integer>();
	public static	Document document=null;
	public static int pdfType;
	public static Properties unicodeProperties;
	public static int pageNumExist=0;
	InputStream inputStream = null;
	public void createPdf(List<ArrayList<Object>>  finalList, Document document, PdfWriter writer, int pdfType)
			throws IOException, DocumentException {

		traileringSpecsHeaderList =(List<TraileringSpecsBean>)finalList.get(0).get(0);
		if(traileringSpecsHeaderList!=null && (!traileringSpecsHeaderList.isEmpty()) && (traileringSpecsHeaderList.get(0).getVehicleId()!=null)){
			this.pdfType = pdfType;
			PdfPTable headerTable = null;
			PdfPTable table = null;
			// step 1
			loadRestriction();
			if(pdfType==0){
				document = new Document();
				document = new Document(PageSize.LETTER, 25, 20, 100, 150);
				document.setMargins(72,72, 75, 115);
				document.setMarginMirroringTopBottom(true);
				String fileName = traileringSpecsHeaderList.get(0).getVehicleId()+"-"+"trailering_fo";


				if(traileringSpecsHeaderList.get(0).getRegionID()!=null && traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getRegionID().intValueExact()==14 && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){
					fileName+="_fr";
				}
				PropertyHelper propertyHelper = new PropertyHelper();
				String location = propertyHelper.getProperty("pdfDefaultLocation");
				writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));
			}


			writer.setPageEvent(new HeaderAndFooter(""));
			writer.setPageEmpty(false);
			// step 3
			document.open();
			// step 4f
			pageNumExist =0;
		
			//	headerTable = createHeader(vehicleItemsXML.get(0),i);
			for (int k = 0; k < finalList.size(); k++) {

				traileringSpecsGCWRBeanList =(List<TraileringSpecsGCWRBean>)finalList.get(k).get(2);
				traileringSpecsContentBeansList =(List<TraileringSpecsContentBean>)finalList.get(k).get(1);
				
				if(traileringSpecsContentBeansList!=null &&!traileringSpecsContentBeansList.isEmpty()){
					pageNumExist++;
				}
				
				if(traileringSpecsGCWRBeanList!=null  && !traileringSpecsGCWRBeanList.isEmpty()){
				//	pageNumExist++;
				}
				if(!traileringSpecsContentBeansList.isEmpty()){
					//if(k>0){
						document.newPage();
					//}
					table = createTable(finalList.get(k));
					/*	table.setSplitLate(false);
					table.setSplitRows(false);*/
					//System.out.println(table.getRows(0, 1).toString());
					//document.add(headerTable);
					
					if(table!=null){
						document.add(table);
					}

					if(traileringSpecsGCWRBeanList!=null && !traileringSpecsGCWRBeanList.isEmpty()){
					//	document.newPage();
						table = createTable2(finalList.get(k));
						table.setSpacingBefore(10);
						table.setSpacingAfter(5);

						document.add(table);
						
					}
					//	PdfPTable footer = createFooter(writer);

					/*	document.add(headerTable);
		document.add(table);*/
					//	document.add(footer);
				}

			}
			if(pdfType==0)
			{

				onCloseDocument(writer, document);
				// step 5
				document.close();
			}
		}
	}

	private void loadRestriction() {

		unicodeProperties = new Properties();
		inputStream = null;

		try {
			inputStream = new FileInputStream("./Unicode.properties");
			unicodeProperties.load(inputStream);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private PdfPTable createTable2(List<Object> finalList) throws DocumentException {

		traileringSpecsContentBeansList =null;
		traileringSpecsGCWRBeanList =null;
		traileringSpecsGCWRContentList=null;
		traileringSpecsGCWRHeaderBeansList=null;
		traileringSpecsBeanRestrictionList = null;

		traileringSpecsContentBeansList =(List<TraileringSpecsContentBean>)finalList.get(1);
		traileringSpecsGCWRBeanList =(List<TraileringSpecsGCWRBean>)finalList.get(2);
		traileringSpecsGCWRContentList =(List<TraileringSpecsGCWRContent>)finalList.get(3);
		traileringSpecsGCWRHeaderBeansList =(List<TraileringSpecsGCWRHeaderBean>)finalList.get(4);
		traileringSpecsBeanRestrictionList = (List<TraileringSpecsBeanRestriction>)finalList.get(5);
		traileringSpecsBeanRestrictionList2 =(List<TraileringSpecsBeanRestriction>)finalList.get(6);
		PdfPTable table = null;
		PdfPTable tableH = null;
		PdfPTable tableRightHeaders2 = null;
		PdfPTable tableLeftHeaders2 = null;
		BaseFont base = null;
		try {
			base = BaseFont.createFont("c:/windows/fonts/ARIALUNI.ttf", BaseFont.IDENTITY_H, false);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.WHITE);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		Font superScriptfont = new Font(base, 10, Font.NORMAL);



		tableH = new PdfPTable(1);
		tableH.getDefaultCell().setBorder(0);
		tableH.getDefaultCell().setPadding(0);
		tableH.setTotalWidth(475);
		tableH.setLockedWidth(true);
		tableH.setSplitRows(true);
		tableH.setSplitLate(true);

		tableH.setHeaderRows(2);
		if(traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){

			insertCell(tableH, null,"PNBV pour ratio moteur / essieu arri�re combin� avec Bo�te de vitesses automatique", null, Element.ALIGN_CENTER, Font.NORMAL, boldContentFont, new BaseColor(204,204,204));

		}
		else{
			insertCell(tableH, null,"GCWR For Engine/Rear Axle Ratio Combination with Automatic Transmission", null, Element.ALIGN_CENTER, Font.NORMAL, boldContentFont, new BaseColor(204,204,204));
		}
		tableLeftHeaders2 = new PdfPTable(2);
		tableLeftHeaders2.setTotalWidth(475);
		tableLeftHeaders2.setWidths(new int[]{66,409});
		tableLeftHeaders2.getDefaultCell().setBorder(0);
		tableLeftHeaders2.getDefaultCell().setPadding(0);
		//tableLeft.setTotalWidth(68);

		PdfPCell cell;
		table = new PdfPTable(2);
		table.setTotalWidth(475);
		table.setWidths(new int[]{66,409});
		table.setLockedWidth(true);
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);

		//insertCell(tableLeft, null,"Model", null, Element.ALIGN_CENTER, Font.NORMAL, boldContentFont, new BaseColor(204,204,204));

		if(traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){

			cell =	new PdfPCell(new Phrase("Moteur ",boldContentFont));

		}
		else{
			cell =	new PdfPCell(new Phrase("Engine ",boldContentFont));
		}
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setNoWrap(false);
		cell.setMinimumHeight(32.5f);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		tableLeftHeaders2.addCell(cell);

		tableRightHeaders2 = new PdfPTable(traileringSpecsGCWRHeaderBeansList.size());
		tableRightHeaders2.getDefaultCell().setBorder(0);
		tableRightHeaders2.getDefaultCell().setPadding(0);
		//	tableRight.setTotalWidth(475);

		if(traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){

			cell =	new PdfPCell(new Phrase("(PNVC) poids nominal brut combin� lbs. (kg)   ",boldContentFont));

		}
		else{
			cell =	new PdfPCell(new Phrase("(GCWR) Gross Combination Weight Ratings lbs. (kg) ",boldContentFont));
		}
		cell.setColspan(traileringSpecsGCWRHeaderBeansList.size());
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setNoWrap(false);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		tableRightHeaders2.addCell(cell);
		int colSpan=0;

		for (TraileringSpecsGCWRHeaderBean traileringSpecsGCWRHeaderBean : traileringSpecsGCWRHeaderBeansList) {
			float cellval =Float.parseFloat(traileringSpecsGCWRHeaderBean.getGCWRValueMetric().toString());
			DecimalFormat df = new DecimalFormat("#");
			String cellT = 	df.format(cellval);
			cell =	new PdfPCell(new Phrase(traileringSpecsGCWRHeaderBean.getGCWRValue()+" ("+cellT+")",boldContentFont));
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setNoWrap(false);
			cell.setMinimumHeight(20.4f);
			cell.setColspan(colSpan);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableRightHeaders2.addCell(cell);
		}


		tableLeftHeaders2.addCell(tableRightHeaders2);




		List<BigDecimal> gvwrList = new ArrayList<BigDecimal>();
		for (TraileringSpecsGCWRBean traileringSpecsGCWRBean_temp : traileringSpecsGCWRBeanList) {
			if(!gvwrList.contains(traileringSpecsGCWRBean_temp.getGCWRValue())){
				gvwrList.add(traileringSpecsGCWRBean_temp.getGCWRValue());
			}
		}

		PdfPTable tableContent2 = new PdfPTable(1+gvwrList.size());
		float[] columnsArray = new float[1+(gvwrList.size())] ;
		columnsArray[0]= 66;
		for (int i = 1; i <=(gvwrList.size()); i++) {
			columnsArray[i]=409/(gvwrList.size());
		}
		tableContent2.setWidths(columnsArray);
		tableContent2.getDefaultCell().setBorder(0);
		tableContent2.getDefaultCell().setPadding(0);


		for (TraileringSpecsBean foreachRow : traileringSpecsHeaderList) 
		{
			boolean foundMatch = false;

			insertCell(tableContent2,"("+foreachRow.getRpoName()+") "+foreachRow.getEngineDescription() ,"", null, Element.ALIGN_CENTER, colSpan, tableHeader1,BaseColor.WHITE);

			for (BigDecimal foreachColumn : gvwrList){
				foundMatch = false;
				for (TraileringSpecsGCWRBean foreachCell : traileringSpecsGCWRBeanList) {
					if(foreachCell.getRestricionID()== null){
						foreachCell.setRestricionID(new BigDecimal(20));
					}
					if(foreachCell.getTraileringHeaderID().equals(foreachRow.getTraileringHeaderID()) && foreachCell.getGCWRValue().equals(foreachColumn) )
					{
						foundMatch = true;
						Phrase ph = new Phrase(""+decimalPlaces(foreachCell.getRearAxleRatio().toString(),2),tableHeader1);
						Phrase phN = new Phrase(restrictionFlag_package(foreachCell.getRestricionID().intValueExact()),superScriptfont);
						ph.add(phN);
						insertCustomCell(tableContent2,null,ph, Element.ALIGN_CENTER, 1, tableHeader1);
						//insertCell(tableContent2,null,""+foreachCell.getRearAxleRatio(), null, Element.ALIGN_CENTER, colSpan, tableHeader1,BaseColor.WHITE);
					}
					/*else
					insertCell(tableRight,null,"", null, Element.ALIGN_CENTER, colSpan, tableHeader1,BaseColor.WHITE);
					 */
				}
				if(!foundMatch){
					insertCell(tableContent2,null,"", null, Element.ALIGN_CENTER, colSpan, tableHeader1,BaseColor.WHITE);

				}
			}
		}


		//tableLeftHeaders2.addCell(tableRight);
		//tableH.addCell(table);
		tableH.addCell(tableLeftHeaders2);
		tableH.addCell(tableContent2);

		int count = 0;
		String tempRest="";
		List<String> restrictionlist = new ArrayList<String>();
		for (TraileringSpecsBeanRestriction traileringSpecsBeanRestriction : traileringSpecsBeanRestrictionList2)
		{


			if(traileringSpecsBeanRestriction.getRestrictionText()!=null )
			{
				if(!restrictionlist.contains(traileringSpecsBeanRestriction.getRestrictionText())) {
				count++;
				
				tempRest+=count+" - "+traileringSpecsBeanRestriction.getRestrictionText().trim()+" \n";
				restrictionlist.add(traileringSpecsBeanRestriction.getRestrictionText());
				}
			}

		}
		if(count>0){
			insertCell(tableH,null,tempRest, null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
		}
		//tableH.addCell(table);
		return tableH;

	}

	public String decimalRidder(double d){
		String cell;
		float cellval =(float)d;
		DecimalFormat df = null;      

		df = new DecimalFormat("#");

		cell =	df.format(cellval);


		return cell;

	}

	public String getLocation()
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String location = null;
		if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			location = eProperties.getProperty("pdfDefaultLocation");
		}
		return location;
	}

	class TableHeader extends PdfPageEventHelper {
		/** The header text. */
		String header;
		/** The template with the total number of pages. */
		PdfTemplate total;

		/**
		 * Allows us to change the content of the header.
		 * @param header The new header String
		 */
		public void setHeader(String header) {
			this.header = header;
		}

		/**
		 * Creates the PdfTemplate that will hold the total number of pages.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onOpenDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
		}

		/**
		 * Adds a header to every page
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onEndPage(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			try {
				table.setWidths(new int[]{24, 24, 2});
				table.setTotalWidth(475);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(550);
				table.getDefaultCell().setBorder(Rectangle.BOTTOM);
				table.addCell(header);
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Page %d of", writer.getCurrentPageNumber()));
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.BOTTOM);
				table.addCell(cell);
				table.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
			}
			catch(DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		/**
		 * Fills out the total number of pages before the document is closed.
		 * @see com.itextpdf.text.pdf.PdfPageEventHelper#onCloseDocument(
		 *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
		 */
		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT,
					new Phrase(String.valueOf(writer.getCurrentPageNumber() - 1)),
					2, 2, 0);
		}
	}


	public  PdfPTable createTable(List<Object> finalList) throws DocumentException {

		traileringSpecsContentBeansList =null;
		traileringSpecsGCWRBeanList =null;
		traileringSpecsGCWRContentList=null;
		traileringSpecsGCWRHeaderBeansList=null;
		traileringSpecsBeanRestrictionList = null;
		
		traileringSpecsHeaderList =(List<TraileringSpecsBean>)finalList.get(0);
		traileringSpecsContentBeansList =(List<TraileringSpecsContentBean>)finalList.get(1);
		traileringSpecsGCWRBeanList =(List<TraileringSpecsGCWRBean>)finalList.get(2);
		traileringSpecsGCWRContentList =(List<TraileringSpecsGCWRContent>)finalList.get(3);
		traileringSpecsGCWRHeaderBeansList =(List<TraileringSpecsGCWRHeaderBean>)finalList.get(4);
		traileringSpecsBeanRestrictionList = (List<TraileringSpecsBeanRestriction>)finalList.get(5);
		traileringSpecsBeanRestrictionList2 =(List<TraileringSpecsBeanRestriction>)finalList.get(6);
		restrictionID = new int[traileringSpecsBeanRestrictionList2.size()];
		ArrayList<BigDecimal> columnsList = new ArrayList<BigDecimal>(traileringSpecsHeaderList.size());
		//PdfPTable table = null;
		PdfPTable tableH = null;
		PdfPTable tableRightHeaders = null;
		PdfPTable tableLeftHeaders = null;
		PdfPTable tableContents = null;

		com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldFont =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD,BaseColor.WHITE);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		BaseFont base = null;
		try {
			base = BaseFont.createFont("c:/windows/fonts/ARIALUNI.ttf", BaseFont.IDENTITY_H, false);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Font Wfont = new Font(base, 8, Font.NORMAL);
		Font superBoldScriptfont = new Font(base, 9, Font.NORMAL);
		Font superScriptfont = new Font(base, 10, Font.NORMAL);
		restrictionIDList.clear();
		for (TraileringSpecsBeanRestriction traileringSpecsBeanRestriction : traileringSpecsBeanRestrictionList2) {
			if(!restrictionIDList.contains(traileringSpecsBeanRestriction.getRestrictionID().intValueExact())){
				restrictionIDList.add(traileringSpecsBeanRestriction.getRestrictionID().intValueExact());
			}
		}

		tableH = new PdfPTable(1);
		tableH.getDefaultCell().setBorder(0);
		tableH.getDefaultCell().setPadding(0);
		tableH.setTotalWidth(475);
		tableH.setLockedWidth(true);
		for (TraileringSpecsBeanRestriction traileringSpecsBeanRestriction : traileringSpecsBeanRestrictionList)
		{

			if(traileringSpecsBeanRestriction.getOptionalTypeDescription()!=null )
			{
				insertCell(tableH,null,""+traileringSpecsBeanRestriction.getOptionalTypeDescription(), null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
			}


		}

		PdfPCell cell1;
		
		if(!traileringSpecsBeanRestrictionList.isEmpty())			
			cell1 =	new PdfPCell(new Phrase(traileringSpecsBeanRestrictionList.get(0).getPullDownText(),boldContentFont));
			else
			cell1 =	new PdfPCell(new Phrase("",boldContentFont));
		
		cell1.setBackgroundColor(new BaseColor(204,204,204));
		cell1.setNoWrap(false);
		cell1.setMinimumHeight(18f);
		cell1.setBackgroundColor(new BaseColor(204,204,204));
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell1.setVerticalAlignment(Element.ALIGN_CENTER);
		cell1.setPaddingTop(4f);
		tableH.addCell(cell1);
		//	insertCell(tableH, null,traileringSpecsBeanRestrictionList.get(0).getPullDownText(), null, Element.ALIGN_CENTER, Font.NORMAL, boldContentFont, new BaseColor(204,204,204));

		tableLeftHeaders = new PdfPTable(2);
		tableLeftHeaders.setTotalWidth(475);
		tableLeftHeaders.setWidths(new int[]{66,409});
		tableLeftHeaders.setLockedWidth(true);
		tableLeftHeaders.getDefaultCell().setBorder(0);
		tableLeftHeaders.getDefaultCell().setPadding(0);
		//tableLeft.setTotalWidth(68);

		PdfPCell cell;
		/*table = new PdfPTable(2);
		table.setTotalWidth(475);
		table.setWidths(new int[]{66,409});
		table.setLockedWidth(true);
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);*/

		//insertCell(tableLeft, null,"Model", null, Element.ALIGN_CENTER, Font.NORMAL, boldContentFont, new BaseColor(204,204,204));
		if(traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){

			cell =	new PdfPCell(new Phrase("Mod�le",boldContentFont));

		}
		else{
			cell =	new PdfPCell(new Phrase("Model",boldContentFont));
		}

		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setNoWrap(false);

		cell.setMinimumHeight(32f);

		/*	if(traileringSpecsHeaderList.size()>1){
			cell.setMinimumHeight(43f);
		}*/
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		tableLeftHeaders.addCell(cell);
		tableRightHeaders = new PdfPTable(traileringSpecsHeaderList.size()*2);
		tableRightHeaders.getDefaultCell().setBorder(0);
		tableRightHeaders.getDefaultCell().setPadding(0);




		for (TraileringSpecsBean traileringSpecsBean : traileringSpecsHeaderList) {

			if(traileringSpecsBean.getRestrictionID()== null){
				traileringSpecsBean.setRestrictionID(new BigDecimal(10));
			}
			Phrase ph = new Phrase("("+traileringSpecsBean.getRpoName()+") "+traileringSpecsBean.getEngineDescription(),boldContentFont);
			Phrase phN = new Phrase(restrictionFlag_package(traileringSpecsBean.getRestrictionID().intValueExact()),superScriptfont);
			ph.add(phN);
			cell = new PdfPCell(ph);
			cell.setColspan(2);
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setNoWrap(false);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			tableRightHeaders.addCell(cell);

			/*cell = new PdfPCell(new Phrase("Axle Ratio",boldContentFont));
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setNoWrap(false);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableRight.addCell(cell);


			cell = new PdfPCell(new Phrase("Maximum Trailer Weight \n lbs. (kg)",boldContentFont));
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setNoWrap(false);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableRight.addCell(cell);*/

		}

		for (TraileringSpecsBean traileringSpecsBean : traileringSpecsHeaderList){

			if(traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){

				cell =	new PdfPCell(new Phrase("Rapport de pont",boldContentFont));

			}
			else{
				cell =	new PdfPCell(new Phrase("Axle Ratio",boldContentFont));
			}
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setNoWrap(false);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableRightHeaders.addCell(cell);


			if(traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){

				cell =	new PdfPCell(new Phrase("Maximal de la remorque Poids lbs. (kg) ",boldContentFont));

			}
			else{
				cell =	new PdfPCell(new Phrase("Maximum Trailer Weight \n lbs. (kg)",boldContentFont));
			}
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setNoWrap(false);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableRightHeaders.addCell(cell);
		}
		tableLeftHeaders.addCell(tableRightHeaders);

		//	tableRight.setTotalWidth(475);


		tableContents = new PdfPTable(1+(traileringSpecsHeaderList.size()*2));
		tableContents.setTotalWidth(475);
		float[] columnsArray = new float[1+(traileringSpecsHeaderList.size()*2)] ;
		columnsArray[0]= 66;
		for (int i = 1; i <=(traileringSpecsHeaderList.size()*2); i++) {
			columnsArray[i]=409/(traileringSpecsHeaderList.size()*2);
		}
		tableContents.setWidths(columnsArray);
		tableContents.setLockedWidth(true);
		tableContents.getDefaultCell().setBorder(0);
		tableContents.getDefaultCell().setPadding(0);
		for (TraileringSpecsBean traileringSpec: traileringSpecsHeaderList) {
			columnsList.add(traileringSpec.getTraileringHeaderID());
		}
		List<BigDecimal> engineSortList = new ArrayList<BigDecimal>();
		for (TraileringSpecsGCWRContent traileringEngineSort : traileringSpecsGCWRContentList) {
			engineSortList.add(traileringEngineSort.getEngineSort());
		}


		for (TraileringSpecsContentBean foreachRow : traileringSpecsContentBeansList) {
			boolean foundMatch = false;
			if(foreachRow.getTCName()==null || foreachRow.getTCName()=="null"){
				foreachRow.setTCName("");
			}
			cell =	new PdfPCell(new Phrase(foreachRow.getModelName()+"\n"+foreachRow.getTCName(),boldContentFont));
			cell.setBackgroundColor(BaseColor.WHITE);
			cell.setNoWrap(false);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setRowspan(foreachRow.getMaxRows().intValueExact());
			tableContents.addCell(cell);
			//insertCell(tableContents,foreachRow.getModelName(),"", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
			List<BigDecimal> traileringIDList = new ArrayList<BigDecimal>();


			/*for (BigDecimal foreachColumn : columnsList){

					foundMatch = false;
					//foreach cell 
					for (TraileringSpecsGCWRContent foreachCell : traileringSpecsGCWRContentList) {
						for(int i =1;i<= foreachRow.getMaxRows().intValueExact();i++ ){	
							for (int j =1;j<=columnsList.size();j++ ){
						if(!traileringIDList.contains(foreachCell.getTraileringCategoryHeaderID()) && (foreachCell.getEngineSort().intValueExact()==(j*10))){
						if(foreachCell.getTraileringCateogoryID().equals(foreachRow.getTraileringCategoryID())
								&& foreachColumn.equals(foreachCell.getTraileringHeaderID())) {


								foundMatch = true;
								traileringIDList.add(foreachCell.getTraileringCategoryHeaderID());
							insertCell(tableContents,null,""+foreachCell.getAxleRatio(), null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
							if(foreachCell.getMaxTraileringWeight()!=null){
								insertCell(tableContents,null,foreachCell.getMaxTraileringWeight()+" ("+foreachCell.getMaxTraileringWeightMetric().intValue()+")", null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);

							}
							else{
								foundMatch = true;
								insertCell(tableContents,null,"--", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
							}

						}
						}
						}
					}
					if(!foundMatch) {

						insertCell(tableContents,null,"-----", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
						insertCell(tableContents,null,"-----", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
					}
				}

			}*/

			//multi dimensional Array logic

			//for each row 
			for (int i = 1; i <=foreachRow.getMaxRows().intValueExact(); i++) {
				foundMatch = false;
				//foreach collumn
				for (int j = 1; j <= columnsList.size(); j++) {
					foundMatch = false;
					for (TraileringSpecsGCWRContent foreachCell : traileringSpecsGCWRContentList) {
						foundMatch = false;
						if(!traileringIDList.contains(foreachCell.getTraileringCategoryHeaderID())
								&& 
								/*(foreachCell.getEngineSort().intValueExact()==(j*10)) &&*/
								foreachCell.getTraileringCateogoryID().equals(foreachRow.getTraileringCategoryID())
								&& columnsList.get(j-1).equals(foreachCell.getTraileringHeaderID())
								){

							if(foreachCell.getMaxTraileringWeightRestricionID()== null){
								foreachCell.setMaxTraileringWeightRestricionID(new BigDecimal(20));
							}

							if(foreachCell.getAxleRatioRestrictionID()== null){
								foreachCell.setAxleRatioRestrictionID(new BigDecimal(20));
							}
							traileringIDList.add(foreachCell.getTraileringCategoryHeaderID());
							foundMatch = true;
							Phrase ph = null;
							if(foreachCell.getAxleRatio()!=null){
							 ph = new Phrase(""+decimalPlaces(foreachCell.getAxleRatio().toString(),2),tableHeader1);
							}
							else {
								ph = new Phrase("",tableHeader1);
							}
							Phrase phN = new Phrase(restrictionFlag_package(foreachCell.getAxleRatioRestrictionID().intValueExact()),superScriptfont);
							ph.add(phN);
							insertCustomCell(tableContents,null,ph, Element.ALIGN_CENTER, 1, tableHeader1);
							//insertCell(tableContents,null,""+foreachCell.getAxleRatio(), null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
						
							ph = new Phrase(""+foreachCell.getMaxTraileringWeight()+" ("+decimalRidder(Math.round(Float.valueOf(foreachCell.getMaxTraileringWeightMetric().toString())))+")",tableHeader1);
							phN = new Phrase(restrictionFlag_package(foreachCell.getMaxTraileringWeightRestricionID().intValueExact()),superScriptfont);
							ph.add(phN);
							insertCustomCell(tableContents,null,ph, Element.ALIGN_CENTER, 1, tableHeader1);
							//	insertCell(tableContents,null,""+foreachCell.getMaxTraileringWeight()+" ("+foreachCell.getMaxTraileringWeightMetric().intValue()+")", null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
							break;
						}

					}
					if(!foundMatch) {

						insertCell(tableContents,null,"", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
						insertCell(tableContents,null,"", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
					}


				}



			}




		}


		/*table.addCell(tableLeft);
		table.addCell(tableRight);*/
		//	tableH.addCell(table);
		tableH.addCell(tableLeftHeaders);
		tableH.addCell(tableContents);
		String tempFooterNote ="";
		String tempRest="";
		if(traileringSpecsBeanRestrictionList.size()>0 && !traileringSpecsBeanRestrictionList.isEmpty()){


			for (TraileringSpecsBeanRestriction traileringSpecsBeanRestriction : traileringSpecsBeanRestrictionList)
			{

				if(traileringSpecsBeanRestriction.getOptionalFooterNote1()!=null){

					tempFooterNote+= traileringSpecsBeanRestriction.getOptionalFooterNote1().replace("null", "").trim();
					//	insertCell(tableH,null,""+, null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
				}


			}

		}
		if(traileringSpecsGCWRBeanList==null || traileringSpecsGCWRBeanList.isEmpty()){
			int restCount=0;
			for (TraileringSpecsBeanRestriction traileringSpecsBeanRestriction : traileringSpecsBeanRestrictionList2)
			{

				if(traileringSpecsBeanRestriction.getRestrictionText()!=null )
				{
					restCount++;
					tempRest +=restCount+" - "+traileringSpecsBeanRestriction.getRestrictionText()+"\n"; 
					//insertCell(tableH,null,restCount+" - "+traileringSpecsBeanRestriction.getRestrictionText()+" \n", null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
				}

			}

		}
		if(!(tempFooterNote.trim().equalsIgnoreCase("") && tempRest.trim().equalsIgnoreCase("") ))
		{
			insertCell(tableH,null,tempFooterNote+" \n"+tempRest, null, Element.ALIGN_LEFT, 1, tableHeader1,BaseColor.WHITE);
		}
		//tableH.addCell(table);
		return tableH;

	}


	private static void insertImage(PdfPTable table, PdfPCell cell,
			int align, int i, Font tableHeader1) {
		cell.setHorizontalAlignment(align);
		cell.setVerticalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setBorderWidth(0.5f);
		//add the call to the table
		table.addCell(cell);

	}


	public void startRadioPDFGeneration (List<ArrayList<Object>> traileringSpecsList) {

		try {

			new ItextPDFGenerator_TraileringSpecs().createPdf(traileringSpecsList,null,null,0 );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	public String decimalPlaces(String cellvalue, int decimalPlaces){
		String cell;
		float cellval =Float.parseFloat(cellvalue);
		DecimalFormat df = null;      


		if(decimalPlaces==0)
		{
			df = new DecimalFormat("#");
		}

		if(decimalPlaces==1)
		{
			df = new DecimalFormat("#.0");
		}
		if(decimalPlaces==2)
		{
			df = new DecimalFormat("#.00");
		}
		if(decimalPlaces==3)
		{
			df =  new DecimalFormat("#.000");
		}

		cell =	df.format(cellval);


		return cell;

	}
	public static String restrictionFlag_package(int currentRestrictionID){
		String unicodeFlag="";
		boolean isRestrictionExist = false;
		if(currentRestrictionID!=20){
			int restrictionPosition=1;

			for (int restriction : restrictionIDList) {


				if(currentRestrictionID==restriction){
					isRestrictionExist = true;
					break;
				}
				restrictionPosition++;
			}


			if(unicodeProperties.getProperty(String.valueOf(restrictionPosition))!=null && !unicodeProperties.getProperty(String.valueOf(restrictionPosition)).isEmpty())
			{
				unicodeFlag = unicodeProperties.getProperty(String.valueOf(restrictionPosition));
			}

		}
		if(!isRestrictionExist) {
			unicodeFlag="";
		}
		return unicodeFlag;
	}

	public static void insertCustomCell(PdfPTable table,String isNew, Phrase p1, int align, int colspan, Font font){



		//create a new cell with the specified Text and Font
		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font redFont1 =  FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		pdfType =2;
		if(pdfType==VehicleConstant.PRINTBOOKS){

			redFont1 = FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.RED);

		}

		if(isNew!=null){
			para.add(new Phrase(isNew, redFont1));
		}
		para.add(p1);
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		//in case there is no text and you wan to create an empty row

		//add the call to the table
		table.addCell(cell);

	}

	public static void insertCell(PdfPTable table,String boldText, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font redFont1 =  FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.BLACK);
		Paragraph para = new Paragraph();


		if(boldText!=null){
			para.add(new Phrase(boldText, boldContentFont));
		}
		para.add(new Phrase(text, font));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, boldContentFont1));
		}
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(colspan);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		cell.setBackgroundColor(color);
		//in case there is no text and you wan to create an empty row
		if(text.trim()== null || text.trim().equalsIgnoreCase("")){
			cell.setMinimumHeight(10f);
		}
		//add the call to the table
		table.addCell(cell);

	}

	public void onCloseDocument(PdfWriter writer, Document document) {
		Paragraph p1 = new Paragraph("Testing************");
		PdfPCell cell = new PdfPCell();
		cell.addElement(p1);

		try {
			document.add(cell);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private PdfPTable createFooter(PdfWriter writer) {
		DateFormat defDate=null;
		defDate  = DateFormat.getDateInstance(DateFormat.LONG);
		String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, defDate.format(new Date())); 
		com.itextpdf.text.Font footerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		PdfPTable table = new PdfPTable(1);
		table.setTotalWidth(475);
		Paragraph p1 = new Paragraph("Published " + currDate +" Page "+writer.getCurrentPageNumber(),footerFont);
		PdfPCell cell = new PdfPCell();

		p1.setAlignment(Element.ALIGN_CENTER);
		cell.addElement(p1);
		cell.setPaddingTop(40);
		cell.setPaddingBottom(40);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		return table;
	}


	public class HeaderAndFooter extends PdfPageEventHelper {

		private String name = "";
		PdfTemplate total;

		protected Phrase footer;
		protected Phrase header;

		/*
		 * Font for header and footer part.
		 */
		com.itextpdf.text.Font headerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		/*private static Font headerFont = new Font(Font.COURIER, 9,
	            Font.NORMAL,Color.blue);

	    private static Font footerFont = new Font(Font.TIMES_ROMAN, 9,
	            Font.BOLD,Color.blue);*/


		/*
		 * constructor
		 */
		public HeaderAndFooter(String name) {
			super();
			this.name = name;
			header = new Phrase("***** Header *****");
			footer = new Phrase("**** Footer ****");
		}

		@Override
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
			// TODO Auto-generated method stub
			super.onOpenDocument(writer, document);
		}
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			if(!traileringSpecsHeaderList.isEmpty()){
				PdfContentByte cb = writer.getDirectContent();

				//header content
				String headerContent = "Name: " +name;

				//header content
				String footerContent = headerContent;
				/*
				 * Header
				 */
				/*	ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(headerContent,headerFont), 
	                document.leftMargin(), document.top() -30, 0);*/

				/*
				 * Foooter
				 */
				DateFormat defDate=null;
				PropertyHelper propertyHelper = new PropertyHelper();
				if(traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){
					defDate  = DateFormat.getDateInstance(DateFormat.LONG,Locale.FRANCE);

					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
					if(propertyHelper.getProperty("ForcedateOnPDF_FR")!=null && propertyHelper.getProperty("ForcedateOnPDF_FR").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_FR");
					}
					ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
							writer.getCurrentPageNumber()),boldContentFont), 
							document.left()+250 , document.bottom()-45, 0);

				}
				else{
					defDate  = DateFormat.getDateInstance(DateFormat.LONG);
					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_EN")!=null && propertyHelper.getProperty("ForcedateOnPDF_EN").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_EN");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
					ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
							writer.getCurrentPageNumber()),boldContentFont), 
							document.left()+250 , document.bottom()-45, 0);
				}


				PdfPTable table = new PdfPTable(3);
				table.getDefaultCell().setBorder(0);
				//table.getDefaultCell().setPaddingBottom(25);

				PdfPTable table1 = null;

				table.setTotalWidth(475);
				try {
					table.setWidths(new int[] {150,195,135});
				} catch (DocumentException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setLockedWidth(true);
				PdfPCell cell;

				com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.WHITE);

				//Paragraph p1 = new Paragraph(vehicleItemsXML2.get(0).getVehicleName(),tableHeader);
				//Paragraph p1 = new Paragraph(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader);
				//p1.setAlignment(Element.ALIGN_LEFT);
				cell = new PdfPCell(new Phrase(traileringSpecsHeaderList.get(0).getVehicleYear() +" "+ traileringSpecsHeaderList.get(0).getDivisionName() +" "+ traileringSpecsHeaderList.get(0).getVehicleName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);

				//	cell.addElement(p1);
				table.addCell(cell);

				//Paragraph p2 = new Paragraph("RPO CODES",tableHeader);
				/*if(pageLabelCount.size()>1){
					cell = new PdfPCell(new Phrase("SPECS" + " - " +pageLabel,tableHeader));
				}
				else
				{*/
				
				if(traileringSpecsHeaderList.get(0).getPulldownText()!=null && traileringSpecsHeaderList.get(0).getPulldownText().trim().equalsIgnoreCase("- DIMENSIONS"))
				{
					traileringSpecsHeaderList.get(0).setPulldownText("");
				}
				if( traileringSpecsHeaderList.get(0).getPulldownText()==null || pageNumExist<=1 ){
					traileringSpecsHeaderList.get(0).setPulldownText("");
				}
				com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.WHITE);

				if(traileringSpecsHeaderList.get(0).getLocaleCode()!=null && traileringSpecsHeaderList.get(0).getLocaleCode().intValueExact()==2){

					cell =	new PdfPCell(new Phrase("�quipements de remorquage "+ traileringSpecsHeaderList.get(0).getPulldownText().trim(),boldContentFont));

				}
				else{
					cell =	new PdfPCell(new Phrase("TRAILERING SPECS "+traileringSpecsHeaderList.get(0).getPulldownText().trim(),boldContentFont));
				}

				//}
				cell.setMinimumHeight(15f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p2.setAlignment(Element.ALIGN_CENTER);

				//cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				//cell.addElement(p2);

				table.addCell(cell);

				//	Paragraph p3 = new Paragraph(vehicleItemsXML.get(0).getRegionName(),tableHeader);
				cell = new PdfPCell(new Phrase(traileringSpecsHeaderList.get(0).getRegionName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p3.setAlignment(Element.ALIGN_RIGHT);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				//cell.addElement(p3);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				cell.setPaddingLeft(2f);

				table.addCell(cell);
				//	table.addCell(table2);
				table.writeSelectedRows(0, -1, 70, 750, writer.getDirectContent());
			}
			else {
				PdfContentByte cb = writer.getDirectContent();
				DateFormat defDate=null;
				defDate  = DateFormat.getDateInstance(DateFormat.LONG);

				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
						writer.getCurrentPageNumber()),headerFont), 
						document.left()+250 , document.bottom()-45, 0);

			}

		}




	}


	public void startRadioPDFGeneration(List<ArrayList<Object>> vehicleItemsXML,
			Document document, PdfWriter writer, int pdfType) {
		try {

			new ItextPDFGenerator_TraileringSpecs().createPdf(vehicleItemsXML,document,writer,pdfType );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}










}
