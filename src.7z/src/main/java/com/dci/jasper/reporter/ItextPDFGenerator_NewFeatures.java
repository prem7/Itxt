package com.dci.jasper.reporter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.dci.enterprise.dao.ItextWheelsPDFGeneratorDAO;
import com.dci.enterprise.model.ModelCoverPageBean;
import com.dci.enterprise.model.NewFeaturesBean;
import com.dci.enterprise.model.WheelsAndRadiosBean;
import com.google.common.base.CaseFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class ItextPDFGenerator_NewFeatures extends PdfPageEventHelper implements ItextWheelsPDFGeneratorDAO {
	private static int subCategoryID;

	public static int pdfType;

	public void createPdf(int subCategoryID, ModelCoverPageBean modelCoverPageBean, Document document, PdfWriter writer, int pdfType)
			throws IOException, DocumentException {
		this.subCategoryID = subCategoryID;
		this.pdfType = pdfType;
		ModelCoverPageBean modelCoverPageBean2 = new ModelCoverPageBean();
		modelCoverPageBean2 =  modelCoverPageBean;
		if(modelCoverPageBean!=null){
			writer.setPageEmpty(false);
			writer.setPageEvent(null);
			writer.setPageEvent(new HeaderAndFooter(""));
			// step 1
			document.open();
			// step 4
			//	PdfPTable headerTable = createHeader(vehicleItemsXML);
			PdfPTable table = createTable(subCategoryID,modelCoverPageBean2);
			//PdfPTable footer = createFooter(writer);

			//	document.add(headerTable);
			document.add(table);
			//document.add(footer);

			if(pdfType==0)
			{

				onCloseDocument(writer, document);
				// step 5
				document.close();
			}

		}
	}


	public static PdfPTable createTable(int subCategoryID,ModelCoverPageBean modelCoverPageBean) throws DocumentException {
		Map<java.math.BigDecimal, String> modelNames = null;
		
		modelNames= modelCoverPageBean.getModelNames();
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);
		
		PdfPTable table1 = null;
		PdfPTable table3;
		PdfPTable table2;
		table.setTotalWidth(475);
		table.setLockedWidth(true);
		table.setSplitLate(false);
		PdfPCell cell;
		BaseFont base = null;
		BaseFont base_regular = null;
		BaseFont base_arial = null;
		try {
			base = BaseFont.createFont("C:/reports/font/CadillacSansA-Thin.ttf", BaseFont.IDENTITY_H, false);
			base_regular = BaseFont.createFont("C:/reports/font/CadillacSerif-Regular.ttf", BaseFont.IDENTITY_H, false);
			base_arial = BaseFont.createFont("c:/windows/fonts/ARIAL.ttf", BaseFont.IDENTITY_H, false);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
		Font cadFont_Light = new Font(base, 18, Font.NORMAL);
		Font cadFont_Light_3 = new Font(base, 36, Font.NORMAL);
		Font temp_Large;
		Font cadFont_regular = new Font(base_regular, 20f, Font.NORMAL);
		cadFont_Light_3.setColor(83, 84, 86);
		cadFont_Light.setColor(83, 84, 86);
		cadFont_regular.setColor(83, 84, 86);
		Font regularFont = new Font(base_arial,12f,Font.NORMAL);
		Font regularFont_bold = new Font(base_arial,14f,Font.BOLD);
		Font regularFont_Large = new Font(base_arial,10f,Font.BOLD);
		com.itextpdf.text.Font tableHeader =  FontFactory.getFont("arial", 40, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldFontLarge =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
	
		table1 = new PdfPTable(1);
		table1.setTotalWidth(475);
		table1.setWidths(new int[]{475});
		String frExten = "";
		if(modelCoverPageBean.getLocaleCode()!=null && modelCoverPageBean.getLocaleCode().intValueExact()==2){
			frExten="_fr";
		}
		
		boldFont = regularFont_bold;
		boldFontLarge = regularFont;			
		temp_Large = regularFont_Large;
		
		int divisionID =modelCoverPageBean.getDivisionID().intValueExact();
		
		

			insertCell(table1,"  ",  "",
					(modelCoverPageBean.getVehicleYear()+" " + modelCoverPageBean.getDivisionName()+" " + modelCoverPageBean.getVehicleName()), 
					Element.ALIGN_CENTER, 0, boldFont,BaseColor.WHITE);
			
			insertCell(table1," ",  "",
					"", 
					Element.ALIGN_CENTER, 0, boldFont,BaseColor.WHITE);
			
			
			
			
			insertCell(table1," ",  "",
					"", 
					Element.ALIGN_CENTER, 0, boldFont,BaseColor.WHITE);		
			
			
		
		
	/*	for (Entry<java.math.BigDecimal, String> entry : modelNames.entrySet()) {
			insertCell(table1,"", "",
					entry.getValue(), 
					Element.ALIGN_CENTER, 0, boldFontLarge,BaseColor.WHITE);
		}*/
			
			insertCell(table1,"", "",
					"Deletions", 
					Element.ALIGN_LEFT, 0, regularFont_bold,BaseColor.WHITE);
			
		for (NewFeaturesBean newFeaturesList : modelCoverPageBean.getNewFeaturesList()) {
				if (newFeaturesList.getTypeID().intValueExact()==7) {
				insertCell(table1,"", "",
						"\u2022 " +newFeaturesList.NFtext, 
						Element.ALIGN_LEFT, 0, boldFontLarge,BaseColor.WHITE);
				}
			}
			
			insertCell(table1," ",  "",
					"", 
					Element.ALIGN_CENTER, 0, boldFont,BaseColor.WHITE);
			
			
			insertCell(table1,"", "",
					"New Features", 
					Element.ALIGN_LEFT, 0, regularFont_bold,BaseColor.WHITE);
	
			
			for (NewFeaturesBean newFeaturesList : modelCoverPageBean.getNewFeaturesList()) {
				if (newFeaturesList.getTypeID().intValueExact()==8) {
				insertCell(table1,"", "",
						"\u2022 " +newFeaturesList.NFtext, 
						Element.ALIGN_LEFT, 0, boldFontLarge,BaseColor.WHITE);
				}
			}
			
			insertCell(table1," ",  "",
					"", 
					Element.ALIGN_CENTER, 0, boldFont,BaseColor.WHITE);
			
			insertCell(table1,"", "",
					"Changes", 
					Element.ALIGN_LEFT, 0, regularFont_bold,BaseColor.WHITE);
	
			
			for (NewFeaturesBean newFeaturesList : modelCoverPageBean.getNewFeaturesList()) {
				if (newFeaturesList.getTypeID().intValueExact()==9) {
					
				insertCell(table1,"", "",
						"\u2022 "+newFeaturesList.NFtext, 
						Element.ALIGN_LEFT, 0, boldFontLarge,BaseColor.WHITE);
				}
			}
			
		Image image = null;	
		

		
		table.addCell(table1);
		
		return table;
		
		
	}
	public String getLocation()
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String location = null;
		if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			location = eProperties.getProperty("pdfDefaultLocation");
		}
		return location;
	}






	public void startRadioPDFGeneration(int subCategoryID, List<WheelsAndRadiosBean> list) {

		/*try {
			new ItextPDFGenerator_ModelCoverPage().createPdf(subCategoryID,list,null,null,0 );
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}*/


	}

	public static void insertCell(PdfPTable table,String text1, String text,String endingBoldText, int align, int colspan, Font font, BaseColor color){



		//create a new cell with the specified Text and Font
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		
		if(text1!=null){
			para.add(new Phrase(text1, font));
		}
		para.add(new Phrase(text, boldContentFont));
		if(endingBoldText!=null){
			para.add(new Phrase(endingBoldText, font));
		}
		//para.add("\u2022 ");
		PdfPCell cell = new PdfPCell();
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(8f);
		cell.setLeading(2f, 1f);
		cell.setBorderWidth(0);
		cell.setBackgroundColor(color);
		//add the call to the table
		//cell.addElement(para1);
		//para.add(new vch)
		cell.addElement(para);
		table.addCell(cell);

	}

	public void onCloseDocument(PdfWriter writer, Document document) {
		Paragraph p1 = new Paragraph("Testing************");
		PdfPCell cell = new PdfPCell();
		cell.addElement(p1);

		try {
			document.add(cell);
		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}

	public class HeaderAndFooter extends PdfPageEventHelper {

		private String name = "";
		PdfTemplate total;

		protected Phrase footer;
		protected Phrase header;

		/*
		 * Font for header and footer part.
		 */
		com.itextpdf.text.Font headerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);

		/*
		 * constructor
		 */
		public HeaderAndFooter(String name) {
			super();
			this.name = name;
			header = new Phrase("***** Header *****");
			footer = new Phrase("**** Footer ****");
		}

		@Override
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
			super.onOpenDocument(writer, document);
		}
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
		
		
				PdfContentByte cb = writer.getDirectContent();
				DateFormat defDate=null;
				defDate  = DateFormat.getDateInstance(DateFormat.LONG);

				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
						writer.getCurrentPageNumber()),headerFont), 
						document.left()+250 , document.bottom()-45, 0);

			
		}
	}

	public void startRadioPDFGeneration(int subCategoryID,
			ModelCoverPageBean modelCoverPageBean, Document document,
			PdfWriter writer, int pdfType) {

		try {
			new ItextPDFGenerator_NewFeatures().createPdf(subCategoryID,modelCoverPageBean,document,writer,pdfType );
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}


	}


	@Override
	public void startRadioPDFGeneration(int subcategoryID, List<WheelsAndRadiosBean> vehicleItemsXML, Document document,
			PdfWriter writer, int vehiclePrint) {
		// TODO Auto-generated method stub

	}


}
