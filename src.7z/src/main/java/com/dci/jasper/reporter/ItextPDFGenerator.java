package com.dci.jasper.reporter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import com.dci.enterprise.dao.ItextPDFGeneratorDAO;
import com.dci.enterprise.model.ColorAndTrimAvailability_Combined;
import com.dci.enterprise.model.ColorAndTrimBean;
import com.dci.enterprise.model.ColorAndTrimHelper;
import com.dci.enterprise.model.ColorRestrictionBean;
import com.dci.enterprise.model.ColorTrimAvailabliltiy;
import com.dci.enterprise.model.ExtraColumnsHeaderBean;
import com.dci.extrafunc.PropertyHelper;
import com.dci.general.utilities.VehicleConstant;
import com.google.common.base.CaseFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.HyphenationAuto;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class ItextPDFGenerator extends PdfPageEventHelper implements ItextPDFGeneratorDAO {

	/** The resulting PDF file. */
	static int numberOfcolor=0;
	private static List<ColorAndTrimHelper>  seatInteriorList;
	private Map<Long, ColorAndTrimBean> linkedHash; 
	private List<ColorTrimAvailabliltiy> colorList_t4;
	private List<ColorTrimAvailabliltiy> colorList;
	private List<ColorTrimAvailabliltiy> colorList_t5;
	public static int tableWidth = 475;
	private List<ColorTrimAvailabliltiy> MasterColorList = new ArrayList<ColorTrimAvailabliltiy>();
	private static List<ColorAndTrimBean> seatIntAvailability;
	private static List<ColorAndTrimBean> tempColorTrimSeatList;
	private static List<ExtraColumnsHeaderBean> ExtraColumnsHeaderList;
	private List<ColorAndTrimBean> colorAndTrim_ExtList;
	private List<ColorTrimAvailabliltiy> colorTrimAvailabliltiys;
	private static List<ColorRestrictionBean> restrictionList;
	private static int[] restrictionID; 
	public static	Document document=null;
	public static boolean isPOG = false;
	public static int pdfType;
	public static Properties unicodeProperties;
	InputStream inputStream = null;
	public static int pageNum = 0;
	static PdfPTable restrictionTable ;

	/**
	 * Creates a PDF with five tables.
	 * @param writer 
	 * @param document 
	 * @param pdfType 
	 * @param    filename the name of the PDF file that will be created.
	 * @param vehicleItemsXML 
	 * @throws    DocumentException 
	 * @throws    IOException
	 */
	public void createPdf( List<ArrayList<Object>> list, Document document, PdfWriter writer, int pdfType)
			throws IOException, DocumentException {
				seatInteriorList = (List<ColorAndTrimHelper>) list.get(0).get(0);
		if(seatInteriorList!=null){
			
			this.pdfType = pdfType;
			PropertyHelper propertyHelper = new PropertyHelper();
			String location = propertyHelper.getProperty("pdfDefaultLocation");
			int defaultColSize = 0;
			int i =0;

			// step 1
			if(pdfType!=VehicleConstant.VEHICLE_PRINT){
				String fileName = seatInteriorList.get(0).getVehicleId()+"-"+"col_trim_fo";
				if(seatInteriorList.get(0).getRegionID().intValueExact()==14 && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
					fileName+="_fr";
				}
				document = new Document();
				// step 2
				if( seatInteriorList.get(0).getIsLandscape()!=null && seatInteriorList.get(0).getIsLandscape().intValueExact()==1){

					document = new Document(PageSize.LETTER.rotate(), 100, 50, 20, 25);
					document.setMargins(72,72,72, 72);
				}
				else{
					document = new Document(PageSize.LETTER, 25, 20, 50, 100);
					document.setMargins(72,72, 75, 115);
				}
				// step 3
				writer = PdfWriter.getInstance(document, new FileOutputStream(location+fileName+".pdf"));
				writer.setPageEmpty(false);

				writer.setPageEvent(new HeaderAndFooter(""));

				document.open();
			}
			writer.setPageEvent(new HeaderAndFooter(""));

			this.document = document;
			/*	document.setPageSize(PageSize.LETTER.rotate());
		document.setMargins(72,72,85, 72);
		tableWidth = 575;*/
			document.newPage();
			// step 4
			pageNum = 0;
			for (int k = 0; k < list.size(); k++) {
				seatInteriorList = (List<ColorAndTrimHelper>) list.get(k).get(0);
				if(seatInteriorList!=null && !seatInteriorList.isEmpty()){
					pageNum++;
				}

			}

			for (int k = 0; k < list.size(); k++) {
				if(k>0){
					document.newPage();
				}
				seatInteriorList = (List<ColorAndTrimHelper>) list.get(k).get(0);
				linkedHash = (LinkedHashMap <Long, ColorAndTrimBean>) list.get(k).get(1);
				tempColorTrimSeatList = (List<ColorAndTrimBean>) list.get(k).get(7);
				//ExtraColumnsHeaderList = (List<ExtraColumnsHeaderBean>) list.get(k).get(8);
				seatIntAvailability = (List<ColorAndTrimBean>) list.get(k).get(3);
				colorAndTrim_ExtList = (List<ColorAndTrimBean>) list.get(k).get(4);
				colorTrimAvailabliltiys =(List<ColorTrimAvailabliltiy>) list.get(k).get(5);
				restrictionList =(List<ColorRestrictionBean>)list.get(k).get(6);
				restrictionID = new int[restrictionList.size()];
				colorList = (List<ColorTrimAvailabliltiy>) list.get(k).get(2);
				colorList_t4 = new ArrayList<ColorTrimAvailabliltiy>();
				colorList_t5 =  new ArrayList<ColorTrimAvailabliltiy>();
				sortColorList(colorList);

				loadRestriction();
				int m =0;
				if(seatInteriorList!=null && !seatInteriorList.isEmpty()){

					for (Iterator iterator = restrictionList.iterator(); iterator.hasNext();) {

						ColorRestrictionBean object = (ColorRestrictionBean) iterator.next();
						restrictionID[m]= object.getRestrictionID().intValueExact();
						m++;
					}

					Comparator<ColorTrimAvailabliltiy> cmp = new Comparator<ColorTrimAvailabliltiy>() {


						public int compare(ColorTrimAvailabliltiy a,
								ColorTrimAvailabliltiy b) {
							//if(a.getIntSort().)
							return a.getIntSort().compareTo(b.getIntSort());
							
							 //return Integer.parseInt(a.getIntSort()) - Integer.parseInt(b.getIntSort());
						}
					};
					
					int tempColorSort=1;
					//check for null before sorting 
					for (ColorTrimAvailabliltiy color_seat : colorList_t4) {
					
						if(color_seat.getIntSort().equals("null")) {
							color_seat.setIntSort(Integer.toString(tempColorSort));
							tempColorSort++;
						}
						
					}
					 tempColorSort=1;
					for (ColorTrimAvailabliltiy color_exterior : colorList_t5) {
						
						if(color_exterior.getIntSort().equals("null")) {
							color_exterior.setIntSort(Integer.toString(tempColorSort));
							tempColorSort++;
						}
					}
					
					
					//sorting based on interior sort					
					Collections.sort(colorList_t4, cmp);
					Collections.sort(colorList_t5, cmp);
					
					for (int j = 0; j < colorList_t4.size(); j++) {
						MasterColorList.add(colorList_t4.get(j));
					}


					for(int j =0;j<defaultColSize; j ++){
						colorList_t4.remove(colorList_t4.get(colorList_t4.size()-1));
					}


					PdfPTable table = createTable1(seatInteriorList, linkedHash,colorList_t4);
					table.getRows();
					document.add(table);
					table = createTable2(colorAndTrim_ExtList, colorTrimAvailabliltiys, colorList_t4,restrictionList);
					//table.getRows();
					table.setSpacingBefore(10);
					table.setSpacingAfter(5);

					document.add(table);

					colorList_t4 = MasterColorList;
					int temp = MasterColorList.size();
					if(defaultColSize>0){
						for(int j =0;j<temp-defaultColSize; j ++){
							colorList_t4.remove(0);
						}

						table = createTable1(seatInteriorList, linkedHash,colorList_t4);

						document.add(table);
						table = createTable2(colorAndTrim_ExtList, colorTrimAvailabliltiys, colorList_t5,restrictionList);

						table.setSpacingBefore(10);
						table.setSpacingAfter(5);
						document.add(table);

					}
				}

			}
			// step 5
			if(pdfType!=VehicleConstant.VEHICLE_PRINT){
				onCloseDocument(writer, document);
				// step 5
				document.close();
			}
		}
	}

	private void sortColorList(List<ColorTrimAvailabliltiy> colorList) {
		for (ColorTrimAvailabliltiy colorTrimAvailabliltiy : colorList) {
			if(colorTrimAvailabliltiy.getTypeId()==null || colorTrimAvailabliltiy.getTypeId().intValueExact()==4 )
			{
				colorList_t4.add(colorTrimAvailabliltiy);

			}
			if(colorTrimAvailabliltiy.getTypeId()==null || colorTrimAvailabliltiy.getTypeId().intValueExact()==5 )
			{
				colorList_t5.add(colorTrimAvailabliltiy);
			}
		}
	}

	/**
	 * Creates a table; widths are set with setWidths().
	 * @param colorList 
	 * @param vehicleItemsXML 
	 * @return a PdfPTable
	 * @throws DocumentException
	 */
	public static PdfPTable createTable1(List<ColorAndTrimHelper> seatInteriorList,
			Map<Long, ColorAndTrimBean> linkedHash, List<ColorTrimAvailabliltiy> colorList) throws DocumentException {

		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);
		PdfPTable table1;
		PdfPTable table3;
		PdfPTable table2;
		BaseFont base = null;
		try {
			base = BaseFont.createFont("c:/windows/fonts/ARIALUNI.ttf", BaseFont.IDENTITY_H, false);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Font Wfont = new Font(base, 8, Font.NORMAL);
		Font superBoldScriptfont = new Font(base, 9, Font.NORMAL);
		Font superScriptfont = new Font(base, 10, Font.NORMAL);

		table.setTotalWidth(tableWidth);
		table.setLockedWidth(true);
		PdfPCell cell;
		com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.WHITE);
		com.itextpdf.text.Font tableHFont =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA, 6, Font.BOLD,BaseColor.BLACK);



		Paragraph p1 = new Paragraph("2015 CHEVY",tableHeader);
		p1.setAlignment(Element.ALIGN_LEFT);


		//cell = new PdfPCell(new Phrase("2015 GMC SIERRA 2500HD" + "\t\t" + " COLOUR AND TRIM - SIERRA "+"\t\t"+"CANADA" ,tableHeader));
		cell = new PdfPCell();
		cell.addElement(p1);
		p1 = new Paragraph("Canada",tableHeader);
		p1.setAlignment(Element.ALIGN_RIGHT);
		cell.addElement(p1);
		cell.setColspan(1);
		cell.setBackgroundColor(BaseColor.BLACK);
		//	table.addCell(cell);


		Image blackBoxImg = null;
		Image whiteBoxImg = null;
		try {
			blackBoxImg = Image.getInstance("blackbox.gif");
			whiteBoxImg = Image.getInstance("whitebox.gif");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		String stringHeader = " S = Standard Equipment"+"\t \t \t"+" A = Available"+"\t \t \t"+" --(dashes) = Not Available \t \t \t D = ADI Available \n";
		String stringBlack =  " = Included in Equipment Group"+"";
		String stringWhite =  " = Included in Equipment Group but upgradeable\n";
		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			stringHeader = " S = �quipement de s�rie"+"\t\t"+" A = Livrables "+"\t\t"+" --(Tirets) = Non Disponible\n";
			stringBlack =  " = Compris dans le groupe d'�quipements  "+"";
			stringWhite =  " = Compris dans le groupe d'�quipements, mais peut �tre mis � niveau.\n";
		}

		String ending="";
		String truckDesc="";
		if(seatInteriorList.get(0).getDivisionID()!=null){
			if(seatInteriorList.get(0).getDivisionID().intValueExact()==1 || seatInteriorList.get(0).getDivisionID().intValueExact()==2){

				truckDesc = "\n* Indicates availability of feature on multiple models. For example, it indicates feature availability on 2WD and 4WD Models or Rear wheel drive and"+
						" All-wheel drive Models. ";
				if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
					truckDesc = "\n*  Indique disponibilit� de ce type sur plusieurs mod�les. Par exemple, il indique la disponibilit� des fonctions sur les mod�les 2RM et 4RM ou propulsion arri�re et toutes roues motrices mod�les.";
				}

			}
		}
		else{
			truckDesc="";
		}
		ending ="Codes listed in the shaded column titled Ref. Only RPO Code are for internal use only and should not be ordered. ";

		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			ending = "Les codes �num�r�s dans la colonne ombrag�e intitul�e Code �FC de r�f. sont pour usage interne seulement et ne doivent pas �tre command�s.";
		}	
		Paragraph paragraph_black = new Paragraph();
		paragraph_black.setAlignment(Element.ALIGN_CENTER);
		paragraph_black.add(new Phrase(stringHeader, tableHeader1));
		if (blackBoxImg != null) {
			whiteBoxImg.scalePercent(60f);
			blackBoxImg.scalePercent(60f);
			paragraph_black.add(new Chunk( blackBoxImg, 1f, 1f));
		}
		paragraph_black.add(new Phrase(stringBlack, tableHFont));
		paragraph_black.add(new Phrase("  ", tableHFont));
		paragraph_black.add(new Chunk( whiteBoxImg, 1f, 1f));
		paragraph_black.add(new Phrase(stringWhite, tableHFont));
		Paragraph temp1;
		PdfPCell cell1 = new PdfPCell(paragraph_black);
		temp1 = new Paragraph();
		temp1.add(truckDesc);
		temp1.setLeading(1f, 1f);
		temp1.setFont(tableHFont);
		temp1.setAlignment(Element.ALIGN_LEFT);
		//paragraph_black.add(temp);
		cell1.addElement(paragraph_black);
		cell1.addElement(temp1);

		temp1 = new Paragraph();
		//	temp1.add(ending);
		temp1.setFont(tableHFont);
		temp1.setAlignment(Element.ALIGN_LEFT);
		//paragraph_black.add(new Phrase(ending, boldContentFont));

		//cell1.addElement(paragraph_black);
		cell1.addElement(temp1);
		cell1.setPaddingBottom(6f);
		cell1.setPaddingLeft(8f);
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell1.setVerticalAlignment(Element.ALIGN_CENTER);
		table.addCell(cell1);


		//	table.addCell(cell);
		cell.setBorder(0);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setBorder(Rectangle.NO_BORDER);

		table1 = new PdfPTable(5);
		table1.getDefaultCell().setBorder(0);
		table1.getDefaultCell().setPadding(0);
		table1.setTotalWidth(tableWidth);
		cell.setBackgroundColor(new BaseColor(204,204,204));

		table1.setWidths(new float[]{53.2f,135.8f,38.2f,100.2f,148});
		/*if(colorList.size()==5){
			table1.setWidths(new float[]{53.6f,136.2f,38.2f,100f,145});
		}*/
		if(colorList.size()>=6){

			table1.setWidths(new int[]{48,48,38,51,290});
		}
		//table1.setWidths(new int[]{189,38,100,148});
		table1.setLockedWidth(true);
		if(seatInteriorList.get(0).getDivisionID().intValueExact()==1 || seatInteriorList.get(0).getDivisionID().intValueExact()== 2 
				|| seatInteriorList.get(0).getDivisionID().intValueExact()== 5){
			cell = new PdfPCell(new Phrase("Decor Level",boldContentFont1));
			if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
				cell = new PdfPCell(new Phrase("Niveau d�cor",boldContentFont1));
			}

		}
		else{
			cell = new PdfPCell(new Phrase("Model ",boldContentFont1));
			if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
				cell = new PdfPCell(new Phrase("Mod�le",boldContentFont1));
			}
		}
		cell.setNoWrap(false);
		//	cell.setFixedHeight(72f);
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setNoWrap(false);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1.5f);
		cell.setPaddingTop(15);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		//cell.setBorder(Rectangle.NO_BORDER);

		table1.addCell(cell);

		cell = new PdfPCell(new Phrase("Seat Type",boldContentFont1));

		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("Type de si�ges",boldContentFont1));
		}

		cell.setNoWrap(false);
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setNoWrap(false);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1.5f);
		cell.setPaddingTop(15);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table1.addCell(cell);

		cell = new PdfPCell(new Phrase("Seat \n Code",boldContentFont1));
		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("Le code de si�ges",boldContentFont1));
		}

		cell.setNoWrap(false);
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setNoWrap(false);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1.5f);
		cell.setPaddingTop(15);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table1.addCell(cell);

		cell = new PdfPCell(new Phrase("Seat Trim",boldContentFont1));
		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("Garniture de si�ges",boldContentFont1));
		}

		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setNoWrap(false);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1.5f);
		cell.setPaddingTop(15);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		table1.addCell(cell);

		table2 = new PdfPTable(colorList.size());
		table2.getDefaultCell().setBorder(0);
		table2.getDefaultCell().setPadding(0);

		cell = new PdfPCell(new Phrase("Interior",boldContentFont1));
		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("Int�rieur",boldContentFont1));
		}

		cell.setNoWrap(false);
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1.5f);
		cell.setPaddingTop(5);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setColspan(colorList.size());
		table2.addCell(cell);
		//  table.addCell(cell);
		// we add the four remaining cells with addCell()


		for (Iterator iterator = colorList.iterator(); iterator.hasNext();) {
			ColorTrimAvailabliltiy colorCode = (ColorTrimAvailabliltiy) iterator
					.next();
			if(colorCode!=null){
				if(colorCode.getRestrictionID()==null){
					colorCode.setRestrictionID(new BigDecimal(20));
				}
				Chunk chunk = new Chunk(colorCode.getIntColorName().replace("/", "/\n"),boldContentFont1);
				chunk.setHyphenation(new HyphenationAuto("en", "GB", 3,3));
				Phrase ph_1 = new Phrase(chunk);
				Phrase ph_2 = new Phrase(restrictionFlag_package(colorCode.getRestrictionID().intValueExact()),superBoldScriptfont);
				ph_1.add(ph_2);
				cell = new PdfPCell(ph_1);

				cell.setBackgroundColor(new BaseColor(204,204,204));
				cell.setRowspan(2);
				//cell.setNoWrap(false);
				cell.setPaddingBottom(5);
				cell.setLeading(1, 1f);
				cell.setPaddingTop(5);
				cell.setPaddingLeft(0.5f);
				cell.setPaddingRight(0.5f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setMinimumHeight(25f);
				table2.addCell(cell);
			}


		}
		//	table1.setWidths(new int[]{53,136,38,100,148});
		table1.addCell(table2);
		table3 = new PdfPTable(4+colorList.size());
		table3.getDefaultCell().setBorder(0);
		table3.getDefaultCell().setPadding(0);
		table3.setTotalWidth(tableWidth);
		//	31,110,31,108,195

		//table1.setWidths(new float[]{53.2f,135.8f,38.2f,100.2f,148});
		float[] width = new float[colorList.size()+4];
		width[0] = 53.2f;
		width[1] = 135.8f;
		width[2] = 38.2f;
		width[3] = 100.2f;
		for (int i = 4; i<(colorList.size()+4); i++) {
			width[i] = (148f/colorList.size());
		}
		//53,39,38,51,290
		if(colorList.size()>=6){
			width = new float[colorList.size()+4];
			width[0] = 48;
			width[1] = 48;
			width[2] = 38;
			width[3] = 51;
			for (int i = 4; i<(colorList.size()+4); i++) {
				width[i] = (291f/colorList.size());
			}
		}


		table3.setWidths(width);
		table3.getDefaultCell().setBorder(0);
		table3.getDefaultCell().setPadding(0);
		Long[] tempOrder = new Long[linkedHash.size()];
		String [] tempColorOder = new String[colorList.size()];
		int j =0;	
		for (Long temp : linkedHash.keySet()){

			tempOrder[j]= temp;
			j++;
		}

		j =0;

		for (Iterator iterator = colorList.iterator(); iterator.hasNext();) {
			ColorTrimAvailabliltiy colorListOrder = (ColorTrimAvailabliltiy) iterator.next();
			tempColorOder[j]= colorListOrder.getIntColorName();
			j++;
		}



		boolean foundMatch = false;
		int k = 0;
		Comparator<ColorAndTrimBean> cmp = new Comparator<ColorAndTrimBean>() {


			public int compare(ColorAndTrimBean a,
					ColorAndTrimBean b) {
				// TODO Auto-generated method stub
				return a.getSeatSort().compareToIgnoreCase(b.getSeatSort());
			}
		};
		Collections.sort(seatIntAvailability, cmp);


		for (ColorAndTrimBean foreachRow : seatIntAvailability) {

			if(foreachRow.getSeatTypeRestriction()== null){
				foreachRow.setSeatTypeRestriction(new BigDecimal(20));
			}

			if(foreachRow.getSeatCodeRestrictionID()== null){
				foreachRow.setSeatCodeRestrictionID(new BigDecimal(20));
			}
			if(foreachRow.getRestrictionID()== null){
				foreachRow.setRestrictionID(new BigDecimal(20));
			}
			Chunk chunk;

			if(!foreachRow.getDecorLevel().toString().contains("/")){
				chunk = new Chunk(foreachRow.getDecorLevel().toString(),tableHeader1);
				chunk.setHyphenation(new HyphenationAuto("de", "DE", 2,2));
			}
			else{
				chunk = new Chunk(foreachRow.getDecorLevel().toString().replace("/", "/\n"),tableHeader1);
				//Phrase ph_1 = new Phrase(chunk);
			}	
			
			Phrase ph_1 = new Phrase(chunk);
			if(foreachRow.getSeatDecorLevelRestrictionID()!=null){
			Phrase ph_1R = new Phrase(restrictionFlag_package(foreachRow.getSeatDecorLevelRestrictionID().intValueExact()),superScriptfont);
			ph_1.add(ph_1R);
			}
			insertCustomCell(table3,null,ph_1, Element.ALIGN_LEFT, 1, tableHeader1);
			//	insertCell(table3,null,foreachRow.getDecorLevel().toString(), Element.ALIGN_CENTER, 1, tableHeader1);

			Phrase ph1 = new Phrase(foreachRow.getSeatType() ,tableHeader1);
			Phrase ph2 = new Phrase(restrictionFlag_package(foreachRow.getSeatTypeRestriction().intValueExact()),superScriptfont);
			ph1.add(ph2);

			//insertCustomCell(table1,null,p,null, Element.ALIGN_CENTER, 1, tableHeader1,BaseColor.WHITE);
			insertCustomCell(table3,null,ph1, Element.ALIGN_LEFT, 1, tableHeader1);
			//	insertCell(table3, null,foreachRow.getSeatType(), Element.ALIGN_CENTER, 1, tableHeader1);

			ph1 = new Phrase(foreachRow.getSeatCode() ,tableHeader1);
			ph2 = new Phrase(restrictionFlag_package(foreachRow.getSeatCodeRestrictionID().intValueExact()),superScriptfont);
			ph1.add(ph2);
			insertCustomCell(table3,null,ph1, Element.ALIGN_CENTER, 1, tableHeader1);
			//insertCell(table3,null,foreachRow.getSeatCode(), Element.ALIGN_CENTER, 1, tableHeader1);
			//insertCell(table3,null,foreachRow.getSeatTrim(), Element.ALIGN_CENTER, 1, tableHeader1);
			ph1 = new Phrase(foreachRow.getSeatTrim() ,tableHeader1);
			ph2 = new Phrase(restrictionFlag_package(foreachRow.getRestrictionID().intValueExact()),superScriptfont);
			ph1.add(ph2);
			insertCustomCell(table3,null,ph1, Element.ALIGN_CENTER, 1, tableHeader1);
			int m =0;
			int count = 0;
			//Multimap<Long,String> myMultimap = ArrayListMultimap.create();
			/*for (Iterator hashHelper = seatIntAvailability.iterator(); hashHelper.hasNext();) {
				ColorAndTrimBean element = (ColorAndTrimBean) hashHelper.next();
				myMultimap.put(element.getHashCodeGen(), element.getIntColorName());
			}*/
			//	for (int i = 0; i < tempOrder.length; i++) {

			//List<String>  tempHolder = (List<String>) myMultimap;

			List <Long> compHashCode = new ArrayList<Long>();
			List <String> compColor = new ArrayList<String>();
			for (ColorTrimAvailabliltiy foreachColumn : colorList){
				foundMatch = false;
				for (ColorAndTrimHelper foreachCell : seatInteriorList){
					long currentHash = foreachRow.getHashCodeGen();
					for(ColorAndTrimBean foreachTempRow: tempColorTrimSeatList){
						if((foreachCell.getHashCodeGen()==currentHash)&&
								(foreachCell.getSeatID().equals(foreachTempRow.getSeatID()))&&
								(!(compHashCode.contains(currentHash) && compColor.contains(foreachColumn.getIntColorName())))&&
								foreachCell.getIntColorName().equalsIgnoreCase(foreachColumn.getIntColorName())){

							if(foreachCell.getRestrictionID()!=null){
								Phrase ph = checkColorCodes(seatInteriorList,tempColorTrimSeatList,colorList,currentHash,foreachColumn.getIntColorName());
								//Phrase phN = new Phrase(restrictionFlag_package(foreachCell.getRestrictionID().intValueExact()),superScriptfont);
								//ph.add(phN);
								insertCustomCell(table3,null,ph, Element.ALIGN_CENTER, 1, tableHeader1);
								foundMatch = true;
								compHashCode.add(currentHash);
								compColor.add(foreachColumn.getIntColorName());
							}
							else{
								insertCustomCell(table3,null,checkColorCodes(seatInteriorList,tempColorTrimSeatList,colorList,currentHash,foreachColumn.getIntColorName()), Element.ALIGN_CENTER, 1, tableHeader1);
							//	insertCell(table3,null,checkColorCodes(seatInteriorList,tempColorTrimSeatList,colorList,currentHash,foreachColumn.getIntColorName()), Element.ALIGN_CENTER, 1, tableHeader1);
								foundMatch = true;
								compHashCode.add(currentHash);
								compColor.add(foreachColumn.getIntColorName());
							}


						}
					}
				}

				if(!foundMatch){
					insertCell(table3,null, "--", Element.ALIGN_CENTER, 1, tableHeader1);
				}
			}
		}

		//	}}

		/*for (Iterator iteratorTemp = seatInteriorList.iterator(); iteratorTemp.hasNext();) {
				ColorAndTrimHelper colorAndTrimBean2 = (ColorAndTrimHelper) iteratorTemp.next();
			for (Iterator iterator = seatIntAvailability.iterator(); iterator.hasNext();) {
				ColorAndTrimBean colorAndTrimBean1 = (ColorAndTrimBean) iterator.next();
				if(colorAndTrimBean2.getSeatID().equals(colorAndTrimBean1.getSeatID())){

					System.out.println(colorAndTrimBean1.getSeatID() +" ----------" + colorAndTrimBean2.getIntColorCode()+""+ colorAndTrimBean1.getSeatTrimCode());
					insertCell(table3,colorAndTrimBean1.getIntColorCode()+""+ colorAndTrimBean.getSeatTrimCode(), Element.ALIGN_CENTER, 1, tableHeader1);
				}
			}

		}*/



		table.addCell(table1);
		table.addCell(table3);
		return table;
	}

	private static Phrase checkColorCodes(
			List<ColorAndTrimHelper> seatInteriorList,
			List<ColorAndTrimBean> tempColorTrimSeatList,
			List<ColorTrimAvailabliltiy> colorList, long currentHash, String currentColor) throws DocumentException {
		BaseFont base = null;
		try {
			base = BaseFont.createFont("c:/windows/fonts/ARIALUNI.ttf", BaseFont.IDENTITY_H, false);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Font basefont = new Font(base, 8, Font.NORMAL);
		Font superScriptfont = new Font(base, 10, Font.NORMAL);
		String temp = "";
		Phrase ph = new Phrase();
		for (ColorAndTrimHelper foreachCell : seatInteriorList){
			for(ColorAndTrimBean foreachTempRow: tempColorTrimSeatList){
				if((foreachCell.getHashCodeGen()==currentHash)&&
						(foreachCell.getSeatID().equals(foreachTempRow.getSeatID()))&&
						foreachCell.getIntColorName().equalsIgnoreCase(currentColor)){
					if(foreachCell.getRestrictionID()== null){
						foreachCell.setRestrictionID(new BigDecimal(20));
					}
					
					Chunk availabilityCode = new Chunk(foreachCell.getIntColorCode()+foreachTempRow.getSeatTrimCode(),basefont);
					Chunk restrictionValue = new Chunk(restrictionFlag_package(foreachCell.getRestrictionID().intValueExact())+"\n",superScriptfont);
					ph.add(availabilityCode);
					ph.add(restrictionValue);
					//temp+=foreachCell.getIntColorCode()+foreachTempRow.getSeatTrimCode()+restrictionFlag_package(foreachCell.getRestrictionID().intValueExact())+"\n";
				}

				//Phrase phN = new Phrase(restrictionFlag_package(foreachCell.getRestrictionID().intValueExact()),superScriptfont);
			}}

		return	ph;
	
	}

	/**
	 * Creates a table; widths are set with setWidths().
	 * @param restrictionList 
	 * @return a PdfPTable
	 * @throws DocumentException
	 */
	public static PdfPTable createTable2(List<ColorAndTrimBean> colorAndTrim_ExtList,
			List<ColorTrimAvailabliltiy> colorTrimAvailabliltiys, 
			List<ColorTrimAvailabliltiy> colorList, List<ColorRestrictionBean> restrictionList) throws DocumentException {
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA, 6, Font.BOLD,BaseColor.BLACK);
		BaseFont base = null;
		try {
			base = BaseFont.createFont("c:/windows/fonts/ARIALUNI.ttf", BaseFont.IDENTITY_H, false);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Font Wfont = new Font(base, 12, Font.NORMAL);
		Font superBoldScriptfont = new Font(base, 9, Font.NORMAL);
		Font superScriptfont = new Font(base, 10, Font.NORMAL);
		Font baseFont = new Font(base, 8, Font.NORMAL);
		PdfPTable table = new PdfPTable(1);
		PdfPTable table1;
		PdfPTable table2;
		table.getDefaultCell().setBorder(0);
		table.getDefaultCell().setPadding(0);
		table.setTotalWidth(tableWidth);
		table.setLockedWidth(true);
		table.setSplitLate(true);
		table.setSplitRows(true);
		table.setHeaderRows(1);
		table.setKeepTogether(true);
		//	table.keepRowsTogether(new int[] { 0, 9 });
		//table.setBreakPoints(8);

		PdfPCell cell;
		com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.WHITE);
		com.itextpdf.text.Font tableHeader1 =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
		cell = new PdfPCell(new Phrase("2015 GMC SIERRA 2500HD" + "\t\t" + " COLOUR AND TRIM - SIERRA "+"\t\t"+"CANADA" ,tableHeader));
		cell.setColspan(1);
		cell.setBackgroundColor(BaseColor.BLACK);




		table1 = new PdfPTable(4);
		table1.getDefaultCell().setBorder(0);
		table1.getDefaultCell().setPadding(0);
		table1.setTotalWidth(tableWidth);
		cell.setBackgroundColor(new BaseColor(204,204,204));
		//table1.setWidths(new int[]{53,136,38,110,138});
		table1.setWidths(new int[]{189,38,100,148});
		/*if(colorList.size()==5){
			table1.setWidths(new float[]{189.8f,38.2f,100f,145});
		}*/
		if(colorList.size()>=6){
			table1.setWidths(new float[]{92.4f,38,50,290});
		}


		table1.setLockedWidth(true);


		cell = new PdfPCell(new Phrase("Exterior \n Solid Paint",boldContentFont1));
		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("Ext�rieur  \n La peinture solide ",boldContentFont1));
		}
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setNoWrap(false);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1.5f);
		cell.setPaddingTop(15);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table1.addCell(cell);

		cell = new PdfPCell(new Phrase("Color \n Code",boldContentFont1));

		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==1  && seatInteriorList.get(0).getRegionID().intValueExact()==14){
			cell = new PdfPCell(new Phrase("Colour \n Code",boldContentFont1));
		}


		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("Code Couleur",boldContentFont1));
		}
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setNoWrap(false);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1.5f);
		cell.setPaddingTop(15);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table1.addCell(cell);

		cell = new PdfPCell(new Phrase("Touch Up \n Paint Number",boldContentFont1));
		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("Touchez-Up \n Nombre de peinture",boldContentFont1));
		}
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setNoWrap(false);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1f);
		cell.setPaddingTop(15);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table1.addCell(cell);



		table2 = new PdfPTable(colorList.size());
		table2.getDefaultCell().setBorder(0);
		table2.getDefaultCell().setPadding(0);
		int intColor=0;
		int extraCol =0;
		for (ColorTrimAvailabliltiy colorTrimAvailabliltiy : colorList) {
			if(colorTrimAvailabliltiy.isExtraColumn()==true){
				extraCol++;
			}
			else
				intColor++;
		}




		cell = new PdfPCell(new Phrase("Interior",boldContentFont1));
		if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
			cell = new PdfPCell(new Phrase("Int�rieur",boldContentFont1));
		}
		cell.setNoWrap(false);
		cell.setBackgroundColor(new BaseColor(204,204,204));
		cell.setRowspan(2);
		cell.setPaddingBottom(5);
		cell.setLeading(1, 1.5f);
		cell.setPaddingTop(5);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setColspan(intColor);
		table2.addCell(cell);

		if(extraCol>0){

			cell = new PdfPCell(new Phrase("Options",boldContentFont1));
			if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
				cell = new PdfPCell(new Phrase("Options",boldContentFont1));
			}
			cell.setNoWrap(false);
			cell.setBackgroundColor(new BaseColor(204,204,204));
			cell.setRowspan(2);
			cell.setPaddingBottom(5);
			cell.setLeading(1, 1.5f);
			cell.setPaddingRight(0.75f);
			cell.setPaddingTop(5);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setColspan(extraCol);
			table2.addCell(cell);

		}


		List<String> colorList_loop = new ArrayList<String>();
		for (Iterator iterator = colorList.iterator(); iterator.hasNext();) {
			ColorTrimAvailabliltiy colorCode = (ColorTrimAvailabliltiy) iterator
					.next();
			if(colorCode!=null){
				if(colorCode.getRestrictionID()==null){
					colorCode.setRestrictionID(new BigDecimal(20));
				}


				Chunk chunk = new Chunk(colorCode.getIntColorName().replace("/", "/\n"),boldContentFont1);

				chunk.setHyphenation(new HyphenationAuto("en", "GB", 3,3));
				Phrase ph1 = new Phrase(chunk);
				Phrase ph2 = new Phrase(restrictionFlag_package(colorCode.getRestrictionID().intValueExact()),superBoldScriptfont);
				ph1.add(ph2);
				cell = new PdfPCell(ph1);

				cell.setBackgroundColor(new BaseColor(204,204,204));
				cell.setRowspan(2);
				cell.setNoWrap(false);
				cell.setPaddingBottom(5);
				cell.setPaddingLeft(0.5f);
				cell.setPaddingRight(0.5f);
				cell.setLeading(1, 1f);
				cell.setPaddingTop(5);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setMinimumHeight(25f);
				table2.addCell(cell);
			}
		}

		PdfPTable table3;
		table1.addCell(table2);
		table3 = new PdfPTable(3+colorList.size());
		table3.setTotalWidth(tableWidth);
		float[] width = new float[colorList.size()+3];
		//table1.setWidths(new int[]{189,38,100,148});
		//table1.setWidths(new int[]{189,38,100,148});
		width[0] = 189f;
		width[1] = 38f;
		width[2] = 100f;

		for (int i = 3; i<(colorList.size()+3); i++) {
			width[i] = (148f/colorList.size());
		}


		if(colorList.size()>=6){
			width = new float[colorList.size()+3];
			//{92.4f,38,50,290})
			width[0] = 92.4f;
			width[1] = 38;
			width[2] = 50;

			for (int i = 3; i<(colorList.size()+3); i++) {
				width[i] = (290f/colorList.size());
			}
		}

		table3.setWidths(width);
		table3.getDefaultCell().setBorder(0);
		table3.getDefaultCell().setPadding(0);

		//	table3.setWidths(new int[]{189,39,109,46,46,45});

		for (ColorAndTrimBean foreachRow : colorAndTrim_ExtList) {
			//for (Iterator iterator = colorAndTrim_ExtList.iterator(); iterator.hasNext();) {
			//ColorAndTrimBean colorAndTrimBeanTemp = (ColorAndTrimBean) iterator.next();
			String isNew="";
			if(foreachRow.getNewoptionFlag()!=null && foreachRow.getNewoptionFlag().intValueExact()==1)
			{
				if(seatInteriorList.get(0).getLocaleCode()!= null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
					isNew ="Nouveau! ";
				}
				else
					isNew = "NEW! ";
			}
			if(foreachRow.getExtraText()==null || foreachRow.getExtraText().equalsIgnoreCase("null")){
				foreachRow.setExtraText("");
			}
			if(foreachRow.getRestrictionID()!=null)
			{
				Phrase ph1 = new Phrase(foreachRow.getExteriorColorName(),tableHeader1);
				Phrase ph2 = new Phrase(restrictionFlag_package(foreachRow.getRestrictionID().intValueExact()),superScriptfont);
				ph1.add(ph2);
				Phrase ph3 = new Phrase("\n"+foreachRow.getExtraText(),tableHeader1);
				ph1.add(ph3);
				insertCustomCell(table3, isNew,ph1, Element.ALIGN_LEFT, 1, tableHeader1);
			}
			else
			{
				insertCell(table3, isNew,foreachRow.getExteriorColorName()+"\n"+foreachRow.getExtraText(), Element.ALIGN_LEFT, 1, tableHeader1);
			}
			if(seatInteriorList.get(0).getLocaleCode()==null ) {
				
				seatInteriorList.get(0).setLocaleCode(new BigDecimal(1));
			}
			if((foreachRow.getExteriorColorCode()==null || foreachRow.getExteriorColorCode().equalsIgnoreCase("null")) && seatInteriorList.get(0).getLocaleCode().compareTo(new BigDecimal(1))==0){

				foreachRow.setExteriorColorCode("none");
			}
			
			if((foreachRow.getExteriorColorCode()==null || foreachRow.getExteriorColorCode().equalsIgnoreCase("null") || foreachRow.getExteriorColorCode().trim().equalsIgnoreCase("none")) && seatInteriorList.get(0).getLocaleCode().compareTo(new BigDecimal(2))==0){

				foreachRow.setExteriorColorCode("Aucun");
			}
			
			
			insertCell(table3,null, foreachRow.getExteriorColorCode(), Element.ALIGN_CENTER, 1, tableHeader1);
			insertCell(table3,null, foreachRow.getExteriorColorWanNumber(), Element.ALIGN_CENTER, 1, tableHeader1);

			// foreachColumn for (Iterator iterator1 = colorTrimAvailablitys.iterator(); iterator1.hasNext();) {
			
			
			//combining available code into resultset
			List<ColorAndTrimAvailability_Combined> colorAvailabilityCombined = new ArrayList<ColorAndTrimAvailability_Combined>();
			
			
			
		for (ColorTrimAvailabliltiy colorAvailability : colorTrimAvailabliltiys) {	
			boolean newColorCombo = true;
			if(colorAvailabilityCombined.size()>0) {
			for (ColorAndTrimAvailability_Combined colorAvailability_Combined : colorAvailabilityCombined) {
					if(colorAvailability_Combined.getColorName().equalsIgnoreCase(colorAvailability.getIntColorName()) &&
							colorAvailability_Combined.getVehicleHasExteriorColorID().equals(colorAvailability.getVehicleHasExteriorColorID())){
						
						
						colorAvailability_Combined.getCombinedAvailabilty().add(colorAvailability.getAvailableCodeName());
						newColorCombo = false;
					}
					
					
					

					
			}
			
			
			if(newColorCombo) {
				
			
					ColorAndTrimAvailability_Combined colAvail_com = new ColorAndTrimAvailability_Combined();
					colAvail_com.setColorID(colorAvailability.getIntColorID());
					colAvail_com.setVehicleHasExteriorColorID(colorAvailability.getVehicleHasExteriorColorID());
					List<String> temp_col = new ArrayList<String>();						
					colAvail_com.setColorName(colorAvailability.getIntColorName() );
					temp_col.add(colorAvailability.getAvailableCodeName());					
					colAvail_com.setCombinedAvailabilty(temp_col);
					colorAvailabilityCombined.add(colAvail_com);
					
					//	colAvail_com.setCombinedAvailabilty(n);
					//colAvail_com.setColorID(colorAvailability.getIntColorID());
				
			}
			
			}
					
					else {
						ColorAndTrimAvailability_Combined colAvail_com = new ColorAndTrimAvailability_Combined();
						colAvail_com.setColorID(colorAvailability.getInteriorID());
						colAvail_com.setVehicleHasExteriorColorID(colorAvailability.getVehicleHasExteriorColorID());
						List<String> temp_col = new ArrayList<String>();						
						colAvail_com.setColorName(colorAvailability.getIntColorName() );
						temp_col.add(colorAvailability.getAvailableCodeName());						
						colAvail_com.setCombinedAvailabilty(temp_col);
						colorAvailabilityCombined.add(colAvail_com);
						
						//	colAvail_com.setCombinedAvailabilty(n);
						//colAvail_com.setColorID(colorAvailability.getIntColorID());
					}
				}
				
			
			
			
			
			
			
			boolean foundMatch = false;

			for (ColorTrimAvailabliltiy foreachColumn : colorList){
				foundMatch = false;
				for (ColorTrimAvailabliltiy foreachcell : colorTrimAvailabliltiys) {	
					if(foreachRow.getVehicleHasExteriorColorID()!=null){
						if(foreachRow.getVehicleHasExteriorColorID().equals(foreachcell.getVehicleHasExteriorColorID()) && foreachColumn.getInteriorID().equals(foreachcell.getInteriorID())){
						//if(foreachRow.getVehicleHasExteriorColorID().equals(foreachcell.getVehicleHasExteriorColorID()) && foreachColumn.getIntColorName().equalsIgnoreCase(foreachcell.getIntColorName())){	
						if(foreachcell.getAvExtraText()==null || foreachcell.getAvExtraText().equalsIgnoreCase("null"))
							{
								foreachcell.setAvExtraText("");
							}
					
						if(foreachcell.getRestrictionID()== null){
							foreachcell.setRestrictionID(new BigDecimal(20));
						}
							
							/*if(!ExtraColumnsHeaderList.isEmpty()){

						insertCell(table3, null,foreachcell.getAvailableCodeName()+"\n"+foreachcell.getAvExtraText(), Element.ALIGN_CENTER, 1, tableHeader1);
					}*/if(foreachcell.getAvailableCodeName().equalsIgnoreCase("n/a")||foreachcell.getAvailableCodeID().intValueExact()==7){
						foreachcell.setAvailableCodeName("--");
					}
							
							if(foreachcell.getAvailableCodeName().equalsIgnoreCase("--")){
								foundMatch= false;
							}
							else
							{
								insertCellWithRestriction(table3, null,foreachcell.getAvailableCodeName(),restrictionFlag_package(foreachcell.getRestrictionID().intValueExact())+"\n"+foreachcell.getAvExtraText(), Element.ALIGN_CENTER, 1, superScriptfont,baseFont);
								foundMatch= true;
							}

						}


					}
				}
				
				
if(!foundMatch){
	
	for (ColorAndTrimAvailability_Combined foreachcell : colorAvailabilityCombined) {	
		if(foreachRow.getVehicleHasExteriorColorID()!=null){
			if(foreachRow.getVehicleHasExteriorColorID().equals(foreachcell.getVehicleHasExteriorColorID()) && foreachColumn.getIntColorName().equals(foreachcell.getColorName())){
			//if(foreachRow.getVehicleHasExteriorColorID().equals(foreachcell.getVehicleHasExteriorColorID()) && foreachColumn.getIntColorName().equalsIgnoreCase(foreachcell.getIntColorName())){	
			
				if(foreachcell.getCombinedAvailabilty().contains("A")) {
				
				insertCell(table3, null,"A", Element.ALIGN_CENTER, 1, baseFont);
				foundMatch= true;
				}

		

			}


		}
	}
	
			

				}

				
				if(!foundMatch){
					
					insertCell(table3, null,"--", Element.ALIGN_CENTER, 1, baseFont);

				}


			}
		}



		restrictionTable = new PdfPTable(1);
		restrictionTable.getDefaultCell().setBorder(0);
		restrictionTable.getDefaultCell().setPadding(0);
		restrictionTable.setTotalWidth(tableWidth);
		/*	restrictionTable.setSplitLate(true);
		restrictionTable.setSplitRows(true);*/
		restrictionTable.setLockedWidth(true);
		com.itextpdf.text.Font restrictionFont =  FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL,BaseColor.BLACK);
		int count = 0;
		//Phrase para = new Phrase();
		String txt = ""; 
		Paragraph para = new Paragraph();
		if(seatInteriorList.get(0).getPulldownText()!= null &&
				!seatInteriorList.get(0).getPulldownText().replace("\n", "").replace("null", "").trim().equals("") )
		{
			txt = seatInteriorList.get(0).getPulldownText().replace("null\n\n", "")+"\n";
		}

		for (Iterator iterator = restrictionList.iterator(); iterator.hasNext();) {
			ColorRestrictionBean colorRestrictionBean = (ColorRestrictionBean) iterator
					.next();
			count++;

			txt += count+" - "+colorRestrictionBean.getRestriction().trim()+"\n \n";
		}
		para.add(new Phrase(txt, restrictionFont));
		PdfPCell restcell = new PdfPCell(para);
		restrictionTable.addCell(restcell);

		table1.getDefaultCell().setPadding(0);
		table3.getDefaultCell().setPadding(0);
		if(table3.getRows().size()>=10)
		{
			table3.keepRowsTogether(5, table3.getRows().size());
			//	table3.setBreakPoints(0);
		}
		table.addCell(table1);
		table.addCell(table3);
		table.addCell(restrictionTable);

		return table;
	}






	private static void insertCellWithRestriction(PdfPTable table,String isNew, String availableCodeName,
			String restriction, int align, int i, Font superScriptfont, Font basefont) {
		
		Paragraph para = new Paragraph();
		para.add(new Phrase(availableCodeName, basefont));
		para.add(new Phrase(restriction, superScriptfont));
		PdfPCell cell = new PdfPCell(para);
		cell.setHorizontalAlignment(align);
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		//in case there is no text and you wan to create an empty row
		if(availableCodeName.trim().equalsIgnoreCase("")){
			cell.setMinimumHeight(10f);
		}
		//add the call to the table
		table.addCell(cell);
	}

	public static String restrictionFlag(int currentRestrictionID){
		String unicodeFlag="";
		boolean isRestrictionExist = false;
		if(currentRestrictionID!=10){
			int restrictionPosition=1;			
			for (Iterator iterator = restrictionList.iterator(); iterator
					.hasNext();) {

				Integer restictionId = (Integer) iterator.next();
				if(currentRestrictionID==restictionId){
					isRestrictionExist = true;
					break;
				}
				restrictionPosition++;

			}

			if(unicodeProperties.getProperty(String.valueOf(restrictionPosition))!=null && !unicodeProperties.getProperty(String.valueOf(restrictionPosition)).isEmpty())
			{
				unicodeFlag = unicodeProperties.getProperty(String.valueOf(restrictionPosition));
			}

		}
		if(!isRestrictionExist) {
			unicodeFlag="";
		}
		return unicodeFlag;


	}
	public static String restrictionFlag_package(int currentRestrictionID){
		String unicodeFlag="";
		boolean isRestrictionExist = false;
		if(currentRestrictionID!=20){
			int restrictionPosition=1;

			for (ColorRestrictionBean colorRestrictionBean : restrictionList) {


				if(currentRestrictionID==colorRestrictionBean.getRestrictionID().intValueExact()){
					isRestrictionExist = true;
					break;
					
				}
				restrictionPosition++;
			}


			if(unicodeProperties.getProperty(String.valueOf(restrictionPosition))!=null && !unicodeProperties.getProperty(String.valueOf(restrictionPosition)).isEmpty())
			{
				unicodeFlag = unicodeProperties.getProperty(String.valueOf(restrictionPosition));
			}

		}
		if(!isRestrictionExist) {
			unicodeFlag="";
		}
		return unicodeFlag;
	}


	public void loadRestriction(){

		unicodeProperties = new Properties();
		inputStream = null;

		try {
			inputStream = new FileInputStream("./Unicode.properties");
			unicodeProperties.load(inputStream);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}







	/**
	 * Creates a table; widths are set in the constructor.
	 * @return a PdfPTable
	 * @throws DocumentException
	 */
	public static PdfPTable createTable3() throws DocumentException {
		PdfPTable table = new PdfPTable(new float[]{ 2, 1, 1 });
		table.setWidthPercentage(55.067f);
		PdfPCell cell;
		cell = new PdfPCell(new Phrase("Table 3"));
		cell.setColspan(3);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Cell with rowspan 2"));
		cell.setRowspan(2);
		table.addCell(cell);
		table.addCell("row 1; cell 1");
		table.addCell("row 1; cell 2");
		table.addCell("row 2; cell 1");
		table.addCell("row 2; cell 2");
		return table;
	}

	/**
	 * Creates a table; widths are set with special setWidthPercentage() method.
	 * @return a PdfPTable
	 * @throws DocumentException
	 */
	public static PdfPTable createTable4() throws DocumentException {
		PdfPTable table = new PdfPTable(3);
		Rectangle rect = new Rectangle(523, 770);
		table.setWidthPercentage(new float[]{ 144, 72, 72 }, rect);
		PdfPCell cell;
		cell = new PdfPCell(new Phrase("Table 4"));
		cell.setColspan(3);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Cell with rowspan 2"));
		cell.setRowspan(2);
		table.addCell(cell);
		table.addCell("row 1; cell 1");
		table.addCell("row 1; cell 2");
		table.addCell("row 2; cell 1");
		table.addCell("row 2; cell 2");
		return table;
	}

	public String getLocation()
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String location = null;
		if(eProperties.getProperty("pdfDefaultLocation")!=null && !eProperties.getProperty("pdfDefaultLocation").isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			location = eProperties.getProperty("pdfDefaultLocation");
		}
		return location;
	}

	/**
	 * Creates a table; widths are set with setTotalWidth().
	 * @return a PdfPTable
	 * @throws DocumentException
	 */
	public static PdfPTable createTable5() throws DocumentException {
		PdfPTable table = new PdfPTable(3);
		table.setTotalWidth(new float[]{ 144, 72, 72 });
		table.setLockedWidth(true);
		PdfPCell cell;
		cell = new PdfPCell(new Phrase("Table 5"));
		cell.setColspan(3);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Cell with rowspan 2"));
		cell.setRowspan(2);
		table.addCell(cell);
		table.addCell("row 1; cell 1");
		table.addCell("row 1; cell 2");
		table.addCell("row 2; cell 1");
		table.addCell("row 2; cell 2");
		return table;
	}

	public void startRadioPDFGeneration(int id) {
		// TODO Auto-generated method stub

	}


	public static void insertCell(PdfPTable table,String isNew, String text, int align, int colspan, Font font){

		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font redFont1 =  FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		pdfType =2;
		if(pdfType==VehicleConstant.PRINTBOOKS || pdfType==VehicleConstant.VEHICLE_PRINT )
		{
			redFont1 = FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.RED);

		}

		if(isNew!=null){
			para.add(new Phrase(isNew, redFont1));
		}
		para.add(new Phrase(text, font));

		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(3.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		//in case there is no text and you wan to create an empty row
		if(text.trim().equalsIgnoreCase("")){
			cell.setMinimumHeight(10f);
		}
		//add the call to the table
		table.addCell(cell);
	}


	public class HeaderAndFooter extends PdfPageEventHelper {

		private String name = "";
		PdfTemplate total;

		protected Phrase footer;
		protected Phrase header;

		/*
		 * Font for header and footer part.
		 */
		com.itextpdf.text.Font headerFont =  FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD,BaseColor.BLACK);
		/*private static Font headerFont = new Font(Font.COURIER, 9,
	            Font.NORMAL,Color.blue);

	    private static Font footerFont = new Font(Font.TIMES_ROMAN, 9,
	            Font.BOLD,Color.blue);*/


		/*
		 * constructor
		 */
		public HeaderAndFooter(String name) {
			super();
			this.name = name;
			header = new Phrase("***** Header *****");
			footer = new Phrase("**** Footer ****");
		}

		@Override
		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
			// TODO Auto-generated method stub
			super.onOpenDocument(writer, document);
		}
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			if(!seatInteriorList.isEmpty()){
				PdfContentByte cb = writer.getDirectContent();

				//header content
				String headerContent = "Name: " +name;

				//header content
				String footerContent = headerContent;
				/*
				 * Header
				 */
				/*	ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(headerContent,headerFont), 
	                document.leftMargin(), document.top() -30, 0);*/

				/*
				 * Foooter
				 */
				DateFormat defDate=null;
				PropertyHelper propertyHelper = new PropertyHelper();
				if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2){
					defDate  = DateFormat.getDateInstance(DateFormat.LONG,Locale.FRANCE);

					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_FR")!=null && propertyHelper.getProperty("ForcedateOnPDF_FR").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_FR");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);

					if(seatInteriorList.get(0).getIsLandscape()!=null && seatInteriorList.get(0).getIsLandscape().intValueExact()==1){
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+350 , document.bottom()-45, 0);
					}
					else{
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Publi� " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+250 , document.bottom()-45, 0);
					}


				}
				else{
					defDate  = DateFormat.getDateInstance(DateFormat.LONG);
					String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
					if(propertyHelper.getProperty("ForcedateOnPDF_EN")!=null && propertyHelper.getProperty("ForcedateOnPDF_EN").trim()!="") {
						currDate = propertyHelper.getProperty("ForcedateOnPDF_EN");
					}
					com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.BLACK);

					if(seatInteriorList.get(0).getIsLandscape()!=null && seatInteriorList.get(0).getIsLandscape().intValueExact()==1){
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.bottom() , document.left()+250,-90);
					}
					else{
						ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
								writer.getCurrentPageNumber()),boldContentFont), 
								document.left()+250 , document.bottom()-45, 0);
					}

				}

				PdfPTable table = new PdfPTable(3);
				table.getDefaultCell().setBorder(0);
				//table.getDefaultCell().setPaddingBottom(25);

				PdfPTable table1 = null;

				table.setTotalWidth(tableWidth);
				try {
					table.setWidths(new int[] {150,195,135});
				} catch (DocumentException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				table.setLockedWidth(true);
				PdfPCell cell;

				com.itextpdf.text.Font tableHeader =  FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD,BaseColor.WHITE);

				//Paragraph p1 = new Paragraph(vehicleItemsXML2.get(0).getVehicleName(),tableHeader);
				//Paragraph p1 = new Paragraph(vehicleItemsXML.get(0).getVehicleYear() +" "+ vehicleItemsXML.get(0).getDivisionName() +" "+ vehicleItemsXML.get(0).getVehicleName(),tableHeader);
				//p1.setAlignment(Element.ALIGN_LEFT);
				cell = new PdfPCell(new Phrase(seatInteriorList.get(0).getVehicleYear() +" "+ seatInteriorList.get(0).getDivisionName() +" "+ seatInteriorList.get(0).getVehicleName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);

				//	cell.addElement(p1);
				table.addCell(cell);

				//Paragraph p2 = new Paragraph("RPO CODES",tableHeader);
				/*if(pageLabelCount.size()>1){
					cell = new PdfPCell(new Phrase("STANDARD EQUIPMENT" + " - " +pageLabel,tableHeader));
				}*/
				//else

				if(seatInteriorList.get(0).getPageLabel()== null )
				{
					seatInteriorList.get(0).setPageLabel("");
				}
				else
				{
					//	seatInteriorList.get(0).setPageLabel(" - "+seatInteriorList.get(0).getPageLabel());
				}
				if(pageNum<=1)
				{
					seatInteriorList.get(0).setPageLabel("");
				}
				cell = new PdfPCell(new Phrase("COLOR AND TRIM " +seatInteriorList.get(0).getPageLabel() ,tableHeader));
				if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getRegionID().intValueExact()==14)
				{
					cell = new PdfPCell(new Phrase("COLOUR AND TRIM "+seatInteriorList.get(0).getPageLabel(),tableHeader));
				}
				if(seatInteriorList.get(0).getLocaleCode()!=null && seatInteriorList.get(0).getLocaleCode().intValueExact()==2)
				{
					cell = new PdfPCell(new Phrase("COULEURS ET GARNITURES "+seatInteriorList.get(0).getPageLabel(),tableHeader));
				}
				cell.setMinimumHeight(15f);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p2.setAlignment(Element.ALIGN_CENTER);

				//cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				//cell.setPaddingLeft(2f);
				//cell.addElement(p2);

				table.addCell(cell);

				//	Paragraph p3 = new Paragraph(vehicleItemsXML.get(0).getRegionName(),tableHeader);
				cell = new PdfPCell(new Phrase(seatInteriorList.get(0).getRegionName(),tableHeader));
				cell.setMinimumHeight(15f);
				cell.setBackgroundColor(BaseColor.BLACK);
				//	p3.setAlignment(Element.ALIGN_RIGHT);
				cell.setVerticalAlignment(Element.ALIGN_CENTER);
				cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				//cell.addElement(p3);
				//	cell.setPaddingBottom(0.3f);
				//	cell.setPaddingTop(0.3f);
				cell.setPaddingLeft(2f);

				table.addCell(cell);

				//	table.addCell(table2);
				if(seatInteriorList.get(0).getIsLandscape()!=null && seatInteriorList.get(0).getIsLandscape().intValueExact()==1){
					table.writeSelectedRows(0, -1,110, 550, writer.getDirectContent());
				}
				else{
					table.writeSelectedRows(0, -1, 70, 750, writer.getDirectContent());
				}
			}
			else {
				PdfContentByte cb = writer.getDirectContent();
				DateFormat defDate=null;
				defDate  = DateFormat.getDateInstance(DateFormat.LONG);

				String currDate = CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, defDate.format(new Date()));
				com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
				ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase(String.format("Published " + currDate +" Page %d ", 
						writer.getCurrentPageNumber()),headerFont), 
						document.left()+250 , document.bottom()-45, 0);

			}

		}




	}
	public static void insertCustomCell(PdfPTable table,String isNew, Phrase p1, int align, int colspan, Font font){



		//create a new cell with the specified Text and Font
		//PdfPCell cell = new PdfPCell(new Phrase(text,font));
		com.itextpdf.text.Font boldContentFont =  FontFactory.getFont(FontFactory.HELVETICA, 8, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font boldContentFont1 =  FontFactory.getFont(FontFactory.HELVETICA,7, Font.BOLD,BaseColor.BLACK);
		com.itextpdf.text.Font redFont1 =  FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.BLACK);
		Paragraph para = new Paragraph();
		pdfType =2;
		if(pdfType==VehicleConstant.PRINTBOOKS){

			redFont1 = FontFactory.getFont(FontFactory.HELVETICA,8, Font.NORMAL,BaseColor.RED);

		}

		if(isNew!=null){
			para.add(new Phrase(isNew, redFont1));
		}
		para.add(p1);
		PdfPCell cell = new PdfPCell(para);
		//set the cell alignment
		cell.setHorizontalAlignment(align);
		//set the cell column span in case you want to merge two or more cells
		cell.setColspan(0);
		//cell.setBackgroundColor(BaseColor.RED);
		cell.setPaddingBottom(3.5f);
		cell.setPaddingTop(3f);
		cell.setPaddingLeft(2f);
		cell.setPaddingRight(0.5f);
		cell.setLeading(2f, 1f);
		cell.setMinimumHeight(10f);
		cell.setBorderWidth(0.5f);
		//in case there is no text and you wan to create an empty row

		//add the call to the table
		table.addCell(cell);

	}

	public void startColorAndTrimPDFGeneration(List<ArrayList<Object>> vehicleItemsXML,int pdfType) {
		try {
			new ItextPDFGenerator().createPdf(vehicleItemsXML,null,null,pdfType );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void startColorAndTrimPDFGeneration(List<ArrayList<Object>> vehicleItemsXML,
			Document document, PdfWriter writer,int pdfType) {
		isPOG =true;
		try {
			new ItextPDFGenerator().createPdf(vehicleItemsXML,document,writer,pdfType );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
