package com.dci.extrafunc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyHelper {
	
	public String getProperty(String propertyName)
	{
		Properties eProperties = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("EOG.properties");
			eProperties.load(input);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		String propertyValue = null;
		if(eProperties.getProperty(propertyName)!=null && !eProperties.getProperty(propertyName).isEmpty() && eProperties.getProperty("singlevehicleId")!=" ")
		{
			propertyValue = eProperties.getProperty(propertyName);
		}
		return propertyValue;
	}
}
