package com.dci.extrafunc;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlRootElement(name ="Category")
@XmlType(name ="", propOrder = {"modelYear","mmc","packageCode","rpoName","cfdWrapper",})
public class CategoryBuilder {
	String modelYear;
	String mmc;
	String packageCode;
	String categoryName;

	CFDWrapper cfdWrapper;
	
	public CFDWrapper getCfdWrapper() {
		return cfdWrapper;
	}	
	@XmlElement(name="Content")
	public void setCfdWrapper(CFDWrapper cfdWrapper2) {
		this.cfdWrapper = cfdWrapper2;
	}

	@XmlAttribute
	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getModelYear() {
		return modelYear;
	}

	public void setModelYear(String modelYear) {
		this.modelYear = modelYear;
	}

	public String getMmc() {
		return mmc;
	}

	public void setMmc(String mmc) {
		this.mmc = mmc;
	}

	public String getPackageCode() {
		return packageCode;
	}

	public void setPackageCode(String packageCode) {
		this.packageCode = packageCode;
	}
	String rpoName;
	public String getRpoName() {
		return rpoName;
	}

	@XmlElement(name="RpoName")
	public void setRpoName(String rpoName) {
		this.rpoName = rpoName;
	}



}
