package com.dci.extrafunc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class JAXBExample {
	public static void main(String[] args) {

		Customer customer = new Customer();
		Customer customer1 = new Customer();
		List <Customer> customerList = new ArrayList<Customer>();
		customer.setId(100);
		customer.setName("mky3ong");
		customer.setAge(29);
		customerList.add(customer);
		customer1.setId(200);
		customer1.setName("mkyo3ng2");
		customer1.setAge(239);
		customerList.add(customer1);
		
		


		try {
		
			FileWriter fileWriter = new FileWriter("C:\\TestingXMLRender.xml",true);
			
			JAXBContext jaxbContext = JAXBContext.newInstance(CFDXML.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			jaxbMarshaller.marshal(customer, fileWriter);			
			jaxbMarshaller.marshal(customer, System.out);
			
			jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
			jaxbMarshaller.marshal(customer1, fileWriter);			
			jaxbMarshaller.marshal(customer1, System.out);
			

		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}
}