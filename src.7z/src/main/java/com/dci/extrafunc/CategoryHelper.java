package com.dci.extrafunc;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="categoryHelp")


public class CategoryHelper {
	
	CategoryBuilder TempList;

	public CategoryBuilder getTempList() {
		return TempList;
	}

	 // @XmlElementWrapper(name = "trackList")
	 //   @XmlElement(name = "track")
	public void setTempList(CategoryBuilder categoryBuilder) {
		TempList = categoryBuilder;
	}
	
	


}