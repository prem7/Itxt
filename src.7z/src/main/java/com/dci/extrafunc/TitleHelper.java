package com.dci.extrafunc;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


@XmlRootElement(name="Title")
public class TitleHelper {
	String originalText;
	String TranslatedText;
	@XmlJavaTypeAdapter(CDATAAdapter.class)
	public String getOriginalText() {
		return originalText;
	}
	public void setOriginalText(String originalText) {
		this.originalText = originalText;
	}
	@XmlJavaTypeAdapter(CDATAAdapter.class)
	public String getTranslatedText() {
		return TranslatedText;
	}
	public void setTranslatedText(String translatedText) {
		TranslatedText = translatedText;
	}



}
