package com.dci.extrafunc;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
@XmlType(name ="", propOrder = {"titleHelpers","descHelpers"})
public class CFDWrapper {
	TitleHelper titleHelpers1;
	DescHelper descHelpers;
	
	public TitleHelper getTitleHelpers() {
		return titleHelpers1;
	}
	
	@XmlElement(name="Title")
	public void setTitleHelpers(TitleHelper titleHelper) {
		this.titleHelpers1 = titleHelper;
	}
	
	public DescHelper getDescHelpers() {
		return descHelpers;
	}
	@XmlElement(name="Description")	
	public void setDescHelpers(DescHelper descHelper) {
		this.descHelpers = descHelper;
	}
	

}
