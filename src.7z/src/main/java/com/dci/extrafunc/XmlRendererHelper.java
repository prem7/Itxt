/* package com.dci.extrafunc;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import com.sun.xml.txw2.output.IndentingXMLStreamWriter;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dci.general.utilities.UtilityDAO;
import com.sun.xml.internal.bind.marshaller.CharacterEscapeHandler;

public class XmlRendererHelper {

	public static void main (String args[]){

		long startSystemTime = System.currentTimeMillis();
		System.out.println("Starting program");
		//log.info("Starting program");
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		startXMlRendering(context);
		context.close();
		System.err.println("TOTAL TIME TAKE "+((System.currentTimeMillis()-startSystemTime)));


	}

	private static void startXMlRendering(ApplicationContext context) {

		UtilityDAO utilityDAO = (UtilityDAO)context.getBean("UtilityDAO");
		createXml(utilityDAO.startXMLRendering("18785"));
		
	}

	private static void createXml(List<CategoryBuilder> element_List) {
		//CFDXML cfdTemp = new CFDXML();
		CFDOriginalXML cfdHelp = new CFDOriginalXML();
		BufferedWriter writer = null;
		File selectedFile = new File("C:\\TestingXMLRender.xml");
		
		cfdHelp.setCategoryHelper(element_List);
		/*try {
			writer = new BufferedWriter(new FileWriter(selectedFile));

			JAXBContext jaxbContext = JAXBContext.newInstance(CFDOriginalXML.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			jaxbMarshaller.setProperty(CharacterEscapeHandler.class.getName(),
	                new XmlCharacterHandler());
			cfdHelp.setCategoryHelper(element_List);
			jaxbMarshaller.marshal(cfdHelp, selectedFile);
			jaxbMarshaller.marshal(cfdHelp, System.out);
			
		jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);


		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		marshaller(cfdHelp,selectedFile);


	}
	
	
	public static void marshaller(Object object, File file) {
		try {
			JAXBContext jc = JAXBContext.newInstance(CFDOriginalXML.class);
			Marshaller m = jc.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			//handling CDATA - is described in adapter section
			XMLOutputFactory xof = XMLOutputFactory.newInstance();
			XMLStreamWriter streamWriter = new CDataXMLStreamWriter(
					new IndentingXMLStreamWriter(
							xof.createXMLStreamWriter(new FileWriter(file,true))));
			
			m.marshal(object, streamWriter);			
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	  private static XMLSerializer getXMLSerializer() {
	        // configure an OutputFormat to handle CDATA
	        OutputFormat of = new OutputFormat();

	        // specify which of your elements you want to be handled as CDATA.
	        // The use of the '^' between the namespaceURI and the localname
	        // seems to be an implementation detail of the xerces code.
	        // When processing xml that doesn't use namespaces, simply omit the
	        // namespace prefix as shown in the third CDataElement below.
	        of.setCDataElements(
	            new String[] { "ns1^foo",   // <ns1:foo>
	                   "ns2^bar",   // <ns2:bar>
	                   "^baz" });   // <baz>

	        // set any other options you'd like
	        of.setPreserveSpace(true);
	        of.setIndenting(true);

	        // create the serializer
	        XMLSerializer serializer = new XMLSerializer(of);
	        serializer.setOutputByteStream(System.out);

	        return serializer;
	    }
}
 */