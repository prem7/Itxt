package com.dci.extrafunc;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;



@XmlRootElement(name="Description")
public class DescHelper {
	@XmlJavaTypeAdapter(CDATAAdapter.class)
	public String getOriginalText() {
		return originalText;
	}
	@XmlJavaTypeAdapter(CDATAAdapter.class)
	public String getTranslatedText() {
		return TranslatedText;
	}

	String originalText;
	String TranslatedText;
	

	@XmlElement
	public void setOriginalText(String originalText) {
		this.originalText = originalText;
	}
	
	@XmlElement
	public void setTranslatedText(String translatedText) {
		TranslatedText = translatedText;
	}
	
	

}
