//package com.dci.extrafunc;
//
//import java.io.File;
//import java.io.FileWriter;
//import java.util.Scanner;
//
//public class Scan {
//	
//	public static void main(String args[]) {
//		String from= "C:\\TestingXMLRender2.xml";
//	 //   String to = "C:\\TestingXMLRender3.xml"'
//		File f = new File(from);
//	    File t = new File(to);
//	    try {
//	        Scanner s = new Scanner(f);
//	        FileWriter fw = new FileWriter(to);
//	        while (true) {
//	            if (s.hasNext()) {
//	                String a = s.next();
//	                if (a.contains("<") || a.contains(">") || a.contains("&")) {
//	                    a.replace("<", "&lt;,");
//	                    a.replace(">","&gt;,");
//	                    a.replace("&","amp;,");
//
//	                }
//	                fw.append(a);
//	            } else {
//	                break;
//	            }
//	        }
//	        fw.close();
//	        s.close();
//	    } catch (Exception e) {
//	        System.out.println(e);
//	    }
//	}
//}
