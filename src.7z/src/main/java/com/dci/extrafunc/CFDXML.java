package com.dci.extrafunc;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ConsumerFriendlyDescriptions")

public class CFDXML {

	String marketingDesc;
	String TranslatedText;
	
	String marketingTitle;
	String translatedMarketingTitle;
	
	public String getOriginalText() {
		return marketingDesc;
	}

	public String getTranslatedText() {
		return TranslatedText;
	}

	public String getMarketingDesc() {
		return marketingDesc;
	}
	@XmlElement
	public void setMarketingDesc(String marketingDesc) {
		this.marketingDesc = marketingDesc;
	}

	public String getMarketingTitle() {
		return marketingTitle;
	}
	
	@XmlElement
	public void setMarketingTitle(String marketingTitle) {
		this.marketingTitle = marketingTitle;
	}

	public String getTranslatedMarketingTitle() {
		return translatedMarketingTitle;
	}
	@XmlElement
	public void setTranslatedMarketingTitle(String translatedMarketingTitle) {
		this.translatedMarketingTitle = translatedMarketingTitle;
	}
	@XmlElement
	public void setTranslatedText(String translatedText) {
		TranslatedText = translatedText;
	}

/*	//@XmlElementWrapper(name = "stateList")
	@XmlElement
	public void setMarketingDescTitle(String originalText) {
		this.marketingDesc = originalText;
	}
	@XmlElement
	public void setTranslatedText(String translatedText) {
		TranslatedText = translatedText;
	}
	*/
	
	
}