package com.dci.extrafunc;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name ="ConsumerFriendlyDescriptions")

public class CFDOriginalXML {
	
	List<CategoryBuilder> categoryHelper;
	
	public List<CategoryBuilder> getCategoryHelper() {
		return categoryHelper;
	}
	@XmlElement(name ="Cateogory")
	public void setCategoryHelper(List<CategoryBuilder> element_List) {
		this.categoryHelper = element_List;
	}
	
	
	
}