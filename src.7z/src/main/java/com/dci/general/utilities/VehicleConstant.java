package com.dci.general.utilities;

public class VehicleConstant {
	
	public static final String TRANSMISSION = "Transmissions";
	
	public static final String TRANSMISSION_fr = "Boîtes de vitesses";
	
	public static final int SINGLERUN = 0;
 
	public static final int PRODUCTPORTFOLIO = 1;
	
	//RED FONT FOR "NEW!"
	public static final int PRINTBOOKS= 2; 

	/** WHEELS = 1
	 */
	public static final int WHEELS = 1;
	/** RADIOS = 2
	 */
	public static final int RADIOS = 2;
	/** MODELS = 3
	 */
	public static final int MODELS = 3;
	/** COLOR_AND_TRIM = 4
	 */
	public static final int COLOR_AND_TRIM = 4;
	/** PATTERN_ORDER = 5
	 */
	public static final int PATTERN_ORDER = 5;
	/** COLOR_TRIM = OrderingInfoConstants.COLOR_TRIM
	 */    
	public static final int COLOR_TRIM = 9;        
	/** ACCESSORIES = 6
	 */
	public static final int ACCESSORIES = 6;

	public static final int STD_EQUIPMENT= 7;

	public static final int PEG_STAIRSTEP =8;

	public static final int EQP_GROUPS =10;

	public static final int EQP_GROUPS_WITH_ADD=11;

	public static final int EXTERIOR = 12;

	public static final int INTERIOR = 13;

	public static final int MECHANICAL = 14;

	public static final int ENGINE_AXLE = 15;

	public static final int SEO_SHIPTHRU =16;
	
	public static final int ON_STAR_FLEET =17;
	
	public static final int DIMENSION =18;
	
	public static final int SPECS =19;
	
	public static final int TRAILERING_SPECS =20;
	
	public static final int RPO_CODES =21;
	
	public static final int DIST_UPDATE =22;
	
	public static final int VEHICLE_PRINT = 23;
	
	public static final int PEGSTAIRSTEP =26;
	
	public static final int NEWFEATURES_2018 =41;
	
	public static final int NEWFEATURES_2019 =42;
	
	public static final int ONSTAR = 29;
	
	public static final int TRAILERING = 8;
	
	public static final int SPECS_PDF = 9;
	
	public static final int DIM_PDF = 6;
	
	public static final int SEO_SHIP_PDF = 10;
	
	public static final int TRAILERING_SPECS_PDF =8;
	
	public static final int WHEELS_PDF = 1;
	/** RADIOS = 2
	 */
	public static final int RADIOS_PDF = 2;
	
	public static final int RPO_CODES_PDF =18;
	
	public static final int ENGINE_AXLE_PDF = 14;
	
	public static final int EQP_GROUPS_PDF = 11;
}
