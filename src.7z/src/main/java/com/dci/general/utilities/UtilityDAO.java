package com.dci.general.utilities;

import java.util.List;

import com.dci.extrafunc.CFDXML;
import com.dci.extrafunc.CategoryBuilder;

public interface UtilityDAO {

	public String[] getVehicleItemsXML(int lang);
	public boolean isDomestic(String vehicleID);
	public List<CategoryBuilder> startXMLRendering(String vehicleID);

}
